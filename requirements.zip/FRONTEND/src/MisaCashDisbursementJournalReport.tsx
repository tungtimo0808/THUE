import {CASH_PERIODS,cashPeriodDates,cashPeriodSubtitle} from "./cash-report-periods";
import {cashDateRange,cashDateValue,isCashDateInRange} from './cash-date';
import React, { useState, useMemo } from "react";
import {
  ChevronLeft,
  Printer,
  Download,
  Settings,
  HelpCircle,
  X,
  Search,
  RefreshCw,
  Mail,
  MessageCircle,
  ChevronDown,
  Filter,
  Columns,
  Calendar,
} from "lucide-react";

export interface CashDisbursementRow {
  account?: string;
  bookDate: string;
  voucherNo: string;
  voucherDate: string;
  description: string;
  credit111?: number;
  debitAcc141?: number;
  debitAcc2?: number;
  debitAcc3?: number;
  debitAcc4?: number;
  debitOtherAmount?: number;
  debitOtherAcc?: string;
}

export interface AccountOption {
  code: string;
  name: string;
}

const ACCOUNT_OPTIONS: AccountOption[] = [
  { code: "111", name: "Tiền mặt" },
  { code: "112", name: "Tiền gửi không kỳ hạn" },
  { code: "1121", name: "TGNH BIDV" },
];

const DEFAULT_ROWS: CashDisbursementRow[] = [
  {
    bookDate: "06/10/2026",
    voucherNo: "PC00001",
    voucherDate: "06/10/2026",
    description: "Chi tiền cho Nguyen Hoang Tung",
    credit111: 10000000,
    debitAcc141: 10000000,
  },
];

export interface MisaCashDisbursementJournalReportProps {
  initialAccount?: string;
  data?: CashDisbursementRow[];
  onBack: () => void;
  notify?: (msg: string) => void;
}

export default function MisaCashDisbursementJournalReport({
  initialAccount="111",
  onBack,
  notify,
  data=DEFAULT_ROWS,
}: MisaCashDisbursementJournalReportProps) {
  // Drawer Parameters State matching Screenshot 1
  const [isParamDrawerOpen, setIsParamDrawerOpen] = useState(false);
  const [reportPeriodPreset, setReportPeriodPreset] = useState("Tháng này");
  const [fromDate, setFromDate] = useState(()=>cashDateRange('Tháng này')![0]);
  const [toDate, setToDate] = useState(()=>cashDateRange('Tháng này')![1]);
  const [selectedAccount, setSelectedAccount] = useState(initialAccount);
  const [selectedBankAccount, setSelectedBankAccount] = useState("");
  const [mergeSameEntries, setMergeSameEntries] = useState(true);

  // Drawer draft state
  const [draftPeriodPreset, setDraftPeriodPreset] = useState("Tháng này");
  const [draftFromDate, setDraftFromDate] = useState(()=>cashDateRange('Tháng này')![0]);
  const [draftToDate, setDraftToDate] = useState(()=>cashDateRange('Tháng này')![1]);
  const [draftAccount, setDraftAccount] = useState(initialAccount);
  const [draftBankAccount, setDraftBankAccount] = useState("");
  const [draftMergeSameEntries, setDraftMergeSameEntries] = useState(true);
  const [isAccountDropdownOpen, setIsAccountDropdownOpen] = useState(false);

  // Search keyword inside report table
  const [searchKeyword, setSearchKeyword] = useState("");

  const handleOpenDrawer = () => {
    setDraftPeriodPreset(reportPeriodPreset);
    setDraftFromDate(fromDate);
    setDraftToDate(toDate);
    setDraftAccount(selectedAccount);
    setDraftBankAccount(selectedBankAccount);
    setDraftMergeSameEntries(mergeSameEntries);
    setIsAccountDropdownOpen(false);
    setIsParamDrawerOpen(true);
  };

  const handleApplyParams = () => {
    if(!Number.isFinite(cashDateValue(draftFromDate))||!Number.isFinite(cashDateValue(draftToDate))||cashDateValue(draftFromDate)>cashDateValue(draftToDate)){notify?.('Vui lòng nhập khoảng ngày hợp lệ theo DD/MM/YYYY.');return;}
    setReportPeriodPreset(draftPeriodPreset);
    setFromDate(draftFromDate);
    setToDate(draftToDate);
    setSelectedAccount(draftAccount);
    setSelectedBankAccount(draftBankAccount);
    setMergeSameEntries(draftMergeSameEntries);
    setIsParamDrawerOpen(false);
    notify?.("Đã cập nhật S03a2 - DN: Sổ nhật ký chi tiền.");
  };

  const handleResetParams = () => {
    setDraftPeriodPreset("Tháng này");
    setDraftFromDate(cashDateRange('Tháng này')![0]);
    setDraftToDate(cashDateRange('Tháng này')![1]);
    setDraftAccount(initialAccount);
    setDraftBankAccount("");
    setDraftMergeSameEntries(true);
    setIsAccountDropdownOpen(false);
  };

  const handlePresetChange = (preset: string) => {
    setDraftPeriodPreset(preset);
    const range=cashPeriodDates(preset);
    if(range){setDraftFromDate(range[0]);setDraftToDate(range[1]);}
  };

  // Subtitle period text matching Screenshot 2
  const periodSubtitle = useMemo(()=>cashPeriodSubtitle(fromDate,toDate),[fromDate,toDate]);

  // Filter rows
  const filteredRows = useMemo(() => {
    const periodRows=data.filter(r=>isCashDateInRange(r.bookDate,fromDate,toDate)&&(!r.account||r.account.startsWith(selectedAccount)));
    if (!searchKeyword.trim()) return periodRows;
    const kw = searchKeyword.toLowerCase();
    return periodRows.filter(
      (r) =>
        r.voucherNo.toLowerCase().includes(kw) ||
        r.description.toLowerCase().includes(kw)
    );
  }, [searchKeyword,fromDate,toDate,data,selectedAccount]);

  const totalCredit111 = useMemo(() => {
    return filteredRows.reduce((acc, r) => acc + (r.credit111 || 0), 0);
  }, [filteredRows]);

  const totalDebit141 = useMemo(() => {
    return filteredRows.reduce((acc, r) => acc + (r.debitAcc141 || 0), 0);
  }, [filteredRows]);

  const formatMoney = (val?: number) => {
    if (val === undefined || val === null || val === 0) return "";
    return val.toLocaleString("vi-VN");
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100%",
        width: "100%",
        background: "#ffffff",
        overflow: "hidden",
        fontFamily: "inherit",
      }}
    >
      {/* 1. Header Bar matching Screenshot 2 */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "10px 20px",
          background: "#ffffff",
          borderBottom: "1px solid #e2e8f0",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <button
            type="button"
            onClick={onBack}
            style={{
              background: "none",
              border: "none",
              color: "#334155",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: 4,
              borderRadius: 4,
            }}
            title="Quay lại danh mục báo cáo"
          >
            <ChevronLeft size={20} />
          </button>
          <h2
            style={{
              margin: 0,
              fontSize: 14.5,
              fontWeight: 700,
              color: "#0f172a",
            }}
          >
            S03a2 - DN: Sổ nhật ký chi tiền
          </h2>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <button
            type="button"
            style={{
              height: 32,
              padding: "0 12px",
              background: "#ffffff",
              border: "1px solid #cbd5e1",
              borderRadius: 4,
              fontSize: 12.5,
              fontWeight: 500,
              color: "#334155",
              cursor: "pointer",
            }}
            onClick={() => notify?.("Xem danh sách báo cáo đã lưu...")}
          >
            Danh sách báo cáo đã lưu
          </button>

          <button
            type="button"
            style={{
              height: 32,
              padding: "0 12px",
              background: "#ffffff",
              border: "1px solid #cbd5e1",
              borderRadius: 4,
              fontSize: 12.5,
              fontWeight: 500,
              color: "#334155",
              cursor: "pointer",
            }}
            onClick={() => notify?.("Đã lưu mẫu báo cáo thành công.")}
          >
            Lưu báo cáo
          </button>

          <button
            type="button"
            style={{
              height: 32,
              padding: "0 18px",
              background: "#00a862",
              border: "none",
              borderRadius: 4,
              fontSize: 13,
              fontWeight: 600,
              color: "#ffffff",
              cursor: "pointer",
              boxShadow: "0 1px 2px rgba(0,0,0,0.05)",
            }}
            onClick={handleOpenDrawer}
          >
            Chọn tham số
          </button>
        </div>
      </div>

      {/* 2. Action Toolbar matching Screenshot 2 & 3 */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "8px 20px",
          background: "#ffffff",
          borderBottom: "1px solid #e2e8f0",
        }}
      >
        {/* Left Toolbar Icons */}
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button
            type="button"
            style={{
              width: 28,
              height: 28,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              background: "#ffffff",
              border: "1px solid #cbd5e1",
              borderRadius: 4,
              color: "#64748b",
              cursor: "pointer",
            }}
            title="Bộ lọc"
            onClick={() => notify?.("Mở bộ lọc...")}
          >
            <Filter size={14} />
          </button>
          <button
            type="button"
            style={{
              width: 28,
              height: 28,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              background: "#ffffff",
              border: "1px solid #cbd5e1",
              borderRadius: 4,
              color: "#64748b",
              cursor: "pointer",
            }}
            title="Tùy chỉnh cột"
            onClick={() => notify?.("Tùy chỉnh hiển thị cột...")}
          >
            <Columns size={14} />
          </button>
        </div>

        {/* Right Toolbar Icons */}
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div
            style={{
              position: "relative",
              display: "flex",
              alignItems: "center",
            }}
          >
            <Search
              size={14}
              style={{
                position: "absolute",
                left: 10,
                color: "#94a3b8",
              }}
            />
            <input
              type="text"
              placeholder="Nhập từ khóa tìm kiếm"
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              style={{
                height: 30,
                width: 200,
                padding: "0 10px 0 30px",
                border: "1px solid #cbd5e1",
                borderRadius: 4,
                fontSize: 12.5,
                outline: "none",
                background: "#ffffff",
              }}
            />
          </div>

          <button
            type="button"
            style={{
              background: "none",
              border: "none",
              color: "#64748b",
              cursor: "pointer",
              padding: 4,
            }}
            title="Nạp lại"
            onClick={() => notify?.("Đã làm mới dữ liệu báo cáo.")}
          >
            <RefreshCw size={15} />
          </button>

          <button
            type="button"
            style={{
              background: "none",
              border: "none",
              color: "#64748b",
              cursor: "pointer",
              padding: 4,
            }}
            title="Gửi email"
            onClick={() => notify?.("Mở hộp thoại gửi email...")}
          >
            <Mail size={15} />
          </button>

          <button
            type="button"
            style={{
              background: "none",
              border: "none",
              color: "#64748b",
              cursor: "pointer",
              padding: 4,
            }}
            title="Phản hồi"
            onClick={() => notify?.("Mở phản hồi...")}
          >
            <MessageCircle size={15} />
          </button>

          <button
            type="button"
            style={{
              background: "none",
              border: "none",
              color: "#64748b",
              cursor: "pointer",
              padding: 4,
            }}
            title="In"
            onClick={() => window.print()}
          >
            <Printer size={15} />
          </button>

          <button
            type="button"
            style={{
              display: "flex",
              alignItems: "center",
              gap: 4,
              background: "#ffffff",
              border: "1px solid #cbd5e1",
              borderRadius: 4,
              padding: "3px 8px",
              color: "#334155",
              cursor: "pointer",
            }}
            title="Xuất khẩu Excel"
            onClick={() => notify?.("Đang xuất khẩu báo cáo ra Excel...")}
          >
            <span style={{ fontSize: 12, fontWeight: 700 }}>XLS</span>
            <ChevronDown size={13} color="#64748b" />
          </button>

          <button
            type="button"
            style={{
              background: "none",
              border: "none",
              color: "#64748b",
              cursor: "pointer",
              padding: 4,
            }}
            title="Tùy chỉnh"
            onClick={() => notify?.("Mở cài đặt...")}
          >
            <Settings size={15} />
          </button>
        </div>
      </div>

      {/* 3. Centered Report Title matching Screenshot 2 */}
      <div style={{ textAlign: "center", padding: "16px 20px 10px 20px" }}>
        <h3
          style={{
            margin: 0,
            fontSize: 14,
            fontWeight: 700,
            color: "#0f172a",
            letterSpacing: "0.2px",
          }}
        >
          SỔ NHẬT KÝ CHI TIỀN
        </h3>
        <div
          style={{
            fontSize: 12.5,
            fontStyle: "italic",
            color: "#475569",
            marginTop: 4,
          }}
        >
          {periodSubtitle}
        </div>
      </div>

      {/* 4. Table Area matching Screenshots 2 & 3 */}
      <div
        style={{
          flex: 1,
          overflow: "auto",
          padding: "0 20px 16px 20px",
          background: "#ffffff",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <div
          style={{
            border: "1px solid #cbd5e1",
            background: "#ffffff",
            boxShadow: "0 1px 3px rgba(0,0,0,0.05)",
            overflowX: "auto",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <table
            style={{
              width: "max-content",
              minWidth: "100%",
              borderCollapse: "collapse",
              fontSize: 12.5,
              fontFamily: "inherit",
            }}
          >
            <thead>
              {/* Header Row 1 */}
              <tr style={{ background: "#e2f0d9" }}>
                <th
                  rowSpan={2}
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "8px 12px",
                    textAlign: "center",
                    fontWeight: 700,
                    color: "#1e293b",
                    minWidth: 140,
                  }}
                >
                  Ngày, tháng ghi sổ
                </th>
                <th
                  colSpan={2}
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "6px 12px",
                    textAlign: "center",
                    fontWeight: 700,
                    color: "#1e293b",
                    minWidth: 200,
                  }}
                >
                  Chứng từ
                </th>
                <th
                  rowSpan={2}
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "8px 12px",
                    textAlign: "left",
                    fontWeight: 700,
                    color: "#1e293b",
                    minWidth: 260,
                  }}
                >
                  Diễn giải
                </th>
                <th
                  rowSpan={2}
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "8px 12px",
                    textAlign: "right",
                    fontWeight: 700,
                    color: "#1e293b",
                    minWidth: 140,
                  }}
                >
                  Ghi có TK {selectedAccount}
                </th>
                <th
                  colSpan={4}
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "6px 12px",
                    textAlign: "center",
                    fontWeight: 700,
                    color: "#1e293b",
                    minWidth: 440,
                  }}
                >
                  Ghi nợ các TK
                </th>
                <th
                  colSpan={2}
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "6px 12px",
                    textAlign: "center",
                    fontWeight: 700,
                    color: "#1e293b",
                    minWidth: 200,
                  }}
                >
                  Ghi nợ các TK khác
                </th>
              </tr>

              {/* Header Row 2 Subheaders matching Screenshots 2 & 3 */}
              <tr style={{ background: "#e2f0d9" }}>
                {/* Chứng từ subheaders */}
                <th
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "5px 8px",
                    textAlign: "center",
                    fontWeight: 700,
                    fontSize: 12,
                    minWidth: 100,
                  }}
                >
                  Số hiệu
                </th>
                <th
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "5px 8px",
                    textAlign: "center",
                    fontWeight: 700,
                    fontSize: 12,
                    minWidth: 100,
                  }}
                >
                  Ngày tháng
                </th>

                {/* Ghi nợ các TK subheaders matching Screenshot 2 */}
                <th
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "5px 8px",
                    textAlign: "right",
                    fontWeight: 700,
                    fontSize: 12,
                    minWidth: 110,
                  }}
                >
                  141
                </th>
                <th
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "5px 8px",
                    textAlign: "center",
                    fontWeight: 700,
                    fontSize: 12,
                    minWidth: 110,
                  }}
                >
                  .....
                </th>
                <th
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "5px 8px",
                    textAlign: "center",
                    fontWeight: 700,
                    fontSize: 12,
                    minWidth: 110,
                  }}
                >
                  .....
                </th>
                <th
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "5px 8px",
                    textAlign: "center",
                    fontWeight: 700,
                    fontSize: 12,
                    minWidth: 110,
                  }}
                >
                  .....
                </th>

                {/* Ghi nợ các TK khác subheaders matching Screenshot 3 */}
                <th
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "5px 8px",
                    textAlign: "center",
                    fontWeight: 700,
                    fontSize: 12,
                    minWidth: 120,
                  }}
                >
                  Số tiền
                </th>
                <th
                  style={{
                    border: "1px solid #cbd5e1",
                    padding: "5px 8px",
                    textAlign: "center",
                    fontWeight: 700,
                    fontSize: 12,
                    minWidth: 80,
                  }}
                >
                  Số hiệu
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredRows.map((row, idx) => (
                <tr
                  key={idx}
                  style={{
                    background: "#ffffff",
                    transition: "background 0.15s ease",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = "#f8fafc";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = "#ffffff";
                  }}
                >
                  <td
                    style={{
                      border: "1px solid #e2e8f0",
                      padding: "7px 10px",
                      textAlign: "center",
                    }}
                  >
                    {row.bookDate}
                  </td>
                  <td
                    style={{
                      border: "1px solid #e2e8f0",
                      padding: "7px 10px",
                      textAlign: "center",
                      color: "#0284c7",
                      cursor: "pointer",
                      fontWeight: 500,
                    }}
                    onClick={() => notify?.(`Mở chứng từ chi tiền ${row.voucherNo}`)}
                  >
                    {row.voucherNo}
                  </td>
                  <td
                    style={{
                      border: "1px solid #e2e8f0",
                      padding: "7px 10px",
                      textAlign: "center",
                    }}
                  >
                    {row.voucherDate}
                  </td>
                  <td
                    style={{
                      border: "1px solid #e2e8f0",
                      padding: "7px 12px",
                    }}
                  >
                    {row.description}
                  </td>
                  <td
                    style={{
                      border: "1px solid #e2e8f0",
                      padding: "7px 12px",
                      textAlign: "right",
                      fontWeight: 600,
                    }}
                  >
                    {formatMoney(row.credit111)}
                  </td>
                  <td
                    style={{
                      border: "1px solid #e2e8f0",
                      padding: "7px 12px",
                      textAlign: "right",
                      fontWeight: 600,
                    }}
                  >
                    {formatMoney(row.debitAcc141)}
                  </td>
                  <td
                    style={{
                      border: "1px solid #e2e8f0",
                      padding: "7px 12px",
                      textAlign: "right",
                    }}
                  >
                    {formatMoney(row.debitAcc2)}
                  </td>
                  <td
                    style={{
                      border: "1px solid #e2e8f0",
                      padding: "7px 12px",
                      textAlign: "right",
                    }}
                  >
                    {formatMoney(row.debitAcc3)}
                  </td>
                  <td
                    style={{
                      border: "1px solid #e2e8f0",
                      padding: "7px 12px",
                      textAlign: "right",
                    }}
                  >
                    {formatMoney(row.debitAcc4)}
                  </td>
                  <td
                    style={{
                      border: "1px solid #e2e8f0",
                      padding: "7px 12px",
                      textAlign: "right",
                    }}
                  >
                    {formatMoney(row.debitOtherAmount)}
                  </td>
                  <td
                    style={{
                      border: "1px solid #e2e8f0",
                      padding: "7px 8px",
                      textAlign: "center",
                    }}
                  >
                    {row.debitOtherAcc || ""}
                  </td>
                </tr>
              ))}

              {/* Total Row matching Screenshot 2 */}
              <tr style={{ background: "#f8fafc", fontWeight: 700 }}>
                <td
                  style={{
                    border: "1px solid #e2e8f0",
                    padding: "7px 10px",
                    textAlign: "center",
                  }}
                ></td>
                <td
                  style={{
                    border: "1px solid #e2e8f0",
                    padding: "7px 10px",
                    textAlign: "left",
                    fontWeight: 700,
                  }}
                >
                  Tổng cộng
                </td>
                <td
                  style={{
                    border: "1px solid #e2e8f0",
                    padding: "7px 10px",
                  }}
                ></td>
                <td
                  style={{
                    border: "1px solid #e2e8f0",
                    padding: "7px 12px",
                  }}
                ></td>
                <td
                  style={{
                    border: "1px solid #e2e8f0",
                    padding: "7px 12px",
                    textAlign: "right",
                    fontWeight: 700,
                  }}
                >
                  {formatMoney(totalCredit111)}
                </td>
                <td
                  style={{
                    border: "1px solid #e2e8f0",
                    padding: "7px 12px",
                    textAlign: "right",
                    fontWeight: 700,
                  }}
                >
                  {formatMoney(totalDebit141)}
                </td>
                <td
                  style={{
                    border: "1px solid #e2e8f0",
                    padding: "7px 12px",
                  }}
                ></td>
                <td
                  style={{
                    border: "1px solid #e2e8f0",
                    padding: "7px 12px",
                  }}
                ></td>
                <td
                  style={{
                    border: "1px solid #e2e8f0",
                    padding: "7px 12px",
                  }}
                ></td>
                <td
                  style={{
                    border: "1px solid #e2e8f0",
                    padding: "7px 12px",
                  }}
                ></td>
                <td
                  style={{
                    border: "1px solid #e2e8f0",
                    padding: "7px 8px",
                  }}
                ></td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Footer Bar matching Screenshot 2 */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "8px 4px",
            fontSize: 12.5,
            color: "#475569",
          }}
        >
          <div>Tổng số: {filteredRows.length}</div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span>Số dòng/trang</span>
              <select
                defaultValue="20"
                style={{
                  height: 26,
                  padding: "0 6px",
                  border: "1px solid #cbd5e1",
                  borderRadius: 3,
                  fontSize: 12,
                  outline: "none",
                  background: "#ffffff",
                }}
              >
                <option value="10">10</option>
                <option value="20">20</option>
                <option value="50">50</option>
                <option value="100">100</option>
              </select>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <button
                type="button"
                disabled
                style={{
                  border: "none",
                  background: "transparent",
                  color: "#94a3b8",
                  cursor: "not-allowed",
                  fontSize: 12,
                  padding: "2px 6px",
                }}
              >
                |&lt;
              </button>
              <button
                type="button"
                disabled
                style={{
                  border: "none",
                  background: "transparent",
                  color: "#94a3b8",
                  cursor: "not-allowed",
                  fontSize: 12,
                  padding: "2px 6px",
                }}
              >
                &lt;
              </button>
              <span
                style={{
                  padding: "2px 8px",
                  background: "#00a862",
                  color: "#ffffff",
                  borderRadius: 3,
                  fontSize: 12,
                  fontWeight: 600,
                }}
              >
                1
              </span>
              <button
                type="button"
                disabled
                style={{
                  border: "none",
                  background: "transparent",
                  color: "#94a3b8",
                  cursor: "not-allowed",
                  fontSize: 12,
                  padding: "2px 6px",
                }}
              >
                &gt;
              </button>
              <button
                type="button"
                disabled
                style={{
                  border: "none",
                  background: "transparent",
                  color: "#94a3b8",
                  cursor: "not-allowed",
                  fontSize: 12,
                  padding: "2px 6px",
                }}
              >
                &gt;|
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 5. Parameter Drawer matching Screenshot 1 */}
      {isParamDrawerOpen && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            zIndex: 9999,
            display: "flex",
            justifyContent: "flex-end",
            background: "rgba(0, 0, 0, 0.45)",
          }}
          onClick={() => setIsParamDrawerOpen(false)}
        >
          <div
            style={{
              width: 520,
              height: "100%",
              background: "#ffffff",
              boxShadow: "-4px 0 16px rgba(0,0,0,0.15)",
              display: "flex",
              flexDirection: "column",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "16px 20px",
                borderBottom: "1px solid #e2e8f0",
              }}
            >
              <h3
                style={{
                  margin: 0,
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#0f172a",
                }}
              >
                Chọn tham số
              </h3>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <HelpCircle
                  size={18}
                  color="#64748b"
                  style={{ cursor: "pointer" }}
                />
                <button
                  type="button"
                  onClick={() => setIsParamDrawerOpen(false)}
                  style={{
                    background: "none",
                    border: "none",
                    color: "#64748b",
                    cursor: "pointer",
                    padding: 2,
                  }}
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Body */}
            <div
              style={{
                flex: 1,
                overflowY: "auto",
                padding: "18px 20px",
                display: "flex",
                flexDirection: "column",
                gap: 16,
              }}
            >
              {/* Kỳ báo cáo * */}
              <div>
                <label
                  style={{
                    fontSize: 12.5,
                    color: "#475569",
                    display: "block",
                    marginBottom: 6,
                  }}
                >
                  Kỳ báo cáo <span style={{ color: "#dc2626" }}>*</span>
                </label>
                <select
                  value={draftPeriodPreset}
                  onChange={(e) => handlePresetChange(e.target.value)}
                  style={{
                    width: "100%",
                    height: 32,
                    padding: "0 10px",
                    border: "1px solid #00a862",
                    borderRadius: 4,
                    fontSize: 13,
                    background: "#ffffff",
                    outline: "none",
                  }}
                >
                  {CASH_PERIODS.map(period=><option key={period} value={period}>{period}</option>)}
                </select>
              </div>

              {/* Từ ngày - Đến ngày matching Screenshot 1 */}
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: 12,
                }}
              >
                <div>
                  <label
                    style={{
                      fontSize: 12.5,
                      color: "#475569",
                      display: "block",
                      marginBottom: 6,
                    }}
                  >
                    Từ ngày
                  </label>
                  <div style={{ position: "relative" }}>
                    <input
                      type="text"
                      value={draftFromDate}
                      onChange={(e) => setDraftFromDate(e.target.value)}
                      style={{
                        width: "100%",
                        height: 32,
                        padding: "0 30px 0 10px",
                        border: "1px solid #cbd5e1",
                        borderRadius: 4,
                        fontSize: 13,
                        outline: "none",
                        background: "#ffffff",
                      }}
                    />
                    <Calendar
                      size={14}
                      style={{
                        position: "absolute",
                        right: 10,
                        top: 9,
                        color: "#94a3b8",
                      }}
                    />
                  </div>
                </div>

                <div>
                  <label
                    style={{
                      fontSize: 12.5,
                      color: "#475569",
                      display: "block",
                      marginBottom: 6,
                    }}
                  >
                    Đến ngày
                  </label>
                  <div style={{ position: "relative" }}>
                    <input
                      type="text"
                      value={draftToDate}
                      onChange={(e) => setDraftToDate(e.target.value)}
                      style={{
                        width: "100%",
                        height: 32,
                        padding: "0 30px 0 10px",
                        border: "1px solid #cbd5e1",
                        borderRadius: 4,
                        fontSize: 13,
                        outline: "none",
                        background: "#ffffff",
                      }}
                    />
                    <Calendar
                      size={14}
                      style={{
                        position: "absolute",
                        right: 10,
                        top: 9,
                        color: "#94a3b8",
                      }}
                    />
                  </div>
                </div>
              </div>

              {/* Tài khoản * & Tài khoản ngân hàng matching Screenshot 1 */}
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "1fr 1.8fr",
                  gap: 12,
                }}
              >
                {/* Tài khoản with dropdown */}
                <div style={{ position: "relative" }}>
                  <label
                    style={{
                      fontSize: 12.5,
                      color: "#475569",
                      display: "block",
                      marginBottom: 6,
                    }}
                  >
                    Tài khoản <span style={{ color: "#dc2626" }}>*</span>
                  </label>
                  <div
                    style={{
                      height: 32,
                      padding: "0 10px",
                      border: "1px solid #00a862",
                      borderRadius: 4,
                      fontSize: 13,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      cursor: "pointer",
                      background: "#ffffff",
                    }}
                    onClick={() => setIsAccountDropdownOpen((prev) => !prev)}
                  >
                    <span>{draftAccount}</span>
                    <ChevronDown size={14} color="#64748b" />
                  </div>

                  {/* Account Dropdown Table */}
                  {isAccountDropdownOpen && (
                    <div
                      style={{
                        position: "absolute",
                        top: 58,
                        left: 0,
                        width: 320,
                        background: "#ffffff",
                        boxShadow: "0 4px 14px rgba(0,0,0,0.15)",
                        borderRadius: 4,
                        border: "1px solid #cbd5e1",
                        zIndex: 100,
                        overflow: "hidden",
                      }}
                    >
                      <table
                        style={{
                          width: "100%",
                          borderCollapse: "collapse",
                          fontSize: 12.5,
                        }}
                      >
                        <thead>
                          <tr
                            style={{
                              background: "#f8fafc",
                              borderBottom: "1px solid #e2e8f0",
                            }}
                          >
                            <th
                              style={{
                                padding: "6px 10px",
                                textAlign: "left",
                                fontWeight: 700,
                                color: "#334155",
                                width: "40%",
                              }}
                            >
                              Số tài khoản
                            </th>
                            <th
                              style={{
                                padding: "6px 10px",
                                textAlign: "left",
                                fontWeight: 700,
                                color: "#334155",
                              }}
                            >
                              Tên tài khoản
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {ACCOUNT_OPTIONS.map((acc) => {
                            const isSelected = draftAccount === acc.code;
                            return (
                              <tr
                                key={acc.code}
                                style={{
                                  background: isSelected ? "#00a862" : "#ffffff",
                                  color: isSelected ? "#ffffff" : "#1e293b",
                                  cursor: "pointer",
                                  transition: "background 0.15s ease",
                                }}
                                onClick={() => {
                                  setDraftAccount(acc.code);
                                  setIsAccountDropdownOpen(false);
                                }}
                                onMouseEnter={(e) => {
                                  if (!isSelected)
                                    e.currentTarget.style.backgroundColor =
                                      "#f1f5f9";
                                }}
                                onMouseLeave={(e) => {
                                  if (!isSelected)
                                    e.currentTarget.style.backgroundColor =
                                      "#ffffff";
                                }}
                              >
                                <td
                                  style={{
                                    padding: "6px 10px",
                                    fontWeight: isSelected ? 700 : 400,
                                  }}
                                >
                                  {acc.code}
                                </td>
                                <td style={{ padding: "6px 10px" }}>
                                  {acc.name}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Tài khoản ngân hàng */}
                <div>
                  <label
                    style={{
                      fontSize: 12.5,
                      color: "#475569",
                      display: "block",
                      marginBottom: 6,
                    }}
                  >
                    Tài khoản ngân hàng
                  </label>
                  <select
                    value={draftBankAccount}
                    onChange={(e) => setDraftBankAccount(e.target.value)}
                    disabled={draftAccount === "111"}
                    style={{
                      width: "100%",
                      height: 32,
                      padding: "0 10px",
                      border: "1px solid #cbd5e1",
                      borderRadius: 4,
                      fontSize: 13,
                      background: draftAccount === "111" ? "#f8fafc" : "#ffffff",
                      color: draftAccount === "111" ? "#94a3b8" : "#1e293b",
                      outline: "none",
                      cursor: draftAccount === "111" ? "not-allowed" : "pointer",
                    }}
                  >
                    <option value="">(Tất cả)</option>
                    <option value="BIDV_01">BIDV - 1234567890</option>
                    <option value="VCB_01">Vietcombank - 0987654321</option>
                  </select>
                </div>
              </div>

              {/* Checkbox: Cộng gộp các bút toán giống nhau matching Screenshot 1 */}
              <div>
                <label
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    fontSize: 13,
                    color: "#1e293b",
                    cursor: "pointer",
                  }}
                >
                  <input
                    type="checkbox"
                    checked={draftMergeSameEntries}
                    onChange={(e) =>
                      setDraftMergeSameEntries(e.target.checked)
                    }
                    style={{ accentColor: "#00a862", width: 16, height: 16 }}
                  />
                  <span>Cộng gộp các bút toán giống nhau</span>
                </label>
              </div>
            </div>

            {/* Footer matching Screenshot 1 */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "12px 20px",
                borderTop: "1px solid #e2e8f0",
                background: "#f8fafc",
              }}
            >
              <button
                type="button"
                onClick={handleResetParams}
                style={{
                  height: 32,
                  padding: "0 14px",
                  background: "#ffffff",
                  border: "1px solid #cbd5e1",
                  borderRadius: 4,
                  fontSize: 13,
                  color: "#334155",
                  cursor: "pointer",
                }}
              >
                Xóa điều kiện
              </button>

              <div style={{ display: "flex", gap: 10 }}>
                <button
                  type="button"
                  onClick={() => setIsParamDrawerOpen(false)}
                  style={{
                    height: 32,
                    padding: "0 18px",
                    background: "#ffffff",
                    border: "1px solid #cbd5e1",
                    borderRadius: 4,
                    fontSize: 13,
                    color: "#334155",
                    cursor: "pointer",
                    fontWeight: 500,
                  }}
                >
                  Hủy
                </button>
                <button
                  type="button"
                  onClick={handleApplyParams}
                  style={{
                    height: 32,
                    padding: "0 20px",
                    background: "#00a862",
                    border: "none",
                    borderRadius: 4,
                    fontSize: 13,
                    color: "#ffffff",
                    cursor: "pointer",
                    fontWeight: 600,
                  }}
                >
                  Xem báo cáo
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
