import { test } from "node:test";
import assert from "node:assert/strict";
import {
  normalizeReportHeaders,
  reportColumns,
  canonicalReportName,
} from "../src/audited-report-schema.ts";
import {
  auditedPeriodRange,
  isAuditedParameters,
  validateAuditedParameters,
  initialAuditedParameters,
  taxMonthRange,
} from "../src/audited-report-parameters.ts";
test("monthly tax parameters produce a complete month and reject invalid months", () => {
  assert.deepEqual(taxMonthRange("2", "2024"), ["2024-02-01", "2024-02-29"]);
  assert.deepEqual(taxMonthRange("9", "2026"), ["2026-09-01", "2026-09-30"]);
  assert.equal(taxMonthRange("13", "2026"), null);
  assert.equal(taxMonthRange("0", "2026"), null);
});
test("point-in-time reports use the observed cutoff date instead of month end", () => {
  const definition = {
    name: "Tuổi nợ",
    category: "Bán hàng",
    viewer: "dynamic" as const,
    labels: ["Đến ngày"],
    headers: [],
    selectors: [],
    checkboxes: [],
    fields: [{ label: "Đến ngày", kind: "date", default: "08/10/2026" }],
  };
  assert.equal(
    initialAuditedParameters(definition).fields["Đến ngày"],
    "2026-10-08",
  );
});
test("required report fields block an incomplete application of filters", () => {
  const parameters = {
    fields: { "Tài khoản": "" },
    selected: {},
    checks: {},
    radio: "",
  };
  const definition = {
    name: "Giấy đề nghị thanh toán công nợ",
    category: "Bán hàng",
    viewer: "dynamic" as const,
    labels: ["Tài khoản"],
    headers: [],
    selectors: [],
    checkboxes: [],
    fields: [{ label: "Tài khoản", kind: "combo", required: true }],
  };
  assert.match(validateAuditedParameters(parameters, definition), /tài khoản/);
  assert.equal(
    validateAuditedParameters(
      { ...parameters, fields: { "Tài khoản": "131" } },
      definition,
    ),
    "",
  );
});

test("saved report parameters reject malformed browser storage", () => {
  const valid = {
    fields: { Năm: "2026" },
    selected: { "0": ["1"] },
    checks: { Total: true },
    radio: "",
  };
  assert.equal(isAuditedParameters(valid), true);
  assert.equal(isAuditedParameters({ ...valid, fields: null }), false);
  assert.equal(
    isAuditedParameters({ ...valid, selected: { "0": null } }),
    false,
  );
  assert.equal(
    isAuditedParameters({ ...valid, checks: { Total: "true" } }),
    false,
  );
});

test("fixed-column clones do not duplicate grouped report headers", () => {
  const headers = normalizeReportHeaders([
    [
      { text: "Tên khách hàng", colSpan: 1, rowSpan: 2 },
      { text: "Phát sinh", colSpan: 2, rowSpan: 1 },
    ],
    [
      { text: "Tên khách hàng", colSpan: 1, rowSpan: 1 },
      { text: "Nợ", colSpan: 1, rowSpan: 1 },
      { text: "Có", colSpan: 1, rowSpan: 1 },
    ],
  ]);
  assert.deepEqual(
    headers[1].map((cell) => cell.text),
    ["Nợ", "Có"],
  );
  assert.deepEqual(
    reportColumns(headers).map((column) => column.path),
    ["Tên khách hàng", "Phát sinh / Nợ", "Phát sinh / Có"],
  );
});

test("MISA periods handle week, semester and explicit quarter choices", () => {
  const today = new Date(2026, 9, 8);
  assert.deepEqual(auditedPeriodRange("Tuần này", today), [
    "2026-10-05",
    "2026-10-11",
  ]);
  assert.deepEqual(auditedPeriodRange("Đầu quý đến hiện tại", today), [
    "2026-10-01",
    "2026-10-08",
  ]);
  assert.deepEqual(auditedPeriodRange("Sáu tháng đầu năm", today), [
    "2026-01-01",
    "2026-06-30",
  ]);
  assert.deepEqual(auditedPeriodRange("Quý 2", today), [
    "2026-04-01",
    "2026-06-30",
  ]);
  assert.deepEqual(auditedPeriodRange("Tháng 2", new Date(2024, 9, 8)), [
    "2024-02-01",
    "2024-02-29",
  ]);
});

test("simple cloned headers collapse to a single row", () => {
  const headers = normalizeReportHeaders([
    [{ text: "Ngày chứng từ", colSpan: 1, rowSpan: 2 }],
    [{ text: "Ngày chứng từ", colSpan: 1, rowSpan: 1 }],
  ]);
  assert.equal(headers.length, 1);
  assert.equal(headers[0][0].rowSpan, 1);
});

test("legacy catalogue aliases resolve without deleting old names", () => {
  assert.equal(
    canonicalReportName("S35 - DN: Số chi tiết bán hàng"),
    canonicalReportName("S35-DN: Sổ chi tiết bán hàng"),
  );
  assert.equal(
    canonicalReportName("Chi tiết công nợ phải thu theo mặt hàng (tỉnh)"),
    canonicalReportName("Chi tiết công nợ phải thu theo mặt hàng (tĩnh)"),
  );
});

test("month/quarter report defaults use a month number instead of a month input value", () => {
  const definition = {
    name: "Đối chiếu thuế", category: "Thuế", viewer: "dynamic" as const,
    labels: ["Kỳ báo cáo", "Tháng", "Năm"], headers: [], selectors: [], checkboxes: [],
    fields: [{label:"Kỳ báo cáo",kind:"radio"}],
    radios: [{label:"Theo tháng",checked:true},{label:"Theo quý",checked:false}],
  };
  const params = initialAuditedParameters(definition);
  assert.equal(params.fields.Tháng, String(new Date().getMonth()+1));
  assert.equal(params.radio, "Theo tháng");
  assert.equal(validateAuditedParameters(params, definition), "");
});
