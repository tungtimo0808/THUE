import type { DirectoryTabDefinition } from "./misa-directory-definitions";
export default function DirectoryTabContent({
  tab,
  data,
  values,
  onChange,
}: {
  tab: string;
  data?: DirectoryTabDefinition;
  values: Record<string, string>;
  onChange: (key: string, value: string) => void;
}) {
  if (!data) return null;
  const readGrid = (key: string): Record<string, string>[] => {
    try {
      const value = JSON.parse(values[key] ?? (tab === "Tài khoản ngân hàng" ? "[{}]" : "[]"));
      return Array.isArray(value)
        ? value.filter(
            (row) => row && typeof row === "object" && !Array.isArray(row),
          )
        : [];
    } catch {
      return [];
    }
  };
  return (
    <section className="md-tab-content" aria-label={tab}>
      <div className="md-fields">
        {data.fields.map((field) => {
          const key = `${tab}:${field.label}`;
          return (
            <label key={key}>
              {field.label}{field.label==="Loại hợp đồng"&&<em>*</em>}
              {field.options ? <select value={values[key]||""} onChange={e=>onChange(key,e.target.value)}><option value="">{field.label === "Loại hợp đồng" ? "Chọn loại hợp đồng" : `Chọn ${field.label.toLowerCase()}`}</option>{field.options.map(option=><option key={option}>{option}</option>)}</select> : field.kind === "textarea" ? (
                <textarea
                  value={values[key] || ""}
                  onChange={(e) => onChange(key, e.target.value)}
                />
              ) : (
                <input
                  type={field.kind === "number" ? "number" : "text"}
                  step={field.kind === "number" ? (field.label === "Số người phụ thuộc" ? "1" : "any") : undefined}
                  min={field.kind === "number" ? "0" : undefined}
                  value={values[key] || ""}
                  onInput={(e) => onChange(key, e.currentTarget.value)}
                  onChange={(e) => onChange(key, e.target.value)}
                />
              )}
            </label>
          );
        })}
      </div>
      {data.headers.map((headers, index) => {
        const key = `${tab}:grid:${index}`,
          rows = readGrid(key);
        return (
          <div key={key} className="md-tab-grid">
            <table>
              <thead>
                <tr>
                  {headers.map((header) => (
                    <th key={header}>{header}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {!rows.length && tab.startsWith("Thông tin người phụ thuộc") && <tr><td colSpan={headers.length}>Không có người phụ thuộc</td></tr>}
                {rows.map((row, rowIndex) => (
                  <tr key={rowIndex}>
                    {headers.map((header) => (
                      <td key={header}>
                        <input
                          aria-label={`${header} dòng ${rowIndex + 1}`}
                          value={row[header] || ""}
                          onInput={(e) => {
                            const value = e.currentTarget.value;
                            onChange(
                              key,
                              JSON.stringify(
                                rows.map((old, i) =>
                                  i === rowIndex
                                    ? { ...old, [header]: value }
                                    : old,
                                ),
                              ),
                            );
                          }}
                          onChange={(e) => {
                            const value = e.target.value;
                            onChange(
                              key,
                              JSON.stringify(
                                rows.map((old, i) =>
                                  i === rowIndex
                                    ? { ...old, [header]: value }
                                    : old,
                                ),
                              ),
                            );
                          }}
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            <div>
              <button
                onClick={() => onChange(key, JSON.stringify([...rows, {}]))}
              >
                {tab.startsWith("Thông tin người phụ thuộc") ? "Thêm người phụ thuộc" : "Thêm dòng"}
              </button>
              <button
                disabled={!rows.length}
                onClick={() => onChange(key, "[]")}
              >
                {tab === "Tài khoản ngân hàng" || tab.startsWith("Thông tin người phụ thuộc") ? "Xóa tất cả" : "Xóa hết dòng"}
              </button>
            </div>
          </div>
        );
      })}
    </section>
  );
}
