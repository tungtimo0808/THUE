import { exportVisibleTable } from "./table-actions";
import MisaPaymentTermsWorkspace from "./MisaPaymentTermsWorkspace";
import {useNavigate,useSearchParams} from "react-router-dom";
import MisaReportCenterWorkspace from "./MisaReportCenterWorkspace";
import { useState, useRef, useEffect, useCallback } from "react";
import MisaApiDocumentStatus from "./MisaApiDocumentStatus";
import { apiDate, apiNumber, apiUnitName, useMisaApiLists, useMisaApiSave } from "./misa-api-lists";
import {
  saveGoodsPurchase, saveItem, saveMultiInvoicePurchase, savePurchaseContract, savePurchaseDiscount,
  savePurchaseReturn, saveServicePurchase, saveSupplierReconciliation, uninvoicedPurchases, createApiWriter,
} from "./misa-api-writes";
import { useApiSession } from "./ApiSession";
import { request } from "./live-api";
import {
  Search,
  RefreshCw,
  Sparkles,
  Plus,
  Building2,
  Package,
  FileCheck,
  CreditCard,
  FileText,
  SlidersHorizontal,
  ChevronDown,
  Filter,
  Printer,
  FileSpreadsheet,
  Columns3,
  ChevronLeft,
  ChevronRight,
  AlertCircle,
  Clock,
  RotateCw,
  Settings,
  MoreHorizontal,
  Banknote,
  ChevronUp,
  MapPin,
  Pencil,
  Trash2,
  HelpCircle,
  X,
  ShoppingCart,
  Coins,
  RotateCcw,
  Percent,
  ShieldCheck,
  Lightbulb,
} from "lucide-react";
import {
  PurchaseOrderModal,
  PurchaseContractModal,
  PurchaseVoucherModal,
  PurchaseReturnModal,
  PurchaseDiscountModal,
  ReconciliationPeriodModal,
  SupplierModal,
  ReceiveInvoiceSelectModal,
  PurchaseServiceModal,
  PurchaseMultiInvoiceModal,
  type UninvoicedVoucher,

  SAMPLE_SUPPLIERS,
  formatVND,
} from "./MisaPurchaseModals";
import {
  DebtOffsetModal,
  MultiDebtOffsetModal,
  UnOffsetModal,
  MultiUnOffsetModal,
  DebtClearingModal,
} from "./MisaPurchaseUtilityModals";
import { AIAssistantModal, SupplierPaymentModal } from "./MisaCashWorkspace";
import { MisaItemNatureDrawer } from "./MisaItemNatureDrawer";
import { MisaInventoryItemModal, type InventoryItemData } from "./MisaInventoryItemModal";
import "./misa-cash.css";

export default function MisaPurchaseWorkspace({
  company: _company = { id: "abc", name: "CÔNG TY TNHH THƯƠNG MẠI VÀ DỊCH VỤ ABC" },
  period: _period = "2026-12",
  tab = "process",
  href,
  notify,
}: {
  company?: { id: string; name: string };
  period?: string;
  tab?: string;
  href?: (path: string) => string;
  notify: (msg: string) => void;
}) {
  const { token } = useApiSession();
  const { rows: apiRows, connected: apiConnected, reload: reloadApi } = useMisaApiLists(_company.id, {
    suppliers: "/api/v1/master-data/parties/",
    items: "/api/v1/master-data/items/",
    units: "/api/v1/master-data/units-of-measure/",
    accounts: "/api/v1/general-ledger/accounts/",
    warehouses: "/api/v1/master-data/warehouses/",
    taxRates: "/api/v1/master-data/tax-rates/",
    orders: "/api/v1/purchases/purchase-orders/",
    contracts: "/api/v1/purchases/purchase-contracts/",
    vouchers: "/api/v1/purchases/goods-purchases/",
    serviceVouchers: "/api/v1/purchases/service-purchases/",
    returns: "/api/v1/purchases/purchase-returns/",
    discounts: "/api/v1/purchases/purchase-discounts/",
    invoices: "/api/v1/purchases/input-invoices/",
    payables: "/api/v1/accounts-payable/payables/",
    reconciliations: "/api/v1/accounts-payable/supplier-reconciliations/",
  }, notify);
  const apiSave = useMisaApiSave(_company.id, notify, reloadApi);
  /** Status cell of a row loaded from the backend: label plus its next workflow action. */
  const apiStatus = (path: string, key: string, id: string, fallback: string, canPost = true) => {
    const record = apiConnected ? apiRows[key]?.find((row) => row.id === id) : undefined;
    return record ? <MisaApiDocumentStatus path={path} record={record} companyId={_company.id}
      notify={notify} onChanged={reloadApi} canPost={canPost} /> : fallback;
  };
  const loadUninvoicedVouchers = useCallback(async () => {
    const rows = await uninvoicedPurchases(createApiWriter(_company.id, (path, init) => request(path, token, init)));
    return rows.map((row) => ({ ...row, postDate: apiDate(row.postDate), docDate: apiDate(row.docDate) }) as UninvoicedVoucher);
  }, [_company.id, token]);
  const [paymentTermsOpen,setPaymentTermsOpen]=useState(false);
  const navigate=useNavigate();
  const [purchaseParams]=useSearchParams();
  const openPurchaseReport=(name:string)=>{const base=href?.("/purchases/reports")||"/purchases/reports";navigate(`${base}${base.includes("?")?"&":"?"}report=${encodeURIComponent(name)}`);};
  // Modal states
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showContractModal, setShowContractModal] = useState(false);
  const [showVoucherModal, setShowVoucherModal] = useState(false);
  const [editingVoucher, setEditingVoucher] = useState<any>(null);
  const [showReturnModal, setShowReturnModal] = useState(false);
  const [showDiscountModal, setShowDiscountModal] = useState(false);
  const [showReconciliationModal, setShowReconciliationModal] = useState(false);
  const [showSupplierModal, setShowSupplierModal] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<any | null>(null);

  // Purchase utilities states (5 Tiện ích mua hàng MISA)
  const [showUtilityMenu, setShowUtilityMenu] = useState(false);
  const [showDebtOffsetModal, setShowDebtOffsetModal] = useState(false);
  const [showMultiDebtOffsetModal, setShowMultiDebtOffsetModal] = useState(false);
  const [showUnOffsetModal, setShowUnOffsetModal] = useState(false);
  const [showMultiUnOffsetModal, setShowMultiUnOffsetModal] = useState(false);
  const [showDebtClearingModal, setShowDebtClearingModal] = useState(false);
  const [suppliers, setSuppliers] = useState([
    {
      id: "ncc-01",
      code: "NCC00001",
      name: "Tran Thi Huong",
      address: "",
      debtAmount: 17000000,
      taxCode: "030178006908",
      invoiceRisk: "",
      refDoc: "",
      phone: "097775611",
      isInternal: false,
      isBranch: false,
      partnerType: "org" as const,
      isCustomer: false,
    },
  ]);
  const [selectedSupplierIds, setSelectedSupplierIds] = useState<string[]>([]);
  const [supplierSearchText, setSupplierSearchText] = useState("");
  const [showSupplierSummaryCards, setShowSupplierSummaryCards] = useState(true);
  const [showAddSupplierDropdown, setShowAddSupplierDropdown] = useState(false);
  const [activeSupplierMenuId, setActiveSupplierMenuId] = useState<string | null>(null);
  const [supplierRowsPerPage, setSupplierRowsPerPage] = useState(20);
  const [showSupplierPaymentModal, setShowSupplierPaymentModal] = useState(false);
  const [showAIModal, setShowAIModal] = useState(false);
  const [showReceiveInvoiceModal, setShowReceiveInvoiceModal] = useState(false);
  const [showServiceModal, setShowServiceModal] = useState(false);
  const [showMultiInvoiceModal, setShowMultiInvoiceModal] = useState(false);
  const [showAddPurchaseMenu, setShowAddPurchaseMenu] = useState(false);
  const [showNatureDrawer, setShowNatureDrawer] = useState(false);
  const [showItemModal, setShowItemModal] = useState(false);
  const [selectedNature, setSelectedNature] = useState<string>("Hàng hóa");
  const [editingItem, setEditingItem] = useState<InventoryItemData | null>(null);
  const [receiveInvoiceViewMode, setReceiveInvoiceViewMode] = useState<"empty_guide" | "list">("list");
  const [receivedInvoices, setReceivedInvoices] = useState([
    {
      id: "inv-01",
      receivedDate: "29/09/2026",
      invoiceNo: "0002810",
      invoiceSeries: "1C26TAA",
      invoiceDate: "29/09/2026",
      supplierName: "Công ty TNHH Thiết bị Công nghiệp Tân Phát",
      supplierTaxCode: "0102345678",
      voucherCode: "NK00001",
      subtotal: 21500000,
      vatAmount: 2150000,
      totalAmount: 23650000,
      status: "Đã nhận HĐ",
    },
    {
      id: "inv-02",
      receivedDate: "22/09/2026",
      invoiceNo: "0001452",
      invoiceSeries: "1C26TBB",
      invoiceDate: "22/09/2026",
      supplierName: "Công ty Cổ phần Thép Hòa Phát Hưng Yên",
      supplierTaxCode: "0900123456",
      voucherCode: "NK00002",
      subtotal: 80454545,
      vatAmount: 8045455,
      totalAmount: 88500000,
      status: "Đã nhận HĐ",
    },
  ]);
  const [selectedInvoiceIds, setSelectedInvoiceIds] = useState<string[]>([]);
  const [invoiceSearchText, setInvoiceSearchText] = useState("");

  // Biểu đồ (Chart Dashboard) states
  const [currencyUnit, setCurrencyUnit] = useState("Đồng");
  const [showCurrencyMenu, setShowCurrencyMenu] = useState(false);
  const [chartRefreshTime, setChartRefreshTime] = useState("11:32");
  const [chartPeriods, setChartPeriods] = useState<Record<string, string>>({
    orders: "Tháng này",
    contracts: "Tháng này",
    purchases: "Tháng này",
    debt: "Tháng này",
    buyValue: "Tháng này",
  });
  const [openPeriodMenu, setOpenPeriodMenu] = useState<string | null>(null);

  const handleRefreshChart = () => {
    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`;
    setChartRefreshTime(timeStr);
    notify(`Đã cập nhật số liệu biểu đồ mua hàng tính đến ${timeStr}.`);
  };

  // Flowchart dropdown menu and hover timer
  const [activeFlowchartMenu, setActiveFlowchartMenu] = useState<string | null>(null);
  const flowchartMenuTimer = useRef<number | null>(null);
  const [_voucherKindOption, setVoucherKindOption] = useState<"goods" | "service" | "multi">("goods");

  const handleFlowchartMouseEnter = (menu: string) => {
    if (flowchartMenuTimer.current) {
      clearTimeout(flowchartMenuTimer.current);
      flowchartMenuTimer.current = null;
    }
    setActiveFlowchartMenu(menu);
  };

  const handleFlowchartMouseLeave = () => {
    flowchartMenuTimer.current = window.setTimeout(() => {
      setActiveFlowchartMenu(null);
    }, 220);
  };

  // Filters
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRowId, setSelectedRowId] = useState<string | null>("po-01");

  // Sample data: Đơn mua hàng (Image 2)
  const [orders, setOrders] = useState([
    {
      id: "po-01",
      code: "ĐMH00001",
      date: "29/09/2026",
      deliveryDate: "05/10/2026",
      supplier: "Công ty TNHH Thiết bị Công nghiệp Tân Phát",
      amount: 38750000,
      status: "Chưa thực hiện",
      description: "Mua vật tư phục vụ dự án tháng 9/2026",
    },
    {
      id: "po-02",
      code: "ĐMH00002",
      date: "25/09/2026",
      deliveryDate: "30/09/2026",
      supplier: "Công ty Cổ phần Thép Hòa Phát Hưng Yên",
      amount: 145000000,
      status: "Đang thực hiện",
      description: "Đơn đặt hàng thép xây dựng lô 2",
    },
  ]);

  // Sample data: Hợp đồng mua (Image 3)
  const [contracts, setContracts] = useState([
    {
      id: "hd-01",
      code: "HĐM00001",
      date: "29/09/2026",
      supplier: "Công ty TNHH Thiết bị Công nghiệp Tân Phát",
      amount: 38750000,
      status: "Chưa thực hiện",
      deliveryStatus: "Chưa giao",
    },
    {
      id: "hd-02",
      code: "HĐM00002",
      date: "15/08/2026",
      supplier: "Công ty TNHH Nhập khẩu & Thương mại Sao Nam",
      amount: 92000000,
      status: "Đang thực hiện",
      deliveryStatus: "Đang giao",
    },
  ]);

  // Sample data: Chứng từ mua hàng (Image 4)
  const [vouchers, setVouchers] = useState([
    {
      id: "nk-01",
      code: "NK00001",
      date: "29/09/2026",
      supplier: "Công ty TNHH Thiết bị Công nghiệp Tân Phát",
      amount: 23650000,
      kind: "Mua hàng trong nước nhập kho",
      status: "Chưa thanh toán",
      description: "Mua hàng nhập kho vật tư thép Ø6",
    },
    {
      id: "nk-02",
      code: "NK00002",
      date: "22/09/2026",
      supplier: "Công ty Cổ phần Thép Hòa Phát Hưng Yên",
      amount: 88500000,
      kind: "Mua hàng trong nước nhập kho",
      status: "Đã thanh toán",
      description: "Nhập kho ống thép đúc",
    },
  ]);

  // Sample data: Trả lại hàng mua (Image 5)
  const [returns, setReturns] = useState([
    {
      id: "xk-01",
      code: "XK00001",
      date: "29/09/2026",
      supplier: "Công ty TNHH Thiết bị Công nghiệp Tân Phát",
      amount: 2365000,
      reason: "Trả lại hàng mua do sai quy cách Ø6",
      status: "Giảm trừ công nợ",
    },
  ]);

  // Sample data: Giảm giá hàng mua (Screenshot 1)
  const [discounts, setDiscounts] = useState([
    {
      id: "mgg-01",
      code: "MGG00001",
      date: "29/09/2026",
      supplier: "Công ty TNHH Thiết bị Công nghiệp Tân Phát",
      amount: 165000,
      reason: "Giảm giá hàng mua vật tư thép do giao trễ",
      status: "Giảm trừ công nợ",
    },
  ]);

  // Sample data: Hàng hóa, dịch vụ (Screenshot 2)
  const [inventoryItems, setInventoryItems] = useState<InventoryItemData[]>([
    {
      id: "cpmh",
      name: "Chi phí mua hàng",
      code: "CPMH",
      vatPolicy: "Chưa xác định",
      nature: "Dịch vụ",
      stockQty: 0,
      stockValue: 0,
      unit: "Lần",
    },
    {
      id: "vt01",
      name: "Thép cuộn mạ kẽm Ø6",
      code: "VT001",
      vatPolicy: "10%",
      nature: "Vật tư hàng hóa",
      stockQty: 4500,
      stockValue: 96750000,
      unit: "Kg",
    },
    {
      id: "vt02",
      name: "Ống thép đúc phi 90 dày 3.5mm",
      code: "VT002",
      vatPolicy: "10%",
      nature: "Vật tư hàng hóa",
      stockQty: 120,
      stockValue: 41400000,
      unit: "Cây",
    },
    {
      id: "vt03",
      name: "Bulong nở inox M12x100",
      code: "VT003",
      vatPolicy: "8%",
      nature: "Vật tư hàng hóa",
      stockQty: 2500,
      stockValue: 31250000,
      unit: "Bộ",
    },
    {
      id: "tp01",
      name: "Bàn làm việc khung thép sơn tĩnh điện",
      code: "VT00002",
      vatPolicy: "Chưa xác định",
      nature: "Thành phẩm",
      stockQty: 50,
      stockValue: 62500000,
      unit: "Bộ",
      vthhGroups: ["TP"],
      stockAccount: "155",
      revenueAccount: "5112",
      costAccount: "632",
    },
  ]);

  const handleSelectNature = (_natureId: string, natureName: string) => {
    setShowNatureDrawer(false);
    setSelectedNature(natureName);
    setEditingItem(null);
    setShowItemModal(true);
    notify(`Đã chọn tính chất: ${natureName}. Mở form thêm mới Hàng hóa, dịch vụ.`);
  };

  const handleSaveInventoryItem = async (itemData: InventoryItemData, keepOpen?: boolean) => {
    if (apiConnected && !editingItem) {
      const saved = await apiSave((writer) => saveItem(writer, itemData));
      if (saved && !keepOpen) setShowItemModal(false);
      return saved;
    }
    if (editingItem) {
      setInventoryItems((prev) =>
        prev.map((it) => (it.id === editingItem.id ? { ...it, ...itemData } : it))
      );
      notify(`Đã cập nhật hàng hóa, dịch vụ [${itemData.code}] ${itemData.name}!`);
    } else {
      setInventoryItems((prev) => [
        {
          id: `item-${Date.now()}`,
          ...itemData,
        },
        ...prev,
      ]);
      notify(`Đã thêm mới [${itemData.code}] ${itemData.name} (${itemData.nature}) thành công!`);
    }
    if (!keepOpen) {
      setShowItemModal(false);
      setEditingItem(null);
    }
  };

  // Sample data: Đối chiếu công nợ (Screenshot 3)
  const [reconciliations, setReconciliations] = useState([
    {
      id: "dc-01",
      period: "Tháng 09/2026",
      supplier: "Công ty TNHH Thiết bị Công nghiệp Tân Phát",
      account: "331",
      supplierDebt: 38750000,
      bookDebt: 38750000,
      difference: 0,
      status: "Khớp đúng 100%",
    },
  ]);

  useEffect(() => {
    if (!apiConnected) return;
    const parties = apiRows.suppliers;
    const supplierName = (row: any) => row.supplier_name || row.seller_name ||
      parties?.find((party) => party.id === row.supplier)?.name || "";
    if (parties) setSuppliers(parties.map((party) => ({
      id: party.id, code: party.code || "", name: party.name || "",
      address: party.address || "",
      debtAmount: apiRows.payables?.filter((debt) => debt.supplier === party.id)
        .reduce((total, debt) => total + apiNumber(debt.balance), 0) || 0,
      taxCode: party.tax_code || "",
      invoiceRisk: "", refDoc: "", phone: party.phone || "",
      isInternal: false, isBranch: false, partnerType: "org" as const, isCustomer: false,
    })));
    if (apiRows.items) setInventoryItems(apiRows.items.map((item) => ({
      id: item.id, code: item.code || "", name: item.name || "",
      vatPolicy: "", nature: item.item_type || "Hàng hóa", stockQty: 0,
      stockValue: 0, unit: apiUnitName(apiRows.units, item.base_uom),
    })));
    if (apiRows.orders) setOrders(apiRows.orders.map((row) => ({
      id: row.id, code: row.number || "", date: apiDate(row.document_date),
      deliveryDate: apiDate(row.delivery_date), supplier: supplierName(row),
      amount: apiNumber(row.total_amount), status: row.status_display || row.status || "",
      description: row.notes || "",
    })));
    if (apiRows.contracts) setContracts(apiRows.contracts.map((row) => ({
      id: row.id, code: row.number || "", date: apiDate(row.document_date),
      supplier: supplierName(row), amount: apiNumber(row.total_amount),
      status: row.status_display || row.status || "", deliveryStatus: "",
    })));
    if (apiRows.vouchers) setVouchers(([
      ...apiRows.vouchers.map((row) => ({ ...row, apiKey: "vouchers", apiPath: "/api/v1/purchases/goods-purchases/" })),
      ...(apiRows.serviceVouchers || []).map((row) => ({ ...row, apiKey: "serviceVouchers", apiPath: "/api/v1/purchases/service-purchases/" })),
    ] as Record<string, any>[]).sort((a, b) => String(b.document_date).localeCompare(String(a.document_date))).map((row) => ({
      id: row.id, code: row.number || "", date: apiDate(row.document_date),
      supplier: supplierName(row), amount: apiNumber(row.total_amount),
      kind: row.apiKey === "serviceVouchers" ? "Mua dịch vụ" : row.purchase_type === "DIRECT" ? "Không qua kho" : "Nhập kho",
      status: row.status || "", description: row.notes || "", apiKey: row.apiKey, apiPath: row.apiPath,
    })));
    if (apiRows.returns) setReturns(apiRows.returns.map((row) => ({
      id: row.id, code: row.number || "", date: apiDate(row.document_date),
      supplier: supplierName(row), amount: apiNumber(row.total_amount),
      reason: row.reason || "", status: row.status || "",
    })));
    if (apiRows.discounts) setDiscounts(apiRows.discounts.map((row) => ({
      id: row.id, code: row.number || "", date: apiDate(row.document_date),
      supplier: supplierName(row), amount: apiNumber(row.total_amount),
      reason: row.reason || "", status: row.status || "",
    })));
    if (apiRows.invoices) setReceivedInvoices(apiRows.invoices.map((row) => ({
      id: row.id, receivedDate: apiDate(row.created_at), invoiceNo: row.invoice_number || "",
      invoiceSeries: row.invoice_series || "", invoiceDate: apiDate(row.invoice_date),
      supplierName: supplierName(row), supplierTaxCode: row.supplier_tax_code || "",
      voucherCode: "", subtotal: apiNumber(row.subtotal), vatAmount: apiNumber(row.tax_amount),
      totalAmount: apiNumber(row.total_amount), status: row.status || "",
    })));
    if (apiRows.reconciliations) setReconciliations(apiRows.reconciliations.map((row) => ({
      id: row.id, period: `${apiDate(row.period_start)} - ${apiDate(row.period_end)}`,
      supplier: supplierName(row), account: "331", supplierDebt: apiNumber(row.supplier_balance),
      bookDebt: apiNumber(row.closing_balance), difference: apiNumber(row.difference),
      status: row.status_display || row.status || "",
    })));
  }, [apiRows, apiConnected]);

  // Handlers for saves
  const handleSaveOrder = async (data: any): Promise<boolean> => {
    if (apiConnected && token) {
      const toDate = (value: string) => {
        const match = String(value || "").match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
        return match ? `${match[3]}-${match[2]}-${match[1]}` : value;
      };
      const supplier = apiRows.suppliers?.find((row) => row.code === data.supplierCode);
      if (!supplier) {
        notify("Chọn mã nhà cung cấp có trong danh mục trước khi lưu đơn mua.");
        return false;
      }
      const inputLines = (data.items || []).filter((line: any) => line.code && Number(line.quantity) > 0);
      if (!inputLines.length) {
        notify("Đơn mua cần ít nhất một hàng hóa có mã và số lượng.");
        return false;
      }
      const catalogLines = inputLines.map((line: any) => ({ input: line, item: apiRows.items?.find((row) => row.code === line.code) }));
      const missing = catalogLines.find(({ item }: any) => !item);
      if (missing) {
        notify(`Mã hàng ${missing.input.code} chưa có trong danh mục.`);
        return false;
      }
      const taxRateFor = (input: any) => apiRows.taxRates?.find((rate) =>
        rate.status === "ACTIVE" && rate.application_form === "PERCENT" &&
        ["INPUT", "BOTH"].includes(rate.business_scope) &&
        Number(rate.rate_percent) === Number(input.vatRate || 0));
      if (catalogLines.some(({ input }: any) => Number(input.vatRate) > 0 && !taxRateFor(input))) {
        notify("Thuế suất đầu vào trên đơn mua chưa có trong danh mục thuế.");
        return false;
      }
      try {
        const list = async (path: string): Promise<any[]> => {
          const result = await request<any[] | { results: any[] }>(`${path}?company_id=${encodeURIComponent(_company.id)}`, token);
          return Array.isArray(result) ? result : result.results;
        };
        const branches = await list("/api/v1/organization/branches/");
        const branch = branches.find((row) => row.status === "ACTIVE");
        if (!branch) {
          notify("Cần có chi nhánh đang hoạt động để lập đơn mua.");
          return false;
        }
        let warehouse: any;
        if (catalogLines.some(({ item }: any) => item.track_inventory)) {
          const warehouses = await list("/api/v1/master-data/warehouses/");
          warehouse = warehouses.find((row) => row.status === "ACTIVE" && (row.code === data.deliveryLocation || row.name === data.deliveryLocation))
            || warehouses.find((row) => row.status === "ACTIVE");
          if (!warehouse) {
            notify("Cần có kho đang hoạt động để nhận hàng theo dõi tồn kho.");
            return false;
          }
        }
        const saved = await request<any>(`/api/v1/purchases/purchase-orders/?company_id=${encodeURIComponent(_company.id)}`, token, {
          method: "POST",
          body: JSON.stringify({
            company: _company.id,
            branch: branch.id,
            supplier: supplier.id,
            number: data.orderCode || "",
            document_date: toDate(data.orderDate),
            delivery_date: toDate(data.deliveryDate),
            receiving_location: data.deliveryLocation || warehouse?.name || "",
            receiving_warehouse: warehouse?.id || null,
            contact_person: data.contactPerson || "",
            notes: data.description || "",
            lines: catalogLines.map(({ input, item }: any, index: number) => ({
              line_no: index + 1,
              item: item.id,
              uom: item.purchase_uom || item.base_uom,
              quantity: input.quantity,
              unit_price: input.unitPrice || 0,
              description: input.name || item.name,
              tax_rate: taxRateFor(input)?.id || null,
              warehouse: warehouse?.id || null,
            })),
          }),
        });
        reloadApi();
        notify(`Đã lưu đơn mua hàng ${saved.number || data.orderCode}.`);
        return true;
      } catch (error) {
        notify(`Không lưu được đơn mua hàng: ${error instanceof Error ? error.message : String(error)}`);
        return false;
      }
    }
    setOrders([
      {
        id: `po-${Date.now()}`,
        code: data.orderCode,
        date: data.orderDate,
        deliveryDate: data.deliveryDate,
        supplier: data.supplierName,
        amount: data.totalGrand,
        status: data.status,
        description: data.description,
      },
      ...orders,
    ]);
    notify(`Đã lưu Đơn mua hàng ${data.orderCode}!`);
    return true;
  };

  const handleSaveContract = (data: any) => {
    if (apiConnected) return apiSave((writer) => savePurchaseContract(writer, data));
    setContracts([
      {
        id: `hd-${Date.now()}`,
        code: data.contractCode,
        date: data.signDate,
        supplier: data.supplierName,
        amount: data.grandTotal,
        status: data.contractStatus,
        deliveryStatus: data.deliveryStatus,
      },
      ...contracts,
    ]);
    notify(`Đã lưu Hợp đồng mua ${data.contractCode}!`);
  };

  const handleSaveVoucher = async (data: any) => {
    if (apiConnected && token) {
      const result = await saveGoodsPurchase(createApiWriter(_company.id, (path, init) => request(path, token, init)), data);
      notify(result.message);
      reloadApi();
      return result;
    }
    setVouchers([
      {
        id: `nk-${Date.now()}`,
        code: data.voucherCode,
        date: data.docDate,
        supplier: data.supplierName,
        amount: data.grandTotal,
        kind: data.purchaseType,
        status: data.paymentOption === "paid" ? "Đã thanh toán" : "Chưa thanh toán",
        description: data.description,
      },
      ...vouchers,
    ]);
    notify(`Đã lập Chứng từ mua hàng ${data.voucherCode}!`);
    return { record: { id: `nk-${Date.now()}`, number: data.voucherCode } };
  };

  const handleSaveReturn = (data: any) => {
    if (apiConnected) return apiSave((writer) => savePurchaseReturn(writer, data));
    setReturns([
      {
        id: `xk-${Date.now()}`,
        code: data.voucherCode,
        date: data.docDate,
        supplier: data.supplierName,
        amount: data.grandTotal,
        reason: data.reason,
        status: data.returnOption === "cash" ? "Thu tiền mặt" : "Giảm trừ công nợ",
      },
      ...returns,
    ]);
    notify(`Đã lưu Chứng từ trả lại hàng mua ${data.voucherCode}!`);
  };

  const handleSaveDiscount = (data: any) => {
    if (apiConnected) return apiSave((writer) => savePurchaseDiscount(writer, data));
    setDiscounts([
      {
        id: `mgg-${Date.now()}`,
        code: data.voucherCode,
        date: data.docDate,
        supplier: data.supplierName,
        amount: data.grandTotal,
        reason: data.description,
        status: data.discountOption === "cash" ? "Thu tiền mặt" : "Giảm trừ công nợ",
      },
      ...discounts,
    ]);
    notify(`Đã lưu Chứng từ giảm giá hàng mua ${data.voucherCode}!`);
  };

  const handleSaveReconciliation = (data: any) => {
    if (apiConnected) return apiSave((writer) => saveSupplierReconciliation(writer, data));
    setReconciliations([
      {
        id: `dc-${Date.now()}`,
        period: "Kỳ đối chiếu mới",
        supplier: data.supplier,
        account: data.debtAccount.split(" ")[0],
        supplierDebt: 23650000,
        bookDebt: 23650000,
        difference: 0,
        status: "Đã đối chiếu hoàn tất",
      },
      ...reconciliations,
    ]);
    notify(`Đã đối chiếu thành công kỳ công nợ với ${data.supplier}!`);
  };

  const handleSaveSupplier = async (data: any, andNew = false): Promise<boolean> => {
    if (apiConnected && token) {
      const input = {
        company: _company.id,
        code: String(data.code || "").trim(),
        name: String(data.name || "").trim(),
        party_type: data.partnerType === "individual" ? "INDIVIDUAL" : "ORGANIZATION",
        tax_code: String(data.taxCode || "").trim() || null,
        legal_name: String(data.name || "").trim(),
        notes: String(data.notes || ""),
      };
      if (!input.code || !input.name) {
        notify("Cần nhập mã và tên nhà cung cấp.");
        return false;
      }
      try {
        const path = editingSupplier
          ? `/api/v1/master-data/parties/${editingSupplier.id}/?company_id=${encodeURIComponent(_company.id)}`
          : `/api/v1/master-data/parties/?company_id=${encodeURIComponent(_company.id)}`;
        await request(path, token, {
          method: editingSupplier ? "PATCH" : "POST",
          body: JSON.stringify(input),
        });
        reloadApi();
        notify(`Đã lưu nhà cung cấp ${input.name}.`);
        setEditingSupplier(null);
        if (!andNew) setShowSupplierModal(false);
        return true;
      } catch (error) {
        notify(`Không lưu được nhà cung cấp: ${error instanceof Error ? error.message : String(error)}`);
        return false;
      }
    }
    if (editingSupplier) {
      setSuppliers((prev) =>
        prev.map((s) =>
          s.id === editingSupplier.id
            ? {
                ...s,
                code: data.code || s.code,
                name: data.name || s.name,
                address: data.address || "",
                taxCode: data.taxCode || "",
                phone: data.phone || data.contactPhone || "",
                isInternal: Boolean(data.isInternal),
                isCustomer: Boolean(data.isCustomer),
                partnerType: data.partnerType,
                supplierGroup: data.supplierGroup,
                employee: data.employee,
              }
            : s
        )
      );
      notify(`Đã cập nhật thông tin nhà cung cấp ${data.name || data.code}!`);
      setEditingSupplier(null);
    } else {
      const newSupplier = {
        id: `ncc-${Date.now()}`,
        code: data.code || `NCC0000${suppliers.length + 1}`,
        name: data.name || "Nhà cung cấp mới",
        address: data.address || "",
        debtAmount: 0,
        taxCode: data.taxCode || "",
        invoiceRisk: "",
        refDoc: "",
        phone: data.phone || data.contactPhone || "",
        isInternal: Boolean(data.isInternal),
        isBranch: false,
        partnerType: data.partnerType || "org",
        isCustomer: Boolean(data.isCustomer),
        supplierGroup: data.supplierGroup || "",
        employee: data.employee || "",
      };
      setSuppliers([newSupplier, ...suppliers]);
      notify(`Đã lưu nhà cung cấp ${data.name || data.code}!`);
    }
    if (!andNew) setShowSupplierModal(false);
    return true;
  };

  const handleSaveReceivedInvoice = (selectedVouchers: UninvoicedVoucher[]) => {
    sessionStorage.setItem("tax_intake_purchase_context", JSON.stringify(selectedVouchers.map((row) => ({
      id: row.id, code: row.voucherCode, supplier: row.supplierName,
    }))));
    setShowReceiveInvoiceModal(false);
    navigate(href ? href("/invoices/incoming/inbox") : "/invoices/incoming/inbox");
    return true;
  };
  const handleSaveService = (data: any) => {
    if (apiConnected) return apiSave((writer) => saveServicePurchase(writer, data));
    setVouchers([
      {
        id: `mdv-${Date.now()}`,
        code: data.voucherCode,
        date: data.docDate,
        supplier: data.supplierName,
        amount: data.grandTotal,
        kind: "Mua dịch vụ",
        status: data.paymentOption === "paid" ? "Đã thanh toán" : "Chưa thanh toán",
        description: data.description,
      },
      ...vouchers,
    ]);
    notify(`Đã lập Chứng từ mua dịch vụ ${data.voucherCode}!`);
  };

  const handleSaveMultiInvoice = (data: any) => {
    if (apiConnected) return apiSave((writer) => saveMultiInvoicePurchase(writer, data));
    setVouchers([
      {
        id: `mhd-${Date.now()}`,
        code: data.voucherCode,
        date: data.docDate,
        supplier: data.deliverer || "Nhiều nhà cung cấp",
        amount: data.grandTotal,
        kind: data.purchaseKind || "Mua hàng nhiều hóa đơn",
        status: data.paymentOption === "paid" ? "Đã thanh toán" : "Chưa thanh toán",
        description: data.description,
      },
      ...vouchers,
    ]);
    notify(`Đã lập Chứng từ mua hàng nhiều hóa đơn ${data.voucherCode}!`);
  };

  // Render all modals
  const renderModals = () => (
    <>
      {showOrderModal && (
        <PurchaseOrderModal
          onClose={() => setShowOrderModal(false)}
          onSubmit={handleSaveOrder}
          supplierCatalog={apiConnected ? (apiRows.suppliers || []).map((row) => ({ code: row.code, name: row.name, tax_code: row.tax_code })) : undefined}
          itemCatalog={apiConnected ? (apiRows.items || []).map((row) => ({ code: row.code, name: row.name, unit: apiUnitName(apiRows.units, row.purchase_uom || row.base_uom), price: Number(row.purchase_price || 0) })) : undefined}
          onOpenSupplierModal={() => setShowSupplierModal(true)}
        />
      )}

      {showContractModal && (
        <PurchaseContractModal
          onClose={() => setShowContractModal(false)}
          onSubmit={handleSaveContract}
          onOpenSupplierModal={() => setShowSupplierModal(true)}
        />
      )}

      {showVoucherModal && (
        <PurchaseVoucherModal
          onClose={() => { setShowVoucherModal(false); setEditingVoucher(null); }}
          onSubmit={handleSaveVoucher}
          onOpenSupplierModal={() => setShowSupplierModal(true)}
          initialRecord={editingVoucher}
          supplierCatalog={apiConnected ? (apiRows.suppliers || []).filter((row) => row.status === "ACTIVE").map((row) => ({ id: row.id, code: row.code, name: row.name, address: row.address, contact: row.contact_person, taxCode: row.tax_code, debtDays: row.payment_term_days })) : undefined}
          itemCatalog={apiConnected ? (apiRows.items || []).filter((row) => row.status === "ACTIVE").map((row) => ({ id: row.id, code: row.code, name: row.name, unit: apiUnitName(apiRows.units, row.base_uom), price: Number(row.purchase_price || 0), stockAccount: apiRows.accounts?.find((account) => account.id === row.inventory_account)?.code })) : undefined}
          warehouseCatalog={apiConnected ? (apiRows.warehouses || []).filter((row) => row.status === "ACTIVE").map((row) => ({ id: row.id, code: row.code, name: row.name })) : undefined}
        />
      )}

      {showReturnModal && (
        <PurchaseReturnModal
          onClose={() => setShowReturnModal(false)}
          onSubmit={handleSaveReturn}
          onOpenSupplierModal={() => setShowSupplierModal(true)}
        />
      )}

      {showDiscountModal && (
        <PurchaseDiscountModal
          onClose={() => setShowDiscountModal(false)}
          onSubmit={handleSaveDiscount}
          onOpenSupplierModal={() => setShowSupplierModal(true)}
          purchaseSources={(apiRows.vouchers || []).filter((row) => row.purchase_type === "WAREHOUSE")}
          sourceCatalog={{ suppliers: apiRows.suppliers || [], items: apiRows.items || [],
            warehouses: apiRows.warehouses || [], accounts: apiRows.accounts || [],
            units: apiRows.units || [], taxRates: apiRows.taxRates || [] }}
        />
      )}

      {showReconciliationModal && (
        <ReconciliationPeriodModal
          onClose={() => setShowReconciliationModal(false)}
          onSubmit={handleSaveReconciliation}
          supplierOptions={apiConnected ? (apiRows.suppliers || []).map((row) => ({ code: row.code, name: row.name })) : undefined}
        />
      )}

      {showSupplierModal && (
        <SupplierModal
          initialData={editingSupplier}
          onClose={() => {
            setShowSupplierModal(false);
            setEditingSupplier(null);
          }}
          onSubmit={handleSaveSupplier}
        />
      )}

      {showSupplierPaymentModal && (
        <SupplierPaymentModal
          onClose={() => setShowSupplierPaymentModal(false)}
          onSubmit={(_payload) => {
            setShowSupplierPaymentModal(false);
            notify("Đã lập chứng từ trả tiền nhà cung cấp theo hóa đơn thành công!");
          }}
        />
      )}

      {showReceiveInvoiceModal && (
        <ReceiveInvoiceSelectModal
          onClose={() => setShowReceiveInvoiceModal(false)}
          onSubmit={handleSaveReceivedInvoice}
          loadVouchers={apiConnected ? loadUninvoicedVouchers : undefined}
          onOpenSupplierModal={() => setShowSupplierModal(true)}
        />
      )}

      {showAIModal && (
        <AIAssistantModal
          onClose={() => setShowAIModal(false)}
          onApply={(doc) => {
            setShowAIModal(false);
            notify(`Đã nạp dữ liệu hóa đơn mua hàng ${doc.code}.`);
          }}
        />
      )}

      {showServiceModal && (
        <PurchaseServiceModal
          onClose={() => setShowServiceModal(false)}
          onSubmit={handleSaveService}
          onOpenSupplierModal={() => setShowSupplierModal(true)}
        />
      )}

      {showMultiInvoiceModal && (
        <PurchaseMultiInvoiceModal
          onClose={() => setShowMultiInvoiceModal(false)}
          onSubmit={handleSaveMultiInvoice}
          onOpenSupplierModal={() => setShowSupplierModal(true)}
        />
      )}

      {showNatureDrawer && (
        <MisaItemNatureDrawer
          isOpen={showNatureDrawer}
          onClose={() => setShowNatureDrawer(false)}
          onSelectNature={handleSelectNature}
          notify={notify}
        />
      )}

      {showItemModal && (
        <MisaInventoryItemModal
          isOpen={showItemModal}
          onClose={() => {
            setShowItemModal(false);
            setEditingItem(null);
          }}
          initialNature={selectedNature}
          editingItem={editingItem}
          onSubmit={handleSaveInventoryItem}
          onChangeNature={() => {
            setShowItemModal(false);
            setShowNatureDrawer(true);
          }}
          notify={notify}
        />
      )}

      {paymentTermsOpen&&<MisaPaymentTermsWorkspace companyId={_company.id} onClose={()=>setPaymentTermsOpen(false)}/>}
      {/* 5 Tiện ích mua hàng chuẩn MISA AMIS */}
      {showDebtOffsetModal && (
        <DebtOffsetModal
          onClose={() => setShowDebtOffsetModal(false)}
          onSuccess={(message) => {
            setShowDebtOffsetModal(false);
            notify(message);
          }}
        />
      )}

      {showMultiDebtOffsetModal && (
        <MultiDebtOffsetModal
          onClose={() => setShowMultiDebtOffsetModal(false)}
          onSuccess={(_message) => {
            setShowMultiDebtOffsetModal(false);
            notify("Đã hoàn tất đối trừ chứng từ nhiều đối tượng thành công!");
          }}
        />
      )}

      {showUnOffsetModal && (
        <UnOffsetModal
          onClose={() => setShowUnOffsetModal(false)}
          onSuccess={(_message) => {
            setShowUnOffsetModal(false);
            notify("Đã thực hiện bỏ đối trừ chứng từ thành công!");
          }}
        />
      )}

      {showMultiUnOffsetModal && (
        <MultiUnOffsetModal
          onClose={() => setShowMultiUnOffsetModal(false)}
          onSuccess={(_message) => {
            setShowMultiUnOffsetModal(false);
            notify("Đã bỏ đối trừ chứng từ nhiều đối tượng thành công!");
          }}
        />
      )}

      {showDebtClearingModal && (
        <DebtClearingModal
          onClose={() => setShowDebtClearingModal(false)}
          onSuccess={(message) => {
            setShowDebtClearingModal(false);
            notify(message);
          }}
        />
      )}
    </>
  );

  // -------------------------------------------------------------------------
  // 0. TAB: BIỂU ĐỒ (EXACT MATCHING SCREENSHOT)
  // -------------------------------------------------------------------------
  if(tab==="reports")return <MisaReportCenterWorkspace key={purchaseParams.get("report")||"purchases"} embedded initialCategory="purchases" initialReport={purchaseParams.get("report")} notify={notify}/>;

  if (tab === "chart") {
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          minHeight: "100%",
          background: "#f4f5f8",
          padding: "12px 18px 24px 18px",
          boxSizing: "border-box",
          fontFamily: "Roboto, Arial, sans-serif",
          position: "relative",
        }}
      >
        {/* Backdrop for closing popups */}
        {(showCurrencyMenu || openPeriodMenu !== null) && (
          <div
            onClick={() => {
              setShowCurrencyMenu(false);
              setOpenPeriodMenu(null);
            }}
            style={{
              position: "fixed",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              zIndex: 40,
              background: "transparent",
            }}
          />
        )}

        {/* Subheader: Đơn vị tính tiền Đồng ▾ */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13, color: "#475569" }}>
            <span>Đơn vị tính tiền</span>
            <div style={{ position: "relative" }}>
              <button
                type="button"
                onClick={() => {
                  setOpenPeriodMenu(null);
                  setShowCurrencyMenu(!showCurrencyMenu);
                }}
                style={{
                  background: "none",
                  border: "none",
                  color: "var(--brand)",
                  fontWeight: 500,
                  cursor: "pointer",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 4,
                  padding: "2px 4px",
                  fontSize: 13,
                }}
              >
                <span>{currencyUnit}</span>
                <ChevronDown size={14} />
              </button>

              {showCurrencyMenu && (
                <div
                  style={{
                    position: "absolute",
                    top: "100%",
                    left: 0,
                    marginTop: 4,
                    background: "#ffffff",
                    border: "1px solid #cbd5e1",
                    borderRadius: 4,
                    boxShadow: "0 4px 12px rgba(0,0,0,0.12)",
                    zIndex: 50,
                    minWidth: 130,
                    overflow: "hidden",
                  }}
                >
                  {["Đồng", "Nghìn đồng", "Triệu đồng", "Tỷ đồng"].map((unit) => (
                    <div
                      key={unit}
                      onClick={() => {
                        setCurrencyUnit(unit);
                        setShowCurrencyMenu(false);
                        notify(`Đã chuyển đơn vị tính tiền sang: ${unit}`);
                      }}
                      style={{
                        padding: "7px 12px",
                        fontSize: 13,
                        color: currencyUnit === unit ? "var(--brand)" : "#1e293b",
                        fontWeight: currencyUnit === unit ? 600 : 400,
                        background: currencyUnit === unit ? "#eff6ff" : "#ffffff",
                        cursor: "pointer",
                      }}
                      onMouseEnter={(e) => {
                        if (currencyUnit !== unit) e.currentTarget.style.background = "#f8fafc";
                      }}
                      onMouseLeave={(e) => {
                        if (currencyUnit !== unit) e.currentTarget.style.background = "#ffffff";
                      }}
                    >
                      {unit}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* TOP ROW: 3 SUMMARY KPI CARDS */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: 14,
            marginBottom: 14,
          }}
        >
          {/* CARD 1: Đơn mua hàng (Purple Header #8b5cf6) */}
          <div
            style={{
              background: "#ffffff",
              borderRadius: 6,
              border: "1px solid #e2e8f0",
              boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
              display: "flex",
              flexDirection: "column",
              position: "relative",
            }}
          >
            {/* Header */}
            <div
              style={{
                background: "#8b5cf6",
                color: "#ffffff",
                padding: "8px 14px",
                borderTopLeftRadius: 5,
                borderTopRightRadius: 5,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                position: "relative",
              }}
            >
              <span style={{ fontWeight: 600, fontSize: 13.5 }}>Đơn mua hàng</span>
              <div style={{ position: "relative" }}>
                <button
                  type="button"
                  onClick={() => {
                    setShowCurrencyMenu(false);
                    setOpenPeriodMenu(openPeriodMenu === "orders" ? null : "orders");
                  }}
                  style={{
                    background: "transparent",
                    border: "none",
                    color: "#ffffff",
                    fontSize: 12.5,
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 4,
                    cursor: "pointer",
                    padding: "2px 4px",
                  }}
                >
                  <span>{chartPeriods.orders}</span>
                  <ChevronDown size={13} />
                </button>
                {openPeriodMenu === "orders" && (
                  <div
                    style={{
                      position: "absolute",
                      right: 0,
                      top: "100%",
                      marginTop: 4,
                      background: "#ffffff",
                      border: "1px solid #cbd5e1",
                      borderRadius: 4,
                      boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
                      zIndex: 50,
                      minWidth: 120,
                      overflow: "hidden",
                    }}
                  >
                    {["Hôm nay", "Tuần này", "Tháng này", "Tháng trước", "Quý này", "Năm nay"].map((p) => (
                      <div
                        key={p}
                        onClick={() => {
                          setChartPeriods((prev) => ({ ...prev, orders: p }));
                          setOpenPeriodMenu(null);
                          notify(`Đã lọc Đơn mua hàng theo: ${p}`);
                        }}
                        style={{
                          padding: "6px 12px",
                          fontSize: 12.5,
                          color: chartPeriods.orders === p ? "var(--brand)" : "#1e293b",
                          background: chartPeriods.orders === p ? "#eff6ff" : "#ffffff",
                          cursor: "pointer",
                        }}
                      >
                        {p}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Body Rows */}
            <div style={{ padding: "10px 14px", display: "flex", flexDirection: "column", gap: 6, flex: 1 }}>
              {[
                { label: "Giá trị đơn hàng", isDebt: false, tabTarget: "orders", modal: () => setShowOrderModal(true) },
                { label: "Đã thực hiện", isDebt: false, tabTarget: "orders", modal: () => setShowOrderModal(true) },
                { label: "Đã thanh toán", isDebt: false, tabTarget: "transactions", modal: () => setShowVoucherModal(true) },
                { label: "Còn phải trả", isDebt: true, tabTarget: "reconciliation", modal: () => setShowReconciliationModal(true) },
              ].map((row, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    if (href) {
                      navigate(href(`/purchases/${row.tabTarget}`));
                    } else {
                      row.modal();
                    }
                  }}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "5px 4px",
                    cursor: "pointer",
                    fontSize: 13,
                    color: "#334155",
                    borderRadius: 4,
                    transition: "background 0.15s ease",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#f8fafc")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  <span>{row.label}</span>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                      color: row.isDebt ? "#ea580c" : "var(--brand)",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  >
                    <span>0</span>
                    <ChevronRight size={13} />
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div
              style={{
                padding: "8px 14px",
                borderTop: "1px solid #f1f5f9",
                display: "flex",
                alignItems: "center",
                gap: 6,
                fontSize: 11.5,
                color: "#64748b",
              }}
            >
              <Clock size={12.5} style={{ color: "#94a3b8" }} />
              <span>Số liệu tính đến: {chartRefreshTime}</span>
              <span
                onClick={handleRefreshChart}
                style={{
                  color: "var(--brand)",
                  cursor: "pointer",
                  fontWeight: 500,
                  marginLeft: 4,
                }}
                onMouseEnter={(e) => (e.currentTarget.style.textDecoration = "underline")}
                onMouseLeave={(e) => (e.currentTarget.style.textDecoration = "none")}
              >
                Tải lại
              </span>
            </div>
          </div>

          {/* CARD 2: Hợp đồng mua (Ocean Blue Header var(--brand)) */}
          <div
            style={{
              background: "#ffffff",
              borderRadius: 6,
              border: "1px solid #e2e8f0",
              boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
              display: "flex",
              flexDirection: "column",
              position: "relative",
            }}
          >
            {/* Header */}
            <div
              style={{
                background: "var(--brand)",
                color: "#ffffff",
                padding: "8px 14px",
                borderTopLeftRadius: 5,
                borderTopRightRadius: 5,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                position: "relative",
              }}
            >
              <span style={{ fontWeight: 600, fontSize: 13.5 }}>Hợp đồng mua</span>
              <div style={{ position: "relative" }}>
                <button
                  type="button"
                  onClick={() => {
                    setShowCurrencyMenu(false);
                    setOpenPeriodMenu(openPeriodMenu === "contracts" ? null : "contracts");
                  }}
                  style={{
                    background: "transparent",
                    border: "none",
                    color: "#ffffff",
                    fontSize: 12.5,
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 4,
                    cursor: "pointer",
                    padding: "2px 4px",
                  }}
                >
                  <span>{chartPeriods.contracts}</span>
                  <ChevronDown size={13} />
                </button>
                {openPeriodMenu === "contracts" && (
                  <div
                    style={{
                      position: "absolute",
                      right: 0,
                      top: "100%",
                      marginTop: 4,
                      background: "#ffffff",
                      border: "1px solid #cbd5e1",
                      borderRadius: 4,
                      boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
                      zIndex: 50,
                      minWidth: 120,
                      overflow: "hidden",
                    }}
                  >
                    {["Hôm nay", "Tuần này", "Tháng này", "Tháng trước", "Quý này", "Năm nay"].map((p) => (
                      <div
                        key={p}
                        onClick={() => {
                          setChartPeriods((prev) => ({ ...prev, contracts: p }));
                          setOpenPeriodMenu(null);
                          notify(`Đã lọc Hợp đồng mua theo: ${p}`);
                        }}
                        style={{
                          padding: "6px 12px",
                          fontSize: 12.5,
                          color: chartPeriods.contracts === p ? "var(--brand)" : "#1e293b",
                          background: chartPeriods.contracts === p ? "#eff6ff" : "#ffffff",
                          cursor: "pointer",
                        }}
                      >
                        {p}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Body Rows */}
            <div style={{ padding: "10px 14px", display: "flex", flexDirection: "column", gap: 6, flex: 1 }}>
              {[
                { label: "Giá trị hợp đồng", isDebt: false, tabTarget: "contracts", modal: () => setShowContractModal(true) },
                { label: "Đã thực hiện", isDebt: false, tabTarget: "contracts", modal: () => setShowContractModal(true) },
                { label: "Đã thanh toán", isDebt: false, tabTarget: "transactions", modal: () => setShowVoucherModal(true) },
                { label: "Còn phải trả", isDebt: true, tabTarget: "reconciliation", modal: () => setShowReconciliationModal(true) },
              ].map((row, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    if (href) {
                      navigate(href(`/purchases/${row.tabTarget}`));
                    } else {
                      row.modal();
                    }
                  }}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "5px 4px",
                    cursor: "pointer",
                    fontSize: 13,
                    color: "#334155",
                    borderRadius: 4,
                    transition: "background 0.15s ease",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#f8fafc")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  <span>{row.label}</span>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                      color: row.isDebt ? "#ea580c" : "var(--brand)",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  >
                    <span>0</span>
                    <ChevronRight size={13} />
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div
              style={{
                padding: "8px 14px",
                borderTop: "1px solid #f1f5f9",
                display: "flex",
                alignItems: "center",
                gap: 6,
                fontSize: 11.5,
                color: "#64748b",
              }}
            >
              <Clock size={12.5} style={{ color: "#94a3b8" }} />
              <span>Số liệu tính đến: {chartRefreshTime}</span>
              <span
                onClick={handleRefreshChart}
                style={{
                  color: "var(--brand)",
                  cursor: "pointer",
                  fontWeight: 500,
                  marginLeft: 4,
                }}
                onMouseEnter={(e) => (e.currentTarget.style.textDecoration = "underline")}
                onMouseLeave={(e) => (e.currentTarget.style.textDecoration = "none")}
              >
                Tải lại
              </span>
            </div>
          </div>

          {/* CARD 3: Mua hàng (Teal Green Header #009688) */}
          <div
            style={{
              background: "#ffffff",
              borderRadius: 6,
              border: "1px solid #e2e8f0",
              boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
              display: "flex",
              flexDirection: "column",
              position: "relative",
            }}
          >
            {/* Header */}
            <div
              style={{
                background: "#009688",
                color: "#ffffff",
                padding: "8px 14px",
                borderTopLeftRadius: 5,
                borderTopRightRadius: 5,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                position: "relative",
              }}
            >
              <span style={{ fontWeight: 600, fontSize: 13.5 }}>Mua hàng</span>
              <div style={{ position: "relative" }}>
                <button
                  type="button"
                  onClick={() => {
                    setShowCurrencyMenu(false);
                    setOpenPeriodMenu(openPeriodMenu === "purchases" ? null : "purchases");
                  }}
                  style={{
                    background: "transparent",
                    border: "none",
                    color: "#ffffff",
                    fontSize: 12.5,
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 4,
                    cursor: "pointer",
                    padding: "2px 4px",
                  }}
                >
                  <span>{chartPeriods.purchases}</span>
                  <ChevronDown size={13} />
                </button>
                {openPeriodMenu === "purchases" && (
                  <div
                    style={{
                      position: "absolute",
                      right: 0,
                      top: "100%",
                      marginTop: 4,
                      background: "#ffffff",
                      border: "1px solid #cbd5e1",
                      borderRadius: 4,
                      boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
                      zIndex: 50,
                      minWidth: 120,
                      overflow: "hidden",
                    }}
                  >
                    {["Hôm nay", "Tuần này", "Tháng này", "Tháng trước", "Quý này", "Năm nay"].map((p) => (
                      <div
                        key={p}
                        onClick={() => {
                          setChartPeriods((prev) => ({ ...prev, purchases: p }));
                          setOpenPeriodMenu(null);
                          notify(`Đã lọc Mua hàng theo: ${p}`);
                        }}
                        style={{
                          padding: "6px 12px",
                          fontSize: 12.5,
                          color: chartPeriods.purchases === p ? "var(--brand)" : "#1e293b",
                          background: chartPeriods.purchases === p ? "#eff6ff" : "#ffffff",
                          cursor: "pointer",
                        }}
                      >
                        {p}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Body Rows (3 rows in screenshot) */}
            <div style={{ padding: "10px 14px", display: "flex", flexDirection: "column", gap: 8, flex: 1, justifyContent: "space-around" }}>
              {[
                { label: "Tổng tiền mua hàng", isDebt: false, tabTarget: "transactions", modal: () => setShowVoucherModal(true) },
                { label: "Đã thanh toán", isDebt: false, tabTarget: "transactions", modal: () => setShowVoucherModal(true) },
                { label: "Còn phải trả", isDebt: true, tabTarget: "reconciliation", modal: () => setShowReconciliationModal(true) },
              ].map((row, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    if (href) {
                      navigate(href(`/purchases/${row.tabTarget}`));
                    } else {
                      row.modal();
                    }
                  }}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "5px 4px",
                    cursor: "pointer",
                    fontSize: 13,
                    color: "#334155",
                    borderRadius: 4,
                    transition: "background 0.15s ease",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#f8fafc")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  <span>{row.label}</span>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                      color: row.isDebt ? "#ea580c" : "var(--brand)",
                      fontWeight: 600,
                      fontSize: 13,
                    }}
                  >
                    <span>0</span>
                    <ChevronRight size={13} />
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div
              style={{
                padding: "8px 14px",
                borderTop: "1px solid #f1f5f9",
                display: "flex",
                alignItems: "center",
                gap: 6,
                fontSize: 11.5,
                color: "#64748b",
              }}
            >
              <Clock size={12.5} style={{ color: "#94a3b8" }} />
              <span>Số liệu tính đến: {chartRefreshTime}</span>
              <span
                onClick={handleRefreshChart}
                style={{
                  color: "var(--brand)",
                  cursor: "pointer",
                  fontWeight: 500,
                  marginLeft: 4,
                }}
                onMouseEnter={(e) => (e.currentTarget.style.textDecoration = "underline")}
                onMouseLeave={(e) => (e.currentTarget.style.textDecoration = "none")}
              >
                Tải lại
              </span>
            </div>
          </div>
        </div>

        {/* BOTTOM ROW: 2 RANKING PANELS */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: 14,
          }}
        >
          {/* PANEL 1 (LEFT): Nhà cung cấp có công nợ lớn */}
          <div
            style={{
              background: "#ffffff",
              borderRadius: 6,
              border: "1px solid #e2e8f0",
              boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
              padding: "16px 18px 12px 18px",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              minHeight: 290,
              position: "relative",
            }}
          >
            {/* Top Header */}
            <div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
                <strong style={{ fontSize: 14.5, color: "#1e293b", fontWeight: 700 }}>
                  Nhà cung cấp có công nợ lớn
                </strong>
                <div style={{ position: "relative" }}>
                  <button
                    type="button"
                    onClick={() => {
                      setShowCurrencyMenu(false);
                      setOpenPeriodMenu(openPeriodMenu === "debt" ? null : "debt");
                    }}
                    style={{
                      background: "#ffffff",
                      border: "1px solid #cbd5e1",
                      borderRadius: 4,
                      padding: "3px 8px",
                      fontSize: 12,
                      color: "#475569",
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 4,
                      cursor: "pointer",
                    }}
                  >
                    <span>{chartPeriods.debt}</span>
                    <ChevronDown size={13} />
                  </button>
                  {openPeriodMenu === "debt" && (
                    <div
                      style={{
                        position: "absolute",
                        right: 0,
                        top: "100%",
                        marginTop: 4,
                        background: "#ffffff",
                        border: "1px solid #cbd5e1",
                        borderRadius: 4,
                        boxShadow: "0 4px 12px rgba(0,0,0,0.12)",
                        zIndex: 50,
                        minWidth: 120,
                        overflow: "hidden",
                      }}
                    >
                      {["Hôm nay", "Tuần này", "Tháng này", "Tháng trước", "Quý này", "Năm nay"].map((p) => (
                        <div
                          key={p}
                          onClick={() => {
                            setChartPeriods((prev) => ({ ...prev, debt: p }));
                            setOpenPeriodMenu(null);
                            notify(`Đã lọc công nợ nhà cung cấp theo: ${p}`);
                          }}
                          style={{
                            padding: "6px 12px",
                            fontSize: 12.5,
                            color: chartPeriods.debt === p ? "var(--brand)" : "#1e293b",
                            background: chartPeriods.debt === p ? "#eff6ff" : "#ffffff",
                            cursor: "pointer",
                          }}
                        >
                          {p}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Stats Row */}
              <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 18 }}>
                <div>
                  <div style={{ display: "flex", alignItems: "baseline" }}>
                    <span style={{ fontSize: 24, fontWeight: 700, color: "#0f172a", lineHeight: 1 }}>0</span>
                    <span style={{ fontSize: 14, fontWeight: 600, color: "#0f172a", marginLeft: 2 }}>đ</span>
                  </div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#94a3b8", letterSpacing: 0.5, marginTop: 4 }}>
                    TỔNG
                  </div>
                </div>
                <div style={{ fontSize: 12, color: "#64748b" }}>
                  Đvt: {currencyUnit.toLowerCase()}
                </div>
              </div>

              {/* 5 Rows with 5 Colored square bullets and rounded skeleton bars */}
              <div style={{ display: "flex", flexDirection: "column", gap: 14, marginBottom: 16 }}>
                {["#8b5cf6", "#6366f1", "#06b6d4", "#10b981", "#f59e0b"].map((color, idx) => (
                  <div key={idx} style={{ display: "flex", alignItems: "center", gap: 14 }}>
                    <div
                      style={{
                        width: 9,
                        height: 9,
                        borderRadius: 2,
                        background: color,
                        flexShrink: 0,
                      }}
                    />
                    <div style={{ flex: 2, height: 9, background: "#f1f5f9", borderRadius: 4 }} />
                    <div style={{ flex: 1.2, height: 9, background: "#f1f5f9", borderRadius: 4 }} />
                    <div style={{ flex: 1, height: 9, background: "#f1f5f9", borderRadius: 4 }} />
                  </div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div
              style={{
                borderTop: "1px solid #f1f5f9",
                paddingTop: 8,
                display: "flex",
                alignItems: "center",
                gap: 6,
                fontSize: 11.5,
                color: "#64748b",
              }}
            >
              <Clock size={12.5} style={{ color: "#94a3b8" }} />
              <span>Số liệu tính đến: {chartRefreshTime}</span>
              <span
                onClick={handleRefreshChart}
                style={{
                  color: "var(--brand)",
                  cursor: "pointer",
                  fontWeight: 500,
                  marginLeft: 4,
                }}
                onMouseEnter={(e) => (e.currentTarget.style.textDecoration = "underline")}
                onMouseLeave={(e) => (e.currentTarget.style.textDecoration = "none")}
              >
                Tải lại
              </span>
            </div>
          </div>

          {/* PANEL 2 (RIGHT): Nhà cung cấp có giá trị mua lớn */}
          <div
            style={{
              background: "#ffffff",
              borderRadius: 6,
              border: "1px solid #e2e8f0",
              boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
              padding: "16px 18px 12px 18px",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              minHeight: 290,
              position: "relative",
            }}
          >
            {/* Top Header */}
            <div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
                <strong style={{ fontSize: 14.5, color: "#1e293b", fontWeight: 700 }}>
                  Nhà cung cấp có giá trị mua lớn
                </strong>
                <div style={{ position: "relative" }}>
                  <button
                    type="button"
                    onClick={() => {
                      setShowCurrencyMenu(false);
                      setOpenPeriodMenu(openPeriodMenu === "buyValue" ? null : "buyValue");
                    }}
                    style={{
                      background: "#ffffff",
                      border: "1px solid #cbd5e1",
                      borderRadius: 4,
                      padding: "3px 8px",
                      fontSize: 12,
                      color: "#475569",
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 4,
                      cursor: "pointer",
                    }}
                  >
                    <span>{chartPeriods.buyValue}</span>
                    <ChevronDown size={13} />
                  </button>
                  {openPeriodMenu === "buyValue" && (
                    <div
                      style={{
                        position: "absolute",
                        right: 0,
                        top: "100%",
                        marginTop: 4,
                        background: "#ffffff",
                        border: "1px solid #cbd5e1",
                        borderRadius: 4,
                        boxShadow: "0 4px 12px rgba(0,0,0,0.12)",
                        zIndex: 50,
                        minWidth: 120,
                        overflow: "hidden",
                      }}
                    >
                      {["Hôm nay", "Tuần này", "Tháng này", "Tháng trước", "Quý này", "Năm nay"].map((p) => (
                        <div
                          key={p}
                          onClick={() => {
                            setChartPeriods((prev) => ({ ...prev, buyValue: p }));
                            setOpenPeriodMenu(null);
                            notify(`Đã lọc giá trị mua nhà cung cấp theo: ${p}`);
                          }}
                          style={{
                            padding: "6px 12px",
                            fontSize: 12.5,
                            color: chartPeriods.buyValue === p ? "var(--brand)" : "#1e293b",
                            background: chartPeriods.buyValue === p ? "#eff6ff" : "#ffffff",
                            cursor: "pointer",
                          }}
                        >
                          {p}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Stats Row */}
              <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 18 }}>
                <div>
                  <div style={{ display: "flex", alignItems: "baseline" }}>
                    <span style={{ fontSize: 24, fontWeight: 700, color: "#0f172a", lineHeight: 1 }}>0</span>
                    <span style={{ fontSize: 14, fontWeight: 600, color: "#0f172a", marginLeft: 2 }}>đ</span>
                  </div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#94a3b8", letterSpacing: 0.5, marginTop: 4 }}>
                    TỔNG
                  </div>
                </div>
                <div style={{ fontSize: 12, color: "#64748b" }}>
                  Đvt: {currencyUnit.toLowerCase()}
                </div>
              </div>

              {/* 5 Rows with 5 Colored square bullets and rounded skeleton bars */}
              <div style={{ display: "flex", flexDirection: "column", gap: 14, marginBottom: 16 }}>
                {["#8b5cf6", "#6366f1", "#06b6d4", "#10b981", "#f59e0b"].map((color, idx) => (
                  <div key={idx} style={{ display: "flex", alignItems: "center", gap: 14 }}>
                    <div
                      style={{
                        width: 9,
                        height: 9,
                        borderRadius: 2,
                        background: color,
                        flexShrink: 0,
                      }}
                    />
                    <div style={{ flex: 2, height: 9, background: "#f1f5f9", borderRadius: 4 }} />
                    <div style={{ flex: 1.2, height: 9, background: "#f1f5f9", borderRadius: 4 }} />
                    <div style={{ flex: 1, height: 9, background: "#f1f5f9", borderRadius: 4 }} />
                  </div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div
              style={{
                borderTop: "1px solid #f1f5f9",
                paddingTop: 8,
                display: "flex",
                alignItems: "center",
                gap: 6,
                fontSize: 11.5,
                color: "#64748b",
              }}
            >
              <Clock size={12.5} style={{ color: "#94a3b8" }} />
              <span>Số liệu tính đến: {chartRefreshTime}</span>
              <span
                onClick={handleRefreshChart}
                style={{
                  color: "var(--brand)",
                  cursor: "pointer",
                  fontWeight: 500,
                  marginLeft: 4,
                }}
                onMouseEnter={(e) => (e.currentTarget.style.textDecoration = "underline")}
                onMouseLeave={(e) => (e.currentTarget.style.textDecoration = "none")}
              >
                Tải lại
              </span>
            </div>
          </div>
        </div>

        {renderModals()}
      </div>
    );
  }

  // -------------------------------------------------------------------------
  // 1. TAB: HÀNG HÓA, DỊCH VỤ (EXACT MATCHING SCREENSHOT 2)
  // -------------------------------------------------------------------------
  if (tab === "inventory-items") {
    const filteredItems = inventoryItems.filter(
      (it) =>
        it.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        it.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
        it.nature.toLowerCase().includes(searchQuery.toLowerCase())
    );
    const totalQty = filteredItems.reduce((s, it) => s + (it.stockQty || 0), 0);
    const totalVal = filteredItems.reduce((s, it) => s + (it.stockValue || 0), 0);

    return (
      <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#ffffff" }}>
        {/* Subheader: < Lấy lại danh mục */}
        <div style={{ padding: "8px 16px 4px 16px" }}>
          <span
            style={{ fontSize: 12.5, color: "var(--brand)", cursor: "pointer", fontWeight: 500 }}
            onClick={() => notify("Đã lấy lại toàn bộ danh mục hàng hóa, dịch vụ.")}
          >
            {"< Lấy lại danh mục"}
          </span>
        </div>

        {/* KPI Cards: Hàng hóa sắp hết hàng & Hàng hóa hết hàng (Screenshot 2) */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, padding: "4px 16px 10px 16px" }}>
          {/* Card 1: Sắp hết hàng */}
          <div
            style={{
              border: "1px solid #fed7aa",
              borderRadius: 6,
              background: "#fffaf5",
              padding: "10px 14px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              position: "relative",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 34, height: 34, borderRadius: 6, background: "#ffedd5", display: "grid", placeItems: "center", color: "#f97316" }}>
                <Package size={18} />
              </div>
              <div>
                <span style={{ fontSize: 12, color: "#475569", display: "block" }}>Hàng hóa sắp hết hàng</span>
                <strong style={{ fontSize: 18, color: "#ea580c", fontWeight: 700 }}>0</strong>
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ background: "#334155", color: "#ffffff", padding: "3px 8px", borderRadius: 4, fontSize: 11, fontWeight: 500 }}>
                Bấm vào để lọc
              </span>
              <span style={{ fontSize: 11, color: "#94a3b8" }}>11:35</span>
            </div>
          </div>

          {/* Card 2: Hết hàng */}
          <div
            style={{
              border: "1px solid #fecaca",
              borderRadius: 6,
              background: "#fff5f5",
              padding: "10px 14px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 34, height: 34, borderRadius: 6, background: "#fee2e2", display: "grid", placeItems: "center", color: "#ef4444" }}>
                <AlertCircle size={18} />
              </div>
              <div>
                <span style={{ fontSize: 12, color: "#475569", display: "block" }}>Hàng hóa hết hàng</span>
                <strong style={{ fontSize: 18, color: "#dc2626", fontWeight: 700 }}>0</strong>
              </div>
            </div>
            <span style={{ fontSize: 11, color: "#94a3b8" }}>11:35</span>
          </div>
        </div>

        {/* Table Toolbar (Screenshot 2) */}
        <div style={{ padding: "6px 16px 10px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          {/* Search box */}
          <div style={{ display: "flex", alignItems: "center", border: "1px solid #cbd5e1", borderRadius: 4, padding: "0 10px", height: 30, width: 240, background: "#ffffff" }}>
            <Search size={14} style={{ color: "#94a3b8", marginRight: 6 }} />
            <input
              type="text"
              placeholder="Tìm kiếm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{ border: "none", outline: "none", fontSize: 12.5, width: "100%" }}
            />
          </div>

          {/* Right Action Buttons */}
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <button type="button" onClick={() => notify("Làm mới danh sách")} style={{ width: 30, height: 30, borderRadius: 4, border: "1px solid #cbd5e1", background: "#ffffff", display: "grid", placeItems: "center", cursor: "pointer", color: "#64748b" }} title="Làm mới">
              <RefreshCw size={14} />
            </button>
            <button type="button" style={{ width: 30, height: 30, borderRadius: 4, border: "1px solid #cbd5e1", background: "#ffffff", display: "grid", placeItems: "center", cursor: "pointer", color: "#64748b" }} title="Tùy chỉnh cột">
              <Columns3 size={14} />
            </button>
            <button type="button" style={{ width: 30, height: 30, borderRadius: 4, border: "1px solid #cbd5e1", background: "#ffffff", display: "grid", placeItems: "center", cursor: "pointer", color: "#64748b" }} title="Xuất khẩu">
              <FileSpreadsheet size={14} />
            </button>
            <button type="button" style={{ width: 30, height: 30, borderRadius: 4, border: "1px solid #cbd5e1", background: "#ffffff", display: "grid", placeItems: "center", cursor: "pointer", color: "#64748b" }} title="In">
              <Printer size={14} />
            </button>
            <button type="button" style={{ width: 30, height: 30, borderRadius: 4, border: "1px solid #cbd5e1", background: "#ffffff", display: "grid", placeItems: "center", cursor: "pointer", color: "#64748b" }} title="Bộ lọc">
              <Filter size={14} />
            </button>

            {/* Green Thêm button with caret (Opens MisaItemNatureDrawer with 6 options) */}
            <div style={{ display: "inline-flex", borderRadius: 4, overflow: "hidden", boxShadow: "0 1px 3px rgba(0,0,0,0.12)" }}>
              <button
                type="button"
                onClick={() => setShowNatureDrawer(true)}
                title="Chọn tính chất hàng hóa dịch vụ"
                style={{ height: 30, padding: "0 14px", background: "var(--brand)", color: "#ffffff", border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer" }}
              >
                Thêm
              </button>
              <button
                type="button"
                onClick={() => setShowNatureDrawer(true)}
                title="Chọn tính chất hàng hóa dịch vụ"
                style={{ height: 30, padding: "0 8px", background: "var(--brand)", color: "#ffffff", border: "none", borderLeft: "1px solid rgba(255,255,255,0.2)", cursor: "pointer" }}
              >
                <ChevronDown size={13} />
              </button>
            </div>

            <button type="button" style={{ width: 30, height: 30, borderRadius: 4, border: "1px solid #cbd5e1", background: "#ffffff", display: "grid", placeItems: "center", cursor: "pointer", color: "#64748b" }}>
              •••
            </button>
          </div>
        </div>

        {/* Data Table (Screenshot 2) */}
        <div style={{ flex: 1, overflow: "auto", borderTop: "1px solid #e2e8f0" }}>
          <table className="misa-table" style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5 }}>
            <thead>
              <tr style={{ background: "#e6f4ea", borderBottom: "1px solid #cbd5e1" }}>
                <th style={{ width: 40, textAlign: "center", padding: "8px 4px" }}>
                  <input type="checkbox" style={{ accentColor: "var(--brand)" }} />
                </th>
                <th style={{ padding: "8px 10px", textAlign: "left" }}>Tên</th>
                <th style={{ width: 140, padding: "8px 10px", textAlign: "left" }}>Mã</th>
                <th style={{ width: 180, padding: "8px 10px", textAlign: "left" }}>Giảm thuế theo quy định</th>
                <th style={{ width: 140, padding: "8px 10px", textAlign: "left" }}>Tính chất</th>
                <th style={{ width: 130, padding: "8px 10px", textAlign: "right" }}>Số lượng tồn</th>
                <th style={{ width: 140, padding: "8px 10px", textAlign: "right" }}>Giá trị tồn</th>
                <th style={{ width: 110, padding: "8px 10px", textAlign: "center" }}>Chức năng</th>
              </tr>
            </thead>
            <tbody>
              {filteredItems.map((item) => (
                <tr key={item.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                  <td style={{ textAlign: "center", padding: "8px 4px" }}>
                    <input type="checkbox" />
                  </td>
                  <td style={{ padding: "8px 10px", fontWeight: 500, color: "#1e293b" }}>{item.name}</td>
                  <td style={{ padding: "8px 10px", color: "#475569" }}>{item.code}</td>
                  <td style={{ padding: "8px 10px", color: "#64748b" }}>
                    <div style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                      <span>{item.vatPolicy}</span>
                      <FileText size={13} style={{ color: "var(--brand)" }} />
                    </div>
                  </td>
                  <td style={{ padding: "8px 10px", color: "#475569" }}>{item.nature}</td>
                  <td style={{ padding: "8px 10px", textAlign: "right" }}>
                    {new Intl.NumberFormat("vi-VN", { minimumFractionDigits: 2 }).format(item.stockQty)}
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 600 }}>
                    {formatVND(item.stockValue)}
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    <span
                      onClick={() => {
                        setEditingItem(item);
                        setSelectedNature(item.nature);
                        setShowItemModal(true);
                      }}
                      style={{ color: "var(--brand)", fontWeight: 600, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 2 }}
                    >
                      <span>Sửa</span>
                      <ChevronDown size={12} />
                    </span>
                  </td>
                </tr>
              ))}

              {/* Total row */}
              <tr style={{ background: "#f8fafc", fontWeight: 700, borderTop: "1px solid #cbd5e1" }}>
                <td></td>
                <td style={{ padding: "8px 10px", color: "#1e293b" }}>Tổng</td>
                <td colSpan={3}></td>
                <td style={{ padding: "8px 10px", textAlign: "right", color: "#059669" }}>
                  {new Intl.NumberFormat("vi-VN", { minimumFractionDigits: 2 }).format(totalQty)}
                </td>
                <td style={{ padding: "8px 10px", textAlign: "right", color: "#059669" }}>
                  {formatVND(totalVal)}
                </td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Bottom Pagination */}
        <div style={{ padding: "8px 16px", borderTop: "1px solid #e2e8f0", display: "flex", alignItems: "center", justifyContent: "space-between", background: "#ffffff" }}>
          <span style={{ fontSize: 12, color: "#64748b" }}>Tổng số: <strong>{filteredItems.length}</strong></span>
          <div style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 12, color: "#64748b" }}>
            <span>Số dòng/trang</span>
            <select style={{ height: 26, padding: "0 6px", borderRadius: 3, border: "1px solid #cbd5e1" }}>
              <option value={20}>20</option>
              <option value={50}>50</option>
            </select>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <ChevronLeft size={14} style={{ cursor: "pointer" }} />
              <span style={{ fontWeight: 600, color: "#111827" }}>1</span>
              <ChevronRight size={14} style={{ cursor: "pointer" }} />
            </div>
          </div>
        </div>

        {renderModals()}
      </div>
    );
  }

  // -------------------------------------------------------------------------
  // 2. TAB: ĐỐI CHIẾU CÔNG NỢ (EXACT MATCHING SCREENSHOT 3)
  // -------------------------------------------------------------------------
  if (tab === "reconciliation") {
    return (
      <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#ffffff" }}>
        {/* Toolbar */}
        <div style={{ padding: "12px 18px", borderBottom: "1px solid #e2e8f0", display: "flex", alignItems: "center", justifyContent: "space-between", background: "#f8fafc" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button
              type="button"
              onClick={() => setShowReconciliationModal(true)}
              style={{
                height: 32,
                padding: "0 16px",
                background: "var(--brand)",
                color: "#ffffff",
                border: "none",
                borderRadius: 4,
                fontSize: 13,
                fontWeight: 600,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
              }}
            >
              <Plus size={15} />
              <span>Thêm kỳ đối chiếu</span>
            </button>

            <button
              type="button"
              onClick={() => setShowAIModal(true)}
              style={{
                height: 32,
                padding: "0 12px",
                background: "linear-gradient(135deg, #7c3aed, #4f46e5)",
                color: "#ffffff",
                border: "none",
                borderRadius: 4,
                fontSize: 12.5,
                fontWeight: 600,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
              }}
            >
              <Sparkles size={14} />
              <span>Đối chiếu tự động</span>
            </button>
          </div>

          <div style={{ fontSize: 13, color: "#64748b" }}>
            Tự động đối chiếu file Excel sao kê công nợ từ Nhà cung cấp
          </div>
        </div>

        {/* Table / List View */}
        <div style={{ flex: 1, overflow: "auto", padding: 18 }}>
          <table className="misa-table" style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5 }}>
            <thead>
              <tr style={{ background: "#e6f4ea", borderBottom: "1px solid #cbd5e1" }}>
                <th style={{ width: 120, padding: "8px 10px", textAlign: "left" }}>Kỳ đối chiếu</th>
                <th style={{ padding: "8px 10px", textAlign: "left" }}>Nhà cung cấp</th>
                <th style={{ width: 100, padding: "8px 10px", textAlign: "center" }}>TK Nợ</th>
                <th style={{ width: 140, padding: "8px 10px", textAlign: "right" }}>Nợ NCC báo</th>
                <th style={{ width: 140, padding: "8px 10px", textAlign: "right" }}>Nợ trên sổ sách</th>
                <th style={{ width: 120, padding: "8px 10px", textAlign: "right" }}>Chênh lệch</th>
                <th style={{ width: 150, padding: "8px 10px", textAlign: "center" }}>Kết quả đối chiếu</th>
              </tr>
            </thead>
            <tbody>
              {reconciliations.map((r) => (
                <tr key={r.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                  <td style={{ padding: "8px 10px", fontWeight: 600, color: "var(--brand)" }}>{r.period}</td>
                  <td style={{ padding: "8px 10px", fontWeight: 500 }}>{r.supplier}</td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>{r.account}</td>
                  <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 600 }}>{formatVND(r.supplierDebt)} đ</td>
                  <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 600 }}>{formatVND(r.bookDebt)} đ</td>
                  <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 600, color: r.difference === 0 ? "#16a34a" : "#dc2626" }}>
                    {formatVND(r.difference)} đ
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    <span style={{ background: "#dcfce7", color: "#15803d", padding: "2px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 600 }}>
                      {r.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Bottom Button: Xem danh sách chứng từ (Screenshot 3) */}
        <div style={{ padding: "16px 0", textAlign: "center", borderTop: "1px solid #e2e8f0" }}>
          <button
            type="button"
            onClick={() => notify("Xem danh sách toàn bộ chứng từ công nợ...")}
            style={{
              height: 32,
              padding: "0 18px",
              background: "#ffffff",
              color: "#059669",
              border: "1px solid #10b981",
              borderRadius: 4,
              fontSize: 12.5,
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            Xem danh sách chứng từ
          </button>
        </div>

        {renderModals()}
      </div>
    );
  }

  // -------------------------------------------------------------------------
  // 3. TAB: GIẢM GIÁ HÀNG MUA (EXACT MATCHING SCREENSHOT 1)
  // -------------------------------------------------------------------------
  if (tab === "discounts") {
    return (
      <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#f8fafc" }}>
        <div style={{ padding: "10px 16px", background: "#ffffff", borderBottom: "1px solid #e2e8f0", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <button
            type="button"
            onClick={() => setShowDiscountModal(true)}
            style={{
              height: 32,
              padding: "0 14px",
              background: "var(--brand)",
              color: "#ffffff",
              border: "none",
              borderRadius: 4,
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
              display: "inline-flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            <Plus size={15} />
            <span>Thêm chứng từ giảm giá hàng mua</span>
          </button>
        </div>

        <div style={{ flex: 1, overflow: "auto", background: "#ffffff" }}>
          <table className="misa-table" style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5 }}>
            <thead>
              <tr style={{ background: "#e6f4ea", borderBottom: "1px solid #cbd5e1" }}>
                <th style={{ width: 40, textAlign: "center", padding: "8px 4px" }}><input type="checkbox" /></th>
                <th style={{ width: 110, padding: "8px 10px", textAlign: "left" }}>Số chứng từ</th>
                <th style={{ width: 100, padding: "8px 10px", textAlign: "center" }}>Ngày hạch toán</th>
                <th style={{ padding: "8px 10px", textAlign: "left" }}>Nhà cung cấp</th>
                <th style={{ padding: "8px 10px", textAlign: "left" }}>Lý do giảm giá</th>
                <th style={{ width: 130, padding: "8px 10px", textAlign: "right" }}>Tổng tiền giảm</th>
                <th style={{ width: 130, padding: "8px 10px", textAlign: "center" }}>Phương thức</th>
              </tr>
            </thead>
            <tbody>
              {discounts.map((d) => (
                <tr key={d.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                  <td style={{ textAlign: "center", padding: "8px 4px" }}><input type="checkbox" /></td>
                  <td style={{ padding: "8px 10px" }}>
                    <span style={{ color: "var(--brand)", fontWeight: 600, cursor: "pointer" }} onClick={() => setShowDiscountModal(true)}>
                      {d.code}
                    </span>
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>{d.date}</td>
                  <td style={{ padding: "8px 10px", fontWeight: 500 }}>{d.supplier}</td>
                  <td style={{ padding: "8px 10px" }}>{d.reason}</td>
                  <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 700, color: "#b91c1c" }}>{formatVND(d.amount)} đ</td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    <span style={{ background: "#e0f2fe", color: "var(--brand-hover)", padding: "2px 8px", borderRadius: 10, fontSize: 11, fontWeight: 600 }}>
                      {apiStatus("/api/v1/purchases/purchase-discounts/", "discounts", d.id, d.status)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {renderModals()}
      </div>
    );
  }

  // -------------------------------------------------------------------------
  // 4. TAB: ĐƠN MUA HÀNG (ORDERS)
  // -------------------------------------------------------------------------
  if (tab === "orders") {
    return (
      <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#f8fafc" }}>
        <div style={{ padding: "10px 16px", background: "#ffffff", borderBottom: "1px solid #e2e8f0", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <button
              type="button"
              onClick={() => setShowOrderModal(true)}
              style={{ height: 32, padding: "0 14px", background: "var(--brand)", color: "#ffffff", border: "none", borderRadius: 4, fontSize: 13, fontWeight: 600, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6 }}
            >
              <Plus size={15} />
              <span>Thêm đơn mua hàng</span>
            </button>
            <button
              type="button"
              onClick={() => setShowAIModal(true)}
              style={{ height: 32, padding: "0 12px", background: "linear-gradient(135deg, #7c3aed, #4f46e5)", color: "#ffffff", border: "none", borderRadius: 4, fontSize: 12.5, fontWeight: 600, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6 }}
            >
              <Sparkles size={14} />
              <span className="misa-hidden-ai-marker" />
            </button>
          </div>
        </div>

        <div style={{ flex: 1, overflow: "auto", background: "#ffffff" }}>
          <table className="misa-table" style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5 }}>
            <thead>
              <tr style={{ background: "#e6f4ea", borderBottom: "1px solid #cbd5e1" }}>
                <th style={{ width: 40, textAlign: "center", padding: "8px 4px" }}><input type="checkbox" /></th>
                <th style={{ width: 110, padding: "8px 10px", textAlign: "left" }}>Số đơn hàng</th>
                <th style={{ width: 100, padding: "8px 10px", textAlign: "center" }}>Ngày đơn</th>
                <th style={{ width: 110, padding: "8px 10px", textAlign: "center" }}>Hạn giao</th>
                <th style={{ padding: "8px 10px", textAlign: "left" }}>Nhà cung cấp</th>
                <th style={{ padding: "8px 10px", textAlign: "left" }}>Diễn giải</th>
                <th style={{ width: 120, padding: "8px 10px", textAlign: "right" }}>Tổng tiền</th>
                <th style={{ width: 120, padding: "8px 10px", textAlign: "center" }}>Tình trạng</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((po) => (
                <tr key={po.id} onClick={() => setSelectedRowId(po.id)} style={{ borderBottom: "1px solid #f1f5f9", background: selectedRowId === po.id ? "rgba(0, 176, 107, 0.08)" : "#ffffff", cursor: "pointer" }}>
                  <td style={{ textAlign: "center", padding: "8px 4px" }}><input type="checkbox" checked={selectedRowId === po.id} onChange={() => {}} /></td>
                  <td style={{ padding: "8px 10px" }}>
                    <span style={{ color: "var(--brand)", fontWeight: 600, cursor: "pointer" }} onClick={() => setShowOrderModal(true)}>
                      {po.code}
                    </span>
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>{po.date}</td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>{po.deliveryDate}</td>
                  <td style={{ padding: "8px 10px", fontWeight: 500 }}>{po.supplier}</td>
                  <td style={{ padding: "8px 10px", color: "#475569" }}>{po.description}</td>
                  <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 700, color: "#059669" }}>{formatVND(po.amount)} đ</td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    <span style={{ background: "#dcfce7", color: "#15803d", padding: "2px 8px", borderRadius: 10, fontSize: 11, fontWeight: 600 }}>{apiStatus("/api/v1/purchases/purchase-orders/", "orders", po.id, po.status, false)}</span>
                  </td>
                </tr>
              ))}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={8} style={{ padding: "50px 20px", textAlign: "center", color: "#64748b" }}>
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
                      <ShoppingCart size={38} strokeWidth={1.4} style={{ color: "#94a3b8" }} />
                      <strong style={{ fontSize: 14, color: "#334155" }}>
                        Chưa có đơn mua hàng nào
                      </strong>
                      <span style={{ fontSize: 12.5, color: "#64748b" }}>
                        Nhấn nút <b>"Thêm đơn mua hàng"</b> để bắt đầu lập đơn
                      </span>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {renderModals()}
      </div>
    );
  }

  // -------------------------------------------------------------------------
  // 5. TAB: HỢP ĐỒNG MUA (CONTRACTS)
  // -------------------------------------------------------------------------
  if (tab === "contracts") {
    return (
      <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#f8fafc" }}>
        <div style={{ padding: "10px 16px", background: "#ffffff", borderBottom: "1px solid #e2e8f0", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <button type="button" onClick={() => setShowContractModal(true)} style={{ height: 32, padding: "0 14px", background: "var(--brand)", color: "#ffffff", border: "none", borderRadius: 4, fontSize: 13, fontWeight: 600, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6 }}>
            <Plus size={15} />
            <span>Thêm hợp đồng mua</span>
          </button>
        </div>

        <div style={{ flex: 1, overflow: "auto", background: "#ffffff" }}>
          <table className="misa-table" style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5 }}>
            <thead>
              <tr style={{ background: "#e6f4ea", borderBottom: "1px solid #cbd5e1" }}>
                <th style={{ width: 40, textAlign: "center" }}><input type="checkbox" /></th>
                <th style={{ width: 120, padding: "8px 10px" }}>Số hợp đồng</th>
                <th style={{ width: 110, padding: "8px 10px", textAlign: "center" }}>Ngày ký</th>
                <th style={{ padding: "8px 10px" }}>Nhà cung cấp</th>
                <th style={{ width: 140, padding: "8px 10px", textAlign: "right" }}>Giá trị HĐ</th>
                <th style={{ width: 130, padding: "8px 10px", textAlign: "center" }}>Tình trạng HĐ</th>
                <th style={{ width: 130, padding: "8px 10px", textAlign: "center" }}>Tình trạng giao</th>
              </tr>
            </thead>
            <tbody>
              {contracts.map((c) => (
                <tr key={c.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                  <td style={{ textAlign: "center" }}><input type="checkbox" /></td>
                  <td style={{ padding: "8px 10px" }}>
                    <span style={{ color: "var(--brand)", fontWeight: 600, cursor: "pointer" }} onClick={() => setShowContractModal(true)}>
                      {c.code}
                    </span>
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>{c.date}</td>
                  <td style={{ padding: "8px 10px", fontWeight: 500 }}>{c.supplier}</td>
                  <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 700, color: "#059669" }}>{formatVND(c.amount)} đ</td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    <span style={{ background: "#fef3c7", color: "#92400e", padding: "2px 8px", borderRadius: 10, fontSize: 11, fontWeight: 600 }}>{apiStatus("/api/v1/purchases/purchase-contracts/", "contracts", c.id, c.status, false)}</span>
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    <span style={{ background: "#f1f5f9", color: "#475569", padding: "2px 8px", borderRadius: 10, fontSize: 11, fontWeight: 600 }}>{c.deliveryStatus}</span>
                  </td>
                </tr>
              ))}
              {contracts.length === 0 && (
                <tr>
                  <td colSpan={7} style={{ padding: "50px 20px", textAlign: "center", color: "#64748b" }}>
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
                      <FileCheck size={38} strokeWidth={1.4} style={{ color: "#94a3b8" }} />
                      <strong style={{ fontSize: 14, color: "#334155" }}>
                        Chưa có hợp đồng mua hàng nào
                      </strong>
                      <span style={{ fontSize: 12.5, color: "#64748b" }}>
                        Nhấn nút <b>"Thêm hợp đồng mua"</b> để bắt đầu tạo hợp đồng
                      </span>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {renderModals()}
      </div>
    );
  }

  // -------------------------------------------------------------------------
  // 6. TAB: MUA HÀNG (TRANSACTIONS)
  // -------------------------------------------------------------------------
  if (tab === "transactions") {
    return (
      <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#f8fafc" }}>
        <div style={{ padding: "10px 16px", background: "#ffffff", borderBottom: "1px solid #e2e8f0", display: "flex", alignItems: "center", justifyContent: "space-between", position: "relative" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, position: "relative" }}>
            {/* Button 1: Nhập nhanh */}
            <button
              type="button"
              onClick={() => setShowAIModal(true)}
              style={{
                height: 32,
                padding: "0 14px 0 8px",
                background: "linear-gradient(90deg, #3b82f6 0%, #8b5cf6 50%, #d946ef 100%)",
                color: "#ffffff",
                border: "none",
                borderRadius: 4,
                fontSize: 13,
                fontWeight: 600,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                boxShadow: "0 2px 4px rgba(139, 92, 246, 0.25)",
                transition: "opacity 0.2s",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.92")}
              onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
            >
              <div
                style={{
                  width: 20,
                  height: 20,
                  borderRadius: "50%",
                  background: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  overflow: "hidden",
                  boxShadow: "0 0 0 1.5px rgba(255,255,255,0.6)",
                }}
              >
                <Sparkles size={13} style={{ color: "#8b5cf6" }} />
              </div>
              <span className="misa-hidden-ai-marker" />
            </button>

            {/* Button 2: Split Button "Thêm ▾" */}
            <div style={{ position: "relative", display: "inline-flex" }}>
              <div
                style={{
                  display: "inline-flex",
                  alignItems: "stretch",
                  borderRadius: 4,
                  overflow: "hidden",
                  boxShadow: "0 1px 2px rgba(0, 0, 0, 0.05)",
                }}
              >
                <button
                  type="button"
                  onClick={() => setShowAddPurchaseMenu(!showAddPurchaseMenu)}
                  style={{
                    height: 32,
                    padding: "0 14px",
                    background: "var(--brand)",
                    color: "#ffffff",
                    border: "none",
                    fontSize: 13,
                    fontWeight: 600,
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    borderRight: "1px solid rgba(255, 255, 255, 0.25)",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "var(--brand)")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "var(--brand)")}
                >
                  Thêm
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddPurchaseMenu(!showAddPurchaseMenu)}
                  style={{
                    height: 32,
                    padding: "0 8px",
                    background: "var(--brand)",
                    color: "#ffffff",
                    border: "none",
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "var(--brand)")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "var(--brand)")}
                >
                  <ChevronDown size={14} />
                </button>
              </div>

              {/* Dropdown Menu (Matching Screenshot 2) */}
              {showAddPurchaseMenu && (
                <>
                  <div
                    onClick={() => setShowAddPurchaseMenu(false)}
                    style={{ position: "fixed", inset: 0, zIndex: 99 }}
                  />
                  <div
                    style={{
                      position: "absolute",
                      left: 0,
                      top: "calc(100% + 4px)",
                      background: "#ffffff",
                      borderRadius: 6,
                      border: "1px solid #e2e8f0",
                      boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.15), 0 8px 10px -6px rgba(0, 0, 0, 0.1)",
                      zIndex: 100,
                      minWidth: 260,
                      padding: "6px 0",
                    }}
                  >
                    {[
                      {
                        label: "Chứng từ mua hàng",
                        onClick: () => {
                          setShowAddPurchaseMenu(false);
                          setShowVoucherModal(true);
                        },
                      },
                      {
                        label: "Chứng từ mua dịch vụ",
                        onClick: () => {
                          setShowAddPurchaseMenu(false);
                          setShowServiceModal(true);
                        },
                      },
                      {
                        label: "Chứng từ mua hàng nhiều hóa đơn",
                        onClick: () => {
                          setShowAddPurchaseMenu(false);
                          setShowMultiInvoiceModal(true);
                        },
                      },
                      {
                        label: "Trả tiền theo hóa đơn",
                        onClick: () => {
                          setShowAddPurchaseMenu(false);
                          setShowSupplierPaymentModal(true);
                        },
                      },
                      {
                        label: "Lập từ hóa đơn đầu vào điện tử",
                        onClick: () => {
                          setShowAddPurchaseMenu(false);
                          notify("Đang đồng bộ dữ liệu Hóa đơn điện tử đầu vào...");
                        },
                      },
                    ].map((item, idx) => (
                      <div
                        key={idx}
                        onClick={item.onClick}
                        style={{
                          padding: "9px 18px",
                          fontSize: 13,
                          color: "#1e293b",
                          cursor: "pointer",
                          transition: "background 0.12s, color 0.12s",
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.background = "#f1f5f9";
                          e.currentTarget.style.color = "var(--brand)";
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.background = "transparent";
                          e.currentTarget.style.color = "#1e293b";
                        }}
                      >
                        {item.label}
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Button 3: Nhập từ Excel */}
            <button
              type="button"
              onClick={() => notify("Tính năng Nhập từ Excel đang được tải...")}
              style={{
                height: 32,
                padding: "0 14px",
                background: "#ffffff",
                color: "#1e293b",
                border: "1px solid #cbd5e1",
                borderRadius: 4,
                fontSize: 13,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                transition: "background 0.15s, border-color 0.15s",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "#f8fafc";
                e.currentTarget.style.borderColor = "#94a3b8";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "#ffffff";
                e.currentTarget.style.borderColor = "#cbd5e1";
              }}
            >
              Nhập từ Excel
            </button>

            {/* Button 4: Tiện ích ▾ (5 Tiện ích mua hàng chuẩn MISA) */}
            <div style={{ position: "relative" }}>
              <button
                type="button"
                onClick={() => setShowUtilityMenu(!showUtilityMenu)}
                style={{
                  height: 32,
                  padding: "0 12px",
                  background: "#ffffff",
                  color: "#1e293b",
                  border: "1px solid #cbd5e1",
                  borderRadius: 4,
                  fontSize: 13,
                  cursor: "pointer",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  fontWeight: 500,
                  transition: "background 0.15s, border-color 0.15s",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = "#f8fafc";
                  e.currentTarget.style.borderColor = "#94a3b8";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "#ffffff";
                  e.currentTarget.style.borderColor = "#cbd5e1";
                }}
              >
                <span>Tiện ích</span>
                <ChevronDown size={14} style={{ color: "#64748b" }} />
              </button>

              {showUtilityMenu && (
                <>
                  <div
                    onClick={() => setShowUtilityMenu(false)}
                    style={{ position: "fixed", inset: 0, zIndex: 45 }}
                  />
                  <div
                    style={{
                      position: "absolute",
                      top: "calc(100% + 4px)",
                      right: 0,
                      background: "#ffffff",
                      borderRadius: 6,
                      boxShadow: "0 10px 25px rgba(0,0,0,0.15)",
                      border: "1px solid #e2e8f0",
                      width: 290,
                      zIndex: 50,
                      padding: "4px 0",
                    }}
                  >
                    {[
                      {
                        label: "Đối trừ chứng từ",
                        desc: "Đối trừ thanh toán cho 1 NCC cụ thể (TK 331)",
                        onClick: () => {
                          setShowUtilityMenu(false);
                          setShowDebtOffsetModal(true);
                        },
                      },
                      {
                        label: "Đối trừ chứng từ nhiều đối tượng",
                        desc: "Tự động đối trừ công nợ theo danh sách NCC",
                        onClick: () => {
                          setShowUtilityMenu(false);
                          setShowMultiDebtOffsetModal(true);
                        },
                      },
                      {
                        label: "Bỏ đối trừ",
                        desc: "Hủy kết quả đối trừ của 1 NCC",
                        onClick: () => {
                          setShowUtilityMenu(false);
                          setShowUnOffsetModal(true);
                        },
                      },
                      {
                        label: "Bỏ đối trừ chứng từ nhiều đối tượng",
                        desc: "Hủy hàng loạt chứng từ đã đối trừ",
                        onClick: () => {
                          setShowUtilityMenu(false);
                          setShowMultiUnOffsetModal(true);
                        },
                      },
                      {
                        label: "Bù trừ công nợ",
                        desc: "Bù trừ giữa TK 131 và TK 331 (Khách hàng kiêm NCC)",
                        onClick: () => {
                          setShowUtilityMenu(false);
                          setShowDebtClearingModal(true);
                        },
                      },
                    ].map((item, idx) => (
                      <div
                        key={idx}
                        onClick={item.onClick}
                        style={{
                          padding: "8px 14px",
                          cursor: "pointer",
                          transition: "background 0.12s",
                          borderBottom: idx < 4 ? "1px solid #f8fafc" : "none",
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.background = "#f1f5f9";
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.background = "transparent";
                        }}
                      >
                        <div style={{ fontSize: 13, fontWeight: 500, color: "#1e293b" }}>{item.label}</div>
                        <div style={{ fontSize: 11.5, color: "#64748b" }}>{item.desc}</div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        <div style={{ flex: 1, overflow: "auto", background: "#ffffff" }}>
          <table className="misa-table" style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5 }}>
            <thead>
              <tr style={{ background: "#e6f4ea", borderBottom: "1px solid #cbd5e1" }}>
                <th style={{ width: 40, textAlign: "center" }}><input type="checkbox" /></th>
                <th style={{ width: 110, padding: "8px 10px" }}>Số chứng từ</th>
                <th style={{ width: 100, padding: "8px 10px", textAlign: "center" }}>Ngày hạch toán</th>
                <th style={{ padding: "8px 10px" }}>Loại mua hàng</th>
                <th style={{ padding: "8px 10px" }}>Nhà cung cấp</th>
                <th style={{ padding: "8px 10px" }}>Diễn giải</th>
                <th style={{ width: 130, padding: "8px 10px", textAlign: "right" }}>Tổng tiền</th>
                <th style={{ width: 120, padding: "8px 10px", textAlign: "center" }}>Trạng thái</th>
              </tr>
            </thead>
            <tbody>
              {vouchers.map((v) => (
                <tr key={v.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                  <td style={{ textAlign: "center" }}><input type="checkbox" /></td>
                  <td style={{ padding: "8px 10px" }}>
                    <span style={{ color: "var(--brand)", fontWeight: 600, cursor: "pointer" }} onClick={() => { setEditingVoucher(apiRows.vouchers?.find((row) => row.id === v.id) || null); setShowVoucherModal(true); }}>
                      {v.code}
                    </span>
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>{v.date}</td>
                  <td style={{ padding: "8px 10px", color: "#475569" }}>{v.kind}</td>
                  <td style={{ padding: "8px 10px", fontWeight: 500 }}>{v.supplier}</td>
                  <td style={{ padding: "8px 10px" }}>{v.description}</td>
                  <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 700, color: "#059669" }}>{formatVND(v.amount)} đ</td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    <span style={{ background: v.status === "Đã thanh toán" ? "#dcfce7" : "#fee2e2", color: v.status === "Đã thanh toán" ? "#15803d" : "#b91c1c", padding: "2px 8px", borderRadius: 10, fontSize: 11, fontWeight: 600 }}>{apiStatus((v as any).apiPath || "/api/v1/purchases/goods-purchases/", (v as any).apiKey || "vouchers", v.id, v.status)}</span>
                  </td>
                </tr>
              ))}
              {vouchers.length === 0 && (
                <tr>
                  <td colSpan={8} style={{ padding: "50px 20px", textAlign: "center", color: "#64748b" }}>
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
                      <ShoppingCart size={38} strokeWidth={1.4} style={{ color: "#94a3b8" }} />
                      <strong style={{ fontSize: 14, color: "#334155" }}>
                        Chưa có chứng từ mua hàng trong kỳ kế toán này
                      </strong>
                      <span style={{ fontSize: 12.5, color: "#64748b" }}>
                        Nhấn nút <b>"Thêm"</b> trên thanh công cụ để tạo mới
                      </span>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {renderModals()}
      </div>
    );
  }

  // -------------------------------------------------------------------------
  // 7. TAB: TRẢ LẠI HÀNG MUA (RETURNS)
  // -------------------------------------------------------------------------
  if (tab === "returns") {
    return (
      <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#f8fafc" }}>
        <div style={{ padding: "10px 16px", background: "#ffffff", borderBottom: "1px solid #e2e8f0", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <button type="button" onClick={() => setShowReturnModal(true)} style={{ height: 32, padding: "0 14px", background: "var(--brand)", color: "#ffffff", border: "none", borderRadius: 4, fontSize: 13, fontWeight: 600, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6 }}>
            <Plus size={15} />
            <span>Thêm chứng từ trả lại hàng</span>
          </button>
        </div>

        <div style={{ flex: 1, overflow: "auto", background: "#ffffff" }}>
          <table className="misa-table" style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5 }}>
            <thead>
              <tr style={{ background: "#e6f4ea", borderBottom: "1px solid #cbd5e1" }}>
                <th style={{ width: 40, textAlign: "center" }}><input type="checkbox" /></th>
                <th style={{ width: 110, padding: "8px 10px" }}>Số chứng từ</th>
                <th style={{ width: 100, padding: "8px 10px", textAlign: "center" }}>Ngày hạch toán</th>
                <th style={{ padding: "8px 10px" }}>Nhà cung cấp</th>
                <th style={{ padding: "8px 10px" }}>Lý do trả lại</th>
                <th style={{ width: 130, padding: "8px 10px", textAlign: "right" }}>Tổng tiền</th>
                <th style={{ width: 130, padding: "8px 10px", textAlign: "center" }}>Phương thức</th>
              </tr>
            </thead>
            <tbody>
              {returns.map((r) => (
                <tr key={r.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                  <td style={{ textAlign: "center" }}><input type="checkbox" /></td>
                  <td style={{ padding: "8px 10px" }}>
                    <span style={{ color: "var(--brand)", fontWeight: 600, cursor: "pointer" }} onClick={() => setShowReturnModal(true)}>
                      {r.code}
                    </span>
                  </td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>{r.date}</td>
                  <td style={{ padding: "8px 10px", fontWeight: 500 }}>{r.supplier}</td>
                  <td style={{ padding: "8px 10px" }}>{r.reason}</td>
                  <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 700, color: "#b91c1c" }}>{formatVND(r.amount)} đ</td>
                  <td style={{ padding: "8px 10px", textAlign: "center" }}>
                    <span style={{ background: "#e0f2fe", color: "var(--brand-hover)", padding: "2px 8px", borderRadius: 10, fontSize: 11, fontWeight: 600 }}>{apiStatus("/api/v1/purchases/purchase-returns/", "returns", r.id, r.status)}</span>
                  </td>
                </tr>
              ))}
              {returns.length === 0 && (
                <tr>
                  <td colSpan={7} style={{ padding: "50px 20px", textAlign: "center", color: "#64748b" }}>
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
                      <RotateCcw size={38} strokeWidth={1.4} style={{ color: "#94a3b8" }} />
                      <strong style={{ fontSize: 14, color: "#334155" }}>
                        Chưa có chứng từ trả lại hàng mua
                      </strong>
                      <span style={{ fontSize: 12.5, color: "#64748b" }}>
                        Nhấn nút <b>"Thêm chứng từ trả lại hàng"</b> để bắt đầu lập chứng từ
                      </span>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {renderModals()}
      </div>
    );
  }

  // -------------------------------------------------------------------------
  // 7.1. TAB: NHẬN HÓA ĐƠN (EXACT MATCHING SCREENSHOT 1 & 2)
  // -------------------------------------------------------------------------
  if (tab === "invoices") {
    // Mode 1: Empty guide view matching Screenshot 2
    if (receiveInvoiceViewMode === "empty_guide") {
      return (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            height: "100%",
            background: "#f1f5f9",
            padding: "14px 18px",
            boxSizing: "border-box",
            fontFamily: "Roboto, Arial, sans-serif",
          }}
        >
          <div
            style={{
              flex: 1,
              background: "#ffffff",
              borderRadius: 8,
              border: "1px solid #e2e8f0",
              boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              position: "relative",
              overflow: "hidden",
            }}
          >
            {/* Center Area with exact Illustration from Screenshot 2 */}
            <div
              style={{
                flex: 1,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                padding: "30px 20px",
                textAlign: "center",
              }}
            >
              {/* SVG Vector Graphic Matching Image 2 */}
              <div
                style={{
                  width: 360,
                  maxWidth: "100%",
                  height: 180,
                  position: "relative",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <svg
                  viewBox="0 0 360 180"
                  width="100%"
                  height="100%"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <defs>
                    <filter
                      id="card-shadow"
                      x="-10%"
                      y="-10%"
                      width="125%"
                      height="125%"
                      filterUnits="userSpaceOnUse"
                    >
                      <feDropShadow
                        dx="0"
                        dy="3"
                        stdDeviation="5"
                        floodColor="#000000"
                        floodOpacity="0.06"
                      />
                    </filter>
                  </defs>

                  {/* Left Floating Card: Bill with $ */}
                  <g filter="url(#card-shadow)">
                    <rect
                      x="32"
                      y="32"
                      width="66"
                      height="84"
                      rx="7"
                      fill="#ffffff"
                      stroke="#e2e8f0"
                      strokeWidth="1.2"
                    />
                    {/* Bold green $ sign */}
                    <text
                      x="65"
                      y="74"
                      fill="var(--brand)"
                      fontSize="28"
                      fontWeight="800"
                      textAnchor="middle"
                      fontFamily="Roboto, Arial, sans-serif"
                    >
                      $
                    </text>
                    {/* Bill text lines */}
                    <rect x="46" y="86" width="38" height="4" rx="2" fill="var(--brand)" />
                    <rect x="46" y="94" width="26" height="4" rx="2" fill="var(--brand)" />
                  </g>

                  {/* Right Floating Card: Analytics with chart and $ badge */}
                  <g filter="url(#card-shadow)">
                    <rect
                      x="262"
                      y="32"
                      width="66"
                      height="84"
                      rx="7"
                      fill="#ffffff"
                      stroke="#e2e8f0"
                      strokeWidth="1.2"
                    />
                    {/* Circular Green $ Badge */}
                    <circle cx="295" cy="54" r="12" fill="var(--brand)" />
                    <text
                      x="295"
                      y="59"
                      fill="#ffffff"
                      fontSize="12.5"
                      fontWeight="800"
                      textAnchor="middle"
                      fontFamily="Roboto, Arial, sans-serif"
                    >
                      $
                    </text>
                    {/* 3 Bar Chart Columns */}
                    <rect x="279" y="82" width="7" height="20" rx="2" fill="var(--brand)" />
                    <rect x="291" y="74" width="7" height="28" rx="2" fill="var(--brand)" />
                    <rect x="303" y="78" width="7" height="24" rx="2" fill="var(--brand)" />
                  </g>

                  {/* Curved Connecting Dashed Lines */}
                  <path
                    d="M 65 116 C 65 146, 120 152, 146 138"
                    stroke="#cbd5e1"
                    strokeWidth="1.5"
                    strokeDasharray="3 3"
                    fill="none"
                  />
                  <path
                    d="M 295 116 C 295 146, 240 152, 214 138"
                    stroke="#cbd5e1"
                    strokeWidth="1.5"
                    strokeDasharray="3 3"
                    fill="none"
                  />

                  {/* Floating dots & sparkles */}
                  <circle cx="118" cy="148" r="2" fill="#94a3b8" />
                  <circle cx="242" cy="148" r="2" fill="#94a3b8" />
                  <polygon points="98,140 101,143 98,146 95,143" fill="var(--brand)" />
                  <polygon points="262,140 265,143 262,146 259,143" fill="var(--brand)" />
                  <polygon points="144,72 146,74 144,76 142,74" fill="#94a3b8" />
                  <polygon points="216,68 218,70 216,72 214,70" fill="#94a3b8" />
                  <polygon points="65,22 67,24 65,26 63,24" fill="var(--brand)" />
                  <polygon points="295,20 297,22 295,24 293,22" fill="var(--brand)" />

                  {/* Female Accountant Character in Green working at Laptop */}
                  <g id="accountant-character">
                    {/* Dark flowing hair */}
                    <path
                      d="M 166 78 C 166 60, 194 60, 194 78 C 196 86, 204 102, 198 116 C 193 112, 190 100, 190 94 L 170 94 C 170 100, 167 112, 162 116 C 156 102, 164 86, 166 78 Z"
                      fill="#1e293b"
                    />

                    {/* Face & Neck */}
                    <ellipse cx="180" cy="76" rx="9.5" ry="11.5" fill="#fed7aa" />
                    <rect x="177" y="86" width="6" height="7" fill="#fed7aa" />

                    {/* Hair fringe / bangs */}
                    <path
                      d="M 170.5 73 Q 180 69 187 75 Q 181 79 174 77 Z"
                      fill="#1e293b"
                    />

                    {/* Emerald Green Blouse */}
                    <path
                      d="M 164 93 Q 180 89 196 93 L 203 128 L 157 128 Z"
                      fill="var(--brand)"
                    />
                    {/* White V-neck collar */}
                    <path d="M 176 91 L 180 98 L 184 91 Z" fill="#ffffff" />

                    {/* Sleeves and Arms */}
                    <path
                      d="M 162 101 L 151 118 L 164 122"
                      stroke="var(--brand)"
                      strokeWidth="5.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      fill="none"
                    />
                    <path
                      d="M 198 101 L 209 118 L 196 122"
                      stroke="var(--brand)"
                      strokeWidth="5.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      fill="none"
                    />

                    {/* Hands */}
                    <circle cx="166" cy="122" r="3.5" fill="#fed7aa" />
                    <circle cx="194" cy="122" r="3.5" fill="#fed7aa" />

                    {/* Laptop Screen (angled back) */}
                    <polygon
                      points="154,120 206,120 201,102 159,102"
                      fill="#cbd5e1"
                      stroke="#94a3b8"
                      strokeWidth="1"
                    />
                    <polygon
                      points="156.5,118 203.5,118 199.5,104 160.5,104"
                      fill="#f8fafc"
                    />

                    {/* Laptop Keyboard Base */}
                    <polygon
                      points="146,130 214,130 206,120 154,120"
                      fill="#e2e8f0"
                      stroke="#cbd5e1"
                      strokeWidth="1"
                    />
                    <rect x="175" y="125" width="10" height="3" rx="1" fill="#cbd5e1" />
                  </g>
                </svg>
              </div>

              {/* Title from Screenshot 2 */}
              <h2
                style={{
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#1e293b",
                  marginTop: 22,
                  marginBottom: 16,
                  lineHeight: 1.4,
                  maxWidth: 620,
                }}
              >
                Nhận và quản lý các hóa đơn từ các giao dịch mua hàng với nhà cung cấp
              </h2>

              {/* Action Button: Thêm (solid green) */}
              <button
                type="button"
                onClick={() => setShowReceiveInvoiceModal(true)}
                style={{
                  height: 34,
                  padding: "0 34px",
                  background: "var(--brand)",
                  color: "#ffffff",
                  border: "none",
                  borderRadius: 4,
                  fontSize: 13.5,
                  fontWeight: 600,
                  cursor: "pointer",
                  boxShadow: "0 2px 4px rgba(0, 176, 107, 0.25)",
                  transition: "background 0.15s ease",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "var(--brand)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "var(--brand)")}
              >
                Thêm
              </button>
            </div>

            {/* Bottom Button: Xem danh sách chứng từ (Screenshot 2) */}
            <div
              style={{
                padding: "16px 0 20px 0",
                textAlign: "center",
              }}
            >
              <button
                type="button"
                onClick={() => setReceiveInvoiceViewMode("list")}
                style={{
                  height: 32,
                  padding: "0 20px",
                  background: "#ffffff",
                  color: "var(--brand)",
                  border: "1px solid var(--brand)",
                  borderRadius: 4,
                  fontSize: 12.5,
                  fontWeight: 600,
                  cursor: "pointer",
                  transition: "all 0.15s ease",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = "#f0fdf4";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "#ffffff";
                }}
              >
                Xem danh sách chứng từ
              </button>
            </div>
          </div>

          {renderModals()}
        </div>
      );
    }

    // Mode 2: List / Table view of received invoices
    const filteredInvoices = receivedInvoices.filter((inv) => {
      if (!invoiceSearchText.trim()) return true;
      const q = invoiceSearchText.toLowerCase();
      return (
        inv.invoiceNo.toLowerCase().includes(q) ||
        inv.supplierName.toLowerCase().includes(q) ||
        inv.voucherCode.toLowerCase().includes(q) ||
        inv.invoiceSeries.toLowerCase().includes(q)
      );
    });

    const isAllInvSelected =
      filteredInvoices.length > 0 &&
      filteredInvoices.every((inv) => selectedInvoiceIds.includes(inv.id));

    const totalSub = filteredInvoices.reduce((s, it) => s + it.subtotal, 0);
    const totalVat = filteredInvoices.reduce((s, it) => s + it.vatAmount, 0);
    const totalGrand = filteredInvoices.reduce((s, it) => s + it.totalAmount, 0);

    return (
      <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#f8fafc" }}>
        {/* Toolbar */}
        <div
          style={{
            padding: "10px 18px",
            background: "#ffffff",
            borderBottom: "1px solid #e2e8f0",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <button
              type="button"
              onClick={() => setShowReceiveInvoiceModal(true)}
              style={{
                height: 32,
                padding: "0 16px",
                background: "var(--brand)",
                color: "#ffffff",
                border: "none",
                borderRadius: 4,
                fontSize: 13,
                fontWeight: 600,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
              }}
            >
              <Plus size={15} />
              <span>Nhận hóa đơn</span>
            </button>

            <button
              type="button"
              onClick={() => setReceiveInvoiceViewMode("empty_guide")}
              style={{
                height: 32,
                padding: "0 12px",
                background: "#ffffff",
                border: "1px solid #cbd5e1",
                borderRadius: 4,
                fontSize: 12.5,
                color: "#475569",
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
              }}
            >
              <span>Màn hình hướng dẫn</span>
            </button>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ position: "relative", width: 260 }}>
              <input
                type="text"
                placeholder="Tìm số hóa đơn, nhà cung cấp..."
                value={invoiceSearchText}
                onChange={(e) => setInvoiceSearchText(e.target.value)}
                style={{
                  width: "100%",
                  height: 30,
                  padding: "0 28px 0 10px",
                  border: "1px solid #d1d5db",
                  borderRadius: 4,
                  fontSize: 12.5,
                  boxSizing: "border-box",
                }}
              />
              <Search
                size={14}
                style={{
                  position: "absolute",
                  right: 8,
                  top: "50%",
                  transform: "translateY(-50%)",
                  color: "#94a3b8",
                }}
              />
            </div>
            <button
              type="button"
              onClick={async (event) => { try { await exportVisibleTable(event.currentTarget, "Đã xuất danh sách hóa đơn mua hàng"); } catch (cause) { notify?.(cause instanceof Error ? cause.message : "Không thực hiện được thao tác."); } }}
              style={{
                height: 30,
                padding: "0 10px",
                border: "1px solid #cbd5e1",
                background: "#ffffff",
                borderRadius: 4,
                color: "#334155",
                fontSize: 12.5,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 5,
              }}
            >
              <FileSpreadsheet size={14} style={{ color: "#16a34a" }} />
              <span>Xuất Excel</span>
            </button>
          </div>
        </div>

        {/* Invoices Data Table */}
        <div style={{ flex: 1, overflow: "auto", background: "#ffffff" }}>
          <table className="misa-table" style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5 }}>
            <thead>
              <tr style={{ background: "#e6f4ea", borderBottom: "1px solid #cbd5e1" }}>
                <th style={{ width: 40, textAlign: "center", padding: "8px 6px" }}>
                  <input
                    type="checkbox"
                    checked={isAllInvSelected}
                    onChange={() => {
                      if (isAllInvSelected) {
                        setSelectedInvoiceIds([]);
                      } else {
                        setSelectedInvoiceIds(filteredInvoices.map((i) => i.id));
                      }
                    }}
                  />
                </th>
                <th style={{ width: 110, padding: "8px 10px", textAlign: "left" }}>Ngày nhận HĐ</th>
                <th style={{ width: 110, padding: "8px 10px", textAlign: "left" }}>Số hóa đơn</th>
                <th style={{ width: 90, padding: "8px 10px", textAlign: "center" }}>Ký hiệu</th>
                <th style={{ width: 110, padding: "8px 10px", textAlign: "center" }}>Ngày hóa đơn</th>
                <th style={{ padding: "8px 10px", textAlign: "left" }}>Nhà cung cấp</th>
                <th style={{ width: 110, padding: "8px 10px", textAlign: "center" }}>Mã số thuế</th>
                <th style={{ width: 120, padding: "8px 10px", textAlign: "left" }}>Chứng từ mua</th>
                <th style={{ width: 130, padding: "8px 10px", textAlign: "right" }}>Tiền chưa thuế</th>
                <th style={{ width: 110, padding: "8px 10px", textAlign: "right" }}>Thuế GTGT</th>
                <th style={{ width: 130, padding: "8px 10px", textAlign: "right" }}>Tổng tiền</th>
                <th style={{ width: 110, padding: "8px 10px", textAlign: "center" }}>Trạng thái</th>
              </tr>
            </thead>
            <tbody>
              {filteredInvoices.map((inv) => {
                const isSelected = selectedInvoiceIds.includes(inv.id);
                return (
                  <tr
                    key={inv.id}
                    onClick={() => {
                      setSelectedInvoiceIds((prev) =>
                        prev.includes(inv.id) ? prev.filter((x) => x !== inv.id) : [...prev, inv.id]
                      );
                    }}
                    style={{
                      borderBottom: "1px solid #f1f5f9",
                      background: isSelected ? "rgba(0, 176, 107, 0.08)" : "#ffffff",
                      cursor: "pointer",
                    }}
                  >
                    <td
                      style={{ textAlign: "center", padding: "8px 6px" }}
                      onClick={(e) => e.stopPropagation()}
                    >
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => {
                          setSelectedInvoiceIds((prev) =>
                            prev.includes(inv.id) ? prev.filter((x) => x !== inv.id) : [...prev, inv.id]
                          );
                        }}
                      />
                    </td>
                    <td style={{ padding: "8px 10px", color: "#475569" }}>{inv.receivedDate}</td>
                    <td style={{ padding: "8px 10px" }}>
                      <span
                        style={{ color: "var(--brand)", fontWeight: 600, cursor: "pointer" }}
                        onClick={(e) => {
                          e.stopPropagation();
                          notify(`Xem chi tiết hóa đơn số ${inv.invoiceNo}`);
                        }}
                      >
                        {inv.invoiceNo}
                      </span>
                    </td>
                    <td style={{ padding: "8px 10px", textAlign: "center", color: "#64748b" }}>
                      {inv.invoiceSeries}
                    </td>
                    <td style={{ padding: "8px 10px", textAlign: "center", color: "#475569" }}>
                      {inv.invoiceDate}
                    </td>
                    <td style={{ padding: "8px 10px", fontWeight: 500, color: "#1e293b" }}>
                      {inv.supplierName}
                    </td>
                    <td style={{ padding: "8px 10px", textAlign: "center", color: "#64748b" }}>
                      {inv.supplierTaxCode}
                    </td>
                    <td style={{ padding: "8px 10px" }}>
                      <span
                        style={{ color: "var(--brand)", fontWeight: 500, cursor: "pointer" }}
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowVoucherModal(true);
                        }}
                      >
                        {inv.voucherCode}
                      </span>
                    </td>
                    <td style={{ padding: "8px 10px", textAlign: "right", color: "#334155" }}>
                      {formatVND(inv.subtotal)} đ
                    </td>
                    <td style={{ padding: "8px 10px", textAlign: "right", color: "#334155" }}>
                      {formatVND(inv.vatAmount)} đ
                    </td>
                    <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 700, color: "#059669" }}>
                      {formatVND(inv.totalAmount)} đ
                    </td>
                    <td style={{ padding: "8px 10px", textAlign: "center" }}>
                      <span
                        style={{
                          background: "#dcfce7",
                          color: "#15803d",
                          padding: "2px 8px",
                          borderRadius: 10,
                          fontSize: 11,
                          fontWeight: 600,
                        }}
                      >
                        {inv.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr style={{ background: "#f8fafc", fontWeight: 700, borderTop: "2px solid #cbd5e1" }}>
                <td colSpan={8} style={{ padding: "10px", textAlign: "right", color: "#1e293b" }}>
                  Tổng cộng:
                </td>
                <td style={{ padding: "10px", textAlign: "right", color: "#334155" }}>
                  {formatVND(totalSub)} đ
                </td>
                <td style={{ padding: "10px", textAlign: "right", color: "#334155" }}>
                  {formatVND(totalVat)} đ
                </td>
                <td style={{ padding: "10px", textAlign: "right", color: "#059669" }}>
                  {formatVND(totalGrand)} đ
                </td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Footer info bar */}
        <div
          style={{
            height: 38,
            padding: "0 18px",
            background: "#ffffff",
            borderTop: "1px solid #e2e8f0",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            fontSize: 12,
            color: "#64748b",
          }}
        >
          <div>
            Số dòng: <strong>{filteredInvoices.length}</strong> | Tổng tiền:{" "}
            <strong>{formatVND(totalGrand)} đ</strong>
          </div>
          <div>Trang 1 / 1</div>
        </div>

        {renderModals()}
      </div>
    );
  }

  // -------------------------------------------------------------------------
  // 7.2. TAB: NHÀ CUNG CẤP (SUPPLIERS)
  // -------------------------------------------------------------------------
  if (tab === "suppliers") {
    const filteredSuppliers = suppliers.filter((s) => {
      if (!supplierSearchText.trim()) return true;
      const kw = supplierSearchText.toLowerCase();
      return (
        s.code.toLowerCase().includes(kw) ||
        s.name.toLowerCase().includes(kw) ||
        s.taxCode.toLowerCase().includes(kw) ||
        s.phone.toLowerCase().includes(kw) ||
        s.address.toLowerCase().includes(kw)
      );
    });

    const totalDebt = suppliers.reduce((sum, s) => sum + (s.debtAmount || 0), 0);
    const isAllSelected = filteredSuppliers.length > 0 && selectedSupplierIds.length === filteredSuppliers.length;

    const toggleSelectAll = () => {
      if (isAllSelected) {
        setSelectedSupplierIds([]);
      } else {
        setSelectedSupplierIds(filteredSuppliers.map((s) => s.id));
      }
    };

    const toggleSelectRow = (id: string) => {
      setSelectedSupplierIds((prev) =>
        prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
      );
    };

    const handleDeleteSupplier = async (id: string, name: string) => {
      if (!confirm(`Bạn có chắc muốn xóa nhà cung cấp "${name}"?`)) return;
      try {
        if (apiConnected && token) {
          await request(`/api/v1/master-data/parties/${id}/?company_id=${encodeURIComponent(_company.id)}`, token, { method: "DELETE" });
          reloadApi();
        } else {
          setSuppliers((prev) => prev.filter((s) => s.id !== id));
        }
        notify(`Đã xóa nhà cung cấp "${name}".`);
      } catch (error) {
        notify(`Không xóa được nhà cung cấp: ${error instanceof Error ? error.message : String(error)}`);
      }
    };

    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          height: "100%",
          background: "#f4f5f8",
          padding: "10px 16px 14px 16px",
          boxSizing: "border-box",
          fontFamily: "Roboto, Arial, sans-serif",
          position: "relative",
        }}
      >
        {/* Backdrop for closing dropdowns */}
        {(showAddSupplierDropdown || activeSupplierMenuId !== null) && (
          <div
            onClick={() => {
              setShowAddSupplierDropdown(false);
              setActiveSupplierMenuId(null);
            }}
            style={{
              position: "fixed",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              zIndex: 40,
              background: "transparent",
            }}
          />
        )}

        {/* Breadcrumb matching Screenshot 1: < Tất cả danh mục */}
        <div style={{ marginBottom: 8, display: "flex", alignItems: "center" }}>
          <button
            type="button"
            onClick={() => notify("Xem tất cả danh mục")}
            style={{
              background: "transparent",
              border: "none",
              color: "var(--brand)",
              fontSize: 13,
              fontWeight: 500,
              cursor: "pointer",
              display: "inline-flex",
              alignItems: "center",
              gap: 4,
              padding: 0,
            }}
          >
            <ChevronLeft size={16} />
            <span>Tất cả danh mục</span>
          </button>
        </div>

        {/* Top 3 Stat Cards (Screenshot 1 & 2) */}
        {showSupplierSummaryCards && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 8 }}>
            {/* Card 1: Nợ quá hạn */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #fecaca",
                borderRadius: 4,
                padding: "10px 14px 8px 14px",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                minHeight: 74,
                boxShadow: "0 1px 2px rgba(0,0,0,0.03)",
              }}
            >
              <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
                <div
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: "50%",
                    background: "#fee2e2",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#ef4444",
                    flexShrink: 0,
                  }}
                >
                  <Clock size={16} />
                </div>
                <div>
                  <div style={{ fontSize: 12, color: "#64748b", fontWeight: 500 }}>Nợ quá hạn</div>
                  <div style={{ fontSize: 22, fontWeight: 700, color: "#ef4444", lineHeight: 1.2, marginTop: 2 }}>0</div>
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 4, fontSize: 11, color: "#94a3b8" }}>
                <Clock size={11} />
                <span>14:42 Hôm qua</span>
              </div>
            </div>

            {/* Card 2: Tổng nợ phải trả */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #fed7aa",
                borderRadius: 4,
                padding: "10px 14px 8px 14px",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                minHeight: 74,
                boxShadow: "0 1px 2px rgba(0,0,0,0.03)",
              }}
            >
              <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
                <div
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: "50%",
                    background: "#ffedd5",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#f97316",
                    flexShrink: 0,
                  }}
                >
                  <CreditCard size={16} />
                </div>
                <div>
                  <div style={{ fontSize: 12, color: "#64748b", fontWeight: 500 }}>Tổng nợ phải trả</div>
                  <div style={{ fontSize: 22, fontWeight: 700, color: "#0f172a", lineHeight: 1.2, marginTop: 2 }}>
                    {formatVND(totalDebt)}
                  </div>
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 4, fontSize: 11, color: "#94a3b8" }}>
                <Clock size={11} />
                <span>14:42 Hôm qua</span>
              </div>
            </div>

            {/* Card 3: Đã thanh toán (30 ngày gần đây) */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #bbf7d0",
                borderRadius: 4,
                padding: "10px 14px 8px 14px",
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                minHeight: 74,
                boxShadow: "0 1px 2px rgba(0,0,0,0.03)",
              }}
            >
              <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
                <div
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: "50%",
                    background: "#dcfce7",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#16a34a",
                    flexShrink: 0,
                  }}
                >
                  <Banknote size={16} />
                </div>
                <div>
                  <div style={{ fontSize: 12, color: "#64748b", fontWeight: 500 }}>Đã thanh toán (30 ngày gần đây)</div>
                  <div style={{ fontSize: 22, fontWeight: 700, color: "#16a34a", lineHeight: 1.2, marginTop: 2 }}>10.000.000</div>
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 4, fontSize: 11, color: "#94a3b8" }}>
                <Clock size={11} />
                <span>14:42 Hôm qua</span>
              </div>
            </div>
          </div>
        )}

        {/* Small center collapse/expand chevron button */}
        <div style={{ display: "flex", justifyContent: "center", margin: "-2px 0 6px" }}>
          <button
            type="button"
            onClick={() => setShowSupplierSummaryCards(!showSupplierSummaryCards)}
            title={showSupplierSummaryCards ? "Thu gọn thống kê" : "Mở rộng thống kê"}
            style={{
              background: "#ffffff",
              border: "1px solid #cbd5e1",
              borderRadius: "50%",
              width: 18,
              height: 18,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: "#64748b",
              padding: 0,
            }}
          >
            {showSupplierSummaryCards ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
          </button>
        </div>

        {/* Main Content Card: Toolbar + Table + Footer */}
        <div
          style={{
            flex: 1,
            background: "#ffffff",
            borderRadius: 4,
            border: "1px solid #cbd5e1",
            display: "flex",
            flexDirection: "column",
            overflow: "visible",
            boxShadow: "0 1px 3px rgba(0,0,0,0.05)",
          }}
        >
          {/* Toolbar (Screenshot 1 & 2) */}
          <div
            style={{
              padding: "10px 14px",
              background: "#ffffff",
              borderBottom: "1px solid #e2e8f0",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 12,
              position: "relative",
              zIndex: 30,
            }}
          >
            {/* Left: Search input */}
            <div style={{ position: "relative", width: 260 }}>
              <Search
                size={14}
                style={{
                  position: "absolute",
                  left: 10,
                  top: "50%",
                  transform: "translateY(-50%)",
                  color: "#94a3b8",
                }}
              />
              <input
                type="text"
                placeholder="Tìm kiếm"
                value={supplierSearchText}
                onChange={(e) => setSupplierSearchText(e.target.value)}
                style={{
                  width: "100%",
                  height: 32,
                  padding: "0 10px 0 32px",
                  borderRadius: 4,
                  border: "1px solid #cbd5e1",
                  fontSize: 12.5,
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>

            {/* Right: Actions */}
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <button
                type="button"
                title="Làm mới"
                onClick={() => notify("Đã làm mới danh sách nhà cung cấp")}
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 4,
                  border: "1px solid #cbd5e1",
                  background: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  color: "#475569",
                }}
              >
                <RotateCw size={15} />
              </button>
              <button
                type="button"
                title="Tùy chỉnh cột"
                onClick={() => notify("Tùy chỉnh giao diện & cột hiển thị")}
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 4,
                  border: "1px solid #cbd5e1",
                  background: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  color: "#475569",
                }}
              >
                <SlidersHorizontal size={15} />
              </button>
              <button
                type="button"
                title="Thiết lập danh mục"
                onClick={() => notify("Thiết lập danh mục nhà cung cấp")}
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 4,
                  border: "1px solid #cbd5e1",
                  background: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  color: "#475569",
                }}
              >
                <Settings size={15} />
              </button>
              <button
                type="button"
                title="Bộ lọc"
                onClick={() => notify("Mở bộ lọc nhà cung cấp")}
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 4,
                  border: "1px solid #cbd5e1",
                  background: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  color: "#475569",
                }}
              >
                <Filter size={15} />
              </button>

              <button
                type="button"
                onClick={() => notify("Đang đồng bộ và cập nhật địa chỉ nhà cung cấp")}
                style={{
                  height: 32,
                  padding: "0 12px",
                  background: "#ffffff",
                  border: "1px solid #cbd5e1",
                  borderRadius: 4,
                  fontSize: 12.5,
                  fontWeight: 500,
                  color: "#334155",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  cursor: "pointer",
                }}
              >
                <MapPin size={14} style={{ color: "var(--brand)" }} />
                <span>Cập nhật địa chỉ</span>
              </button>

              {/* Primary Green button: Thêm ▾ (opens SupplierModal matching Screenshot 3) */}
              <div style={{ display: "inline-flex", position: "relative" }}>
                <button
                  type="button"
                  data-testid="btn-add-supplier"
                  onClick={() => {
                    setEditingSupplier(null);
                    setShowSupplierModal(true);
                  }}
                  style={{
                    height: 32,
                    padding: "0 14px",
                    background: "var(--brand)",
                    color: "#ffffff",
                    border: "none",
                    borderTopLeftRadius: 4,
                    borderBottomLeftRadius: 4,
                    fontSize: 13,
                    fontWeight: 600,
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 4,
                  }}
                >
                  <span>Thêm</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddSupplierDropdown(!showAddSupplierDropdown)}
                  style={{
                    height: 32,
                    padding: "0 6px",
                    background: "var(--brand)",
                    color: "#ffffff",
                    border: "none",
                    borderLeft: "1px solid rgba(255,255,255,0.25)",
                    borderTopRightRadius: 4,
                    borderBottomRightRadius: 4,
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <ChevronDown size={14} />
                </button>
                {showAddSupplierDropdown && (
                  <div
                    style={{
                      position: "absolute",
                      top: "100%",
                      right: 0,
                      marginTop: 4,
                      background: "#ffffff",
                      border: "1px solid #cbd5e1",
                      borderRadius: 4,
                      boxShadow: "0 6px 18px rgba(0,0,0,0.12)",
                      zIndex: 50,
                      minWidth: 170,
                      padding: "4px 0",
                    }}
                  >
                    <div
                      onClick={() => {
                        setShowAddSupplierDropdown(false);
                        setEditingSupplier(null);
                        setShowSupplierModal(true);
                      }}
                      style={{ padding: "8px 12px", fontSize: 13, cursor: "pointer", color: "#334155" }}
                    >
                      Thêm nhà cung cấp
                    </div>
                    <div
                      onClick={() => {
                        setShowAddSupplierDropdown(false);
                        notify("Tính năng Nhập khẩu từ Excel");
                      }}
                      style={{ padding: "8px 12px", fontSize: 13, cursor: "pointer", color: "#334155" }}
                    >
                      Nhập khẩu từ Excel
                    </div>
                  </div>
                )}
              </div>

              {/* Tiện ích ▾ (5 Tiện ích mua hàng chuẩn MISA) */}
              <div style={{ position: "relative" }}>
                <button
                  type="button"
                  onClick={() => setShowUtilityMenu(!showUtilityMenu)}
                  style={{
                    height: 32,
                    padding: "0 12px",
                    background: "#ffffff",
                    color: "#1e293b",
                    border: "1px solid #cbd5e1",
                    borderRadius: 4,
                    fontSize: 13,
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    fontWeight: 500,
                  }}
                >
                  <span>Tiện ích</span>
                  <ChevronDown size={14} style={{ color: "#64748b" }} />
                </button>

                {showUtilityMenu && (
                  <>
                    <div
                      onClick={() => setShowUtilityMenu(false)}
                      style={{ position: "fixed", inset: 0, zIndex: 45 }}
                    />
                    <div
                      style={{
                        position: "absolute",
                        top: "calc(100% + 4px)",
                        right: 0,
                        background: "#ffffff",
                        borderRadius: 6,
                        boxShadow: "0 10px 25px rgba(0,0,0,0.15)",
                        border: "1px solid #e2e8f0",
                        width: 290,
                        zIndex: 50,
                        padding: "4px 0",
                      }}
                    >
                      {[
                        {
                          label: "Đối trừ chứng từ",
                          desc: "Đối trừ thanh toán cho 1 NCC cụ thể (TK 331)",
                          onClick: () => {
                            setShowUtilityMenu(false);
                            setShowDebtOffsetModal(true);
                          },
                        },
                        {
                          label: "Đối trừ chứng từ nhiều đối tượng",
                          desc: "Tự động đối trừ công nợ theo danh sách NCC",
                          onClick: () => {
                            setShowUtilityMenu(false);
                            setShowMultiDebtOffsetModal(true);
                          },
                        },
                        {
                          label: "Bỏ đối trừ",
                          desc: "Hủy kết quả đối trừ của 1 NCC",
                          onClick: () => {
                            setShowUtilityMenu(false);
                            setShowUnOffsetModal(true);
                          },
                        },
                        {
                          label: "Bỏ đối trừ chứng từ nhiều đối tượng",
                          desc: "Hủy hàng loạt chứng từ đã đối trừ",
                          onClick: () => {
                            setShowUtilityMenu(false);
                            setShowMultiUnOffsetModal(true);
                          },
                        },
                        {
                          label: "Bù trừ công nợ",
                          desc: "Bù trừ giữa TK 131 và TK 331 (Khách hàng kiêm NCC)",
                          onClick: () => {
                            setShowUtilityMenu(false);
                            setShowDebtClearingModal(true);
                          },
                        },
                      ].map((item, idx) => (
                        <div
                          key={idx}
                          onClick={item.onClick}
                          style={{
                            padding: "8px 14px",
                            cursor: "pointer",
                            transition: "background 0.12s",
                            borderBottom: idx < 4 ? "1px solid #f8fafc" : "none",
                          }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.background = "#f1f5f9";
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.background = "transparent";
                          }}
                        >
                          <div style={{ fontSize: 13, fontWeight: 500, color: "#1e293b" }}>{item.label}</div>
                          <div style={{ fontSize: 11.5, color: "#64748b" }}>{item.desc}</div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>

              <button
                type="button"
                title="Tùy chọn khác"
                onClick={() => notify("Tùy chọn khác")}
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 4,
                  border: "1px solid #cbd5e1",
                  background: "#ffffff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  color: "#475569",
                }}
              >
                <MoreHorizontal size={15} />
              </button>
            </div>
          </div>

          {/* Table Area (Screenshot 1 & 2) */}
          <div style={{ flex: 1, overflow: "auto", position: "relative" }}>
            <table
              className="misa-table"
              style={{
                width: "100%",
                borderCollapse: "separate",
                borderSpacing: 0,
                fontSize: 12.5,
                minWidth: 1650,
                whiteSpace: "nowrap",
              }}
            >
              <thead>
                <tr style={{ background: "#e6f4ea", color: "#1e293b", position: "sticky", top: 0, zIndex: 10 }}>
                  <th style={{ width: 40, textAlign: "center", padding: "8px 4px", borderBottom: "1px solid #cbd5e1", borderRight: "1px solid #e2e8f0" }}>
                    <input
                      type="checkbox"
                      checked={isAllSelected}
                      onChange={toggleSelectAll}
                      style={{ accentColor: "var(--brand)" }}
                    />
                  </th>
                  <th style={{ width: 130, padding: "8px 10px", textAlign: "left", fontWeight: 600, borderBottom: "1px solid #cbd5e1", borderRight: "1px solid #e2e8f0" }}>
                    Mã nhà cung cấp
                  </th>
                  <th style={{ width: 220, padding: "8px 10px", textAlign: "left", fontWeight: 600, borderBottom: "1px solid #cbd5e1", borderRight: "1px solid #e2e8f0" }}>
                    Tên nhà cung cấp
                  </th>
                  <th style={{ width: 240, padding: "8px 10px", textAlign: "left", fontWeight: 600, borderBottom: "1px solid #cbd5e1", borderRight: "1px solid #e2e8f0" }}>
                    Địa chỉ
                  </th>
                  <th style={{ width: 130, padding: "8px 10px", textAlign: "right", fontWeight: 600, borderBottom: "1px solid #cbd5e1", borderRight: "1px solid #e2e8f0" }}>
                    Số tiền nợ
                  </th>
                  <th style={{ width: 170, padding: "8px 10px", textAlign: "left", fontWeight: 600, borderBottom: "1px solid #cbd5e1", borderRight: "1px solid #e2e8f0" }}>
                    Mã số thuế/CCCD chủ hộ
                  </th>
                  <th style={{ width: 140, padding: "8px 10px", textAlign: "left", fontWeight: 600, borderBottom: "1px solid #cbd5e1", borderRight: "1px solid #e2e8f0" }}>
                    Rủi ro về hóa đơn
                  </th>
                  <th style={{ width: 160, padding: "8px 10px", textAlign: "left", fontWeight: 600, borderBottom: "1px solid #cbd5e1", borderRight: "1px solid #e2e8f0" }}>
                    Văn bản tham chiếu
                  </th>
                  <th style={{ width: 130, padding: "8px 10px", textAlign: "left", fontWeight: 600, borderBottom: "1px solid #cbd5e1", borderRight: "1px solid #e2e8f0" }}>
                    Điện thoại
                  </th>
                  <th style={{ width: 150, padding: "8px 10px", textAlign: "center", fontWeight: 600, borderBottom: "1px solid #cbd5e1", borderRight: "1px solid #e2e8f0" }}>
                    Là Đối tượng nội bộ
                  </th>
                  <th style={{ width: 170, padding: "8px 10px", textAlign: "center", fontWeight: 600, borderBottom: "1px solid #cbd5e1", borderRight: "1px solid #e2e8f0" }}>
                    Là Tổng công ty/chi nhánh
                  </th>
                  <th
                    style={{
                      width: 120,
                      padding: "8px 10px",
                      textAlign: "center",
                      fontWeight: 600,
                      borderBottom: "1px solid #cbd5e1",
                      borderLeft: "1px solid #cbd5e1",
                      boxShadow: "-3px 0 6px rgba(0,0,0,0.04)",
                      position: "sticky",
                      right: 0,
                      background: "#e6f4ea",
                      zIndex: 11,
                    }}
                  >
                    Chức năng
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredSuppliers.length === 0 ? (
                  <tr>
                    <td colSpan={12} style={{ textAlign: "center", padding: "40px 0", color: "#64748b" }}>
                      Không có nhà cung cấp nào phù hợp với tìm kiếm
                    </td>
                  </tr>
                ) : (
                  filteredSuppliers.map((s, idx) => {
                    const isChecked = selectedSupplierIds.includes(s.id);
                    return (
                      <tr
                        key={s.id}
                        style={{
                          background: isChecked ? "#f0fdf4" : idx % 2 === 1 ? "#fafafa" : "#ffffff",
                          borderBottom: "1px solid #f1f5f9",
                        }}
                      >
                        <td style={{ textAlign: "center", padding: "8px 4px", borderBottom: "1px solid #e2e8f0", borderRight: "1px solid #f1f5f9" }}>
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => toggleSelectRow(s.id)}
                            style={{ accentColor: "var(--brand)" }}
                          />
                        </td>
                        <td
                          style={{
                            padding: "8px 10px",
                            fontWeight: 500,
                            color: "var(--brand)",
                            cursor: "pointer",
                            borderBottom: "1px solid #e2e8f0",
                            borderRight: "1px solid #f1f5f9",
                          }}
                          onClick={() => {
                            setEditingSupplier(s);
                            setShowSupplierModal(true);
                          }}
                          title="Bấm để xem và sửa thông tin"
                        >
                          {s.code}
                        </td>
                        <td style={{ padding: "8px 10px", fontWeight: 500, color: "#1e293b", borderBottom: "1px solid #e2e8f0", borderRight: "1px solid #f1f5f9" }}>
                          {s.name}
                        </td>
                        <td style={{ padding: "8px 10px", color: "#475569", borderBottom: "1px solid #e2e8f0", borderRight: "1px solid #f1f5f9" }}>
                          {s.address}
                        </td>
                        <td
                          style={{
                            padding: "8px 10px",
                            textAlign: "right",
                            fontWeight: s.debtAmount > 0 ? 600 : 400,
                            color: s.debtAmount > 0 ? "#0f172a" : "#64748b",
                            borderBottom: "1px solid #e2e8f0",
                            borderRight: "1px solid #f1f5f9",
                          }}
                        >
                          {formatVND(s.debtAmount)}
                        </td>
                        <td style={{ padding: "8px 10px", color: "#334155", borderBottom: "1px solid #e2e8f0", borderRight: "1px solid #f1f5f9" }}>
                          {s.taxCode}
                        </td>
                        <td style={{ padding: "8px 10px", color: "#64748b", borderBottom: "1px solid #e2e8f0", borderRight: "1px solid #f1f5f9" }}>
                          {s.invoiceRisk}
                        </td>
                        <td style={{ padding: "8px 10px", color: "#64748b", borderBottom: "1px solid #e2e8f0", borderRight: "1px solid #f1f5f9" }}>
                          {s.refDoc}
                        </td>
                        <td style={{ padding: "8px 10px", color: "#334155", borderBottom: "1px solid #e2e8f0", borderRight: "1px solid #f1f5f9" }}>
                          {s.phone}
                        </td>
                        <td style={{ textAlign: "center", padding: "8px 10px", borderBottom: "1px solid #e2e8f0", borderRight: "1px solid #f1f5f9" }}>
                          <input type="checkbox" checked={s.isInternal} readOnly style={{ accentColor: "var(--brand)" }} />
                        </td>
                        <td style={{ textAlign: "center", padding: "8px 10px", borderBottom: "1px solid #e2e8f0", borderRight: "1px solid #f1f5f9" }}>
                          <input type="checkbox" checked={s.isBranch} readOnly style={{ accentColor: "var(--brand)" }} />
                        </td>
                        <td
                          style={{
                            padding: "8px 10px",
                            textAlign: "center",
                            borderBottom: "1px solid #e2e8f0",
                            borderLeft: "1px solid #e2e8f0",
                            boxShadow: "-3px 0 6px rgba(0,0,0,0.04)",
                            position: "sticky",
                            right: 0,
                            background: isChecked ? "#f0fdf4" : idx % 2 === 1 ? "#fafafa" : "#ffffff",
                            zIndex: 9,
                          }}
                        >
                          <div style={{ display: "inline-flex", alignItems: "center", gap: 4, position: "relative" }}>
                            <button
                              type="button"
                              onClick={() => setShowSupplierPaymentModal(true)}
                              style={{
                                background: "transparent",
                                border: "none",
                                color: "var(--brand)",
                                fontSize: 12.5,
                                fontWeight: 500,
                                cursor: "pointer",
                                padding: "2px 4px",
                              }}
                            >
                              Trả tiền
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setActiveSupplierMenuId(activeSupplierMenuId === s.id ? null : s.id)
                              }
                              style={{
                                background: "transparent",
                                border: "none",
                                color: "var(--brand)",
                                cursor: "pointer",
                                padding: "2px 0",
                                display: "flex",
                                alignItems: "center",
                              }}
                            >
                              <ChevronDown size={14} />
                            </button>

                            {/* Dropdown Action Menu */}
                            {activeSupplierMenuId === s.id && (
                              <div
                                style={{
                                  position: "absolute",
                                  top: "100%",
                                  right: 0,
                                  background: "#ffffff",
                                  border: "1px solid #cbd5e1",
                                  borderRadius: 4,
                                  boxShadow: "0 6px 18px rgba(0,0,0,0.15)",
                                  zIndex: 50,
                                  minWidth: 150,
                                  textAlign: "left",
                                  padding: "4px 0",
                                }}
                              >
                                <div
                                  onClick={() => {
                                    setActiveSupplierMenuId(null);
                                    setShowVoucherModal(true);
                                  }}
                                  style={{ padding: "7px 12px", fontSize: 12.5, cursor: "pointer", color: "#1e293b" }}
                                >
                                  Lập CT mua hàng
                                </div>
                                <div
                                  onClick={() => {
                                    setActiveSupplierMenuId(null);
                                    setEditingSupplier(s);
                                    setShowSupplierModal(true);
                                  }}
                                  style={{ padding: "7px 12px", fontSize: 12.5, cursor: "pointer", color: "#1e293b" }}
                                >
                                  Sửa
                                </div>
                                <div
                                  onClick={() => {
                                    setActiveSupplierMenuId(null);
                                    setEditingSupplier({ ...s, activeTab: "items" });
                                    setShowSupplierModal(true);
                                  }}
                                  style={{ padding: "7px 12px", fontSize: 12.5, cursor: "pointer", color: "var(--brand)", fontWeight: 600 }}
                                >
                                  Xem VTHH cung cấp
                                </div>
                                <div
                                  onClick={() => {
                                    setActiveSupplierMenuId(null);
                                    handleDeleteSupplier(s.id, s.name);
                                  }}
                                  style={{ padding: "7px 12px", fontSize: 12.5, cursor: "pointer", color: "#ef4444" }}
                                >
                                  Xóa
                                </div>
                                <div
                                  onClick={() => {
                                    setActiveSupplierMenuId(null);
                                    notify(`Đã cập nhật trạng thái của nhà cung cấp "${s.name}".`);
                                  }}
                                  style={{ padding: "7px 12px", fontSize: 12.5, cursor: "pointer", color: "#475569" }}
                                >
                                  Ngừng sử dụng
                                </div>
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Bottom Pagination matching Screenshot 1 & 2 */}
          <div
            style={{
              height: 44,
              padding: "0 14px",
              background: "#ffffff",
              borderTop: "1px solid #e2e8f0",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              fontSize: 12.5,
              color: "#334155",
            }}
          >
            <div>
              <span>Tổng số: </span>
              <strong>{filteredSuppliers.length}</strong>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <span>Số dòng/trang</span>
                <select
                  value={supplierRowsPerPage}
                  onChange={(e) => setSupplierRowsPerPage(Number(e.target.value) || 20)}
                  style={{
                    height: 26,
                    padding: "0 4px",
                    borderRadius: 3,
                    border: "1px solid #cbd5e1",
                    fontSize: 12,
                    background: "#ffffff",
                  }}
                >
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 4, color: "#64748b" }}>
                <button
                  type="button"
                  style={{
                    border: "none",
                    background: "transparent",
                    cursor: "pointer",
                    padding: "2px 4px",
                    color: "#94a3b8",
                  }}
                  title="Trang đầu"
                >
                  «
                </button>
                <button
                  type="button"
                  style={{
                    border: "none",
                    background: "transparent",
                    cursor: "pointer",
                    padding: "2px 4px",
                    color: "#94a3b8",
                  }}
                  title="Trang trước"
                >
                  ‹
                </button>
                <span
                  style={{
                    display: "inline-block",
                    width: 22,
                    height: 22,
                    lineHeight: "22px",
                    textAlign: "center",
                    background: "var(--brand)",
                    color: "#ffffff",
                    borderRadius: 3,
                    fontWeight: 600,
                    fontSize: 12,
                  }}
                >
                  1
                </span>
                <button
                  type="button"
                  style={{
                    border: "none",
                    background: "transparent",
                    cursor: "pointer",
                    padding: "2px 4px",
                    color: "#94a3b8",
                  }}
                  title="Trang sau"
                >
                  ›
                </button>
                <button
                  type="button"
                  style={{
                    border: "none",
                    background: "transparent",
                    cursor: "pointer",
                    padding: "2px 4px",
                    color: "#94a3b8",
                  }}
                  title="Trang cuối"
                >
                  »
                </button>
              </div>
            </div>
          </div>
        </div>

        {renderModals()}
      </div>
    );
  }

  // -------------------------------------------------------------------------
  // 8. DEFAULT TAB: QUY TRÌNH (FLOWCHART WORKSPACE FOR PURCHASES)
  // -------------------------------------------------------------------------
  return (
    <div
      className="ref-process-wrapper"
      style={{
        background: "#f1f5f9",
        height: "100%",
        padding: "10px 16px",
        overflowY: "auto",
        overflowX: "hidden",
      }}
    >
      <div
        className="ref-process-layout"
        style={{
          maxWidth: 1080,
          display: "grid",
          gridTemplateColumns: "minmax(0, 2.3fr) minmax(250px, 1fr)",
          gap: 14,
          margin: "0 auto",
        }}
      >
        {/* Panel 1: NGHIỆP VỤ MUA HÀNG (Flowchart matching screenshot) */}
        <section
          className="ref-process-panel"
          style={{
            background: "#ffffff",
            borderRadius: 8,
            border: "1px solid #e2e8f0",
            boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
            overflow: "visible",
            position: "relative",
            zIndex: 20,
          }}
        >
          <h2
            style={{
              fontSize: 13,
              fontWeight: 700,
              textAlign: "center",
              margin: 0,
              padding: "16px 10px 12px 10px",
              borderBottom: "1px solid #f1f5f9",
              color: "#1e293b",
              letterSpacing: "0.5px",
            }}
          >
            NGHIỆP VỤ MUA HÀNG
          </h2>

          <div
            className="ref-process-canvas sv-flow-nodes"
            style={{
              position: "relative",
              height: 330,
              margin: "0 10px",
              overflow: "visible",
            }}
          >
            {/* SVG Connecting Flow Lines matching user screenshot */}
            <svg className="sv-flow-connector"
              viewBox="0 0 660 300"
              preserveAspectRatio="none"
              aria-hidden="true"
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: 300,
                pointerEvents: "none",
                overflow: "visible",
              }}
            >
              <defs>
                <marker id="misa-arrow-pur" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto">
                  <polygon points="0 0, 7 3.5, 0 7" fill="#94a3b8" />
                </marker>
              </defs>

              {/* 1. Left vertical link with 2 circle ends */}
              <circle cx="75" cy="115" r="3.2" fill="#94a3b8" />
              <circle cx="75" cy="175" r="3.2" fill="#94a3b8" />
              <path d="M 75 115 L 75 175" stroke="#94a3b8" strokeWidth="1.8" fill="none" />

              {/* 2. Main horizontal axis line */}
              <path d="M 75 145 L 610 145" stroke="#94a3b8" strokeWidth="1.5" fill="none" markerEnd="url(#misa-arrow-pur)" />

              {/* 3. Col 2: Nhận hàng hóa, dịch vụ <-> Nhận hóa đơn */}
              <path d="M 238 145 L 238 115" stroke="#94a3b8" strokeWidth="1.5" fill="none" />
              <path d="M 238 145 L 238 175" stroke="#94a3b8" strokeWidth="1.5" fill="none" />

              {/* 4. Col 3: Xử lý hóa đơn đầu vào <-> Trả lại hàng mua */}
              <circle cx="408" cy="125" r="3" fill="#94a3b8" />
              <path d="M 408 145 L 408 125" stroke="#94a3b8" strokeWidth="1.5" fill="none" />
              <circle cx="408" cy="175" r="3" fill="#94a3b8" />
              <path d="M 408 145 L 408 175" stroke="#94a3b8" strokeWidth="1.5" fill="none" />

              {/* 5. Col 4: Trả tiền theo hóa đơn <-> Giảm giá hàng mua */}
              <circle cx="578" cy="125" r="3" fill="#94a3b8" />
              <path d="M 578 145 L 578 125" stroke="#94a3b8" strokeWidth="1.5" fill="none" />
              <circle cx="578" cy="175" r="3" fill="#94a3b8" />
              <path d="M 578 145 L 578 175" stroke="#94a3b8" strokeWidth="1.5" fill="none" />
            </svg>

            {/* Col 1 Top: Đơn mua hàng */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "11.36%",
                transform: "translateX(-50%)",
                top: 20,
                width: 110,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 10,
              }}
              onClick={() => setShowOrderModal(true)}
              title="Lập Đơn mua hàng"
            >
              <span className="ref-business-icon order" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>ĐMH</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "#f59e0b", borderColor: "#fbbf24" }}
                >
                  <ShoppingCart size={14} strokeWidth={2.2} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3, textAlign: "center" }}>
                Đơn mua hàng
              </span>
            </div>

            {/* Col 1 Bottom: Hợp đồng mua hàng */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "11.36%",
                transform: "translateX(-50%)",
                top: 185,
                width: 110,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 10,
              }}
              onClick={() => setShowContractModal(true)}
              title="Quản lý Hợp đồng mua hàng"
            >
              <span className="ref-business-icon contract" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>HĐ</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "#f59e0b", borderColor: "#fbbf24" }}
                >
                  <FileCheck size={14} strokeWidth={2.2} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3, textAlign: "center" }}>
                Hợp đồng<br />mua hàng
              </span>
            </div>

            {/* Col 2 Top: Nhận hàng hóa, dịch vụ (With Dropdown Menu matching screenshot) */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "36.06%",
                transform: "translateX(-50%)",
                top: 20,
                width: 125,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                textAlign: "center",
                zIndex: activeFlowchartMenu === "receive-goods" ? 60 : 10,
              }}
              onMouseEnter={() => handleFlowchartMouseEnter("receive-goods")}
              onMouseLeave={handleFlowchartMouseLeave}
            >
              <div
                style={{
                  cursor: "pointer",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
                onClick={() =>
                  setActiveFlowchartMenu((prev) => (prev === "receive-goods" ? null : "receive-goods"))
                }
                title="Nhận hàng hóa, dịch vụ"
              >
                <span className="ref-business-icon receive" style={{ marginBottom: 6 }}>
                  <span
                    className="ref-document-sheet"
                    style={{
                      background: "linear-gradient(90deg, #10b981, #059669)",
                      border: "1px solid #34d399",
                    }}
                  >
                    <b style={{ color: "#ffffff", fontWeight: 800 }}>NH</b>
                    <i /><i /><i />
                  </span>
                  <span
                    className="ref-gold-icon"
                    style={{ background: "#f59e0b", borderColor: "#fbbf24" }}
                  >
                    <Package size={14} strokeWidth={2.2} />
                  </span>
                </span>
                <span
                  style={{
                    fontSize: 11.5,
                    color: "#334155",
                    fontWeight: 500,
                    lineHeight: 1.3,
                    textAlign: "center",
                  }}
                >
                  Nhận hàng<br />hóa, dịch vụ
                </span>
              </div>

              {/* Action Dropdown matching screenshot */}
              {activeFlowchartMenu === "receive-goods" && (
                <div
                  className="ref-action-options"
                  style={{
                    position: "absolute",
                    top: "calc(100% + 4px)",
                    left: "50%",
                    transform: "translateX(-50%)",
                    minWidth: 200,
                    zIndex: 100,
                    background: "#ffffff",
                    boxShadow: "0 10px 25px rgba(0,0,0,0.12), 0 2px 6px rgba(0,0,0,0.04)",
                    borderRadius: 6,
                    border: "1px solid #e2e8f0",
                    padding: "6px 0",
                  }}
                  onMouseEnter={() => handleFlowchartMouseEnter("receive-goods")}
                  onMouseLeave={handleFlowchartMouseLeave}
                >
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      transition: "background 0.15s, color 0.15s",
                      display: "block",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveFlowchartMenu(null);
                      setVoucherKindOption("goods");
                      setShowVoucherModal(true);
                    }}
                  >
                    Chứng từ mua hàng
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      transition: "background 0.15s, color 0.15s",
                      display: "block",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveFlowchartMenu(null);
                      setVoucherKindOption("service");
                      setShowServiceModal(true);
                    }}
                  >
                    Chứng từ mua dịch vụ
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      transition: "background 0.15s, color 0.15s",
                      display: "block",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveFlowchartMenu(null);
                      setVoucherKindOption("multi");
                      setShowMultiInvoiceModal(true);
                    }}
                  >
                    Mua hàng nhiều hóa đơn
                  </button>
                </div>
              )}
            </div>

            {/* Col 2 Bottom: Nhận hóa đơn */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "36.06%",
                transform: "translateX(-50%)",
                top: 185,
                width: 125,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 10,
              }}
              onClick={() => {
                if (href) {
                  navigate(href("/purchases/invoices"));
                } else {
                  setShowReceiveInvoiceModal(true);
                }
              }}
              title="Nhận hóa đơn mua hàng"
            >
              <span className="ref-business-icon invoice" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>HĐ</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "#f59e0b", borderColor: "#fbbf24" }}
                >
                  <FileText size={14} strokeWidth={2.2} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3, textAlign: "center" }}>
                Nhận hóa đơn
              </span>
            </div>

            {/* Col 3 Top: Xử lý hóa đơn đầu vào */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "61.82%",
                transform: "translateX(-50%)",
                top: 20,
                width: 125,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 10,
              }}
              onClick={() => navigate(href ? href("/invoices/incoming/inbox") : "/invoices/incoming/inbox")}
              title="Xử lý hóa đơn đầu vào"
            >
              <span className="ref-business-icon process" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>XL</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "#f59e0b", borderColor: "#fbbf24" }}
                >
                  <Sparkles size={14} strokeWidth={2.2} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3, textAlign: "center" }}>
                Xử lý hóa<br />đơn đầu vào
              </span>
            </div>

            {/* Col 3 Bottom: Trả lại hàng mua */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "61.82%",
                transform: "translateX(-50%)",
                top: 185,
                width: 125,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 10,
              }}
              onClick={() => setShowReturnModal(true)}
              title="Lập chứng từ trả lại hàng mua"
            >
              <span className="ref-business-icon return" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>TL</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "#f59e0b", borderColor: "#fbbf24" }}
                >
                  <RotateCcw size={14} strokeWidth={2.2} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3, textAlign: "center" }}>
                Trả lại<br />hàng mua
              </span>
            </div>

            {/* Col 4 Top: Trả tiền theo hóa đơn */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "87.58%",
                transform: "translateX(-50%)",
                top: 20,
                width: 125,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 10,
              }}
              onClick={() => setShowSupplierPaymentModal(true)}
              title="Trả tiền nhà cung cấp theo hóa đơn"
            >
              <span className="ref-business-icon pay" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>CHI</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "#ea580c", borderColor: "#f97316" }}
                >
                  <Coins size={14} strokeWidth={2.2} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3, textAlign: "center" }}>
                Trả tiền theo<br />hóa đơn
              </span>
            </div>

            {/* Col 4 Bottom: Giảm giá hàng mua */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "87.58%",
                transform: "translateX(-50%)",
                top: 185,
                width: 125,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 10,
              }}
              onClick={() => setShowDiscountModal(true)}
              title="Lập chứng từ Giảm giá hàng mua"
            >
              <span className="ref-business-icon discount" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>GG</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "#f59e0b", borderColor: "#fbbf24" }}
                >
                  <Percent size={14} strokeWidth={2.2} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3, textAlign: "center" }}>
                Giảm giá<br />hàng mua
              </span>
            </div>
          </div>
        </section>

        {/* Panel 2: BÁO CÁO (Right Column) */}
        <aside
          style={{
            background: "#ffffff",
            borderRadius: 8,
            border: "1px solid #e2e8f0",
            boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
          }}
        >
          <h2
            style={{
              fontSize: 13,
              fontWeight: 700,
              margin: 0,
              padding: "14px 16px",
              borderBottom: "1px solid #f1f5f9",
              color: "#1e293b",
            }}
          >
            BÁO CÁO MUA HÀNG
          </h2>

          <ul style={{ listStyle: "none", margin: 0, padding: "10px 14px", display: "flex", flexDirection: "column", gap: 10 }}>
            {['Chi tiết công nợ phải trả nhà cung cấp','Tổng hợp mua hàng theo mặt hàng','Tổng hợp công nợ phải trả nhà cung cấp','Biên bản đối chiếu và xác nhận công nợ phải trả'].map(name=><li key={name}><button style={{border:0,background:'transparent',padding:0,fontSize:12.5,color:'var(--brand)',cursor:'pointer',textAlign:'left'}} onClick={()=>openPurchaseReport(name)}>• {name}</button></li>)}
            <li>
              <span style={{ fontSize: 12.5, color: "var(--brand)", cursor: "pointer", fontWeight: 500 }} onClick={() => openPurchaseReport("Sổ chi tiết mua hàng")}>
                • Sổ chi tiết mua hàng
              </span>
            </li>
            <li>
              <span style={{ fontSize: 12.5, color: "var(--brand)", cursor: "pointer", fontWeight: 500 }} onClick={() => openPurchaseReport("Sổ chi tiết mua hàng")}>
                • Bảng kê hóa đơn dịch vụ mua vào
              </span>
            </li>
            <li>
              <span style={{ fontSize: 12.5, color: "var(--brand)", cursor: "pointer", fontWeight: 500 }} onClick={() => openPurchaseReport("Tổng hợp công nợ phải trả nhà cung cấp")}>
                • Báo cáo công nợ phải trả NCC
              </span>
            </li>
            <li>
              <span style={{ fontSize: 12.5, color: "var(--brand)", cursor: "pointer", fontWeight: 500 }} onClick={() => openPurchaseReport("Tình hình thực hiện đơn mua hàng")}>
                • Tình hình thực hiện đơn mua hàng
              </span>
            </li>
            <li>
              <span style={{ fontSize: 12.5, color: "var(--brand)", cursor: "pointer", fontWeight: 500 }} onClick={() => openPurchaseReport("Tình hình thực hiện hợp đồng mua")}>
                • Theo dõi tiến độ hợp đồng mua
              </span>
            </li>
          </ul>

          <div style={{ marginTop: "auto", padding: "12px 14px", borderTop: "1px solid #f1f5f9", textAlign: "center" }}>
            <span style={{ fontSize: 12, color: "#059669", cursor: "pointer", fontWeight: 600 }} onClick={() => navigate(href?.("/purchases/reports")||"/purchases/reports")}>
              Tất cả báo cáo mua hàng →
            </span>
          </div>
        </aside>

        {/* Panel 3: Quick Action Buttons (Bottom Bar spanning full width) */}
        <div
          className="ref-shortcuts"
          style={{
            gridColumn: "1 / -1",
            background: "#ffffff",
            borderRadius: 8,
            border: "1px solid #e2e8f0",
            boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
            display: "grid",
            gridTemplateColumns: "repeat(5, 1fr)",
            overflow: "visible",
            position: "relative",
            zIndex: 10,
          }}
        >
          <button
            type="button"
            style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8, padding: "14px 8px", background: "#ffffff", border: "none", borderRight: "1px solid #f1f5f9", cursor: "pointer", fontSize: 12, color: "#334155" }}
            onClick={() => setShowSupplierModal(true)}
          >
            <Building2 size={20} style={{ color: "var(--brand)" }} />
            <span>Nhà cung cấp</span>
          </button>

          <button
            type="button"
            style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8, padding: "14px 8px", background: "#ffffff", border: "none", borderRight: "1px solid #f1f5f9", cursor: "pointer", fontSize: 12, color: "#334155" }}
            onClick={() => navigate(href?.("/purchases/inventory-items")||"/purchases/inventory-items")}
          >
            <Package size={20} style={{ color: "#f59e0b" }} />
            <span>Hàng hóa, dịch vụ</span>
          </button>

          <button
            type="button"
            style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8, padding: "14px 8px", background: "#ffffff", border: "none", borderRight: "1px solid #f1f5f9", cursor: "pointer", fontSize: 12, color: "#334155" }}
            onClick={() => setPaymentTermsOpen(true)}
          >
            <ShieldCheck size={20} style={{ color: "var(--brand)" }} />
            <span>Điều khoản thanh toán</span>
          </button>

          <div style={{ position: "relative", borderRight: "1px solid #f1f5f9" }}>
            <button
              type="button"
              style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", gap: 8, padding: "14px 8px", background: "#ffffff", border: "none", cursor: "pointer", fontSize: 12, color: "#334155" }}
              aria-expanded={showUtilityMenu}
              onClick={() => setShowUtilityMenu(!showUtilityMenu)}
            >
              <Lightbulb size={20} style={{ color: "#10b981" }} />
              <span>Tiện ích ▾</span>
            </button>
            {showUtilityMenu && (
              <>
                <div onClick={() => setShowUtilityMenu(false)} style={{ position: "fixed", inset: 0, zIndex: 19 }} />
                <div role="menu" aria-label="Tiện ích mua hàng" style={{ position: "absolute", bottom: "calc(100% + 8px)", left: "50%", transform: "translateX(-50%)", width: 280, background: "white", border: "1px solid #e2e8f0", borderRadius: 6, boxShadow: "0 8px 24px rgba(0,0,0,0.12)", padding: 4, zIndex: 25 }}>
                  {[
                    { label: "Đối trừ chứng từ", open: () => setShowDebtOffsetModal(true) },
                    { label: "Đối trừ chứng từ nhiều đối tượng", open: () => setShowMultiDebtOffsetModal(true) },
                    { label: "Bỏ đối trừ", open: () => setShowUnOffsetModal(true) },
                    { label: "Bỏ đối trừ chứng từ nhiều đối tượng", open: () => setShowMultiUnOffsetModal(true) },
                    { label: "Bù trừ công nợ", open: () => setShowDebtClearingModal(true) },
                  ].map((item) => (
                    <button key={item.label} role="menuitem" style={{ display: "block", width: "100%", textAlign: "left", border: 0, padding: "10px 14px", background: "transparent", cursor: "pointer", fontSize: 12.5, color: "#1e293b", borderRadius: 4 }} onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")} onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")} onClick={() => { setShowUtilityMenu(false); item.open(); }}>
                      {item.label}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          <button
            type="button"
            style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8, padding: "14px 8px", background: "#ffffff", border: "none", cursor: "pointer", fontSize: 12, color: "#334155" }}
            onClick={() => navigate("/admin?tab=config")}
          >
            <SlidersHorizontal size={20} style={{ color: "#64748b" }} />
            <span>Tùy chọn</span>
          </button>
        </div>
      </div>

      {renderModals()}
    </div>
  );
}
