import { exportVisibleTable, printVisibleTable } from "./table-actions";
import LedgerAccountField from "./LedgerAccountField";
import { MapPin } from "lucide-react";
import { formatMoneyInput, parseMoneyInput, parseMoneyInputString } from "./formatMoney";
import MisaDropdownSelect from "./MisaDropdownSelect";
import MisaSaveSplitButton from "./components/MisaSaveSplitButton";
import VoucherDateField from "./VoucherDateField";
import {SupplierModal} from "./MisaPurchaseModals";
import MisaDirectoryWorkspace from "./MisaDirectoryWorkspace";
import {CASH_PERIODS} from "./cash-report-periods";
import {MISA_REPORT_ACCOUNTS} from "./misa-report-accounts";
import BankAccountChoiceTable from "./BankAccountChoiceTable";
import VoucherChoiceTable from "./VoucherChoiceTable";
import CashReferencePicker from "./CashReferencePicker";
import CashOptionsDialog from "./CashOptionsDialog";
import CashExcelImport from "./CashExcelImport";
import CashColumnDialog from "./CashColumnDialog";
import {readCashColumns,type CashColumn} from "./cash-columns";
import CashImportTaxFields from "./CashImportTaxFields";
import {useNavigate,useSearchParams} from "react-router-dom";
import { useApiSession } from "./ApiSession";
import { useMisaApiLists, useMisaApiSave } from "./misa-api-lists";
import {
  completeTransfer, createApiWriter, insurancePaymentRows, internalTransfers, nextVoucherNumber, salaryPaymentRows, savePayrollPayment, openPayables, openReceivables, postMoneyTransaction,
  reverseMoneyTransaction, saveCashReceiptDraft, saveCustomerReceipts, saveMoneyVoucher, saveSupplierPayment, toApiDate,
} from "./misa-api-writes";
import type { CollectionDebtSource } from "./MisaInvoiceCollectionModals";
import { request } from "./live-api";
import React, { useState, useMemo, useRef, useEffect } from "react";
import {currentCashDate,isCashDateInRange,cashDateValue} from './cash-date';
import {nextCashCode,cashLedger,type CashEntry} from './cash-operations';
import {downloadCashCsv} from './cash-download';
import {parseReportDate} from './report-date';
import CashAdvancedPanel,{defaultCashFilter,cashReason,type CashFilter} from './CashAdvancedPanel';
import MisaCashReportView from './MisaCashReportView';
import MisaCashInventoryWorkspace from './MisaCashInventoryWorkspace';
import MisaCashForecastWorkspace from './MisaCashForecastWorkspace';
import MisaPaymentWorkflow from './MisaPaymentWorkflow';
import {
  matchesTransactionPeriod,
  resolveActiveBranchScope,
  resolveActiveDatasetBookType,
  resolveActiveDatasetYear,
  resolveActiveHeaderPeriod,
  resolveActivePeriodRange,
} from './transaction-period';
import {
  ChartNoAxesCombined,
  Filter,
  Plus,
  Search,
  RefreshCw,
  Printer,
  FileSpreadsheet,
  Settings,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  ChevronLeft,
  Clock,
  Sparkles,
  Info,
  X,
  Check,
  Download,
  RotateCw,
  ZoomIn,
  ZoomOut,
  ClipboardList,
  Calculator,
  Coins,
  HelpCircle,
  MessageSquare,
  UserRound,
  Building2,
  Users,
  SlidersHorizontal,
  Trash2,
  Paperclip,
  Upload,
  RotateCcw,
  FileText,
  Calendar,
  Star,
  BookOpen,
  BarChart3,
  ArrowLeft,
  ArrowRight,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
} from "lucide-react";
import {
  SingleCustomerInvoiceCollectionModal,
  MultiCustomerInvoiceCollectionModal,
} from "./MisaInvoiceCollectionModals";
import {
  InsurancePaymentModal,
  SalaryPaymentModal,
  InternalTransferModal,
  MisaEmptyState,
} from "./MisaBankModals";
import "./misa-cash.css";


import { showNotice, showPendingFeature } from "./global-popup";
// Helper format tiền tệ VNĐ
export function formatVND(amount: number): string {
  return new Intl.NumberFormat("vi-VN").format(amount);
}

// Helper chuyển đổi số tiền thành chữ tiếng Việt chuẩn kế toán
export function convertNumberToVietnameseWords(n: number): string {
  if (!n || isNaN(n) || n === 0) return "Không đồng";
  const units = ["", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín"];
  const teens = [
    "mười",
    "mười một",
    "mười hai",
    "mười ba",
    "mười bốn",
    "mười lăm",
    "mười sáu",
    "mười bảy",
    "mười tám",
    "mười chín",
  ];

  function readGroup(g: number): string {
    const h = Math.floor(g / 100);
    const t = Math.floor((g % 100) / 10);
    const u = g % 10;
    let res = "";
    if (h > 0) {
      res += units[h] + " trăm";
      if (t === 0 && u > 0) res += " linh";
    }
    if (t > 1) {
      res += " " + units[t] + " mươi";
      if (u === 1) res += " mốt";
      else if (u === 5) res += " lăm";
      else if (u > 0) res += " " + units[u];
    } else if (t === 1) {
      res += " " + teens[u];
    } else if (u > 0 && h === 0) {
      res += units[u];
    } else if (u > 0) {
      res += " " + units[u];
    }
    return res.trim();
  }

  const scales = ["", "nghìn", "triệu", "tỷ", "nghìn tỷ"];
  let num = Math.abs(Math.round(n));
  let parts: string[] = [];
  let scaleIdx = 0;

  while (num > 0) {
    const grp = num % 1000;
    if (grp > 0) {
      const text = readGroup(grp);
      parts.unshift(text + (scales[scaleIdx] ? " " + scales[scaleIdx] : ""));
    }
    num = Math.floor(num / 1000);
    scaleIdx++;
  }

  const result = parts.join(" ").trim();
  const capitalized = result.charAt(0).toUpperCase() + result.slice(1);
  return capitalized + " đồng";
}

// ----------------------------------------------------------------------
// 1. MODAL "NỘP THUẾ" (MATCHING SCREENSHOT 2)
// ----------------------------------------------------------------------
export function TaxPaymentModal({
  initialMethod = "cash",
  onClose,
  onSubmit,
}: {
  initialMethod?: "cash" | "bank";
  onClose: () => void;
  onSubmit: (taxData: {
    taxType: string;
    paymentMethod: string;
    taxDate: string;
    totalAmount: number;
    items?: { name: string; due: number; pay: number }[];
  }) => void;
}) {
  const [taxType, setTaxType] = useState("Thuế khác");
  const [taxDate, setTaxDate] = useState(currentCashDate);
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "bank">(initialMethod);

  const [taxItems, setTaxItems] = useState<
    { id: string; name: string; due: number; pay: number; checked: boolean }[]
  >([]);

  React.useEffect(() => {
    if (taxType === "Thuế khác") {
      setTaxItems([]);
    } else if (taxType === "Thuế GTGT") {
      setTaxItems([
        { id: "vat1", name: "Thuế GTGT phải nộp quý 3/2026", due: 15420000, pay: 15420000, checked: true },
      ]);
    } else if (taxType === "Thuế TNDN") {
      setTaxItems([
        { id: "cit1", name: "Thuế TNDN tạm nộp quý 3/2026", due: 24500000, pay: 24500000, checked: true },
      ]);
    } else if (taxType === "Thuế TNCN") {
      setTaxItems([
        { id: "pit1", name: "Thuế TNCN khấu trừ từ tiền lương tháng 09/2026", due: 5850000, pay: 5850000, checked: true },
      ]);
    } else if (taxType === "Lệ phí môn bài") {
      setTaxItems([
        { id: "mb1", name: "Lệ phí môn bài bậc 1 (VĐL > 10 tỷ đồng)", due: 3000000, pay: 3000000, checked: true },
      ]);
    } else if (taxType === "Thuế hàng nhập khẩu") {
      setTaxItems([
        { id: "nk1", name: "Thuế nhập khẩu linh kiện thiết bị y tế theo tờ khai 105928374920", due: 18200000, pay: 18200000, checked: true },
        { id: "nk2", name: "Thuế GTGT hàng nhập khẩu theo tờ khai 105928374920", due: 11800000, pay: 11800000, checked: true },
      ]);
    }
  }, [taxType]);

  const toggleCheck = (id: string) => {
    setTaxItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const nextChecked = !item.checked;
          return {
            ...item,
            checked: nextChecked,
            pay: nextChecked ? item.due : 0,
          };
        }
        return item;
      }),
    );
  };

  const updatePayAmount = (id: string, amountStr: string) => {
    const cleanNum = parseInt(amountStr.replace(/\D/g, "") || "0", 10);
    setTaxItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, pay: cleanNum } : item)),
    );
  };

  const totalDue = useMemo(
    () => taxItems.reduce((sum, item) => sum + item.due, 0),
    [taxItems],
  );

  const totalPay = useMemo(
    () =>
      taxItems.reduce(
        (sum, item) => sum + (item.checked ? item.pay : 0),
        0,
      ),
    [taxItems],
  );

  const allChecked = taxItems.length > 0 && taxItems.every((item) => item.checked);
  const toggleAll = () => {
    const nextState = !allChecked;
    setTaxItems((prev) =>
      prev.map((item) => ({
        ...item,
        checked: nextState,
        pay: nextState ? item.due : 0,
      })),
    );
  };

  const handlePay = () => {
    onSubmit({
      taxType,
      paymentMethod,
      taxDate,
      totalAmount: totalPay,
      items: taxItems
        .filter((t) => t.checked && t.pay > 0)
        .map((t) => ({ name: t.name, due: t.due, pay: t.pay })),
    });
  };

  return (
    <div className="misa-modal-backdrop" role="dialog" aria-modal="true">
      <div className="misa-invoice-collect-window">
        {/* Floating Right Drawer Handle */}
        <button
          type="button"
          className="misa-voucher-drawer-handle"
          title="Thu phóng tab"
        >
          <ChevronLeft size={16} />
        </button>

        {/* Modal Header (Matching Screenshot 2) */}
        <header className="misa-invoice-collect-header">
          <div className="misa-invoice-collect-title">Nộp thuế</div>
          <div className="misa-invoice-collect-actions">
            <button
              type="button"
              className="misa-invoice-help-link"
              onClick={() => showPendingFeature("Hướng dẫn sử dụng Nộp thuế")}
            >
              <HelpCircle size={15} />
              <span>Hướng dẫn sử dụng</span>
              <ChevronDown size={13} />
            </button>
            <button
              type="button"
              className="misa-invoice-circle-btn"
              title="Trợ giúp"
            >
              <HelpCircle size={17} />
            </button>
            <button
              type="button"
              className="misa-invoice-circle-btn"
              onClick={onClose}
              title="Đóng"
            >
              <X size={18} />
            </button>
          </div>
        </header>

        {/* Master Box (Matching Screenshot 2) */}
        <div className="misa-invoice-master-box" style={{ flexDirection: "column", gap: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 20, flexWrap: "wrap" }}>
              {/* Loại thuế */}
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 13, color: "#374151" }}>Loại thuế</span>
                <div style={{ position: "relative", width: 180 }}>
                  <select
                    value={taxType}
                    onChange={(e) => setTaxType(e.target.value)}
                    style={{
                      width: "100%",
                      height: 32,
                      padding: "0 28px 0 10px",
                      borderRadius: 4,
                      border: "1px solid #d1d5db",
                      fontSize: 13,
                      background: "#ffffff",
                      appearance: "none",
                      cursor: "pointer",
                    }}
                  >
                    <option value="Thuế khác">Thuế khác</option>
                    <option value="Thuế hàng nhập khẩu">Thuế hàng nhập khẩu</option>
                    <option value="Thuế GTGT">Thuế GTGT</option>
                    <option value="Thuế TNDN">Thuế TNDN tạm tính</option>
                    <option value="Thuế TNCN">Thuế TNCN</option>
                    <option value="Lệ phí môn bài">Lệ phí môn bài</option>
                  </select>
                  <ChevronDown
                    size={14}
                    style={{
                      position: "absolute",
                      right: 8,
                      top: "50%",
                      transform: "translateY(-50%)",
                      pointerEvents: "none",
                      color: "#6b7280",
                    }}
                  />
                </div>
              </div>

              {/* Ngày nộp thuế */}
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 13, color: "#374151" }}>Ngày nộp thuế</span>
                <div style={{ position: "relative", width: 140 }}>
                  <input
                    type="text"
                    value={taxDate}
                    onChange={(e) => setTaxDate(e.target.value)}
                    style={{
                      width: "100%",
                      height: 32,
                      padding: "0 28px 0 10px",
                      borderRadius: 4,
                      border: "1px solid #d1d5db",
                      fontSize: 13,
                      background: "#ffffff",
                    }}
                  />
                  <Calendar
                    size={15}
                    style={{
                      position: "absolute",
                      right: 8,
                      top: "50%",
                      transform: "translateY(-50%)",
                      color: "#6b7280",
                      pointerEvents: "none",
                    }}
                  />
                </div>
              </div>

              {/* Phương thức thanh toán (Tiền gửi first, Tiền mặt second - Screenshot 2) */}
              <div style={{ display: "flex", alignItems: "center", gap: 12, fontSize: 13 }}>
                <span style={{ color: "#374151" }}>Phương thức thanh toán</span>
                <label style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
                  <input
                    type="radio"
                    name="taxPaymentMethod"
                    checked={paymentMethod === "bank"}
                    onChange={() => setPaymentMethod("bank")}
                    style={{ accentColor: "var(--brand)", cursor: "pointer" }}
                  />
                  <span>Tiền gửi</span>
                </label>
                <label style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
                  <input
                    type="radio"
                    name="taxPaymentMethod"
                    checked={paymentMethod === "cash"}
                    onChange={() => setPaymentMethod("cash")}
                    style={{ accentColor: "var(--brand)", cursor: "pointer" }}
                  />
                  <span>Tiền mặt</span>
                </label>
              </div>
            </div>

            {/* Right KPI (Screenshot 2: Số nộp lần này / 0) */}
            <div className="misa-invoice-master-right" style={{ paddingRight: 0 }}>
              <span className="misa-invoice-total-label">Số nộp lần này</span>
              <div className="misa-invoice-total-val">
                {formatVND(totalPay)}
              </div>
            </div>
          </div>

          {taxType === "Thuế hàng nhập khẩu" && <CashImportTaxFields/>}
          {/* Blue Note (Exact text from Screenshot 2) */}
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              gap: 8,
              color: "#1d4ed8",
              fontSize: 12.5,
              lineHeight: 1.5,
              padding: "4px 0",
            }}
          >
            <Info size={16} style={{ flexShrink: 0, marginTop: 2, color: "#2563eb" }} />
            <div>
              <p style={{ margin: 0 }}>
                <em>Lưu ý: Tại đơn vị có phát sinh thuế nhập khẩu, thuế chống bán phá giá, thuế TTĐB, thuế bảo vệ môi trường, thuế GTGT của hàng nhập khẩu thì vui lòng chọn cách nộp thuế sau:</em>
              </p>
              <p style={{ margin: "2px 0 0 0" }}>
                <em>1. Nếu đơn vị quản lý nộp thuế hàng nhập khẩu theo từng tờ khai hải quan thì khi nộp thuế chọn loại &ldquo;Thuế hàng nhập khẩu&rdquo;</em>
              </p>
              <p style={{ margin: "2px 0 0 0" }}>
                <em>2. Nếu đơn vị không có nhu cầu nộp thuế nhập khẩu, thuế chống bán phá giá, thuế TTĐB, thuế bảo vệ môi trường theo từng tờ khai hải quan thì khi nộp thuế chọn loại &ldquo;Thuế khác&rdquo;</em>
              </p>
            </div>
          </div>
        </div>

        {/* Table Container (Matching Screenshot 2) */}
        <div className="misa-invoice-body">
          <div className="misa-invoice-table-container">
            {/* Title Bar */}
            <div style={{ padding: "10px 14px", background: "#ffffff", borderBottom: "1px solid #cbd5e1" }}>
              <strong style={{ fontSize: 13.5, color: "#111827" }}>Chi tiết khoản thuế</strong>
            </div>

            {/* Table Wrapper */}
            <div className="misa-invoice-table-wrapper" style={{ display: "flex", flexDirection: "column" }}>
              <table className="misa-invoice-table">
                <thead>
                  <tr>
                    <th style={{ width: 36, textAlign: "center" }}>
                      <input
                        type="checkbox"
                        checked={allChecked}
                        onChange={toggleAll}
                        style={{ accentColor: "var(--brand)", cursor: "pointer" }}
                      />
                    </th>
                    <th>Khoản phải nộp</th>
                    <th style={{ width: 220, textAlign: "right" }}>Số phải nộp</th>
                    <th style={{ width: 220, textAlign: "right" }}>Số nộp lần này</th>
                  </tr>
                  {/* Summary row directly below Header (Screenshot 2: Cộng) */}
                  <tr style={{ background: "#e2ece5", fontWeight: 700 }}>
                    <td style={{ textAlign: "center", borderRight: "1px solid #cbd5e1" }}></td>
                    <td style={{ fontWeight: 700, color: "#111827" }}>Cộng</td>
                    <td style={{ textAlign: "right", fontWeight: 700, color: "#111827" }}>
                      {formatVND(totalDue)}
                    </td>
                    <td style={{ textAlign: "right", fontWeight: 700, color: "#111827" }}>
                      {formatVND(totalPay)}
                    </td>
                  </tr>
                </thead>
                {taxItems.length > 0 && (
                  <tbody>
                    {taxItems.map((item) => (
                      <tr key={item.id} style={{ background: item.checked ? "#f0fdf4" : "#ffffff" }}>
                        <td style={{ textAlign: "center" }}>
                          <input
                            type="checkbox"
                            checked={item.checked}
                            onChange={() => toggleCheck(item.id)}
                            style={{ accentColor: "var(--brand)", cursor: "pointer" }}
                          />
                        </td>
                        <td>{item.name}</td>
                        <td style={{ textAlign: "right" }}>{formatVND(item.due)}</td>
                        <td style={{ textAlign: "right" }}>
                          <input
                            type="text"
                            value={formatVND(item.pay)}
                            disabled={!item.checked}
                            onChange={(e) => updatePayAmount(item.id, e.target.value)}
                            style={{
                              height: 28,
                              width: 140,
                              padding: "0 8px",
                              borderRadius: 4,
                              border: "1px solid #d1d5db",
                              textAlign: "right",
                              fontSize: 13,
                              background: item.checked ? "#ffffff" : "#f1f5f9",
                            }}
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                )}
              </table>

              {/* Empty state when no records (Screenshot 2) */}
              {taxItems.length === 0 && (
                <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <MisaEmptyState text="Không có dữ liệu" />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer (Matching Screenshot 2) */}
        <footer className="misa-invoice-footer">
          <button
            type="button"
            className="misa-invoice-btn-cancel"
            onClick={onClose}
          >
            Hủy
          </button>
          <button
            type="button"
            className="misa-invoice-btn-submit"
            onClick={handlePay}
          >
            Nộp thuế
          </button>
        </footer>
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// 1b. MODAL "TRẢ TIỀN NHÀ CUNG CẤP THEO HÓA ĐƠN" (MATCHING SCREENSHOT 1)
// ----------------------------------------------------------------------
export function SupplierPaymentModal({
  initialMethod = "cash",
  onClose,
  onSubmit,
  debtSource,
}: {
  /** Backend suppliers and payables; the sample rows are used when absent. */
  debtSource?: CollectionDebtSource;
  initialMethod?: "cash" | "bank";
  onClose: () => void;
  onSubmit: (data: {
    payMethod: string;
    currency: string;
    supplier: string;
    employee: string;
    payDate: string;
    totalAmount: number;
    invoices: any[];
  }) => boolean | void | Promise<boolean | void>;
}) {
  const [payMethod, setPayMethod] = useState(initialMethod === "bank" ? "Tiền gửi" : "Tiền mặt");
  const [supplier, setSupplier] = useState("");
  const [employee, setEmployee] = useState("");
  const [payDate, setPayDate] = useState(currentCashDate);
  const [searchInvoice, setSearchInvoice] = useState("");
  const [quickAmount, setQuickAmount] = useState("");

  const [invoices, setInvoices] = useState<
    {
      id: string;
      voucherDate: string;
      voucherCode: string;
      invoiceDate: string;
      invoiceCode: string;
      description: string;
      dueDate: string;
      totalDebt: number;
      remainingDebt: number;
      payAmount: number;
      account: string;
      terms: string;
      checked: boolean;
      discountRate?: number;
      discountAmount?: number;
      discountAccount?: string;
    }[]
  >([]);

  const handleFetchData = () => {
    setInvoices([
      {
        id: "inv-1",
        voucherDate: "01/09/2026",
        voucherCode: "CT00018",
        invoiceDate: "01/09/2026",
        invoiceCode: "HD-00281",
        description: "Mua giấy in, mực in văn phòng tháng 9",
        dueDate: "15/09/2026",
        totalDebt: 18500000,
        remainingDebt: 18500000,
        payAmount: 18500000,
        account: "331",
        terms: "TT 15 ngày",
        checked: true,
      },
      {
        id: "inv-2",
        voucherDate: "28/08/2026",
        voucherCode: "CT00012",
        invoiceDate: "28/08/2026",
        invoiceCode: "HD-00195",
        description: "Mua bàn ghế làm việc phòng kinh doanh",
        dueDate: "10/09/2026",
        totalDebt: 32000000,
        remainingDebt: 12000000,
        payAmount: 12000000,
        account: "331",
        terms: "TT 30 ngày",
        checked: true,
      },
      {
        id: "inv-3",
        voucherDate: "15/08/2026",
        voucherCode: "CT00008",
        invoiceDate: "15/08/2026",
        invoiceCode: "HD-00114",
        description: "Mua linh kiện máy tính bảo trì hệ thống",
        dueDate: "05/09/2026",
        totalDebt: 8400000,
        remainingDebt: 8400000,
        payAmount: 0,
        account: "331",
        terms: "TT ngay",
        checked: false,
      },
    ]);
  };

  const toggleInvoiceCheck = (id: string) => {
    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id === id) {
          const nextChecked = !inv.checked;
          return {
            ...inv,
            checked: nextChecked,
            payAmount: nextChecked ? inv.remainingDebt : 0,
          };
        }
        return inv;
      }),
    );
  };

  const updateInvoicePayAmount = (id: string, val: string) => {
    const num = parseInt(val.replace(/\D/g, "") || "0", 10);
    setInvoices((prev) =>
      prev.map((inv) => (inv.id === id ? { ...inv, payAmount: num } : inv)),
    );
  };

  const toggleSelectAll = () => {
    const allChecked = invoices.length > 0 && invoices.every((i) => i.checked);
    setInvoices((prev) =>
      prev.map((inv) => ({
        ...inv,
        checked: !allChecked,
        payAmount: !allChecked ? inv.remainingDebt : 0,
      })),
    );
  };

  const handleQuickAmount = (val: string) => {
    const cleanNum = parseInt(val.replace(/\D/g, "") || "0", 10);
    setQuickAmount(cleanNum > 0 ? formatVND(cleanNum) : "");
    let remain = cleanNum;
    setInvoices((prev) =>
      prev.map((inv) => {
        if (remain <= 0) {
          return { ...inv, payAmount: 0, checked: false };
        }
        const alloc = Math.min(remain, inv.remainingDebt);
        remain -= alloc;
        return {
          ...inv,
          payAmount: alloc,
          checked: alloc > 0,
        };
      }),
    );
  };

  const displayedInvoices = useMemo(() => {
    if (!searchInvoice) return invoices;
    const q = searchInvoice.toLowerCase();
    return invoices.filter(
      (inv) =>
        inv.voucherCode.toLowerCase().includes(q) ||
        inv.invoiceCode.toLowerCase().includes(q) ||
        inv.description.toLowerCase().includes(q),
    );
  }, [invoices, searchInvoice]);

  const totalDebtSum = useMemo(
    () => displayedInvoices.reduce((sum, inv) => sum + inv.totalDebt, 0),
    [displayedInvoices],
  );
  const remainingDebtSum = useMemo(
    () => displayedInvoices.reduce((sum, inv) => sum + inv.remainingDebt, 0),
    [displayedInvoices],
  );
  const totalPayAmount = useMemo(
    () =>
      displayedInvoices.reduce(
        (sum, inv) => sum + (inv.checked ? inv.payAmount : 0),
        0,
      ),
    [displayedInvoices],
  );

  const handlePay = () => {
    onSubmit({
      payMethod,
      currency: "VND",
      supplier,
      employee,
      payDate,
      totalAmount: totalPayAmount,
      invoices: displayedInvoices.filter((i) => i.checked && i.payAmount > 0),
    });
  };

  return (
    <div className="misa-modal-backdrop" role="dialog" aria-modal="true">
      <div className="misa-invoice-collect-window">
        {/* Floating Right Drawer Handle */}
        <button
          type="button"
          className="misa-voucher-drawer-handle"
          title="Thu phóng tab"
        >
          <ChevronLeft size={16} />
        </button>

        {/* Modal Header (Matching Screenshot 1) */}
        <header className="misa-invoice-collect-header">
          <div className="misa-invoice-collect-title">
            Trả tiền nhà cung cấp theo hóa đơn
          </div>
          <div className="misa-invoice-collect-actions">
            <button
              type="button"
              className="misa-invoice-help-link"
              onClick={() => showPendingFeature("Hướng dẫn sử dụng Trả tiền nhà cung cấp theo hóa đơn")}
            >
              <HelpCircle size={15} />
              <span>Hướng dẫn sử dụng</span>
              <ChevronDown size={13} />
            </button>
            <button
              type="button"
              className="misa-invoice-circle-btn"
              title="Trợ giúp"
            >
              <HelpCircle size={17} />
            </button>
            <button
              type="button"
              className="misa-invoice-circle-btn"
              onClick={onClose}
              title="Đóng"
            >
              <X size={18} />
            </button>
          </div>
        </header>

        {/* Master Box (Matching Screenshot 1) */}
        <div className="misa-invoice-master-box">
          <div className="misa-invoice-master-left">
            {/* Row 1: Phương thức thanh toán */}
            <div className="misa-invoice-field" style={{ width: 150 }}>
              <label>Phương thức thanh toán</label>
              <div style={{ position: "relative" }}>
                <select
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value)}
                  style={{
                    width: "100%",
                    height: 32,
                    padding: "0 28px 0 10px",
                    borderRadius: 4,
                    border: "1px solid #3b82f6",
                    fontSize: 13,
                    background: "#ffffff",
                    appearance: "none",
                    cursor: "pointer",
                  }}
                >
                  <option value="Tiền mặt">Tiền mặt</option>
                  <option value="Tiền gửi">Tiền gửi</option>
                </select>
                <ChevronDown
                  size={14}
                  style={{
                    position: "absolute",
                    right: 8,
                    top: "50%",
                    transform: "translateY(-50%)",
                    pointerEvents: "none",
                    color: "#6b7280",
                  }}
                />
              </div>
            </div>

            {/* Row 2: Nhà cung cấp (Combobox full width / max-width 720) */}
            <div className="misa-invoice-field" style={{ width: "100%", maxWidth: 720 }}>
              <label>Nhà cung cấp</label>
              <div style={{ position: "relative" }}>
                <select
                  value={supplier}
                  onChange={(e) => setSupplier(e.target.value)}
                  style={{
                    width: "100%",
                    height: 32,
                    padding: "0 30px 0 10px",
                    borderRadius: 4,
                    border: "1px solid #d1d5db",
                    fontSize: 13,
                    background: "#ffffff",
                    appearance: "none",
                    cursor: "pointer",
                  }}
                >
                  <option value="">&nbsp;</option>
                  {debtSource?.customers.map((row) => (
                    <option key={row.code} value={row.code}>{row.code} - {row.name}</option>
                  ))}
                  {!debtSource && <>
                  <option value="Công ty TNHH Thiết bị Văn phòng Hồng Hà">
                    Công ty TNHH Thiết bị Văn phòng Hồng Hà
                  </option>
                  <option value="Công ty TNHH Phúc Long">
                    Công ty TNHH Phúc Long
                  </option>
                  <option value="Công ty CP Công nghệ Sao Việt">
                    Công ty CP Công nghệ Sao Việt
                  </option>
                  <option value="Công ty TNHH Hoàng Gia">
                    Công ty TNHH Hoàng Gia
                  </option>
                  </>}
                </select>
                <ChevronDown
                  size={14}
                  style={{
                    position: "absolute",
                    right: 8,
                    top: "50%",
                    transform: "translateY(-50%)",
                    pointerEvents: "none",
                    color: "#6b7280",
                  }}
                />
              </div>
            </div>

            {/* Row 3: Nhân viên mua hàng, Ngày trả tiền, Nút Lấy dữ liệu */}
            <div className="misa-invoice-grid-row" style={{ alignItems: "flex-end" }}>
              <div className="misa-invoice-field" style={{ width: 260 }}>
                <label>Nhân viên mua hàng</label>
                <div style={{ position: "relative" }}>
                  <select
                    value={employee}
                    onChange={(e) => setEmployee(e.target.value)}
                    style={{
                      width: "100%",
                      height: 32,
                      padding: "0 30px 0 10px",
                      borderRadius: 4,
                      border: "1px solid #d1d5db",
                      fontSize: 13,
                      background: "#ffffff",
                      appearance: "none",
                      cursor: "pointer",
                    }}
                  >
                    <option value="">&nbsp;</option>
                    <option value="Nguyễn Văn Nam">Nguyễn Văn Nam</option>
                    <option value="Lê Thị Mai">Lê Thị Mai</option>
                    <option value="Phạm Hải Đăng">Phạm Hải Đăng</option>
                  </select>
                  <ChevronDown
                    size={14}
                    style={{
                      position: "absolute",
                      right: 8,
                      top: "50%",
                      transform: "translateY(-50%)",
                      pointerEvents: "none",
                      color: "#6b7280",
                    }}
                  />
                </div>
              </div>

              <div className="misa-invoice-field" style={{ width: 140 }}>
                <label>Ngày trả tiền</label>
                <div style={{ position: "relative" }}>
                  <input
                    type="text"
                    value={payDate}
                    onChange={(e) => setPayDate(e.target.value)}
                    style={{
                      width: "100%",
                      height: 32,
                      padding: "0 28px 0 10px",
                      borderRadius: 4,
                      border: "1px solid #d1d5db",
                      fontSize: 13,
                      background: "#ffffff",
                    }}
                  />
                  <Calendar
                    size={15}
                    style={{
                      position: "absolute",
                      right: 8,
                      top: "50%",
                      transform: "translateY(-50%)",
                      color: "#6b7280",
                      pointerEvents: "none",
                    }}
                  />
                </div>
              </div>

              <button
                type="button"
                className="misa-invoice-fetch-btn"
                onClick={() => {
                  if (debtSource) {
                    if (!supplier) { showNotice("Vui lòng chọn nhà cung cấp."); return; }
                    debtSource.load(supplier)
                      .then((rows) => setInvoices(rows))
                      .catch((error) => showNotice(`Không lấy được công nợ: ${error instanceof Error ? error.message : String(error)}`));
                    return;
                  }
                  if (!supplier) {
                    setSupplier("Công ty TNHH Thiết bị Văn phòng Hồng Hà");
                  }
                  handleFetchData();
                }}
              >
                Lấy dữ liệu
              </button>
            </div>
          </div>

          {/* Right Top KPI Total (Screenshot 1: Số trả / 0) */}
          <div className="misa-invoice-master-right">
            <span className="misa-invoice-total-label">Số trả</span>
            <div className="misa-invoice-total-val">
              {formatVND(totalPayAmount)}
            </div>
          </div>
        </div>

        {/* Table Container (Matching Screenshot 1) */}
        <div className="misa-invoice-body">
          <div className="misa-invoice-table-container">
            {/* Table Subheader / Toolbar */}
            <div className="misa-invoice-table-toolbar">
              <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                <strong style={{ fontSize: 13.5, color: "#111827" }}>
                  Chứng từ công nợ
                </strong>
                <input
                  type="text"
                  placeholder="Tìm theo số chứng từ, số hóa đơn"
                  value={searchInvoice}
                  onChange={(e) => setSearchInvoice(e.target.value)}
                  style={{
                    height: 30,
                    width: 250,
                    padding: "0 10px",
                    borderRadius: 4,
                    border: "1px solid #d1d5db",
                    fontSize: 12.5,
                    color: "#111827",
                    outline: "none",
                  }}
                />
              </div>

              {/* Nhập số trả */}
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 12.5, color: "#374151" }}>Nhập số trả</span>
                <input
                  type="text"
                  value={quickAmount}
                  onChange={(e) => handleQuickAmount(e.target.value)}
                  style={{
                    height: 30,
                    width: 140,
                    padding: "0 8px",
                    borderRadius: 4,
                    border: "1px solid #d1d5db",
                    fontSize: 13,
                    textAlign: "right",
                    outline: "none",
                    background: "#ffffff",
                  }}
                />
              </div>
            </div>

            {/* Table Header and Rows (Matching Screenshot 1) */}
            <div className="misa-invoice-table-wrapper">
              <table className="misa-invoice-table">
                <thead>
                  <tr>
                    <th style={{ width: 36, textAlign: "center" }}>
                      <input
                        type="checkbox"
                        checked={invoices.length > 0 && invoices.every((i) => i.checked)}
                        onChange={toggleSelectAll}
                        style={{ accentColor: "var(--brand)", cursor: "pointer" }}
                      />
                    </th>
                    <th style={{ width: 110, textAlign: "center" }}>Ngày chứng từ</th>
                    <th style={{ width: 110 }}>Số chứng từ</th>
                    <th style={{ width: 110, textAlign: "center" }}>Ngày hóa đơn</th>
                    <th style={{ width: 100 }}>Số hóa đơn</th>
                    <th style={{ minWidth: 260 }}>Diễn giải</th>
                    <th style={{ width: 110, textAlign: "center" }}>Hạn thanh toán</th>
                    <th style={{ width: 120, textAlign: "right" }}>Tổng nợ</th>
                    <th style={{ width: 120, textAlign: "right" }}>Số còn nợ</th>
                    <th style={{ width: 120, textAlign: "right" }}>Số trả</th>
                    <th style={{ width: 90, textAlign: "center" }}>TK Phải trả</th>
                    <th style={{ width: 120 }}>Điều khoản TT</th>
                    <th style={{width:120}}>Tỷ lệ chiết khấu (%)</th>
                    <th style={{width:130}}>Tiền chiết khấu</th>
                    <th style={{width:110}}>TK chiết khấu</th>
                  </tr>
                  {/* Summary row directly under Header (Screenshot 1: Tổng) */}
                  <tr style={{ background: "#e2ece5", fontWeight: 700 }}>
                    <td style={{ textAlign: "center", borderRight: "1px solid #cbd5e1" }}></td>
                    <td></td>
                    <td style={{ fontWeight: 700, color: "#111827" }}>Tổng</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td style={{ textAlign: "right", fontWeight: 700, color: "#111827" }}>
                      {formatVND(totalDebtSum)}
                    </td>
                    <td style={{ textAlign: "right", fontWeight: 700, color: "#111827" }}>
                      {formatVND(remainingDebtSum)}
                    </td>
                    <td style={{ textAlign: "right", fontWeight: 700, color: "#111827" }}>
                      {formatVND(totalPayAmount)}
                    </td>
                    <td></td>
                    <td></td>
                    <td></td><td style={{textAlign:"right"}}>{formatVND(displayedInvoices.filter(inv=>inv.checked).reduce((sum,inv)=>sum+(inv.discountAmount || 0),0))}</td><td></td>
                  </tr>
                </thead>
                <tbody>
                  {displayedInvoices.map((inv) => (
                    <tr
                      key={inv.id}
                      style={{
                        background: inv.checked ? "#f0fdf4" : "#ffffff",
                      }}
                    >
                      <td style={{ textAlign: "center" }}>
                        <input
                          type="checkbox"
                          checked={inv.checked}
                          onChange={() => toggleInvoiceCheck(inv.id)}
                          style={{ accentColor: "var(--brand)", cursor: "pointer" }}
                        />
                      </td>
                      <td style={{ textAlign: "center" }}>{inv.voucherDate}</td>
                      <td>
                        <strong style={{ color: "var(--brand)" }}>{inv.voucherCode}</strong>
                      </td>
                      <td style={{ textAlign: "center" }}>{inv.invoiceDate}</td>
                      <td>{inv.invoiceCode}</td>
                      <td>{inv.description}</td>
                      <td style={{ textAlign: "center" }}>{inv.dueDate}</td>
                      <td style={{ textAlign: "right" }}>{formatVND(inv.totalDebt)}</td>
                      <td style={{ textAlign: "right" }}>{formatVND(inv.remainingDebt)}</td>
                      <td style={{ textAlign: "right" }}>
                        <input
                          type="text"
                          value={formatVND(inv.payAmount)}
                          disabled={!inv.checked}
                          onChange={(e) => updateInvoicePayAmount(inv.id, e.target.value)}
                          style={{
                            height: 28,
                            width: 110,
                            padding: "0 8px",
                            borderRadius: 4,
                            border: "1px solid #d1d5db",
                            textAlign: "right",
                            fontSize: 13,
                            background: inv.checked ? "#ffffff" : "#f1f5f9",
                          }}
                        />
                      </td>
                      <td style={{ textAlign: "center" }}>{inv.account}</td>
                      <td>{inv.terms}</td>
                      <td><input aria-label={`Tỷ lệ chiết khấu ${inv.voucherCode}`} type="number" min="0" max="100" value={inv.discountRate || 0} disabled={!inv.checked} onChange={e=>setInvoices(prev=>prev.map(row=>row.id===inv.id?{...row,discountRate:Math.min(100,Math.max(0,Number(e.target.value)||0))}:row))}/></td>
                      <td><input aria-label={`Tiền chiết khấu ${inv.voucherCode}`} type="text" inputMode="numeric" value={formatMoneyInput(inv.discountAmount || 0)} disabled={!inv.checked} onChange={e=>setInvoices(prev=>prev.map(row=>row.id===inv.id?{...row,discountAmount:Math.max(0,parseMoneyInput(e.target.value))}:row))}/></td>
                      <td><input aria-label={`TK chiết khấu ${inv.voucherCode}`} value={inv.discountAccount || "515"} disabled={!inv.checked} onChange={e=>setInvoices(prev=>prev.map(row=>row.id===inv.id?{...row,discountAccount:e.target.value}:row))}/></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Modal Footer (Matching Screenshot 1) */}
        <footer className="misa-invoice-footer">
          <button
            type="button"
            className="misa-invoice-btn-cancel"
            onClick={onClose}
          >
            Hủy
          </button>
          <button
            type="button"
            className="misa-invoice-btn-submit"
            onClick={handlePay}
          >
            Trả tiền
          </button>
        </footer>
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// 2. MODAL "CHỨNG TỪ KẾ TOÁN" (MATCHING SCREENSHOT 1-4 & 5)
// ----------------------------------------------------------------------
export function AccountingVoucherModal({
  voucher,
  onClose,
}: {
  voucher: {
    code: string;
    date: string;
    person: string;
    address: string;
    reason: string;
    debitAccount: string;
    creditAccount: string;
    amount: number;
    amountInWords: string;
    notes?: string;
    chiefAccountant?: string;
    director?: string;
  };
  onClose: () => void;
}) {
  const [zoom, setZoom] = useState(150);
  const [showTip, setShowTip] = useState(true);
  const [showExportMenu, setShowExportMenu] = useState(false);

  const amountWords =
    voucher.amountInWords || convertNumberToVietnameseWords(voucher.amount);
  const dateFormatted = voucher.date
    ? voucher.date.split("-").reverse().join("/")
    : "03/09/2026";

  const handlePrint = () => {
    window.print();
  };

  const handleExportExcel = () => {
    setShowExportMenu(false);
    const excelContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
  <meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8"/>
  <style>
    body { font-family: Roboto, Arial, sans-serif; font-size: 13pt; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #000000; padding: 6px 8px; font-family: Roboto, Arial, sans-serif; }
    th { font-weight: bold; text-align: center; background: #ffffff; }
    .no-border { border: none !important; }
    .center { text-align: center; }
    .right { text-align: right; }
    .bold { font-weight: bold; }
    .italic { font-style: italic; }
    .title { font-size: 18pt; font-weight: bold; text-align: center; }
  </style>
</head>
<body>
  <table>
    <tr class="no-border"><td colspan="3" class="no-border">Công ty Cổ phần Giải pháp Số Việt</td><td colspan="2" class="no-border"></td></tr>
    <tr class="no-border"><td colspan="3" class="no-border">Hà Nội</td><td colspan="2" class="no-border"></td></tr>
    <tr class="no-border"><td colspan="5" class="no-border" style="height: 18px;"></td></tr>
    <tr class="no-border"><td colspan="5" class="no-border title">CHỨNG TỪ KẾ TOÁN</td></tr>
    <tr class="no-border"><td colspan="5" class="no-border" style="height: 18px;"></td></tr>
    <tr class="no-border">
      <td colspan="3" class="no-border">Tên: ${voucher.person || "Hoàng Thiên Bảo"}</td>
      <td colspan="2" class="no-border right">Số: ${voucher.code || "PT00005"}</td>
    </tr>
    <tr class="no-border">
      <td colspan="3" class="no-border">Địa chỉ: ${voucher.address || ""}</td>
      <td colspan="2" class="no-border right">Ngày: ${dateFormatted}</td>
    </tr>
    <tr class="no-border">
      <td colspan="5" class="no-border">Diễn giải: ${voucher.reason || ""}</td>
    </tr>
    <tr class="no-border"><td colspan="5" class="no-border" style="height: 10px;"></td></tr>
    <tr>
      <th style="width: 45px;">STT</th>
      <th>Diễn giải</th>
      <th style="width: 85px;">Ghi nợ</th>
      <th style="width: 85px;">Ghi có</th>
      <th style="width: 140px;">Thành tiền</th>
    </tr>
    <tr>
      <td class="center">1</td>
      <td>${voucher.reason}</td>
      <td class="center">${voucher.debitAccount || "111"}</td>
      <td class="center">${voucher.creditAccount || "141"}</td>
      <td class="right bold" style="mso-number-format:'\\#,\\#\\#0';">${formatVND(voucher.amount)}</td>
    </tr>
    <tr>
      <td class="center"></td>
      <td class="center bold">Cộng</td>
      <td class="center"></td>
      <td class="center"></td>
      <td class="right bold" style="mso-number-format:'\\#,\\#\\#0';">${formatVND(voucher.amount)}</td>
    </tr>
    <tr class="no-border"><td colspan="5" class="no-border" style="height: 12px;"></td></tr>
    <tr class="no-border">
      <td colspan="5" class="no-border">Thành tiền bằng chữ: <i>${amountWords}.</i></td>
    </tr>
    <tr class="no-border">
      <td colspan="5" class="no-border">Ghi chú: ...................................................................................................................................................</td>
    </tr>
    <tr class="no-border"><td colspan="5" class="no-border" style="height: 30px;"></td></tr>
    <tr class="no-border">
      <td colspan="2" class="no-border center bold">Kế toán trưởng</td>
      <td class="no-border"></td>
      <td colspan="2" class="no-border center bold">Giám đốc</td>
    </tr>
    <tr class="no-border">
      <td colspan="2" class="no-border center italic">(Ký, họ tên)</td>
      <td class="no-border"></td>
      <td colspan="2" class="no-border center italic">(Ký, họ tên, đóng dấu)</td>
    </tr>
    <tr class="no-border"><td colspan="5" class="no-border" style="height: 75px;"></td></tr>
    <tr class="no-border">
      <td colspan="2" class="no-border center bold">${voucher.chiefAccountant || "Trương Thị B"}</td>
      <td class="no-border"></td>
      <td colspan="2" class="no-border center bold">${voucher.director || "Nguyễn Văn A"}</td>
    </tr>
  </table>
</body>
</html>
    `;
    const blob = new Blob([excelContent], {
      type: "application/vnd.ms-excel;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Chung_tu_${voucher.code || "PT00005"}.xls`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportWord = () => {
    setShowExportMenu(false);
    const wordContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head>
  <meta http-equiv="content-type" content="application/msword; charset=UTF-8"/>
  <style>
    body { font-family: Roboto, Arial, sans-serif; font-size: 13pt; line-height: 1.35; }
    table { border-collapse: collapse; width: 100%; margin: 15px 0; }
    th, td { border: 1px solid #000000; padding: 6px 8px; font-family: Roboto, Arial, sans-serif; font-size: 13pt; }
    th { font-weight: bold; text-align: center; }
    .no-border { border: none !important; }
    .center { text-align: center; }
    .right { text-align: right; }
    .bold { font-weight: bold; }
    .italic { font-style: italic; }
    .title { font-size: 18pt; font-weight: bold; text-align: center; margin: 15px 0 25px 0; }
  </style>
</head>
<body>
  <div style="margin-bottom: 20px;">
    <div>Công ty Cổ phần Giải pháp Số Việt</div>
    <div>Hà Nội</div>
  </div>
  <div class="title">CHỨNG TỪ KẾ TOÁN</div>
  <table style="border: none; width: 100%; margin-bottom: 10px;">
    <tr class="no-border">
      <td class="no-border" style="width: 65%;">Tên: ${voucher.person || "Hoàng Thiên Bảo"}</td>
      <td class="no-border right" style="width: 35%;">Số: ${voucher.code || "PT00005"}</td>
    </tr>
    <tr class="no-border">
      <td class="no-border">Địa chỉ: ${voucher.address || ""}</td>
      <td class="no-border right">Ngày: ${dateFormatted}</td>
    </tr>
    <tr class="no-border">
      <td class="no-border" colspan="2">Diễn giải: ${voucher.reason || ""}</td>
    </tr>
  </table>
  <table>
    <tr>
      <th style="width: 45px;">STT</th>
      <th>Diễn giải</th>
      <th style="width: 85px;">Ghi nợ</th>
      <th style="width: 85px;">Ghi có</th>
      <th style="width: 140px;">Thành tiền</th>
    </tr>
    <tr>
      <td class="center">1</td>
      <td>${voucher.reason}</td>
      <td class="center">${voucher.debitAccount || "111"}</td>
      <td class="center">${voucher.creditAccount || "141"}</td>
      <td class="right bold">${formatVND(voucher.amount)}</td>
    </tr>
    <tr>
      <td class="center"></td>
      <td class="center bold">Cộng</td>
      <td class="center"></td>
      <td class="center"></td>
      <td class="right bold">${formatVND(voucher.amount)}</td>
    </tr>
  </table>
  <div style="margin: 10px 0;">Thành tiền bằng chữ: <i>${amountWords}.</i></div>
  <div style="margin-bottom: 30px;">Ghi chú: ...................................................................................................................................................</div>
  <table style="border: none; width: 100%; margin-top: 20px;">
    <tr class="no-border">
      <td class="no-border center bold" style="width: 50%;">Kế toán trưởng</td>
      <td class="no-border center bold" style="width: 50%;">Giám đốc</td>
    </tr>
    <tr class="no-border">
      <td class="no-border center italic">(Ký, họ tên)</td>
      <td class="no-border center italic">(Ký, họ tên, đóng dấu)</td>
    </tr>
    <tr class="no-border" style="height: 80px;">
      <td class="no-border center" colspan="2" style="height: 80px;"></td>
    </tr>
    <tr class="no-border">
      <td class="no-border center bold">${voucher.chiefAccountant || "Trương Thị B"}</td>
      <td class="no-border center bold">${voucher.director || "Nguyễn Văn A"}</td>
    </tr>
  </table>
</body>
</html>
    `;
    const blob = new Blob([wordContent], {
      type: "application/msword;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Chung_tu_${voucher.code || "PT00005"}.doc`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="misa-voucher-modal-overlay">
      {/* Top Action Bar */}
      <header className="misa-voucher-topbar">
        <div className="misa-voucher-topbar-left">
          <h2>Chứng từ kế toán</h2>
        </div>
        <div className="misa-voucher-topbar-center">
          <button
            className="misa-voucher-action-btn amis-chat"
            type="button"
            title="Gửi chứng từ qua Sổ Việt Chat"
          >
            <MessageSquare size={16} />
            Gửi chứng từ
          </button>
          <button
            className="misa-voucher-action-btn"
            type="button"
            onClick={handlePrint}
          >
            <Printer size={16} />
            In
          </button>

          <div style={{ position: "relative" }}>
            <button
              className="misa-voucher-action-btn"
              type="button"
              onClick={() => setShowExportMenu((v) => !v)}
              title="Xuất biểu mẫu chứng từ"
            >
              <Download size={16} />
              Xuất file
              <ChevronDown size={12} style={{ marginLeft: 2 }} />
            </button>

            {showExportMenu && (
              <div className="misa-voucher-export-menu">
                <button
                  type="button"
                  className="misa-voucher-export-item"
                  onClick={handleExportExcel}
                >
                  <FileSpreadsheet size={16} style={{ color: "var(--brand)" }} />
                  <span>Xuất Excel biểu mẫu (.xls)</span>
                </button>
                <button
                  type="button"
                  className="misa-voucher-export-item"
                  onClick={handleExportWord}
                >
                  <FileText size={16} style={{ color: "#2563eb" }} />
                  <span>Xuất Word biểu mẫu (.doc)</span>
                </button>
                <button
                  type="button"
                  className="misa-voucher-export-item"
                  onClick={() => {
                    setShowExportMenu(false);
                    handlePrint();
                  }}
                >
                  <Printer size={16} style={{ color: "#ea580c" }} />
                  <span>Xuất PDF / In biểu mẫu (.pdf)</span>
                </button>
              </div>
            )}
          </div>

          <button className="misa-voucher-action-btn" type="button">
            <Settings size={15} />
            Sửa mẫu
          </button>
          <button className="misa-voucher-action-btn" type="button">
            <ClipboardList size={15} />
            Thiết lập người ký
          </button>
        </div>
        <div className="misa-voucher-topbar-right">
          <button className="misa-tax-icon-btn" type="button" title="Trợ giúp">
            <HelpCircle size={18} />
          </button>
          <button
            className="misa-tax-icon-btn"
            onClick={onClose}
            type="button"
            title="Đóng (Esc)"
          >
            <X size={18} />
          </button>
        </div>
      </header>

      {/* Floating Tip Badge */}
      {showTip && (
        <div className="misa-voucher-tip-badge">
          <span>Thay đổi thiết lập thông tin người ký trên báo cáo chứng từ tại đây.</span>
          <button
            style={{
              background: "none",
              border: "none",
              color: "#94a3b8",
              cursor: "pointer",
              marginLeft: 4,
            }}
            onClick={() => setShowTip(false)}
            aria-label="Đóng gợi ý"
          >
            <X size={18} aria-hidden="true" />
          </button>
        </div>
      )}

      {/* Sub Bar (Pagination & Zoom) */}
      <div className="misa-voucher-subbar">
        <div className="misa-voucher-subbar-left">
          <button type="button" title="Trang trước">
            &lt;
          </button>
          <span>1 / 1</span>
          <button type="button" title="Trang sau">
            &gt;
          </button>
        </div>
        <div className="misa-voucher-subbar-right">
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(z - 10, 80))}
          >
            <ZoomOut size={14} />
          </button>
          <span>{zoom}%</span>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(z + 10, 200))}
          >
            <ZoomIn size={14} />
          </button>
          <button type="button" title="Xoay">
            <RotateCw size={14} />
          </button>
          <button type="button" onClick={handlePrint} title="In chứng từ">
            <Printer size={14} />
          </button>
          <button
            type="button"
            onClick={handleExportExcel}
            title="Tải xuống Excel biểu mẫu (.xls)"
          >
            <Download size={14} />
          </button>
        </div>
      </div>

      {/* Split Viewer: Thumbnail sidebar + A4 Paper */}
      <div className="misa-voucher-container">
        {/* Left Thumbnails Sidebar */}
        <aside className="misa-voucher-sidebar">
          <button className="misa-voucher-sidebar-toggle-btn" type="button">
            &lt; - 5
          </button>
          <div className="misa-voucher-thumbnail-card" title="Trang 1 / 1">
            <div className="misa-voucher-thumb-skeleton header" />
            <div className="misa-voucher-thumb-skeleton" />
            <div className="misa-voucher-thumb-skeleton table" />
            <div className="misa-voucher-thumb-skeleton" />
            <div className="misa-voucher-thumb-page-num">1</div>
          </div>
        </aside>

        {/* Paper View Container */}
        <div className="misa-voucher-viewer">
          <div
            className="misa-voucher-paper"
            style={{
              transform: `scale(${zoom / 100})`,
              transformOrigin: "top center",
            }}
          >
            {/* Company Header (Matching Screenshot) */}
            <div className="misa-paper-company-header">
              <div className="misa-paper-company-left">
                <div>Công ty Cổ phần Giải pháp Số Việt</div>
                <div>Hà Nội</div>
              </div>
            </div>

            {/* Title (Matching Screenshot) */}
            <div className="misa-paper-title">
              <h1>CHỨNG TỪ KẾ TOÁN</h1>
            </div>

            {/* Meta Grid (Matching Screenshot) */}
            <div className="misa-paper-meta-grid">
              <div className="misa-paper-meta-left">
                <div className="misa-paper-meta-row">
                  <span className="label">Tên:</span>
                  <span className="value">{voucher.person || "Hoàng Thiên Bảo"}</span>
                </div>
                <div className="misa-paper-meta-row">
                  <span className="label">Địa chỉ:</span>
                  <span className="value">{voucher.address || ""}</span>
                </div>
                <div className="misa-paper-meta-row">
                  <span className="label">Diễn giải:</span>
                  <span className="value">{voucher.reason}</span>
                </div>
              </div>

              <div className="misa-paper-meta-right">
                <div className="misa-paper-meta-row right">
                  <span className="label">Số:</span>
                  <span className="value">{voucher.code}</span>
                </div>
                <div className="misa-paper-meta-row right">
                  <span className="label">Ngày:</span>
                  <span className="value">{dateFormatted}</span>
                </div>
              </div>
            </div>

            {/* Accounting Table (Matching Screenshot) */}
            <table className="misa-paper-table">
              <thead>
                <tr>
                  <th style={{ width: 45 }}>STT</th>
                  <th>Diễn giải</th>
                  <th style={{ width: 85 }}>Ghi nợ</th>
                  <th style={{ width: 85 }}>Ghi có</th>
                  <th style={{ width: 140 }}>Thành tiền</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="center">1</td>
                  <td>{voucher.reason}</td>
                  <td className="center">{voucher.debitAccount || "111"}</td>
                  <td className="center">{voucher.creditAccount || "141"}</td>
                  <td className="right bold">{formatVND(voucher.amount)}</td>
                </tr>
                <tr className="total-row">
                  <td className="center"></td>
                  <td className="center bold">Cộng</td>
                  <td className="center"></td>
                  <td className="center"></td>
                  <td className="right bold">{formatVND(voucher.amount)}</td>
                </tr>
              </tbody>
            </table>

            {/* Words & Notes (Matching Screenshot) */}
            <div className="misa-paper-words">
              Thành tiền bằng chữ: <em>{amountWords}.</em>
            </div>
            <div className="misa-paper-notes">
              <span>Ghi chú:</span>
              <span className="misa-paper-notes-dots"></span>
            </div>

            {/* Signatures (Matching Screenshot) */}
            <div className="misa-paper-signatures">
              <div className="misa-signature-block">
                <strong>Kế toán trưởng</strong>
                <small>(Ký, họ tên)</small>
                <div className="misa-signature-name">
                  {voucher.chiefAccountant || "Trương Thị B"}
                </div>
              </div>
              <div className="misa-signature-block">
                <strong>Giám đốc</strong>
                <small>(Ký, họ tên, đóng dấu)</small>
                <div className="misa-signature-name">
                  {voucher.director || "Nguyễn Văn A"}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// 3. MODAL "TẠO PHIẾU THU / CHI" MISA FORM CHUẨN
// ----------------------------------------------------------------------
export interface VoucherTypeOption {
  id: string;
  index: number;
  label: string;
  shortLabel: string;
  codeLabel: string;
  nameLabel: string;
  personLabel: string;
  addressLabel: string;
  defaultPartnerCode: string;
  defaultPartnerName: string;
  defaultPerson: string;
  defaultAddress: string;
  defaultReason: string;
  defaultDebit: string;
  defaultCredit: string;
  defaultAmount: number;
  hasEmployeeField?: boolean;
  hasCustomerDebtBtn?: boolean;
  hasSettlementDueDate?: boolean;
  hasTaxDeclarationTab?: boolean;
  hasYearField?: boolean;
  hasBatchPaymentCheckbox?: boolean;
  hasQuickAddHint?: boolean;
  layoutType?:
    | "receipt_standard"
    | "receipt_wide_reason"
    | "payment_supplier"
    | "payment_advance"
    | "payment_standard"
    | "bank_payment_supplier"
    | "bank_payment_advance"
    | "bank_payment_external"
    | "bank_payment_salary_advance"
    | "bank_payment_standard";
  employeeLabel?: string;
  extraColumns?: Array<
    | "bankAccount"
    | "bankName"
    | "partnerCode"
    | "partnerName"
    | "employeeCode"
    | "employeeName"
    | "loanContract"
    | "loanDisbursementContract"
  >;
  samplePartners: Array<{
    code: string;
    name: string;
    person: string;
    address: string;
    bankAccount?: string;
    bankName?: string;
  }>;
}

export const SAMPLE_BANK_ACCOUNTS = [
  { account: "123456789", name: "Techcombank - TK VND (123456789)" },
  { account: "987654321", name: "Techcombank - TK USD (987654321)" },
];

export const SAMPLE_BENEFICIARY_ACCOUNTS = [
  { account: "11008480601", name: "Vietcombank - Công ty TNHH Phát Mai Group" },
  { account: "11008703501", name: "BIDV - Công ty Cổ phần Minh Quân Logistics" },
  { account: "11009282101", name: "Techcombank - Công ty TNHH Thiết bị Thanh Trúc" },
  { account: "20046368601", name: "Vietinbank - CTCP Vận tải và Thương mại Vạn Phát" },
];

export const SAMPLE_EMPLOYEES = [
  { code: "TRUONGTHANHQUAN", name: "Trương Thanh Quân", dept: "Ban Giám đốc" },
  { code: "NGUYENTHIYEN", name: "Nguyễn Thị Yến", dept: "Phòng Kế toán" },
  { code: "LEVANHIEU", name: "Lê Văn Hiếu", dept: "Phòng Kế toán" },
  { code: "TRANVANHUNG", name: "Trần Văn Hùng", dept: "Phòng Kế toán" },
  { code: "HOANGBACUNG", name: "Hoàng Bá Cung", dept: "Phòng HC Nhân sự" },
  { code: "LUONGMINHTHANH", name: "Lương Minh Thành", dept: "Phòng Kỹ thuật" },
];

export const MISA_RECEIPT_TYPES: VoucherTypeOption[] = [
  {
    id: "customer",
    index: 1,
    label: "1. Thu tiền khách hàng (không theo hóa đơn)",
    shortLabel: "1. Thu tiền khách hàng (không the...",
    codeLabel: "Mã khách hàng",
    nameLabel: "Tên khách hàng",
    personLabel: "Người nộp",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Thu tiền của ",
    defaultDebit: "111",
    defaultCredit: "131",
    defaultAmount: 0,
    hasEmployeeField: true,
    hasCustomerDebtBtn: true,
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "KH001", name: "Công ty TNHH Minh Phúc", person: "Nguyễn Thị Thanh", address: "Số 18 Hoàng Quốc Việt, Cầu Giấy, Hà Nội" },
      { code: "KH002", name: "Công ty Cổ phần Thương mại Sao Việt", person: "Trần Văn Hưng", address: "25 Lê Duẩn, Hoàn Kiếm, Hà Nội" },
      { code: "KH003", name: "Công ty CP Cơ khí An Phát", person: "Lê Minh Tuấn", address: "KCN Thăng Long, Đông Anh, Hà Nội" },
    ],
  },
  {
    id: "advance_refund",
    index: 2,
    label: "2. Thu hoàn ứng nhân viên",
    shortLabel: "2. Thu hoàn ứng nhân viên",
    codeLabel: "Mã nhân viên",
    nameLabel: "Tên nhân viên",
    personLabel: "Người nộp",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Thu hoàn ứng sau khi quyết toán tạm ứng cho ",
    defaultDebit: "111",
    defaultCredit: "141",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "NV0005", name: "Hoàng Thiên Bảo", person: "Hoàng Thiên Bảo", address: "Phòng Kinh doanh & Dự án" },
      { code: "NV0001", name: "Nguyễn Thị Mai", person: "Nguyễn Thị Mai", address: "Phòng Kế toán - Tài chính" },
      { code: "NV0012", name: "Đặng Văn Lâm", person: "Đặng Văn Lâm", address: "Phòng Kỹ thuật & Công nghệ" },
    ],
  },
  {
    id: "bank_withdrawal",
    index: 3,
    label: "3. Rút tiền gửi về nhập quỹ",
    shortLabel: "3. Rút tiền gửi về nhập quỹ",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nộp",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Rút tiền gửi về nhập quỹ",
    defaultDebit: "111",
    defaultCredit: "1121",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    extraColumns: ["bankAccount", "bankName"],
    samplePartners: [
      { code: "NH001", name: "Ngân hàng TMCP Ngoại thương Việt Nam (Vietcombank)", person: "Thủ quỹ", address: "198 Trần Quang Khải, Hoàn Kiếm, Hà Nội" },
      { code: "NH002", name: "Ngân hàng TMCP Kỹ Thương Việt Nam (Techcombank)", person: "Thủ quỹ", address: "6 Quang Trung, Hoàn Kiếm, Hà Nội" },
      { code: "NH003", name: "Ngân hàng TMCP Đầu tư và Phát triển Việt Nam (BIDV)", person: "Thủ quỹ", address: "35 Hàng Vôi, Hoàn Kiếm, Hà Nội" },
    ],
  },
  {
    id: "loan_recovery",
    index: 4,
    label: "4. Thu hồi các khoản cho vay",
    shortLabel: "4. Thu hồi các khoản cho vay",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nộp",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Thu hồi các khoản cho vay",
    defaultDebit: "111",
    defaultCredit: "1283",
    defaultAmount: 0,
    hasEmployeeField: true,
    hasCustomerDebtBtn: false,
    extraColumns: ["partnerCode", "partnerName", "loanDisbursementContract"],
    samplePartners: [
      { code: "DT002", name: "Công ty CP Đầu tư & Công nghệ Sao Mai", person: "Trần Quốc Đạt", address: "Duy Tân, Cầu Giấy, Hà Nội" },
      { code: "DT007", name: "Công ty TNHH Tư vấn & Dịch vụ Kim Đô", person: "Nguyễn Lan Hương", address: "Phạm Hùng, Nam Từ Liêm, Hà Nội" },
    ],
  },
  {
    id: "other_receipt",
    index: 5,
    label: "5. Thu khác",
    shortLabel: "5. Thu khác",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nộp",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Thu tiền của ",
    defaultDebit: "111",
    defaultCredit: "",
    defaultAmount: 0,
    hasEmployeeField: true,
    hasCustomerDebtBtn: false,
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "DT008", name: "Công ty CP Tái chế & Xử lý Kim loại Nam Hà", person: "Phạm Hải Đăng", address: "KCN Quang Minh, Mê Linh, Hà Nội" },
      { code: "DT015", name: "Bảo hiểm Bảo Việt Hà Nội", person: "Lê Thu Hằng", address: "Trần Hưng Đạo, Hoàn Kiếm, Hà Nội" },
      { code: "KH005", name: "Công ty CP Tập đoàn Sơn Hà", person: "Vũ Tuấn Kiệt", address: "KCN Từ Liêm, Bắc Từ Liêm, Hà Nội" },
    ],
  },
  {
    id: "customer_invoice", index: 6, label: "Thu tiền khách hàng theo hóa đơn",
    shortLabel: "Thu tiền theo hóa đơn", codeLabel: "Mã khách hàng", nameLabel: "Tên khách hàng",
    personLabel: "Người nộp", addressLabel: "Địa chỉ", defaultPartnerCode: "", defaultPartnerName: "",
    defaultPerson: "", defaultAddress: "", defaultReason: "Thu tiền khách hàng theo hóa đơn",
    defaultDebit: "1111", defaultCredit: "131", defaultAmount: 0,
    hasEmployeeField: false, hasCustomerDebtBtn: true, extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [],
  },
];

export const MISA_BANK_RECEIPT_TYPES: VoucherTypeOption[] = [
  {
    id: "customer",
    index: 1,
    label: "1. Thu tiền khách hàng (không theo hóa đơn)",
    shortLabel: "1. Thu tiền khách hàng (không the...",
    codeLabel: "Mã khách hàng",
    nameLabel: "Tên khách hàng",
    personLabel: "Người nộp",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Thu tiền của ",
    defaultDebit: "1121",
    defaultCredit: "131",
    defaultAmount: 0,
    hasEmployeeField: true,
    employeeLabel: "Nhân viên thu nợ",
    hasCustomerDebtBtn: true,
    extraColumns: [],
    samplePartners: [
      { code: "KH001", name: "Công ty TNHH Minh Phúc", person: "Nguyễn Thị Thanh", address: "Số 18 Hoàng Quốc Việt, Cầu Giấy, Hà Nội" },
      { code: "KH002", name: "Công ty Cổ phần Thương mại Sao Việt", person: "Trần Văn Hưng", address: "25 Lê Duẩn, Hoàn Kiếm, Hà Nội" },
      { code: "KH003", name: "Công ty CP Cơ khí An Phát", person: "Lê Minh Tuấn", address: "KCN Thăng Long, Đông Anh, Hà Nội" },
    ],
  },
  {
    id: "advance_refund",
    index: 2,
    label: "2. Thu hoàn ứng nhân viên",
    shortLabel: "2. Thu hoàn ứng nhân viên",
    codeLabel: "Mã nhân viên",
    nameLabel: "Tên nhân viên",
    personLabel: "Người nộp",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Thu hoàn ứng sau quyết toán tạm ứng cho ",
    defaultDebit: "1121",
    defaultCredit: "141",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "NV0005", name: "Hoàng Thiên Bảo", person: "Hoàng Thiên Bảo", address: "Phòng Kinh doanh & Dự án" },
      { code: "NV0001", name: "Nguyễn Thị Mai", person: "Nguyễn Thị Mai", address: "Phòng Kế toán - Tài chính" },
      { code: "NV0012", name: "Đặng Văn Lâm", person: "Đặng Văn Lâm", address: "Phòng Kỹ thuật & Công nghệ" },
    ],
  },
  {
    id: "financial_interest",
    index: 3,
    label: "3. Thu lãi đầu tư tài chính",
    shortLabel: "3. Thu lãi đầu tư tài chính",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nộp",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Thu lãi đầu tư tài chính của ",
    defaultDebit: "1121",
    defaultCredit: "515",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    extraColumns: ["loanContract"],
    samplePartners: [
      { code: "DT001", name: "Công ty CP Chứng khoán VPS", person: "Vũ Hải Đăng", address: "14 Lê Liễu, Cầu Giấy, Hà Nội" },
      { code: "DT002", name: "Công ty CP Đầu tư & Công nghệ Sao Mai", person: "Trần Quốc Đạt", address: "Duy Tân, Cầu Giấy, Hà Nội" },
      { code: "NH001", name: "Ngân hàng TMCP Ngoại thương Việt Nam (Vietcombank)", person: "Nguyễn Văn Hùng", address: "198 Trần Quang Khải, Hoàn Kiếm, Hà Nội" },
    ],
  },
  {
    id: "bank_loan",
    index: 4,
    label: "4. Thu tiền vay qua ngân hàng",
    shortLabel: "4. Thu tiền vay qua ngân hàng",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nộp",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Thu tiền vay qua ngân hàng của ",
    defaultDebit: "1121",
    defaultCredit: "3411",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    extraColumns: ["partnerCode", "partnerName", "loanContract"],
    samplePartners: [
      { code: "NH001", name: "Ngân hàng TMCP Ngoại thương Việt Nam (Vietcombank)", person: "Nguyễn Văn Hùng", address: "198 Trần Quang Khải, Hoàn Kiếm, Hà Nội" },
      { code: "NH002", name: "Ngân hàng TMCP Kỹ Thương Việt Nam (Techcombank)", person: "Trần Minh", address: "6 Quang Trung, Hoàn Kiếm, Hà Nội" },
      { code: "NH003", name: "Ngân hàng TMCP Đầu tư và Phát triển Việt Nam (BIDV)", person: "Lê Hoàng", address: "35 Hàng Vôi, Hoàn Kiếm, Hà Nội" },
    ],
  },
  {
    id: "vat_refund",
    index: 5,
    label: "5. Thu hoàn thuế GTGT",
    shortLabel: "5. Thu hoàn thuế GTGT",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nộp",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Thu hoàn thuế GTGT của ",
    defaultDebit: "1121",
    defaultCredit: "1331",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "CQT01", name: "Cục Thuế Thành phố Hà Nội", person: "Kế toán thuế", address: "187 Giảng Võ, Đống Đa, Hà Nội" },
      { code: "CQT02", name: "Chi cục Thuế Quận Cầu Giấy", person: "Kế toán thuế", address: "Nguyễn Phong Sắc, Cầu Giấy, Hà Nội" },
    ],
  },
  {
    id: "loan_recovery",
    index: 6,
    label: "6. Thu hồi các khoản cho vay",
    shortLabel: "6. Thu hồi các khoản cho vay",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nộp",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Thu hồi các khoản cho vay",
    defaultDebit: "1121",
    defaultCredit: "1283",
    defaultAmount: 0,
    hasEmployeeField: true,
    employeeLabel: "Nhân viên thu nợ",
    hasCustomerDebtBtn: false,
    extraColumns: ["partnerCode", "partnerName", "loanDisbursementContract"],
    samplePartners: [
      { code: "DT002", name: "Công ty CP Đầu tư & Công nghệ Sao Mai", person: "Trần Quốc Đạt", address: "Duy Tân, Cầu Giấy, Hà Nội" },
      { code: "DT007", name: "Công ty TNHH Tư vấn & Dịch vụ Kim Đô", person: "Nguyễn Lan Hương", address: "Phạm Hùng, Nam Từ Liêm, Hà Nội" },
    ],
  },
  {
    id: "other_receipt",
    index: 7,
    label: "7. Thu khác",
    shortLabel: "7. Thu khác",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nộp",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Thu tiền của ",
    defaultDebit: "1121",
    defaultCredit: "",
    defaultAmount: 0,
    hasEmployeeField: true,
    employeeLabel: "Nhân viên thu nợ",
    hasCustomerDebtBtn: false,
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "DT008", name: "Công ty CP Tái chế & Xử lý Kim loại Nam Hà", person: "Phạm Hải Đăng", address: "KCN Quang Minh, Mê Linh, Hà Nội" },
      { code: "DT015", name: "Bảo hiểm Bảo Việt Hà Nội", person: "Lê Thu Hằng", address: "Trần Hưng Đạo, Hoàn Kiếm, Hà Nội" },
      { code: "KH005", name: "Công ty CP Tập đoàn Sơn Hà", person: "Vũ Tuấn Kiệt", address: "KCN Từ Liêm, Bắc Từ Liêm, Hà Nội" },
    ],
  },
];

export const MISA_PAYMENT_TYPES: VoucherTypeOption[] = [
  {
    id: "supplier",
    index: 1,
    label: "1. Trả tiền nhà cung cấp (không theo hóa đơn)",
    shortLabel: "1. Trả tiền nhà cung cấp (không th...",
    codeLabel: "Mã nhà cung cấp",
    nameLabel: "Tên nhà cung cấp",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Chi tiền cho",
    defaultDebit: "331",
    defaultCredit: "111",
    defaultAmount: 0,
    hasEmployeeField: true,
    hasCustomerDebtBtn: true,
    layoutType: "payment_supplier",
    extraColumns: ["partnerCode","partnerName"],
    samplePartners: [
      { code: "NCC001", name: "Công ty TNHH Thiết bị Văn phòng Hồng Hà", person: "Nguyễn Đức Anh", address: "25 Lý Thường Kiệt, Hoàn Kiếm, Hà Nội" },
      { code: "NCC002", name: "Công ty CP Giấy Hải Tiến", person: "Trần Thị Nga", address: "Phố Nối, Hưng Yên" },
      { code: "NCC003", name: "Công ty Viễn thông CMC", person: "Đỗ Tuấn Kiệt", address: "Duy Tân, Cầu Giấy, Hà Nội" },
    ],
  },
  {
    id: "advance",
    index: 2,
    label: "2. Tạm ứng cho nhân viên",
    shortLabel: "2. Tạm ứng cho nhân viên",
    codeLabel: "Mã nhân viên",
    nameLabel: "Tên nhân viên",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Tạm ứng cho nhân viên",
    defaultDebit: "141",
    defaultCredit: "111",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    hasSettlementDueDate: true,
    layoutType: "payment_advance",
    extraColumns: [],
    samplePartners: [
      { code: "NV0005", name: "Hoàng Thiên Bảo", person: "Hoàng Thiên Bảo", address: "Phòng Kinh doanh & Dự án" },
      { code: "NV0001", name: "Nguyễn Thị Mai", person: "Nguyễn Thị Mai", address: "Phòng Kế toán - Tài chính" },
      { code: "NV0012", name: "Đặng Văn Lâm", person: "Đặng Văn Lâm", address: "Phòng Kỹ thuật & Công nghệ" },
    ],
  },
  {
    id: "external_purchase",
    index: 3,
    label: "3. Chi mua ngoài có hóa đơn",
    shortLabel: "3. Chi mua ngoài có hóa đơn",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Chi tiền cho",
    defaultDebit: "",
    defaultCredit: "111",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    hasTaxDeclarationTab: true,
    layoutType: "payment_standard",
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "DT001", name: "Công ty TNHH Dịch vụ Vận tải An Bình", person: "Trần Văn Bình", address: "Hải Phòng" },
      { code: "DT004", name: "Công ty CP Dược phẩm Sao Thái Dương", person: "Phạm Hải Đăng", address: "Hà Nội" },
    ],
  },
  {
    id: "salary_advance",
    index: 4,
    label: "4. Trả lương tạm ứng cho nhân viên",
    shortLabel: "4. Trả lương tạm ứng cho nhân viên",
    codeLabel: "Mã nhân viên",
    nameLabel: "Tên nhân viên",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Trả lương tạm ứng cho nhân viên",
    defaultDebit: "334",
    defaultCredit: "111",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    layoutType: "payment_standard",
    extraColumns: ["employeeCode", "employeeName"],
    samplePartners: [
      { code: "NV0005", name: "Hoàng Thiên Bảo", person: "Hoàng Thiên Bảo", address: "Phòng Kinh doanh" },
      { code: "NV0001", name: "Nguyễn Thị Mai", person: "Nguyễn Thị Mai", address: "Phòng Kế toán" },
      { code: "NV0008", name: "Trương Quốc Khánh", person: "Trương Quốc Khánh", address: "Phòng Marketing" },
    ],
  },
  {
    id: "salary_payment",
    index: 5,
    label: "5. Trả lương nhân viên",
    shortLabel: "5. Trả lương nhân viên",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Trả lương nhân viên",
    defaultDebit: "334",
    defaultCredit: "111",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    layoutType: "payment_standard",
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "DT002", name: "Nhân viên Toàn công ty", person: "Đại diện Công đoàn", address: "Hà Nội" },
      { code: "NV0005", name: "Hoàng Thiên Bảo", person: "Hoàng Thiên Bảo", address: "Phòng Kinh doanh" },
    ],
  },
  {
    id: "bank_deposit",
    index: 6,
    label: "6. Gửi tiền vào ngân hàng",
    shortLabel: "6. Gửi tiền vào ngân hàng",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Gửi tiền vào ngân hàng",
    defaultDebit: "1121",
    defaultCredit: "111",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    layoutType: "payment_standard",
    extraColumns: ["bankAccount", "bankName", "partnerCode", "partnerName"],
    samplePartners: [
      { code: "DT001", name: "Ngân hàng TMCP Ngoại thương Việt Nam (Vietcombank)", person: "Nguyễn Văn A", address: "Hà Nội" },
      { code: "DT002", name: "Ngân hàng TMCP Đầu tư và Phát triển Việt Nam (BIDV)", person: "Trần Thị B", address: "Hà Nội" },
      { code: "DT003", name: "Ngân hàng TMCP Quân đội (MBBank)", person: "Lê Văn C", address: "Hà Nội" },
    ],
  },
  {
    id: "loan_disbursement",
    index: 7,
    label: "7. Chi cho vay",
    shortLabel: "7. Chi cho vay",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Chi tiền cho vay",
    defaultDebit: "1283",
    defaultCredit: "111",
    defaultAmount: 0,
    hasEmployeeField: true,
    hasCustomerDebtBtn: false,
    layoutType: "payment_supplier",
    extraColumns: ["partnerCode", "partnerName", "loanContract"],
    samplePartners: [
      { code: "DT001", name: "Công ty CP Tập đoàn Tài chính Hòa Bình", person: "Vũ Hải Đăng", address: "Cầu Giấy, Hà Nội" },
      { code: "DT005", name: "Công ty TNHH Đầu tư Việt Hưng", person: "Lê Minh Tuấn", address: "Đống Đa, Hà Nội" },
    ],
  },
  {
    id: "other_expense",
    index: 8,
    label: "8. Chi khác",
    shortLabel: "8. Chi khác",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Chi tiền cho",
    defaultDebit: "",
    defaultCredit: "111",
    defaultAmount: 0,
    hasEmployeeField: true,
    hasCustomerDebtBtn: false,
    layoutType: "payment_supplier",
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "DT001", name: "Công ty Cổ phần Vận chuyển Á Châu", person: "Phạm Quốc Hùng", address: "Hoàng Mai, Hà Nội" },
      { code: "DT003", name: "Trung tâm Hội nghị Quốc gia", person: "Trần Mai Anh", address: "Nam Từ Liêm, Hà Nội" },
    ],
  },
  {
    id: "corporate_tax",
    index: 9,
    label: "9. Nộp thuế TNDN tạm tính",
    shortLabel: "9. Nộp thuế TNDN tạm tính",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Nộp thuế thu nhập doanh nghiệp tạm tính",
    defaultDebit: "3334",
    defaultCredit: "111",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    hasYearField: true,
    layoutType: "payment_standard",
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "DT001", name: "Chi cục Thuế TP Hà Nội - Kho bạc Nhà nước", person: "Kho bạc Nhà nước", address: "Hà Nội" },
      { code: "DT002", name: "Chi cục Thuế Quận Cầu Giấy", person: "Đại diện Thuế", address: "Cầu Giấy, Hà Nội" },
    ],
  },
];

export const MISA_BANK_PAYMENT_TYPES: VoucherTypeOption[] = [
  {
    id: "supplier",
    index: 1,
    label: "1. Trả tiền nhà cung cấp (không theo hóa đơn)",
    shortLabel: "1. Trả tiền nhà cung cấp (không th...",
    codeLabel: "Mã nhà cung cấp",
    nameLabel: "Tên nhà cung cấp",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Trả tiền nhà cung cấp",
    defaultDebit: "331",
    defaultCredit: "1121",
    defaultAmount: 0,
    hasEmployeeField: true,
    hasCustomerDebtBtn: true,
    hasBatchPaymentCheckbox: true,
    layoutType: "bank_payment_supplier",
    extraColumns: [],
    samplePartners: [
      { code: "NCC001", name: "Công ty TNHH Thiết bị Văn phòng Hồng Hà", person: "Nguyễn Đức Anh", address: "25 Lý Thường Kiệt, Hoàn Kiếm, Hà Nội", bankAccount: "0021000348291", bankName: "Vietcombank - CN Thăng Long" },
      { code: "NCC002", name: "Công ty CP Giấy Hải Tiến", person: "Trần Thị Nga", address: "Phố Nối, Hưng Yên", bankAccount: "19028374910012", bankName: "Techcombank - CN Phố Nối" },
      { code: "NCC003", name: "Công ty Viễn thông CMC", person: "Đỗ Tuấn Kiệt", address: "Duy Tân, Cầu Giấy, Hà Nội", bankAccount: "21510008472910", bankName: "BIDV - CN Cầu Giấy" },
    ],
  },
  {
    id: "supplier_invoice", index: 12, label: "Trả tiền nhà cung cấp theo hóa đơn",
    shortLabel: "Trả tiền theo hóa đơn", codeLabel: "Mã nhà cung cấp", nameLabel: "Tên nhà cung cấp",
    personLabel: "Người nhận", addressLabel: "Địa chỉ", defaultPartnerCode: "",
    defaultPartnerName: "", defaultPerson: "", defaultAddress: "", defaultReason: "Trả tiền theo hóa đơn",
    defaultDebit: "331", defaultCredit: "1121", defaultAmount: 0, hasEmployeeField: false,
    hasCustomerDebtBtn: false, extraColumns: [], samplePartners: [],
  },
  {
    id: "loan_payment",
    index: 2,
    label: "2. Trả các khoản vay",
    shortLabel: "2. Trả các khoản vay",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Trả các khoản vay cho",
    defaultDebit: "3411",
    defaultCredit: "1121",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    hasQuickAddHint: true,
    layoutType: "bank_payment_standard",
    extraColumns: ["loanContract"],
    samplePartners: [
      { code: "NH001", name: "Ngân hàng TMCP Ngoại thương Việt Nam (Vietcombank)", person: "Đại diện Tín dụng VCB", address: "198 Trần Quang Khải, Hoàn Kiếm, Hà Nội", bankAccount: "0011004123899", bankName: "Vietcombank - Sở Giao Dịch" },
      { code: "NH003", name: "Ngân hàng TMCP Đầu tư và Phát triển Việt Nam (BIDV)", person: "Phòng Tín dụng DN", address: "35 Hàng Vôi, Hoàn Kiếm, Hà Nội", bankAccount: "2151000129", bankName: "BIDV - CN Hoàn Kiếm" },
      { code: "DT001", name: "Công ty CP Tập đoàn Tài chính Hòa Bình", person: "Vũ Hải Đăng", address: "Cầu Giấy, Hà Nội", bankAccount: "1903482710", bankName: "Techcombank - Hội sở" },
    ],
  },
  {
    id: "advance",
    index: 3,
    label: "3. Tạm ứng cho nhân viên",
    shortLabel: "3. Tạm ứng cho nhân viên",
    codeLabel: "Mã nhân viên",
    nameLabel: "Tên nhân viên",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Tạm ứng cho nhân viên",
    defaultDebit: "141",
    defaultCredit: "1121",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    hasSettlementDueDate: true,
    layoutType: "bank_payment_advance",
    extraColumns: [],
    samplePartners: [
      { code: "NV0005", name: "Hoàng Thiên Bảo", person: "Hoàng Thiên Bảo", address: "Phòng Kinh doanh & Dự án", bankAccount: "1028475929", bankName: "Vietcombank - CN Hoàn Kiếm" },
      { code: "NV0001", name: "Nguyễn Thị Mai", person: "Nguyễn Thị Mai", address: "Phòng Kế toán - Tài chính", bankAccount: "1023847592", bankName: "Vietcombank - CN Ba Đình" },
      { code: "NV0012", name: "Đặng Văn Lâm", person: "Đặng Văn Lâm", address: "Phòng Kỹ thuật & Công nghệ", bankAccount: "1903482710", bankName: "Techcombank - Hội sở" },
    ],
  },
  {
    id: "external_purchase",
    index: 4,
    label: "4. Chi mua ngoài có hóa đơn",
    shortLabel: "4. Chi mua ngoài có hóa đơn",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Chi mua ngoài có hóa đơn cho",
    defaultDebit: "",
    defaultCredit: "1121",
    defaultAmount: 0,
    hasEmployeeField: true,
    hasCustomerDebtBtn: false,
    hasTaxDeclarationTab: true,
    layoutType: "bank_payment_external",
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "DT001", name: "Công ty TNHH Dịch vụ Vận tải An Bình", person: "Trần Văn Bình", address: "Hải Phòng", bankAccount: "0021000348291", bankName: "Vietcombank - CN Hải Phòng" },
      { code: "DT004", name: "Công ty CP Dược phẩm Sao Thái Dương", person: "Phạm Hải Đăng", address: "Hà Nội", bankAccount: "19028374910012", bankName: "Techcombank - CN Thăng Long" },
    ],
  },
  {
    id: "salary_advance",
    index: 5,
    label: "5. Trả lương tạm ứng cho nhân viên",
    shortLabel: "5. Trả lương tạm ứng cho nhân viên",
    codeLabel: "Mã nhân viên",
    nameLabel: "Tên nhân viên",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Trả lương tạm ứng cho nhân viên cho",
    defaultDebit: "334",
    defaultCredit: "1121",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasCustomerDebtBtn: false,
    layoutType: "bank_payment_salary_advance",
    extraColumns: ["employeeCode", "employeeName"],
    samplePartners: [
      { code: "NV0005", name: "Hoàng Thiên Bảo", person: "Hoàng Thiên Bảo", address: "Phòng Kinh doanh", bankAccount: "1028475929", bankName: "Vietcombank - CN Hoàn Kiếm" },
      { code: "NV0001", name: "Nguyễn Thị Mai", person: "Nguyễn Thị Mai", address: "Phòng Kế toán", bankAccount: "1023847592", bankName: "Vietcombank - CN Ba Đình" },
      { code: "NV0008", name: "Trương Quốc Khánh", person: "Trương Quốc Khánh", address: "Phòng Marketing", bankAccount: "2151000129", bankName: "BIDV - CN Cầu Giấy" },
    ],
  },
  {
    id: "salary_payment",
    index: 6,
    label: "6. Trả lương nhân viên",
    shortLabel: "6. Trả lương nhân viên",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Trả lương nhân viên",
    defaultDebit: "334",
    defaultCredit: "1121",
    defaultAmount: 0,
    hasEmployeeField: true,
    hasCustomerDebtBtn: false,
    hasBatchPaymentCheckbox: true,
    layoutType: "bank_payment_standard",
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "DT002", name: "Nhân viên Toàn công ty", person: "Đại diện Công đoàn", address: "Hà Nội", bankAccount: "0011004123899", bankName: "Vietcombank - Hội sở" },
      { code: "DT005", name: "Phòng Kỹ thuật & Công nghệ", person: "Đỗ Tuấn Kiệt", address: "Cầu Giấy, Hà Nội", bankAccount: "0021000348291", bankName: "Vietcombank - CN Thăng Long" },
    ],
  },
  {
    id: "loan_disbursement",
    index: 7,
    label: "7. Chi cho vay",
    shortLabel: "7. Chi cho vay",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Chi tiền cho vay",
    defaultDebit: "1283",
    defaultCredit: "1121",
    defaultAmount: 0,
    hasEmployeeField: true,
    hasCustomerDebtBtn: false,
    hasBatchPaymentCheckbox: true,
    layoutType: "bank_payment_standard",
    extraColumns: ["partnerCode", "partnerName", "loanDisbursementContract"],
    samplePartners: [
      { code: "DT001", name: "Công ty CP Tập đoàn Tài chính Hòa Bình", person: "Vũ Hải Đăng", address: "Cầu Giấy, Hà Nội", bankAccount: "1903482710", bankName: "Techcombank - Hội sở" },
      { code: "DT006", name: "Công ty CP Bất động sản Thăng Long", person: "Lê Văn Hùng", address: "Nam Từ Liêm, Hà Nội", bankAccount: "21510008472910", bankName: "BIDV - CN Cầu Giấy" },
    ],
  },
  {
    id: "other_expense",
    index: 8,
    label: "8. Chi khác",
    shortLabel: "8. Chi khác",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Chi tiền cho",
    defaultDebit: "",
    defaultCredit: "1121",
    defaultAmount: 0,
    hasEmployeeField: true,
    hasCustomerDebtBtn: false,
    hasBatchPaymentCheckbox: true,
    layoutType: "bank_payment_standard",
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "DT001", name: "Công ty Cổ phần Vận chuyển Á Châu", person: "Phạm Quốc Hùng", address: "Hoàng Mai, Hà Nội", bankAccount: "0021000348291", bankName: "Vietcombank - CN Thăng Long" },
      { code: "DT003", name: "Công ty Dịch vụ Môi trường Đô thị", person: "Nguyễn Văn Tuấn", address: "Đống Đa, Hà Nội", bankAccount: "19028374910012", bankName: "Techcombank - CN Thăng Long" },
    ],
  },
  {
    id: "tax_cit_payment",
    index: 9,
    label: "9. Nộp thuế TNDN tạm tính",
    shortLabel: "9. Nộp thuế TNDN tạm tính",
    codeLabel: "Mã đối tượng",
    nameLabel: "Tên đối tượng",
    personLabel: "Người nhận",
    addressLabel: "Địa chỉ",
    defaultPartnerCode: "",
    defaultPartnerName: "",
    defaultPerson: "",
    defaultAddress: "",
    defaultReason: "Nộp thuế thu nhập doanh nghiệp tạm tính",
    defaultDebit: "3334",
    defaultCredit: "1121",
    defaultAmount: 0,
    hasEmployeeField: false,
    hasYearField: true,
    hasCustomerDebtBtn: false,
    hasBatchPaymentCheckbox: false,
    layoutType: "bank_payment_standard",
    extraColumns: ["partnerCode", "partnerName"],
    samplePartners: [
      { code: "CQT001", name: "Chi cục Thuế Quận Cầu Giấy", person: "Kho bạc Nhà nước Cầu Giấy", address: "Số 68 Nguyễn Phong Sắc, Cầu Giấy, Hà Nội", bankAccount: "71111054321", bankName: "Kho bạc Nhà nước Cầu Giấy" },
      { code: "CQT002", name: "Cục Thuế Thành phố Hà Nội", person: "Kho bạc Nhà nước Hà Nội", address: "187 Giảng Võ, Đống Đa, Hà Nội", bankAccount: "71111000001", bankName: "Kho bạc Nhà nước TP Hà Nội" },
    ],
  },
];

export interface VoucherDetailRow {
  id: string;
  description: string;
  debit: string;
  credit: string;
  amount: number;
  bankAccount?: string;
  bankName?: string;
  partnerCode?: string;
  partnerName?: string;
  employeeCode?: string;
  employeeName?: string;
  loanContract?: string;
  loanDisbursementContract?: string;
}

export interface VoucherTaxRow {
  id: string;
  invoiceNo: string;
  invoiceDate: string;
  invoiceSeries: string;
  partnerCode: string;
  partnerName: string;
  taxCode: string;
  itemDescription: string;
  untaxedAmount: number;
  taxRate: number;
  taxAmount: number;
  taxAccount: string;
  hasInvoice?: boolean;
  goodsGroup?: string;
}

// ----------------------------------------------------------------------
// 3. MODAL "TẠO PHIẾU THU / CHI" MISA FORM CHUẨN (CHUẨN 5 LOẠI MISA)
// ----------------------------------------------------------------------
export function CreateVoucherModal({
  kind,
  voucherCategory = "cash",
  initialTypeIndex = 0,
  suggestedCode,
  existingCodes = [],
  initialStatement,
  onClose,
  onSave,
}: {
  kind: "receipt" | "payment";
  voucherCategory?: "cash" | "bank";
  initialTypeIndex?: number;
  suggestedCode?: string;
  existingCodes?: string[];
  initialStatement?: { account: string; accountNumber: string; date: string; amount: number; description: string; counterparty: string; counterpartyAccount: string; reference: string } | null;
  onClose: () => void;
  onSave: (doc: any) => void | boolean | Promise<void | boolean>;
}) {
  const [currentCategory, setCurrentCategory] = useState<"cash" | "bank">(voucherCategory);
  const isBank = currentCategory === "bank";
  const isReceipt = kind === "receipt";
  const { companyId, token } = useApiSession();
  const { rows: receiptCatalog, reload: reloadReceiptCatalog } = useMisaApiLists(companyId, {
    funds: "/api/v1/cash/funds/", branches: "/api/v1/organization/branches/", currencies: "/api/v1/master-data/currencies/",
    customers: "/api/v1/master-data/customers/", parties: "/api/v1/master-data/parties/", employees: "/api/v1/organization/employees/",
    bankAccounts: "/api/v1/master-data/company-bank-accounts/",
    receivables: "/api/v1/accounts-receivable/receivables/",
    accounts: "/api/v1/general-ledger/accounts/",
  }, message => setToastMessage(message));
  const { rows: bankPaymentCatalog, reload: reloadBankPaymentCatalog } = useMisaApiLists(!isReceipt && isBank ? companyId : "", {
    profiles: "/api/v1/bank/accounts/", bankAccounts: "/api/v1/master-data/company-bank-accounts/",
    branches: "/api/v1/organization/branches/", parties: "/api/v1/master-data/parties/",
    partyBankAccounts: "/api/v1/master-data/party-bank-accounts/", banks: "/api/v1/master-data/banks/",
    employees: "/api/v1/organization/employees/", payables: "/api/v1/accounts-payable/payables/",
    payableDocuments: "/api/v1/accounts-payable/documents/", supplierInvoices: "/api/v1/accounts-payable/invoices/",
    goodsPurchases: "/api/v1/purchases/goods-purchases/", purchaseCosts: "/api/v1/purchases/purchase-costs/",
    accounts: "/api/v1/general-ledger/accounts/",
  }, message => setToastMessage(message));
  const [bankProfileId, setBankProfileId] = useState(initialStatement?.account || "");
  const [bankBranchId, setBankBranchId] = useState("");
  const [bankExchangeRate, setBankExchangeRate] = useState("1");
  const [bankBeneficiaryName, setBankBeneficiaryName] = useState(initialStatement?.counterparty || "");
  const [bankReference, setBankReference] = useState(initialStatement?.reference || "");
  const [bankFee, setBankFee] = useState(false);
  const [receiverBankBranch, setReceiverBankBranch] = useState("");
  const [bankAllocations, setBankAllocations] = useState<Array<{ payable: string; amount: string; discount: string }>>([]);
  const selectedBankProfile = (bankPaymentCatalog.profiles || []).find(row => row.id === bankProfileId);
  const selectedCompanyBankAccount = (bankPaymentCatalog.bankAccounts || []).find(row => row.id === selectedBankProfile?.account);
  const bankCreditCode = selectedBankProfile?.gl_code || (selectedBankProfile?.currency_code === "VND" ? "1121" : "1122");
  const previousBankCredit = useRef(bankCreditCode);
  useEffect(() => {
    if (!bankProfileId && bankPaymentCatalog.profiles?.length) {
      const first = bankPaymentCatalog.profiles.find(row => (bankPaymentCatalog.bankAccounts || []).some(account =>
        account.id === row.account && account.status === "ACTIVE" && account.allow_payment));
      if (first) setBankProfileId(first.id);
    }
  }, [bankProfileId, bankPaymentCatalog.profiles, bankPaymentCatalog.bankAccounts]);
  useEffect(() => {
    if (selectedBankProfile && selectedCompanyBankAccount) {
      setBankAccount(selectedBankProfile.account_number || "");
      setBankName(selectedBankProfile.bank_name || "");
      setBankBranchId(selectedCompanyBankAccount.branch || (bankPaymentCatalog.branches || [])[0]?.id || "");
      const oldCredit = previousBankCredit.current;
      setRows(previous => previous.map(row => row.credit === oldCredit || row.credit === "1121" || row.credit === "1122" || row.credit === "112"
        ? { ...row, credit: bankCreditCode } : row));
      previousBankCredit.current = bankCreditCode;
    }
  }, [selectedBankProfile, selectedCompanyBankAccount, bankCreditCode, bankPaymentCatalog.branches]);
  const [fundId, setFundId] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [sourceBankAccountId, setSourceBankAccountId] = useState("");
  const [exchangeRate, setExchangeRate] = useState("1");
  const [allocations, setAllocations] = useState<Array<{ receivable: string; amount: string }>>([]);
  const selectedFund = (receiptCatalog.funds || []).find(row => row.id === fundId);
  const receiptCurrency = (receiptCatalog.currencies || []).find(row => row.id === selectedFund?.currency);
  const suggestedCashDebit = (receiptCatalog.accounts || []).find(row => row.id === selectedFund?.gl_account)?.code
    || (receiptCurrency?.code && receiptCurrency.code !== "VND" ? "1112" : "1111");
  const previousSuggestedDebit = useRef(suggestedCashDebit);
  useEffect(() => {
    if (!fundId && receiptCatalog.funds?.length) {
      const active = receiptCatalog.funds.find(row => row.status === "ACTIVE");
      if (active) setFundId(active.id);
    }
  }, [fundId, receiptCatalog.funds]);
  useEffect(() => {
    if (!sourceBankAccountId && receiptCatalog.bankAccounts?.length) {
      const firstBank = receiptCatalog.bankAccounts.find(row => row.status === "ACTIVE");
      if (firstBank) setSourceBankAccountId(firstBank.id);
    }
  }, [sourceBankAccountId, receiptCatalog.bankAccounts]);
  const voucherTypes = isReceipt
    ? (isBank ? MISA_BANK_RECEIPT_TYPES : MISA_RECEIPT_TYPES)
    : (isBank ? MISA_BANK_PAYMENT_TYPES : MISA_PAYMENT_TYPES);

  // Defaults: For receipt/payment
  const [selectedTypeIndex, setSelectedTypeIndex] = useState<number>(initialTypeIndex);
  const currentType = voucherTypes[selectedTypeIndex] || voucherTypes[0];
  const bankDebitFor = (type: VoucherTypeOption) => !isReceipt && isBank && ["supplier", "supplier_invoice", "advance"].includes(type.id)
    ? (bankPaymentCatalog.accounts || []).find(row => row.status === "ACTIVE" && row.is_postable &&
        String(row.code).startsWith(type.id === "advance" ? "141" : "331"))?.code || type.defaultDebit
    : type.defaultDebit;
  const suggestedBankDebit = bankDebitFor(currentType);
  const receiptPartnerChoices = useMemo(() => {
    if (currentType.id === "advance" || currentType.id === "advance_refund") {
      const empSource = (receiptCatalog.employees?.length ? receiptCatalog.employees : bankPaymentCatalog.employees) || [];
      return empSource
        .filter((row: any) => row.status === "ACTIVE")
        .map((row: any) => ({
          code: row.employee_code,
          name: row.full_name,
          person: row.full_name,
          address: row.address || "",
          phone: row.phone || "",
          bankAccount: "",
          bankName: "",
        }));
    }
    const custRows = (receiptCatalog.customers || []).filter((r: any) => !r.status || r.status === "ACTIVE");
    const partyRows = [
      ...(receiptCatalog.parties || []),
      ...(bankPaymentCatalog.parties || []),
    ].filter((r: any) => !r.status || r.status === "ACTIVE");
    const primary = ["customer", "customer_invoice"].includes(currentType.id)
      ? [...custRows, ...partyRows]
      : [...partyRows, ...custRows];
    const seen = new Set<string>();
    const merged: Array<{ code: string; name: string; person: string; address: string; taxCode?: string; phone?: string; bankAccount: string; bankName: string }> = [];
    for (const row of primary) {
      const c = String(row.code || "").trim();
      if (!c || seen.has(c.toLowerCase())) continue;
      seen.add(c.toLowerCase());
      merged.push({
        code: c,
        name: String(row.name || ""),
        person: String(row.representative || row.name || ""),
        address: String(row.address || row.addresses?.[0]?.address_line || ""),
        taxCode: String(row.tax_code || ""),
        phone: String(row.phone || row.contacts?.[0]?.phone || ""),
        bankAccount: "",
        bankName: "",
      });
    }
    return merged.length > 0 || companyId ? merged : (currentType.samplePartners || []);
  }, [currentType, receiptCatalog.customers, receiptCatalog.parties, receiptCatalog.employees, bankPaymentCatalog.parties, bankPaymentCatalog.employees, companyId]);

  const [showTypeDropdown, setShowTypeDropdown] = useState(false);
  const [showPartnerDropdown, setShowPartnerDropdown] = useState(false);
  const [partnerSearch,setPartnerSearch]=useState(false);
  const [showBankAccountDropdown, setShowBankAccountDropdown] = useState(false);
  const [showReceiverDropdown, setShowReceiverDropdown] = useState(false);
  const [showEmployeeDropdown, setShowEmployeeDropdown] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("Ủy nhiệm chi");
  const [showPaymentMethodDropdown, setShowPaymentMethodDropdown] = useState(false);
  const [isBatchPayment, setIsBatchPayment] = useState(false);
  const [showRefModal, setShowRefModal] = useState(false);
  const [quickDirectory,setQuickDirectory]=useState<string|null>(null);
  const [referenceCodes,setReferenceCodes]=useState<string[]>([]);
  const [showDebtLookupModal, setShowDebtLookupModal] = useState(false);

  const initialCode = isBank
    ? (isReceipt ? "NTTK00001" : "UNC00001")
    : (isReceipt ? "PT00001" : "PC00001");
  const [code, setCode] = useState(suggestedCode || initialCode);
  const [bankAccount, setBankAccount] = useState(initialStatement?.accountNumber || "");
  const [bankName, setBankName] = useState("");
  const [receiverAccount, setReceiverAccount] = useState(initialStatement?.counterpartyAccount || "");
  const [receiverBank, setReceiverBank] = useState("");
  const [partnerCode, setPartnerCode] = useState(currentType.defaultPartnerCode);
  const selectedBankParty = (bankPaymentCatalog.parties || []).find(row => row.code === partnerCode);
  const beneficiaryChoices = (bankPaymentCatalog.partyBankAccounts || []).filter(row =>
    row.party === selectedBankParty?.id && row.status === "ACTIVE").map(row => ({
      account: row.account_number,
      name: `${(bankPaymentCatalog.banks || []).find(bank => bank.id === row.bank)?.name || "Ngân hàng"} - ${row.branch_name || ""}`,
    }));
  const [partnerName, setPartnerName] = useState(initialStatement?.counterparty || currentType.defaultPartnerName);
  const [person, setPerson] = useState(currentType.defaultPerson);
  const [address, setAddress] = useState(currentType.defaultAddress);
  const [employee, setEmployee] = useState("");
  const [reason, setReason] = useState(initialStatement?.description || currentType.defaultReason);
  const [originalDocsCount, setOriginalDocsCount] = useState<string>("");
  const [settlementDueDate, setSettlementDueDate] = useState("");
  const [taxYear, setTaxYear] = useState<number>(new Date().getFullYear());
  const [hachToanDate, setHachToanDate] = useState(() => initialStatement?.date ? initialStatement.date.split("-").reverse().join("/") : currentCashDate());
  const [voucherDate, setVoucherDate] = useState(() => initialStatement?.date ? initialStatement.date.split("-").reverse().join("/") : currentCashDate());
  const [showAccount, setShowAccount] = useState(true);
  const [activeTab, setActiveTab] = useState<"accounting" | "tax">("accounting");
  const [batchTaxInvoices, setBatchTaxInvoices] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<string[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  const initialDebit = isReceipt
    ? (isBank ? (currentType.defaultDebit || "1121") : suggestedCashDebit)
    : (isBank ? suggestedBankDebit : (currentType.defaultDebit || ""));
  const initialCredit = !isReceipt
    ? (isBank ? bankCreditCode : (currentType.defaultCredit || "111"))
    : (currentType.defaultCredit || "");

  // Rows state in detail table
  const [rows, setRows] = useState<VoucherDetailRow[]>([
    {
      id: "1",
      description: initialStatement?.description || currentType.defaultReason,
      debit: initialDebit,
      credit: initialCredit,
      amount: initialStatement?.amount || currentType.defaultAmount,
      bankAccount: "",
      bankName: "",
      partnerCode: "",
      partnerName: "",
      employeeCode: "",
      employeeName: "",
      loanContract: "",
      loanDisbursementContract: "",
    },
  ]);
  useEffect(() => {
    if (isReceipt && !isBank && receiptCurrency) {
      const oldSuggestion = previousSuggestedDebit.current;
      if (oldSuggestion !== suggestedCashDebit) {
        setRows(previous => previous.map(row => row.debit === "111" || row.debit === oldSuggestion ? { ...row, debit: suggestedCashDebit } : row));
      }
      previousSuggestedDebit.current = suggestedCashDebit;
    }
  }, [isReceipt, isBank, receiptCurrency, suggestedCashDebit]);
  useEffect(() => {
    if (!isReceipt && isBank && suggestedBankDebit) {
      setRows(previous => previous.map(row => ["331", "141"].includes(row.debit)
        ? { ...row, debit: suggestedBankDebit } : row));
    }
  }, [isReceipt, isBank, suggestedBankDebit]);

  // Tax rows state in "Kê khai hóa đơn và hạch toán thuế"
  const [taxRows, setTaxRows] = useState<VoucherTaxRow[]>([
    {
      id: "1",
      invoiceNo: "0001234",
      invoiceDate: currentCashDate(),
      invoiceSeries: "1C26TAA",
      partnerCode: currentType.defaultPartnerCode || "",
      partnerName: currentType.defaultPartnerName || "",
      taxCode: "0108849201",
      itemDescription: "Chi phí mua ngoài",
      untaxedAmount: 0,
      taxRate: 10,
      taxAmount: 0,
      taxAccount: "1331",
    },
  ]);

  // Compute total amounts
  const totalAmount = useMemo(() => {
    return rows.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
  }, [rows]);

  const totalUntaxedAmount = useMemo(() => {
    return taxRows.reduce((sum, r) => sum + (Number(r.untaxedAmount) || 0), 0);
  }, [taxRows]);

  const totalTaxAmount = useMemo(() => {
    return taxRows.reduce((sum, r) => sum + (Number(r.taxAmount) || 0), 0);
  }, [taxRows]);

  const handleToggleCategory = (cat: "cash" | "bank") => {
    setCurrentCategory(cat);
    const nextIsBank = cat === "bank";
    const nextVoucherTypes = isReceipt
      ? (nextIsBank ? MISA_BANK_RECEIPT_TYPES : MISA_RECEIPT_TYPES)
      : (nextIsBank ? MISA_BANK_PAYMENT_TYPES : MISA_PAYMENT_TYPES);
    const nextIdx = Math.min(selectedTypeIndex, nextVoucherTypes.length - 1);
    setSelectedTypeIndex(nextIdx);
    const nextType = nextVoucherTypes[nextIdx] || nextVoucherTypes[0];
    setPartnerCode(nextType.defaultPartnerCode);
    setPartnerName(nextType.defaultPartnerName);
    setPerson(nextType.defaultPerson);
    setAddress(nextType.defaultAddress);
    setReason(nextType.defaultReason);
    if (cat === "bank") {
      if (isReceipt) {
        if (!code.startsWith("NTTK")) setCode(nextCashCode(kind,existingCodes,"bank"));
      } else {
        if (!code.startsWith("UNC")) setCode(nextCashCode(kind,existingCodes,"bank"));
      }
      setRows((prev) =>
        prev.map((r) => ({
          ...r,
          debit: isReceipt ? (nextType.defaultDebit || "1121") : (nextType.defaultDebit || r.debit),
          credit: !isReceipt ? (isBank ? bankCreditCode : (nextType.defaultCredit || "1121")) : nextType.defaultCredit,
        }))
      );
    } else {
      if (code.startsWith("NTTK") || code.startsWith("UNC")) {
        setCode(nextCashCode(kind,existingCodes,"cash"));
      }
      setRows((prev) =>
        prev.map((r) => ({
          ...r,
          debit: isReceipt ? suggestedCashDebit : (nextType.defaultDebit || r.debit),
          credit: !isReceipt ? "111" : nextType.defaultCredit,
        }))
      );
    }
  };

  // Switching voucher type
  const handleSelectType = (idx: number) => {
    setSelectedTypeIndex(idx);
    setShowTypeDropdown(false);
    setShowPartnerDropdown(false);
    setShowBankAccountDropdown(false);
    setShowReceiverDropdown(false);
    setShowEmployeeDropdown(false);
    setShowPaymentMethodDropdown(false);
    const chosen = voucherTypes[idx] || voucherTypes[0];
    setPartnerCode(chosen.defaultPartnerCode);
    setPartnerName(chosen.defaultPartnerName);
    setPerson(chosen.defaultPerson);
    setAddress(chosen.defaultAddress);
    setReason(chosen.defaultReason);
    setEmployee("");
    setEmployeeId("");
    setSourceBankAccountId("");
    setAllocations([]);
    setBankAllocations([]);
    setBankFee(false);
    setSettlementDueDate(chosen.hasSettlementDueDate ? currentCashDate() : "");
    if (chosen.hasYearField) {
      setTaxYear(2026);
    }
    setActiveTab("accounting");
    setBatchTaxInvoices(false);
    const debitAccount = isReceipt
      ? (isBank ? (chosen.defaultDebit || "1121") : suggestedCashDebit)
      : (isBank ? bankDebitFor(chosen) : (chosen.defaultDebit || ""));
    const creditAccount = !isReceipt
      ? (isBank ? bankCreditCode : (chosen.defaultCredit || "111"))
      : (chosen.defaultCredit || "");
    setRows([
      {
        id: crypto.randomUUID(),
        description: chosen.defaultReason,
        debit: debitAccount,
        credit: creditAccount,
        amount: 0,
        bankAccount: bankAccount,
        bankName: bankName,
        partnerCode: chosen.extraColumns?.includes("partnerCode") ? (chosen.defaultPartnerCode || "") : "",
        partnerName: chosen.extraColumns?.includes("partnerName") ? (chosen.defaultPartnerName || "") : "",
        employeeCode: chosen.extraColumns?.includes("employeeCode") ? (chosen.defaultPartnerCode || "") : "",
        employeeName: chosen.extraColumns?.includes("employeeName") ? (chosen.defaultPartnerName || "") : "",
        loanContract: "",
        loanDisbursementContract: "",
      },
    ]);
    setTaxRows([
      {
        id: crypto.randomUUID(),
        invoiceNo: "0001234",
        invoiceDate: currentCashDate(),
        invoiceSeries: "1C26TAA",
        partnerCode: chosen.defaultPartnerCode || "",
        partnerName: chosen.defaultPartnerName || "",
        taxCode: "0108849201",
        itemDescription: chosen.defaultReason || "Chi mua ngoài có hóa đơn",
        untaxedAmount: 0,
        taxRate: 10,
        taxAmount: 0,
        taxAccount: "1331",
      },
    ]);
  };

  useEffect(() => {
    if (initialTypeIndex !== undefined && initialTypeIndex !== selectedTypeIndex) {
      handleSelectType(initialTypeIndex);
    }
  }, [initialTypeIndex]);

  const handleSelectPartner = (p: { code: string; name: string; person: string; address: string }) => {
    if (!isReceipt && isBank) {
      setBankBeneficiaryName(p.name);
      const party = (bankPaymentCatalog.parties || []).find(row => row.code === p.code);
      const accounts = (bankPaymentCatalog.partyBankAccounts || []).filter(row => row.party === party?.id && row.status === "ACTIVE");
      const selected = accounts.length === 1 ? accounts[0] : null;
      setReceiverAccount(selected?.account_number || "");
      setReceiverBank((bankPaymentCatalog.banks || []).find(row => row.id === selected?.bank)?.name || "");
      setReceiverBankBranch(selected?.branch_name || "");
    }
    if (isReceipt && !isBank && currentType.id === "advance_refund") {
      setEmployeeId((receiptCatalog.employees || []).find(row => row.employee_code === p.code)?.id || "");
    }
    const defaultPrefix = currentType.defaultReason.trim();
    const needsPartnerSuffix = /\b(của|cho)$/i.test(defaultPrefix);
    const oldAutoReason = partnerName ? `${defaultPrefix} ${partnerName}` : "";
    const nextAutoReason = needsPartnerSuffix && p.name ? `${defaultPrefix} ${p.name}` : "";
    const curReasonTrim = reason.trim();
    const shouldAutoFillReason = Boolean(
      nextAutoReason &&
      (!curReasonTrim || curReasonTrim === defaultPrefix || (oldAutoReason && curReasonTrim === oldAutoReason))
    );
    if (shouldAutoFillReason) {
      setReason(nextAutoReason);
    }
    setPartnerCode(p.code);
    setPartnerName(p.name);
    setPerson(p.person);
    setAddress(p.address);
    setShowPartnerDropdown(false);
    // sync to rows
    setRows((prev) =>
      prev.map((r, i) => {
        if (i !== 0) return r;
        const rowDescTrim = (r.description || "").trim();
        const shouldAutoFillRowDesc = Boolean(
          nextAutoReason &&
          (!rowDescTrim || rowDescTrim === defaultPrefix || rowDescTrim === curReasonTrim || (oldAutoReason && rowDescTrim === oldAutoReason))
        );
        return {
          ...r,
          description: shouldAutoFillRowDesc ? nextAutoReason : r.description,
          partnerCode: p.code,
          partnerName: p.name,
          employeeCode: p.code,
          employeeName: p.name,
        };
      })
    );
    setTaxRows((prev) =>
      prev.map((r, i) =>
        i === 0
          ? {
            ...r,
            partnerCode: p.code,
            partnerName: p.name,
          }
          : r
      )
    );
  };

  const handlePartnerCodeChange = (val: string) => {
    setPartnerCode(val);
    const trimmed = val.trim().toLowerCase();
    const matched = trimmed ? receiptPartnerChoices.find((p) => String(p.code).toLowerCase() === trimmed) : undefined;
    if (matched) {
      setPartnerName(matched.name);
      setPerson(matched.person || matched.name);
      if (matched.address) setAddress(matched.address);
    }
    setRows((prev) =>
      prev.map((r, i) =>
        i === 0
          ? {
              ...r,
              partnerCode: val,
              ...(matched ? { partnerName: matched.name } : {}),
            }
          : r,
      ),
    );
  };

  const handlePartnerNameChange = (val: string) => {
    const oldName = partnerName;
    setPartnerName(val);
    if (!person || person === oldName) {
      setPerson(val);
    }
    setRows((prev) =>
      prev.map((r, i) => (i === 0 ? { ...r, partnerName: val } : r)),
    );
  };

  // Row operations for accounting table
  const handleAddRow = () => {
    const debitAccount = isReceipt
      ? (isBank ? (currentType.defaultDebit || "1121") : suggestedCashDebit)
      : (isBank ? suggestedBankDebit : (currentType.defaultDebit || ""));
    const creditAccount = !isReceipt
      ? (isBank ? bankCreditCode : (currentType.defaultCredit || "111"))
      : (currentType.defaultCredit || "");
    setRows((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        description: reason || currentType.defaultReason,
        debit: debitAccount,
        credit: creditAccount,
        amount: 0,
        bankAccount: bankAccount,
        bankName: bankName,
        partnerCode: partnerCode || "",
        partnerName: partnerName || "",
        employeeCode: partnerCode || "",
        employeeName: partnerName || "",
        loanContract: "",
        loanDisbursementContract: "",
      },
    ]);
  };

  const handleDeleteRow = (id: string) => {
    const debitAccount = isReceipt
      ? (isBank ? "112" : suggestedCashDebit)
      : (isBank ? suggestedBankDebit : (currentType.defaultDebit || ""));
    const creditAccount = !isReceipt
      ? (isBank ? "112" : suggestedCashDebit)
      : (currentType.defaultCredit || "");
    if (rows.length <= 1) {
      setRows([
        {
          id: crypto.randomUUID(),
          description: reason,
          debit: debitAccount,
          credit: creditAccount,
          amount: 0,
          bankAccount: bankAccount,
          bankName: bankName,
          partnerCode: "",
          partnerName: "",
          employeeCode: "",
          employeeName: "",
          loanContract: "",
          loanDisbursementContract: "",
        },
      ]);
      return;
    }
    setRows((prev) => prev.filter((r) => r.id !== id));
  };

  const handleClearAllRows = () => {
    const debitAccount = isReceipt
      ? (isBank ? "112" : suggestedCashDebit)
      : (isBank ? suggestedBankDebit : (currentType.defaultDebit || ""));
    const creditAccount = !isReceipt
      ? (isBank ? "112" : suggestedCashDebit)
      : (currentType.defaultCredit || "");
    setRows([
      {
        id: crypto.randomUUID(),
        description: reason,
        debit: debitAccount,
        credit: creditAccount,
        amount: 0,
        bankAccount: bankAccount,
        bankName: bankName,
        partnerCode: "",
        partnerName: "",
        employeeCode: "",
        employeeName: "",
        loanContract: "",
        loanDisbursementContract: "",
      },
    ]);
  };

  // Row operations for tax declaration table
  const handleAddTaxRow = () => {
    setTaxRows((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        invoiceNo: "",
        invoiceDate: currentCashDate(),
        invoiceSeries: "1C26TAA",
        partnerCode: partnerCode || "",
        partnerName: partnerName || "",
        taxCode: "",
        itemDescription: reason || "Chi mua ngoài có hóa đơn",
        untaxedAmount: 0,
        taxRate: 10,
        taxAmount: 0,
        taxAccount: "1331",
      },
    ]);
  };

  const handleDeleteTaxRow = (id: string) => {
    if (taxRows.length <= 1) {
      setTaxRows([
        {
          id: crypto.randomUUID(),
          invoiceNo: "",
          invoiceDate: currentCashDate(),
          invoiceSeries: "1C26TAA",
          partnerCode: "",
          partnerName: "",
          taxCode: "",
          itemDescription: reason || "Chi mua ngoài có hóa đơn",
          untaxedAmount: 0,
          taxRate: 10,
          taxAmount: 0,
          taxAccount: "1331",
        },
      ]);
      return;
    }
    setTaxRows((prev) => prev.filter((r) => r.id !== id));
  };

  const handleClearAllTaxRows = () => {
    setTaxRows([
      {
        id: crypto.randomUUID(),
        invoiceNo: "",
        invoiceDate: currentCashDate(),
        invoiceSeries: "1C26TAA",
        partnerCode: "",
        partnerName: "",
        taxCode: "",
        itemDescription: reason || "Chi mua ngoài có hóa đơn",
        untaxedAmount: 0,
        taxRate: 10,
        taxAmount: 0,
        taxAccount: "1331",
      },
    ]);
  };

  const handleUpdateTaxRow = (id: string, field: keyof VoucherTaxRow, value: any) => {
    setTaxRows((prev) =>
      prev.map((r) => {
        if (r.id !== id) return r;
        const updated = { ...r, [field]: value };
        if (field === "untaxedAmount" || field === "taxRate") {
          const untaxed = field === "untaxedAmount" ? Number(value) : r.untaxedAmount;
          const rate = field === "taxRate" ? Number(value) : r.taxRate;
          updated.taxAmount = Math.round((untaxed * rate) / 100);
        }
        return updated;
      })
    );
  };

  const handleUpdateRow = (id: string, field: keyof VoucherDetailRow, val: any) => {
    if (field === "description" && rows[0]?.id === id) {
      const nextDesc = String(val ?? "");
      const oldRowDesc = (rows[0]?.description || "").trim();
      const curReasonTrim = reason.trim();
      const defaultPrefix = currentType.defaultReason.trim();
      if (
        rows.length === 1 ||
        !curReasonTrim ||
        curReasonTrim === defaultPrefix ||
        curReasonTrim === oldRowDesc
      ) {
        setReason(nextDesc);
      }
    }
    setRows((prev) =>
      prev.map((r) => {
        if (r.id === id) {
          return { ...r, [field]: val };
        }
        return r;
      }),
    );
  };

  // Handle Save
  const handleSave = async (andNew = false, andPrint = false) => {
    if (saving) return;
    const formattedIsoDate = voucherDate.includes("/")
      ? voucherDate.split("/").reverse().join("-")
      : voucherDate;

    const defaultPrefix = currentType.defaultReason.trim();
    const isBarePrefix = (text: string) =>
      !text || text === defaultPrefix || /^(thu tiền của|chi tiền cho|tạm ứng cho|thu hoàn ứng sau khi quyết toán tạm ứng cho|chi mua ngoài có hóa đơn cho|trả các khoản vay cho)$/i.test(text);
    const reasonTrim = reason.trim();
    const firstRowDescTrim = (rows[0]?.description || "").trim();
    const partnerSuffix = (partnerName || person || partnerCode || "").trim();
    let resolvedReason = reasonTrim;
    if (isBarePrefix(resolvedReason) && firstRowDescTrim && !isBarePrefix(firstRowDescTrim)) {
      resolvedReason = firstRowDescTrim;
    } else if (isBarePrefix(resolvedReason) && /\b(của|cho)$/i.test(resolvedReason || defaultPrefix) && partnerSuffix) {
      resolvedReason = `${resolvedReason || defaultPrefix} ${partnerSuffix}`;
    } else if (!resolvedReason) {
      resolvedReason = firstRowDescTrim || defaultPrefix;
    }
    const resolvedRows = rows.map((r, idx) => {
      const rDesc = (r.description || "").trim();
      if (idx === 0 && isBarePrefix(rDesc) && resolvedReason && !isBarePrefix(resolvedReason)) {
        return { ...r, description: resolvedReason };
      }
      if (isBarePrefix(rDesc) && /\b(của|cho)$/i.test(rDesc || defaultPrefix) && partnerSuffix) {
        return { ...r, description: `${rDesc || defaultPrefix} ${partnerSuffix}` };
      }
      return r;
    });

    setSaving(true);
    const saved = await onSave({
      id: crypto.randomUUID(),
      code,
      date: formattedIsoDate,
      partner: partnerName || partnerCode,
      partnerCode,
      description: resolvedReason,
      amount: totalAmount,
      kind,
      voucherCategory: currentCategory,
      status: (isReceipt && !isBank) || (!isReceipt && isBank) ? "draft" : "posted",
      receiptType: currentType.id,
      fundId,
      bankProfileId,
      branchId: bankBranchId,
      employeeId,
      sourceBankAccountId,
      exchangeRate: !isReceipt && isBank ? bankExchangeRate : exchangeRate,
      allocations: !isReceipt && isBank ? bankAllocations : allocations,
      beneficiaryName: bankBeneficiaryName,
      receiverBankBranch,
      bankReference,
      bankFee,
      originalDocsCount,
      debit: resolvedRows[0]?.debit || currentType.defaultDebit,
      credit: resolvedRows[0]?.credit || (isBank ? "112" : currentType.defaultCredit),
      person,
      address,
      employee,
      bankAccount,
      bankName,
      receiverAccount,
      receiverBank,
      paymentMethod,
      isBatchPayment,
      rows: resolvedRows,
      taxRows,
      batchTaxInvoices,
      attachedFiles,
      postDate: hachToanDate,
      reasonLabel: currentType.label.replace(/^\d+\.\s*/,''),
    });
    setSaving(false);
    if (saved === false) return;

    if (andPrint) {
      setToastMessage(`✓ Đã lưu chứng từ ${code} thành công! Đang kết nối máy in...`);
      setTimeout(() => {
        window.print();
        onClose();
      }, 700);
    } else if (andNew) {
      const numPart = parseInt(code.replace(/\D/g, "") || "1", 10) + 1;
      const prefix = isBank ? (isReceipt ? "NTTK" : "UNC") : (isReceipt ? "PT" : "PC");
      const nextCode = `${prefix}${String(numPart).padStart(5, "0")}`;
      setCode(nextCode);
      const debitAccount = isReceipt
        ? (isBank ? (currentType.defaultDebit || "1121") : suggestedCashDebit)
        : (isBank ? suggestedBankDebit : (currentType.defaultDebit || ""));
      const creditAccount = !isReceipt
        ? (isBank ? bankCreditCode : (currentType.defaultCredit || "111"))
        : (currentType.defaultCredit || "");
      setRows([
        {
          id: crypto.randomUUID(),
          description: currentType.defaultReason,
          debit: debitAccount,
          credit: creditAccount,
          amount: 0,
          bankAccount: bankAccount,
          bankName: "",
          partnerCode: "",
          partnerName: "",
          employeeCode: "",
          employeeName: "",
          loanContract: "",
          loanDisbursementContract: "",
        },
      ]);
      const msg = `✓ Đã lưu chứng từ ${code} thành công! Sẵn sàng nhập tiếp ${nextCode}.`;
      setToastMessage(msg);
      setTimeout(() => setToastMessage(null), 3000);
    } else {
      setToastMessage(`✓ Đã lưu chứng từ ${code} thành công!`);
      setTimeout(() => {
        onClose();
      }, 600);
    }
  };

  // Handle file drop/upload
  const acceptAttachments = (files: File[]) => {
    const oversized = files.filter(file => file.size > 5 * 1024 * 1024);
    if (oversized.length) setToastMessage('Tệp đính kèm vượt quá 5MB: ' + oversized.map(file => file.name).join(', '));
    setAttachedFiles(prev => [...prev, ...files.filter(file => file.size <= 5 * 1024 * 1024).map(file => file.name)]);
  };
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    acceptAttachments(Array.from(e.target.files || []));
    e.target.value = '';
  };

  return (
    <div className="misa-tax-modal-overlay">
      <div className="misa-voucher-window">
        {/* Toast alert if any */}
        {toastMessage && (
          <div
            style={{
              position: "absolute",
              top: 12,
              left: "50%",
              transform: "translateX(-50%)",
              background: "var(--brand)",
              color: "#ffffff",
              padding: "6px 16px",
              borderRadius: 6,
              fontSize: 13,
              fontWeight: 600,
              boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
              zIndex: 9999,
              display: "flex",
              alignItems: "center",
              gap: 8,
            }}
          >
            <Check size={16} />
            {toastMessage}
          </div>
        )}

        {/* 1. Header (Matching Screenshot) */}
        <header className="misa-voucher-header">
          <div className="misa-voucher-header-left">
            <button
              className="misa-voucher-back-btn"
              title="Quay lại / Lịch sử"
              type="button"
            >
              <RotateCcw size={16} />
            </button>

            <h2 className="misa-voucher-title" style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
              {isBank ? (isReceipt ? "Thu tiền gửi" : "Ủy nhiệm chi") : (isReceipt ? "Phiếu thu" : "Phiếu chi")} {code}
              {isReceipt && !isBank && (
                <span
                  style={{
                    fontSize: 11,
                    fontWeight: 500,
                    padding: "2px 8px",
                    borderRadius: 12,
                    background: "#f0fdf4",
                    color: "#16a34a",
                    border: "1px solid #bbf7d0",
                    cursor: "pointer",
                    marginLeft: 4,
                  }}
                  title="Bấm để chuyển đổi giữa Tiền gửi (NTTK) và Tiền mặt (PT)"
                  onClick={() => handleToggleCategory(isBank ? "cash" : "bank")}
                >
                  Tiền mặt (PT) ⇄
                </span>
              )}
            </h2>

            {/* Type selector pill button */}
            <MisaDropdownSelect
              buttonClassName="misa-voucher-type-pill"
              itemClassName="misa-voucher-type-item"
              value={selectedTypeIndex}
              onChange={(val) => handleSelectType(Number(val))}
              title="LOẠI CHỨNG TỪ"
              options={voucherTypes.map((t, idx) => ({
                value: idx,
                label: t.label,
              }))}
              buttonStyle={{
                height: 28,
                padding: "0 10px",
                border: "1px solid var(--brand)",
                borderRadius: 4,
                fontSize: 13,
                fontWeight: 600,
                color: "#1e293b",
              }}
              minWidth={320}
              ariaLabel="Loại chứng từ"
            />

            {/* Payment Method Selector Dropdown for Bank Payment (Matching taskbar style) */}
            {isBank && !isReceipt && (
              <MisaDropdownSelect
                value={paymentMethod}
                onChange={(val) => setPaymentMethod(val)}
                title="PHƯƠNG THỨC THANH TOÁN"
                options={[
                  { value: "Ủy nhiệm chi", label: "Ủy nhiệm chi" },
                  { value: "Séc chuyển khoản", label: "Séc chuyển khoản" },
                  { value: "Séc tiền mặt", label: "Séc tiền mặt" },
                  { value: "Bảng kê nộp thuế", label: "Bảng kê nộp thuế" },
                ]}
                buttonStyle={{
                  height: 28,
                  padding: "0 10px",
                  border: "1px solid #cbd5e1",
                  borderRadius: 4,
                  fontSize: 13,
                  fontWeight: 500,
                  color: "#1e293b",
                }}
                minWidth={200}
                ariaLabel="Phương thức thanh toán"
              />
            )}
          </div>

          <div className="misa-voucher-header-tools">
            <a
              href="#help"
              className="misa-voucher-help-link"
              onClick={(e) => {
                e.preventDefault();
                showNotice(
                  `Hướng dẫn hạch toán theo chuẩn Sổ Việt ERP:\n- Nghiệp vụ: ${currentType.label}\n- Nợ TK: ${currentType.defaultDebit || "(Tùy chọn)"}\n- Có TK: ${currentType.defaultCredit || "(Tùy chọn)"}`
                );
              }}
            >
              <HelpCircle size={15} style={{ color: "var(--brand)" }} />
              <span>Hướng dẫn sử dụng</span>
              <ChevronDown size={12} />
            </a>

            <button
              type="button"
              className="misa-tax-icon-btn"
              title="Thiết lập mẫu chứng từ"
            >
              <Settings size={16} />
            </button>

            <button
              type="button"
              className="misa-tax-icon-btn"
              onClick={onClose}
              title="Đóng (Esc)"
            >
              <X size={18} />
            </button>
          </div>
        </header>

        {/* Subheader: Là UNC chuyển tiền theo lô (Format 1 matching Screenshot 1) */}
        {isBank && !isReceipt && currentType.hasBatchPaymentCheckbox && (
          <div
            style={{
              padding: "6px 20px 2px",
              background: "#ffffff",
              display: "flex",
              alignItems: "center",
              borderBottom: "1px solid #f1f5f9",
            }}
          >
            <label
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                fontSize: 13,
                color: "#334155",
                cursor: "pointer",
                fontWeight: 500,
              }}
            >
              <input
                type="checkbox"
                checked={isBatchPayment}
                onChange={(e) => setIsBatchPayment(e.target.checked)}
                style={{ accentColor: "var(--brand)", width: 15, height: 15 }}
              />
              <span>Là UNC chuyển tiền theo lô</span>
            </label>
          </div>
        )}

        {!isReceipt && isBank && (
          <div style={{ display: "none" }}>
            <label>Chi nhánh *<select aria-label="Chi nhánh chi tiền gửi" value={bankBranchId} onChange={event => setBankBranchId(event.target.value)}>
              <option value="">Chọn chi nhánh</option>{(bankPaymentCatalog.branches || []).filter(row => row.status === "ACTIVE" &&
                (!selectedCompanyBankAccount?.branch || row.id === selectedCompanyBankAccount.branch)).map(row => <option key={row.id} value={row.id}>{row.name}</option>)}
            </select></label>
            <label>Tài khoản chi *<select aria-label="Tài khoản ngân hàng chi" value={bankProfileId} onChange={event => setBankProfileId(event.target.value)}>
              <option value="">Chọn tài khoản chi</option>{(bankPaymentCatalog.profiles || []).filter(row => (bankPaymentCatalog.bankAccounts || []).some(account =>
                account.id === row.account && account.status === "ACTIVE" && account.allow_payment)).map(row =>
                <option key={row.id} value={row.id}>{row.account_number} · {row.bank_name} · {row.currency_code}</option>)}
            </select></label>
            <label>Loại tiền<input aria-label="Loại tiền chi tiền gửi" readOnly value={selectedBankProfile?.currency_code || ""} /></label>
            <label>Tỷ giá *<input aria-label="Tỷ giá chi tiền gửi" type="number" min="0.00000001" step="any"
              value={selectedBankProfile?.currency_code === "VND" ? "1" : bankExchangeRate}
              disabled={selectedBankProfile?.currency_code === "VND"} onChange={event => setBankExchangeRate(event.target.value)} /></label>
            <span style={{ alignSelf: "end", fontSize: 12, color: "#475569" }}>Tổng quy đổi: {formatVND(totalAmount * Number(selectedBankProfile?.currency_code === "VND" ? 1 : bankExchangeRate || 0))}</span>
            {(["supplier", "supplier_invoice"].includes(currentType.id)) && <label>Nhà cung cấp *<select aria-label="Nhà cung cấp chi tiền gửi" value={partnerCode} onChange={event => {
              const party = (bankPaymentCatalog.parties || []).find(row => row.code === event.target.value);
              const accounts = (bankPaymentCatalog.partyBankAccounts || []).filter(row => row.party === party?.id && row.status === "ACTIVE");
              const selected = accounts.length === 1 ? accounts[0] : null;
              setPartnerCode(party?.code || ""); setPartnerName(party?.name || ""); setBankBeneficiaryName(party?.name || "");
              setReceiverAccount(selected?.account_number || "");
              setReceiverBank((bankPaymentCatalog.banks || []).find(row => row.id === selected?.bank)?.name || "");
              setReceiverBankBranch(selected?.branch_name || "");
              setBankAllocations([]); setRows(previous => previous.map(row => ({ ...row, partnerCode: party?.code || "", partnerName: party?.name || "" })));
            }}><option value="">Chọn nhà cung cấp</option>{(bankPaymentCatalog.parties || []).filter(row => row.status === "ACTIVE").map(row =>
              <option key={row.id} value={row.code}>{row.code} · {row.name}</option>)}</select></label>}
            {currentType.id === "advance" && <label>Nhân viên tạm ứng *<select aria-label="Nhân viên tạm ứng" value={employeeId} onChange={event => {
              const employee = (bankPaymentCatalog.employees || []).find(row => row.id === event.target.value);
              setEmployeeId(employee?.id || ""); setPartnerCode(employee?.employee_code || "");
              setPartnerName(employee?.full_name || ""); setBankBeneficiaryName(employee?.full_name || "");
            }}><option value="">Chọn nhân viên</option>{(bankPaymentCatalog.employees || []).filter(row => row.status === "ACTIVE").map(row =>
              <option key={row.id} value={row.id}>{row.employee_code} · {row.full_name}</option>)}</select></label>}
            <label>Tên thụ hưởng<input aria-label="Tên người thụ hưởng" value={bankBeneficiaryName} onChange={event => setBankBeneficiaryName(event.target.value)} /></label>
            <label>Chi nhánh ngân hàng nhận<input aria-label="Chi nhánh ngân hàng nhận" value={receiverBankBranch} onChange={event => setReceiverBankBranch(event.target.value)} /></label>
            <label>Mã giao dịch / Giấy báo Nợ<input aria-label="Mã giao dịch ngân hàng" value={bankReference} onChange={event => setBankReference(event.target.value)} /></label>
            {currentType.id === "other_expense" && <label style={{ display: "inline-flex", alignItems: "center", gap: 6 }}><input type="checkbox" checked={bankFee} onChange={event => setBankFee(event.target.checked)} />Phí ngân hàng tự trích</label>}
            {currentType.id === "supplier_invoice" && partnerCode && <div style={{ width: "100%" }}><strong>Công nợ còn phải trả</strong>
              {(bankPaymentCatalog.payables || []).filter(row => row.supplier === (bankPaymentCatalog.parties || []).find(party => party.code === partnerCode)?.id
                && row.currency === selectedBankProfile?.currency_id && Number(row.balance) > 0).map(debt => {
                const selected = bankAllocations.find(item => item.payable === debt.id);
                const source = (bankPaymentCatalog.payableDocuments || []).find(row => row.id === debt.document);
                const invoice = (bankPaymentCatalog.supplierInvoices || []).find(row => row.id === debt.invoice);
                const purchase = (bankPaymentCatalog.goodsPurchases || []).find(row => row.id === debt.goods_purchase);
                const cost = (bankPaymentCatalog.purchaseCosts || []).find(row => row.id === debt.purchase_cost);
                const label = source?.number || invoice?.invoice_number || purchase?.number || cost?.number || debt.id.slice(0, 8);
                return <label key={debt.id} style={{ display: "inline-flex", alignItems: "center", gap: 6, margin: "6px 12px 0 0" }}>
                  <input type="checkbox" checked={Boolean(selected)} onChange={event => {
                    const next = event.target.checked ? [...bankAllocations, { payable: debt.id, amount: String(debt.balance), discount: "0" }] :
                      bankAllocations.filter(item => item.payable !== debt.id);
                    setBankAllocations(next);
                    setRows(next.map((item, index) => {
                      const payable = (bankPaymentCatalog.payables || []).find(row => row.id === item.payable);
                      const source = (bankPaymentCatalog.payableDocuments || []).find(row => row.id === payable?.document);
                      const debit = (bankPaymentCatalog.accounts || []).find(row => row.id === source?.payable_account)?.code || suggestedBankDebit;
                      return { ...rows[0], id: String(index + 1), description: reason,
                        debit, credit: bankCreditCode, amount: Number(item.amount) };
                    }));
                  }} />{label} · hạn {debt.due_date || "—"} · còn {formatVND(Number(debt.balance))}
                  {selected && <><input aria-label={`Số trả ${label}`} type="text" inputMode="numeric"
                    value={formatMoneyInput(selected.amount)} onChange={event => {
                      const clean = parseMoneyInputString(event.target.value, { emptyWhenBlank: false });
                      const next = bankAllocations.map(item => item.payable === debt.id ? { ...item, amount: clean } : item);
                      setBankAllocations(next); setRows(previous => previous.map((row, index) => ({ ...row, amount: Number(next[index]?.amount || 0) })));
                    }} /><input aria-label={`Chiết khấu ${label}`} type="text" inputMode="numeric"
                    value={formatMoneyInput(selected.discount)} onChange={event => setBankAllocations(previous => previous.map(item =>
                      item.payable === debt.id ? { ...item, discount: parseMoneyInputString(event.target.value, { emptyWhenBlank: false }) } : item))} /></>}
                </label>;
              })}
            </div>}
          </div>
        )}
        {isReceipt && !isBank && (
          <div style={{ display: "none" }}>
            <label>Chi nhánh / Quỹ *<select aria-label="Chi nhánh và quỹ tiền mặt" value={fundId} onChange={event => setFundId(event.target.value)}>
              <option value="">Chọn quỹ</option>
              {(receiptCatalog.funds || []).filter(row => row.status === "ACTIVE").map(row => <option key={row.id} value={row.id}>{(receiptCatalog.branches || []).find(branch => branch.id === row.branch)?.name || "Chi nhánh"} · {row.code} · {row.name}</option>)}
            </select></label>
            <label>Loại tiền<input aria-label="Loại tiền phiếu thu" readOnly value={receiptCurrency?.code || ""} /></label>
            <label>Tỷ giá *<input aria-label="Tỷ giá phiếu thu" type="number" min="0.00000001" step="any" value={receiptCurrency?.code === "VND" ? "1" : exchangeRate} disabled={receiptCurrency?.code === "VND"} onChange={event => setExchangeRate(event.target.value)} /></label>
            <span style={{ alignSelf: "end", fontSize: 12, color: "#475569" }}>Tổng quy đổi: {formatVND(totalAmount * Number(receiptCurrency?.code === "VND" ? 1 : exchangeRate || 0))}</span>
            {(["customer", "customer_invoice"].includes(currentType.id)) && <label>Khách hàng *<select aria-label="Khách hàng phiếu thu" value={partnerCode} onChange={event => {
              const customer = (receiptCatalog.customers || []).find(row => row.code === event.target.value);
              setPartnerCode(customer?.code || ""); setPartnerName(customer?.name || ""); setPerson(customer?.name || ""); setAllocations([]);
              setRows(previous => previous.map(row => ({ ...row, partnerCode: customer?.code || "", partnerName: customer?.name || "" })));
            }}><option value="">Chọn khách hàng</option>{(receiptCatalog.customers || []).map(row => <option key={row.id} value={row.code}>{row.code} · {row.name}</option>)}</select></label>}
            {currentType.id === "advance_refund" && <label>Nhân viên hoàn ứng *<select aria-label="Nhân viên hoàn ứng" value={employeeId} onChange={event => {
              const employee = (receiptCatalog.employees || []).find(row => row.id === event.target.value);
              setEmployeeId(employee?.id || ""); setPartnerCode(employee?.employee_code || ""); setPartnerName(employee?.full_name || ""); setPerson(employee?.full_name || "");
            }}><option value="">Chọn nhân viên</option>{(receiptCatalog.employees || []).filter(row => row.status === "ACTIVE").map(row => <option key={row.id} value={row.id}>{row.employee_code} · {row.full_name}</option>)}</select></label>}
            {currentType.id === "bank_withdrawal" && <label>Tài khoản ngân hàng nguồn *<select aria-label="Tài khoản ngân hàng nguồn" value={sourceBankAccountId} onChange={event => setSourceBankAccountId(event.target.value)}>
              <option value="">Chọn tài khoản</option>{(receiptCatalog.bankAccounts || []).filter(row => row.status === "ACTIVE" && row.currency === selectedFund?.currency).map(row => <option key={row.id} value={row.id}>{row.account_number} · {row.account_name}</option>)}
            </select></label>}
            {currentType.id === "customer_invoice" && partnerCode && <div style={{ width: "100%" }}><strong>Chứng từ công nợ còn phải thu</strong>
              {(receiptCatalog.receivables || []).filter(row => row.customer === (receiptCatalog.customers || []).find(customer => customer.code === partnerCode)?.id && row.currency === selectedFund?.currency && Number(row.balance) > 0).map(debt => {
                const selected = allocations.find(item => item.receivable === debt.id);
                return <label key={debt.id} style={{ display: "inline-flex", alignItems: "center", gap: 6, margin: "6px 12px 0 0" }}>
                  <input type="checkbox" checked={Boolean(selected)} onChange={event => {
                    const next = event.target.checked ? [...allocations, { receivable: debt.id, amount: String(debt.balance) }] : allocations.filter(item => item.receivable !== debt.id);
                    setAllocations(next);
                    setRows(next.map((item, index) => { const source = (receiptCatalog.receivables || []).find(row => row.id === item.receivable);
                      const account = (receiptCatalog.accounts || []).find(row => row.id === source?.account);
                      return { ...rows[0], id: String(index + 1), description: reason, debit: receiptCurrency?.code === "VND" ? "1111" : "1112", credit: account?.code || "131", amount: Number(item.amount) };
                    }));
                  }} />{debt.code || debt.source_document_number} · còn {formatVND(Number(debt.balance))}
                  {selected && <input aria-label={`Số tiền thu ${debt.code || debt.source_document_number}`} type="text" inputMode="numeric" value={formatMoneyInput(selected.amount)} onChange={event => {
                    const clean = parseMoneyInputString(event.target.value, { emptyWhenBlank: false });
                    const next = allocations.map(item => item.receivable === debt.id ? { ...item, amount: clean } : item);
                    setAllocations(next); setRows(previous => previous.map((row, index) => ({ ...row, amount: Number(next[index]?.amount || 0) })));
                  }} />}
                </label>;
              })}
            </div>}
          </div>
        )}
        {/* 2. Body Container */}
        <div className="misa-voucher-body">
          {/* Master Form Section */}
          <div className="misa-voucher-master-grid">
            {/* Left Section: Master Form Details */}
            <div className="misa-voucher-master-left">
              {isBank && !isReceipt ? (
                /* CHI TIỀN GỬI / ỦY NHIỆM CHI (MATCHING SCREENSHOTS 1, 2, 3, 4, 5) */
                <>
                  {/* Row 1: Tài khoản chi [+] [v] | Tên ngân hàng chi */}
                  <div className="misa-voucher-row-main">
                    <div className="misa-voucher-field" style={{ width: 240, flexShrink: 0 }}>
                      <label>Tài khoản chi</label>
                      <div className="misa-voucher-combo-input">
                        <input
                          type="text"
                          className="misa-voucher-input"
                          value={bankAccount}
                          readOnly={!isReceipt && isBank}
                          onChange={(e) => setBankAccount(e.target.value)}
                          placeholder=""
                        />
                        <div className="misa-voucher-combo-actions">
                          <button
                            type="button"
                            className="misa-voucher-mini-btn"
                            title="Thêm tài khoản"
                            onClick={()=>setQuickDirectory("Tài khoản ngân hàng")}
                          >
                            <Plus size={13} style={{ strokeWidth: 2.5 }} />
                          </button>
                          <button
                            type="button"
                            className="misa-voucher-mini-btn"
                            title="Chọn tài khoản"
                            onClick={() => setShowBankAccountDropdown(!showBankAccountDropdown)}
                          >
                            <ChevronDown size={13} />
                          </button>
                        </div>
                        {showBankAccountDropdown && <BankAccountChoiceTable rows={!isReceipt && isBank
                          ? (bankPaymentCatalog.profiles || []).filter(row => (bankPaymentCatalog.bankAccounts || []).some(account =>
                              account.id === row.account && account.status === "ACTIVE" && account.allow_payment))
                            .map(row => ({ account: row.account_number, name: row.bank_name }))
                          : SAMPLE_BANK_ACCOUNTS} onSelect={b=>{if (!isReceipt && isBank) {
                            const selected = (bankPaymentCatalog.profiles || []).find(row => row.account_number === b.account);
                            setBankProfileId(selected?.id || "");
                          } else {setBankAccount(b.account);setBankName(b.name);}setShowBankAccountDropdown(false);}}/>}
                      </div>
                    </div>

                    <div className="misa-voucher-field" style={{ flex: 1 }}>
                      <label style={{ visibility: "hidden" }}>Tên ngân hàng chi</label>
                      <input
                        type="text"
                        className="misa-voucher-input"
                        value={bankName}
                        readOnly={!isReceipt && isBank}
                        onChange={(e) => setBankName(e.target.value)}
                        placeholder=""
                      />
                    </div>
                  </div>

                  {/* Row 2: Mã nhà cung cấp / đối tượng / nhân viên [+] [v] [($)] | Tên */}
                  <div className="misa-voucher-row-main">
                    <div className="misa-voucher-field" style={{ width: currentType.hasCustomerDebtBtn ? 280 : 240, flexShrink: 0 }}>
                      <label>{currentType.codeLabel || "Mã đối tượng"}</label>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <div className="misa-voucher-combo-input" style={{ flex: 1, position: "relative" }}>
                          <input
                            type="text"
                            className="misa-voucher-input"
                            onKeyDown={event=>{if(event.key==="F3"){event.preventDefault();setPartnerSearch(true);setShowPartnerDropdown(true);}}}
                            value={partnerCode}
                            onChange={(e) => handlePartnerCodeChange(e.target.value)}
                          />
                          <div className="misa-voucher-combo-actions">
                            <button
                              type="button"
                              className="misa-voucher-mini-btn"
                              title="Thêm nhanh"
                              onClick={()=>setQuickDirectory(currentType.codeLabel?.includes("khách")?"Khách hàng":currentType.codeLabel?.includes("nhân")?"Nhân viên":"Nhà cung cấp")}
                            >
                              <Plus size={13} style={{ strokeWidth: 2.5 }} />
                            </button>
                            <button
                              type="button"
                              className="misa-voucher-mini-btn"
                              title="Chọn từ danh mục"
                              onClick={() => setShowPartnerDropdown(!showPartnerDropdown)}
                            >
                              <ChevronDown size={13} />
                            </button>
                          </div>

                          {showPartnerDropdown && <VoucherChoiceTable kind="partner" openSearch={partnerSearch} onSearchClose={()=>{setPartnerSearch(false);setShowPartnerDropdown(false);}} onNew={name=>setQuickDirectory(name||(currentType.codeLabel?.includes("khách")?"Khách hàng":currentType.codeLabel?.includes("nhân")?"Nhân viên":"Nhà cung cấp"))} rows={receiptPartnerChoices} onSelect={p=>{handleSelectPartner(p);if(p.bankAccount)setReceiverAccount(p.bankAccount);if(p.bankName)setReceiverBank(p.bankName);}}/>}
                        </div>

                        {currentType.hasCustomerDebtBtn && (
                          <button
                            type="button"
                            className="misa-voucher-circle-icon-btn"
                            title="Tra cứu công nợ nhà cung cấp"
                            onClick={() => setShowDebtLookupModal(true)}
                          >
                            $
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="misa-voucher-field" style={{ flex: 1 }}>
                      <label>{currentType.nameLabel || "Tên đối tượng"}</label>
                      <input
                        type="text"
                        className="misa-voucher-input"
                        value={partnerName}
                        onChange={(e) => handlePartnerNameChange(e.target.value)}
                      />
                    </div>
                  </div>

                  {/* Row 3: Địa chỉ full width */}
                  <div className="misa-voucher-row-main">
                    <div className="misa-voucher-field" style={{ flex: 1 }}>
                      <label>{currentType.addressLabel || "Địa chỉ"}</label>
                      <input
                        type="text"
                        className="misa-voucher-input"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                      />
                    </div>
                  </div>

                  {/* Row 4: Tài khoản nhận [v] | Ngân hàng nhận */}
                  <div className="misa-voucher-row-main">
                    <div className="misa-voucher-field" style={{ width: 240, flexShrink: 0 }}>
                      <label>Tài khoản nhận</label>
                      <div className="misa-voucher-combo-input">
                        <input
                          type="text"
                          className="misa-voucher-input"
                          value={receiverAccount}
                          onChange={(e) => setReceiverAccount(e.target.value)}
                          placeholder=""
                        />
                        <div className="misa-voucher-combo-actions">
                          <button
                            type="button"
                            className="misa-voucher-mini-btn"
                            title="Chọn tài khoản nhận"
                            onClick={() => setShowReceiverDropdown(!showReceiverDropdown)}
                          >
                            <ChevronDown size={13} />
                          </button>
                        </div>
                        {showReceiverDropdown && <BankAccountChoiceTable rows={!isReceipt && isBank ? beneficiaryChoices : SAMPLE_BENEFICIARY_ACCOUNTS}
                          onSelect={b=>{setReceiverAccount(b.account);if (!isReceipt && isBank) {
                            const selected = (bankPaymentCatalog.partyBankAccounts || []).find(row => row.party === selectedBankParty?.id && row.account_number === b.account);
                            setReceiverBank((bankPaymentCatalog.banks || []).find(row => row.id === selected?.bank)?.name || "");
                            setReceiverBankBranch(selected?.branch_name || "");
                          } else setReceiverBank(b.name);setShowReceiverDropdown(false);}}/>}
                      </div>
                    </div>

                    <div className="misa-voucher-field" style={{ flex: 1 }}>
                      <label style={{ visibility: "hidden" }}>Ngân hàng nhận</label>
                      <input
                        type="text"
                        className="misa-voucher-input"
                        value={receiverBank}
                        onChange={(e) => setReceiverBank(e.target.value)}
                        placeholder=""
                      />
                    </div>
                  </div>

                  {/* Row 5 & 6: Nhân viên + Nội dung thanh toán OR Nội dung thanh toán + Tham chiếu */}
                  {currentType.hasEmployeeField ? (
                    <>
                      <div className="misa-voucher-row-main">
                        <div className="misa-voucher-field" style={{ width: 240, flexShrink: 0 }}>
                          <label>Nhân viên</label>
                          <div className="misa-voucher-combo-input">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              value={employee}
                              onChange={(e) => setEmployee(e.target.value)}
                            />
                            <div className="misa-voucher-combo-actions">
                              <button
                                type="button"
                                className="misa-voucher-mini-btn"
                                title="Thêm nhân viên"
                                onClick={()=>setQuickDirectory("Nhân viên")}
                              >
                                <Plus size={13} style={{ strokeWidth: 2.5 }} />
                              </button>
                              <button
                                type="button"
                                className="misa-voucher-mini-btn"
                                title="Chọn nhân viên"
                                onClick={() => setShowEmployeeDropdown(!showEmployeeDropdown)}
                              >
                                <ChevronDown size={13} />
                              </button>
                            </div>
                            {showEmployeeDropdown && <VoucherChoiceTable kind="employee" rows={SAMPLE_EMPLOYEES} onSelect={emp=>{setEmployee(`${emp.code} - ${emp.name}`);setShowEmployeeDropdown(false);}}/>}
                          </div>
                        </div>

                        <div className="misa-voucher-field" style={{ flex: 1 }}>
                          <label>Nội dung thanh toán</label>
                          <div className="misa-voucher-reason-wrapper">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              aria-label={isReceipt ? "Lý do nộp" : "Nội dung thanh toán"}
                              value={reason}
                              onChange={(e) => {
                                setReason(e.target.value);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", e.target.value);
                                }
                              }}
                            />
                            <div
                              className="misa-voucher-ava-spark"
                              title="Điền nhanh lý do chuẩn"
                              onClick={() => {
                                const suggested = partnerName
                                  ? `${currentType.defaultReason} ${partnerName}`
                                  : currentType.defaultReason;
                                setReason(suggested);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", suggested);
                                }
                              }}
                            >
                              <Sparkles size={14} />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Row 6: Tham chiếu ... */}
                      <div style={{ paddingTop: 2, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                        <a
                          href="#ref"
                          className="misa-voucher-ref-link"
                          onClick={(e) => {
                            e.preventDefault();
                            setShowRefModal(true);
                          }}
                        >
                          <span>Tham chiếu</span>
                          <span style={{ letterSpacing: 2, marginLeft: 4 }}>...</span>
                        </a>
                        {currentType.id === "other_expense" && (
                          <label style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 13, cursor: "pointer", color: "#334155" }}>
                            <input type="checkbox" checked={bankFee} onChange={event => setBankFee(event.target.checked)} />
                            Phí ngân hàng tự trích
                          </label>
                        )}
                      </div>
                    </>
                  ) : currentType.hasYearField ? (
                    <>
                      <div className="misa-voucher-row-main">
                        <div className="misa-voucher-field" style={{ flex: 1 }}>
                          <label>Nội dung thanh toán</label>
                          <div className="misa-voucher-reason-wrapper">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              aria-label={isReceipt ? "Lý do nộp" : "Nội dung thanh toán"}
                              value={reason}
                              onChange={(e) => {
                                setReason(e.target.value);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", e.target.value);
                                }
                              }}
                            />
                            <div
                              className="misa-voucher-ava-spark"
                              title="Điền nhanh lý do chuẩn"
                              onClick={() => {
                                const suggested = partnerName
                                  ? `${currentType.defaultReason} ${partnerName}`
                                  : currentType.defaultReason;
                                setReason(suggested);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", suggested);
                                }
                              }}
                            >
                              <Sparkles size={14} />
                            </div>
                          </div>
                        </div>

                        <div className="misa-voucher-field" style={{ width: 85, flexShrink: 0 }}>
                          <label>Năm</label>
                          <input
                            type="number"
                            className="misa-voucher-input"
                            value={taxYear}
                            onChange={(e) => setTaxYear(Number(e.target.value) || 2026)}
                            style={{ textAlign: "center" }}
                          />
                        </div>
                      </div>

                      {/* Row 6: Tham chiếu ... */}
                      <div style={{ paddingTop: 2, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                        <a
                          href="#ref"
                          className="misa-voucher-ref-link"
                          onClick={(e) => {
                            e.preventDefault();
                            setShowRefModal(true);
                          }}
                        >
                          <span>Tham chiếu</span>
                          <span style={{ letterSpacing: 2, marginLeft: 4 }}>...</span>
                        </a>
                        {currentType.id === "other_expense" && (
                          <label style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 13, cursor: "pointer", color: "#334155" }}>
                            <input type="checkbox" checked={bankFee} onChange={event => setBankFee(event.target.checked)} />
                            Phí ngân hàng tự trích
                          </label>
                        )}
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="misa-voucher-row-main">
                        <div className="misa-voucher-field" style={{ flex: 1 }}>
                          <label>Nội dung thanh toán</label>
                          <div className="misa-voucher-reason-wrapper">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              aria-label={isReceipt ? "Lý do nộp" : "Nội dung thanh toán"}
                              value={reason}
                              onChange={(e) => {
                                setReason(e.target.value);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", e.target.value);
                                }
                              }}
                            />
                            <div
                              className="misa-voucher-ava-spark"
                              title="Điền nhanh lý do chuẩn"
                              onClick={() => {
                                const suggested = partnerName
                                  ? `${currentType.defaultReason} ${partnerName}`
                                  : currentType.defaultReason;
                                setReason(suggested);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", suggested);
                                }
                              }}
                            >
                              <Sparkles size={14} />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Row 6: Tham chiếu ... */}
                      <div style={{ paddingTop: 2, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                        <a
                          href="#ref"
                          className="misa-voucher-ref-link"
                          onClick={(e) => {
                            e.preventDefault();
                            setShowRefModal(true);
                          }}
                        >
                          <span>Tham chiếu</span>
                          <span style={{ letterSpacing: 2, marginLeft: 4 }}>...</span>
                        </a>
                        {currentType.id === "other_expense" && (
                          <label style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 13, cursor: "pointer", color: "#334155" }}>
                            <input type="checkbox" checked={bankFee} onChange={event => setBankFee(event.target.checked)} />
                            Phí ngân hàng tự trích
                          </label>
                        )}
                      </div>
                    </>
                  )}
                </>
              ) : isReceipt ? (
                /* PHIẾU THU / THU TIỀN GỬI (MATCHING SCREENSHOT 1) */
                <>
                  {/* Row 1: Code and Name */}
                  <div className="misa-voucher-row-main">
                    <div className="misa-voucher-field" style={{ width: currentType.hasCustomerDebtBtn ? 280 : 240, flexShrink: 0 }}>
                      <label>{currentType.codeLabel || (isReceipt ? "Mã đối tượng" : "Mã nhà cung cấp")}</label>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <div className="misa-voucher-combo-input" style={{ flex: 1, position: "relative" }}>
                          <input
                            type="text"
                            className="misa-voucher-input"
                            onKeyDown={event=>{if(event.key==="F3"){event.preventDefault();setPartnerSearch(true);setShowPartnerDropdown(true);}}}
                            value={partnerCode}
                            onChange={(e) => handlePartnerCodeChange(e.target.value)}
                          />
                          <div className="misa-voucher-combo-actions">
                            <button
                              type="button"
                              className="misa-voucher-mini-btn"
                              title="Thêm nhanh"
                              onClick={()=>setQuickDirectory(currentType.codeLabel?.includes("khách")?"Khách hàng":currentType.codeLabel?.includes("nhân")?"Nhân viên":"Nhà cung cấp")}
                            >
                              <Plus size={13} style={{ strokeWidth: 2.5 }} />
                            </button>
                            <button
                              type="button"
                              className="misa-voucher-mini-btn"
                              title="Chọn từ danh mục"
                              onClick={() => setShowPartnerDropdown(!showPartnerDropdown)}
                            >
                              <ChevronDown size={13} />
                            </button>
                          </div>

                          {showPartnerDropdown && <VoucherChoiceTable kind="partner" openSearch={partnerSearch} onSearchClose={()=>{setPartnerSearch(false);setShowPartnerDropdown(false);}} onNew={name=>setQuickDirectory(name||(currentType.codeLabel?.includes("khách")?"Khách hàng":currentType.codeLabel?.includes("nhân")?"Nhân viên":"Nhà cung cấp"))} rows={receiptPartnerChoices} onSelect={p=>{handleSelectPartner(p);if(p.bankAccount)setReceiverAccount(p.bankAccount);if(p.bankName)setReceiverBank(p.bankName);}}/>}
                        </div>

                        {currentType.hasCustomerDebtBtn && (
                          <button
                            type="button"
                            className="misa-voucher-circle-icon-btn"
                            title={isReceipt ? "Tra cứu công nợ khách hàng" : "Tra cứu công nợ nhà cung cấp"}
                            onClick={() => setShowDebtLookupModal(true)}
                          >
                            $
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="misa-voucher-field" style={{ flex: 1 }}>
                      <label>{currentType.nameLabel || (isReceipt ? "Tên đối tượng" : "Tên nhà cung cấp")}</label>
                      <input
                        type="text"
                        className="misa-voucher-input"
                        value={partnerName}
                        onChange={(e) => handlePartnerNameChange(e.target.value)}
                      />
                    </div>
                  </div>

                  {isBank ? (
                    /* THU TIỀN GỬI NTTK (MATCHING SCREENSHOT 1 & SCREENSHOT 2) */
                    <>
                      {/* Row 2: Địa chỉ full-width */}
                      <div className="misa-voucher-row-main">
                        <div className="misa-voucher-field" style={{ flex: 1 }}>
                          <label>{currentType.addressLabel || "Địa chỉ"}</label>
                          <input
                            type="text"
                            className="misa-voucher-input"
                            value={address}
                            onChange={(e) => setAddress(e.target.value)}
                          />
                        </div>
                      </div>

                      {/* Row 3: Nộp vào tài khoản [+] [v] | Tên ngân hàng */}
                      <div className="misa-voucher-row-main">
                        <div className="misa-voucher-field" style={{ width: 240, flexShrink: 0 }}>
                          <label>Nộp vào tài khoản</label>
                          <div className="misa-voucher-combo-input">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              value={bankAccount}
                              onChange={(e) => setBankAccount(e.target.value)}
                              placeholder=""
                            />
                            <div className="misa-voucher-combo-actions">
                              <button
                                type="button"
                                className="misa-voucher-mini-btn"
                                title="Thêm tài khoản"
                                onClick={()=>setQuickDirectory("Tài khoản ngân hàng")}
                              >
                                <Plus size={13} style={{ strokeWidth: 2.5 }} />
                              </button>
                              <button
                                type="button"
                                className="misa-voucher-mini-btn"
                                title="Chọn tài khoản"
                                onClick={() => setShowBankAccountDropdown(!showBankAccountDropdown)}
                              >
                                <ChevronDown size={13} />
                              </button>
                            </div>

                            {showBankAccountDropdown && <BankAccountChoiceTable rows={SAMPLE_BANK_ACCOUNTS} onSelect={b=>{setBankAccount(b.account);setBankName(b.name);setShowBankAccountDropdown(false);}}/>}
                          </div>
                        </div>

                        <div className="misa-voucher-field" style={{ flex: 1 }}>
                          <label style={{ visibility: "hidden" }}>Tên ngân hàng</label>
                          <input
                            type="text"
                            className="misa-voucher-input"
                            value={bankName}
                            onChange={(e) => setBankName(e.target.value)}
                            placeholder=""
                          />
                        </div>
                      </div>

                      {/* Row 4: Nhân viên thu nợ (nếu có) + Lý do thu */}
                      <div className="misa-voucher-row-main">
                        {currentType.hasEmployeeField && (
                          <div className="misa-voucher-field" style={{ width: 240, flexShrink: 0 }}>
                            <label>{currentType.employeeLabel || "Nhân viên thu nợ"}</label>
                            <div className="misa-voucher-combo-input">
                              <input
                                type="text"
                                className="misa-voucher-input"
                                value={employee}
                                onChange={(e) => setEmployee(e.target.value)}
                              />
                              <div className="misa-voucher-combo-actions">
                                <button
                                  type="button"
                                  className="misa-voucher-mini-btn"
                                  title="Thêm nhân viên"
                                  onClick={()=>setQuickDirectory("Nhân viên")}
                                >
                                  <Plus size={13} style={{ strokeWidth: 2.5 }} />
                                </button>
                                <button
                                  type="button"
                                  className="misa-voucher-mini-btn"
                                  title="Chọn nhân viên"
                                  onClick={() => setShowEmployeeDropdown(!showEmployeeDropdown)}
                                >
                                  <ChevronDown size={13} />
                                </button>
                              </div>

                              {showEmployeeDropdown && <VoucherChoiceTable kind="employee" rows={SAMPLE_EMPLOYEES} onSelect={emp=>{setEmployee(`${emp.code} - ${emp.name}`);setShowEmployeeDropdown(false);}}/>}
                            </div>
                          </div>
                        )}

                        <div className="misa-voucher-field" style={{ flex: 1 }}>
                          <label>Lý do thu</label>
                          <div className="misa-voucher-reason-wrapper">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              aria-label={isReceipt ? "Lý do nộp" : "Nội dung thanh toán"}
                              value={reason}
                              onChange={(e) => {
                                setReason(e.target.value);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", e.target.value);
                                }
                              }}
                            />
                            <div
                              className="misa-voucher-ava-spark"
                              title="Điền nhanh lý do chuẩn"
                              onClick={() => {
                                const suggested = partnerName
                                  ? `${currentType.defaultReason}${partnerName}`
                                  : currentType.defaultReason;
                                setReason(suggested);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", suggested);
                                }
                              }}
                            >
                              <Sparkles size={14} />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Row 5: Tham chiếu ... */}
                      <div style={{ paddingTop: 2 }}>
                        <a
                          href="#ref"
                          className="misa-voucher-ref-link"
                          onClick={(e) => {
                            e.preventDefault();
                            setShowRefModal(true);
                          }}
                        >
                          <span>Tham chiếu</span>
                          <span style={{ letterSpacing: 2, marginLeft: 4 }}>...</span>
                        </a>
                      </div>
                    </>
                  ) : (
                    /* CASH RECEIPT (Phiếu thu tiền mặt) */
                    <>
                      {/* Row 2: Người nộp + Địa chỉ */}
                      <div className="misa-voucher-row-main">
                        <div className="misa-voucher-field" style={{ width: 240, flexShrink: 0 }}>
                          <label>{currentType.personLabel || "Người nộp"}</label>
                          <input
                            type="text"
                            className="misa-voucher-input"
                            value={person}
                            onChange={(e) => setPerson(e.target.value)}
                          />
                        </div>

                        <div className="misa-voucher-field" style={{ flex: 1 }}>
                          <label>{currentType.addressLabel || "Địa chỉ"}</label>
                          <input
                            type="text"
                            className="misa-voucher-input"
                            value={address}
                            onChange={(e) => setAddress(e.target.value)}
                          />
                        </div>
                      </div>

                      {/* Row 3: Nhân viên (nếu có) + Lý do nộp + Kèm theo [Số lượng] chứng từ gốc */}
                      <div className="misa-voucher-row-main">
                        {currentType.hasEmployeeField && (
                          <div className="misa-voucher-field" style={{ width: 240, flexShrink: 0 }}>
                            <label>Nhân viên</label>
                            <div className="misa-voucher-combo-input">
                              <input
                                type="text"
                                className="misa-voucher-input"
                                value={employee}
                                onChange={(e) => setEmployee(e.target.value)}
                              />
                              <div className="misa-voucher-combo-actions">
                                <button
                                  type="button"
                                  className="misa-voucher-mini-btn"
                                  title="Thêm nhân viên"
                                  onClick={()=>setQuickDirectory("Nhân viên")}
                                >
                                  <Plus size={13} style={{ strokeWidth: 2.5 }} />
                                </button>
                                <button
                                  type="button"
                                  className="misa-voucher-mini-btn"
                                  title="Chọn nhân viên"
                                  onClick={() => setShowEmployeeDropdown(!showEmployeeDropdown)}
                                >
                                  <ChevronDown size={13} />
                                </button>
                              </div>

                              {showEmployeeDropdown && <VoucherChoiceTable kind="employee" rows={SAMPLE_EMPLOYEES} onSelect={emp=>{setEmployee(`${emp.code} - ${emp.name}`);setShowEmployeeDropdown(false);}}/>}
                            </div>
                          </div>
                        )}

                        <div className="misa-voucher-field" style={{ flex: 1 }}>
                          <label>Lý do nộp</label>
                          <div className="misa-voucher-reason-wrapper">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              aria-label={isReceipt ? "Lý do nộp" : "Nội dung thanh toán"}
                              value={reason}
                              onChange={(e) => {
                                setReason(e.target.value);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", e.target.value);
                                }
                              }}
                            />
                            <div
                              className="misa-voucher-ava-spark"
                              title="Điền nhanh lý do chuẩn"
                              onClick={() => {
                                const suggested = partnerName
                                  ? `${currentType.defaultReason.trim()} ${partnerName}`
                                  : currentType.defaultReason;
                                setReason(suggested);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", suggested);
                                }
                              }}
                            >
                              <Sparkles size={14} />
                            </div>
                          </div>
                        </div>

                        <div className="misa-voucher-field" style={{ width: 240, flexShrink: 0 }}>
                          <label>Kèm theo</label>
                          <div className="misa-voucher-doc-count">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              value={originalDocsCount}
                              onChange={(e) => setOriginalDocsCount(e.target.value)}
                              placeholder="Số lượng"
                            />
                            <span>chứng từ gốc</span>
                          </div>
                        </div>
                      </div>

                      {/* Row 4: Tham chiếu */}
                      <div style={{ paddingTop: 2 }}>
                        <a
                          href="#ref"
                          className="misa-voucher-ref-link"
                          onClick={(e) => {
                            e.preventDefault();
                            setShowRefModal(true);
                          }}
                        >
                          <span>Tham chiếu</span>
                          <span style={{ letterSpacing: 2, marginLeft: 4 }}>--</span>
                        </a>
                      </div>
                    </>
                  )}
                </>
              ) : (
                /* PHIẾU CHI TIỀN MẶT LAYOUT */
                <>
                  <div className="misa-voucher-row-main">
                    <div className="misa-voucher-field" style={{ width: currentType.hasCustomerDebtBtn ? 280 : 240, flexShrink: 0 }}>
                      <label>{currentType.codeLabel}</label>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <div className="misa-voucher-combo-input" style={{ flex: 1, position: "relative" }}>
                          <input
                            type="text"
                            className="misa-voucher-input"
                            onKeyDown={event=>{if(event.key==="F3"){event.preventDefault();setPartnerSearch(true);setShowPartnerDropdown(true);}}}
                            value={partnerCode}
                            onChange={(e) => handlePartnerCodeChange(e.target.value)}
                          />
                          <div className="misa-voucher-combo-actions">
                            <button
                              type="button"
                              className="misa-voucher-mini-btn"
                              title="Thêm nhanh"
                              onClick={()=>setQuickDirectory(currentType.codeLabel?.includes("khách")?"Khách hàng":currentType.codeLabel?.includes("nhân")?"Nhân viên":"Nhà cung cấp")}
                            >
                              <Plus size={13} style={{ strokeWidth: 2.5 }} />
                            </button>
                            <button
                              type="button"
                              className="misa-voucher-mini-btn"
                              title="Chọn từ danh mục"
                              onClick={() => setShowPartnerDropdown(!showPartnerDropdown)}
                            >
                              <ChevronDown size={13} />
                            </button>
                          </div>

                          {showPartnerDropdown && <VoucherChoiceTable kind="partner" openSearch={partnerSearch} onSearchClose={()=>{setPartnerSearch(false);setShowPartnerDropdown(false);}} onNew={name=>setQuickDirectory(name||(currentType.codeLabel?.includes("khách")?"Khách hàng":currentType.codeLabel?.includes("nhân")?"Nhân viên":"Nhà cung cấp"))} rows={receiptPartnerChoices} onSelect={p=>{handleSelectPartner(p);if(p.bankAccount)setReceiverAccount(p.bankAccount);if(p.bankName)setReceiverBank(p.bankName);}}/>}
                        </div>

                        {currentType.hasCustomerDebtBtn && (
                          <button
                            type="button"
                            className="misa-voucher-circle-icon-btn"
                            title="Tra cứu công nợ nhà cung cấp"
                            onClick={() => setShowDebtLookupModal(true)}
                          >
                            $
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="misa-voucher-field" style={{ flex: 1 }}>
                      <label>{currentType.nameLabel}</label>
                      <input
                        type="text"
                        className="misa-voucher-input"
                        value={partnerName}
                        onChange={(e) => handlePartnerNameChange(e.target.value)}
                      />
                    </div>
                  </div>

                  {/* Row 2: Address */}
                  <div className="misa-voucher-row-main">
                    <div className="misa-voucher-field" style={{ width:240 }}>
                      <label>Người nhận</label>
                      <input aria-label="Người nhận" className="misa-voucher-input" value={person} onChange={event=>setPerson(event.target.value)}/>
                    </div>
                    <div className="misa-voucher-field" style={{ flex: 1 }}>
                      <label>{currentType.addressLabel || "Địa chỉ"}</label>
                      <input
                        type="text"
                        className="misa-voucher-input"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                      />
                    </div>
                  </div>

                  {currentType.layoutType === "payment_supplier" ? (
                    /* PHIẾU CHI TYPE 1: Row 3 Lý do chi (full-width), Row 4 Nhân viên + Kèm theo, Row 5 Tham chiếu */
                    <>
                      <div className="misa-voucher-row-main">
                        <div className="misa-voucher-field" style={{ flex: 1 }}>
                          <label>Lý do chi</label>
                          <div className="misa-voucher-reason-wrapper">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              aria-label={isReceipt ? "Lý do nộp" : "Nội dung thanh toán"}
                              value={reason}
                              onChange={(e) => {
                                setReason(e.target.value);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", e.target.value);
                                }
                              }}
                            />
                            <div
                              className="misa-voucher-ava-spark"
                              title="Điền nhanh lý do chuẩn"
                              onClick={() => {
                                const suggested = partnerName
                                  ? `${currentType.defaultReason} ${partnerName}`
                                  : currentType.defaultReason;
                                setReason(suggested);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", suggested);
                                }
                              }}
                            >
                              <Sparkles size={14} />
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="misa-voucher-row-main">
                        <div className="misa-voucher-field" style={{ width: 240, flexShrink: 0 }}>
                          <label>Nhân viên</label>
                          <div className="misa-voucher-combo-input">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              value={employee}
                              onChange={(e) => setEmployee(e.target.value)}
                            />
                            <div className="misa-voucher-combo-actions">
                              <button
                                type="button"
                                className="misa-voucher-mini-btn"
                                title="Thêm nhân viên"
                                onClick={()=>setQuickDirectory("Nhân viên")}
                              >
                                <Plus size={13} style={{ strokeWidth: 2.5 }} />
                              </button>
                              <button
                                type="button"
                                className="misa-voucher-mini-btn"
                                title="Chọn nhân viên"
                                onClick={() => setEmployee("NV0005 - Hoàng Thiên Bảo")}
                              >
                                <ChevronDown size={13} />
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="misa-voucher-field" style={{ width: 210, flexShrink: 0 }}>
                          <label>Kèm theo</label>
                          <div className="misa-voucher-doc-count">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              value={originalDocsCount}
                              onChange={(e) => setOriginalDocsCount(e.target.value)}
                              placeholder="Số lượng"
                            />
                            <span>chứng từ gốc</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <a
                          href="#ref"
                          className="misa-voucher-ref-link"
                          onClick={(e) => {
                            e.preventDefault();
                            setShowRefModal(true);
                          }}
                        >
                          <span>Tham chiếu</span>
                          <span style={{ letterSpacing: 2 }}>...</span>
                        </a>
                      </div>
                    </>
                  ) : (
                    /* PHIẾU CHI TYPE 2, 3, 4, 5: Row 3 Lý do chi + Kèm theo, Row 4 Tham chiếu */
                    <>
                      <div className="misa-voucher-row-main">
                        <div className="misa-voucher-field" style={{ flex: 1 }}>
                          <label>Lý do chi</label>
                          <div className="misa-voucher-reason-wrapper">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              aria-label={isReceipt ? "Lý do nộp" : "Nội dung thanh toán"}
                              value={reason}
                              onChange={(e) => {
                                setReason(e.target.value);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", e.target.value);
                                }
                              }}
                            />
                            <div
                              className="misa-voucher-ava-spark"
                              title="Điền nhanh lý do chuẩn"
                              onClick={() => {
                                const suggested = partnerName
                                  ? `${currentType.defaultReason} ${partnerName}`
                                  : currentType.defaultReason;
                                setReason(suggested);
                                if (rows.length > 0) {
                                  handleUpdateRow(rows[0].id, "description", suggested);
                                }
                              }}
                            >
                              <Sparkles size={14} />
                            </div>
                          </div>
                        </div>

                        {currentType.hasYearField && (
                          <div className="misa-voucher-field" style={{ width: 85, flexShrink: 0 }}>
                            <label>Năm</label>
                            <input
                              type="number"
                              className="misa-voucher-input"
                              value={taxYear}
                              onChange={(e) => setTaxYear(Number(e.target.value) || 2026)}
                              style={{ textAlign: "center" }}
                            />
                          </div>
                        )}

                        <div className="misa-voucher-field" style={{ width: 210, flexShrink: 0 }}>
                          <label>Kèm theo</label>
                          <div className="misa-voucher-doc-count">
                            <input
                              type="text"
                              className="misa-voucher-input"
                              value={originalDocsCount}
                              onChange={(e) => setOriginalDocsCount(e.target.value)}
                              placeholder="Số lượng"
                            />
                            <span>chứng từ gốc</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <a
                          href="#ref"
                          className="misa-voucher-ref-link"
                          onClick={(e) => {
                            e.preventDefault();
                            setShowRefModal(true);
                          }}
                        >
                          <span>Tham chiếu</span>
                          <span style={{ letterSpacing: 2 }}>...</span>
                        </a>
                      </div>
                    </>
                  )}
                </>
              )}
            </div>

            {/* Right Section: Dates, Total, Voucher Code, Settlement Due Date */}
            <div className="misa-voucher-master-right">
              {/* Total Block (Always at top, full width of column, right-aligned) */}
              <div className="misa-voucher-total-block">
                <div className="misa-voucher-total-label">Tổng tiền</div>
                <div
                  className="misa-voucher-total-number"
                  style={{
                    fontSize: (() => {
                      const len = (totalAmount === 0 ? "0" : formatVND(totalAmount)).length;
                      if (len > 18) return "20px";
                      if (len > 15) return "24px";
                      if (len > 12) return "28px";
                      return "32px";
                    })(),
                  }}
                  title={totalAmount === 0 ? "0" : formatVND(totalAmount)}
                >
                  {totalAmount === 0 ? "0" : formatVND(totalAmount)}
                </div>
              </div>

              {/* Metadata Fields Stack (Full width, stable rows below Total) */}
              <div className="misa-voucher-meta-stack">
                <div className="misa-voucher-meta-row">
                  <label>Ngày hạch toán</label>
                  <div className="misa-voucher-meta-control">
                    <VoucherDateField value={hachToanDate} onChange={setHachToanDate} label="Ngày hạch toán" />
                  </div>
                </div>

                <div className="misa-voucher-meta-row">
                  <label>{isBank ? "Ngày chứng từ" : (isReceipt ? "Ngày phiếu thu" : "Ngày phiếu chi")}</label>
                  <div className="misa-voucher-meta-control">
                    <VoucherDateField
                      value={voucherDate}
                      onChange={setVoucherDate}
                      label={isBank ? "Ngày chứng từ" : (isReceipt ? "Ngày phiếu thu" : "Ngày phiếu chi")}
                    />
                  </div>
                </div>

                <div className="misa-voucher-meta-row">
                  <label>{isBank ? "Số chứng từ" : (isReceipt ? "Số phiếu thu" : "Số phiếu chi")}</label>
                  <div className="misa-voucher-meta-control">
                    <input
                      type="text"
                      className="misa-voucher-input"
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                      aria-label={isBank ? "Số chứng từ" : (isReceipt ? "Số phiếu thu" : "Số phiếu chi")}
                      required
                    />
                  </div>
                </div>

                {currentType.hasSettlementDueDate && (
                  <div className="misa-voucher-meta-row">
                    <label>Hạn quyết toán</label>
                    <div className="misa-voucher-meta-control">
                      <VoucherDateField value={settlementDueDate} onChange={setSettlementDueDate} label="Hạn quyết toán" />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* 3. Detail Section: Tab Bar & Accounting Grid Table */}
          <div className="misa-voucher-details-section" style={{ position: "relative" }}>
            {/* Drawer side toggle button matching MISA assistant */}
            <div
              className="misa-voucher-drawer-handle"
              title="Kiểm tra nhanh định khoản"
              onClick={() => showPendingFeature("Kiểm tra định khoản tự động")}
            >
              <ChevronLeft size={14} />
            </div>

            <div className="misa-voucher-tabs-bar">
              <div
                className={`misa-voucher-tab ${activeTab === "accounting" ? "active" : ""}`}
                onClick={() => setActiveTab("accounting")}
                style={{ cursor: "pointer" }}
              >
                Hạch toán
              </div>

              {currentType.hasTaxDeclarationTab && (
                <div
                  className={`misa-voucher-tab ${activeTab === "tax" ? "active" : ""}`}
                  onClick={() => setActiveTab("tax")}
                  style={{
                    cursor: "pointer",
                    borderBottom: activeTab === "tax" ? "2px solid var(--brand)" : "none",
                    color: activeTab === "tax" ? "var(--brand)" : "#475569",
                    fontWeight: activeTab === "tax" ? 700 : 500,
                  }}
                >
                  Kê khai hóa đơn và hạch toán thuế
                </div>
              )}

              <div className="misa-voucher-tab-tools">
                {currentType.hasTaxDeclarationTab && (
                  <label
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 6,
                      fontSize: 12,
                      color: "#374151",
                      cursor: "pointer",
                      marginRight: 10,
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={batchTaxInvoices}
                      onChange={(e) => setBatchTaxInvoices(e.target.checked)}
                      style={{ accentColor: "var(--brand)" }}
                    />
                    <span>Hạch toán gộp nhiều hóa đơn</span>
                    <HelpCircle size={13} style={{ color: "#9ca3af" }} />
                  </label>
                )}

                <button
                  type="button"
                  className="misa-voucher-ava-pill"
                  onClick={() => {
                    showNotice(
                      `Định khoản mặc định của nghiệp vụ ${currentType.label}: Nợ TK ${currentType.defaultDebit || "(Tùy chọn)"} / Có TK ${currentType.defaultCredit || "(Tùy chọn)"}.\nĐây là gợi ý, chưa phải kết quả kiểm tra tự động; hệ thống kiểm tra khi lưu/ghi sổ.`,
                      "info",
                    );
                  }}
                >
                  <img
                    src="/ava_avatar.jpg"
                    alt="Biểu tượng"
                    style={{ width: 18, height: 18, borderRadius: "50%", objectFit: "cover" }}
                  />
                  <span>Kiểm tra</span>
                  <ChevronDown size={12} />
                </button>
              </div>
            </div>

            {/* Grid Table */}
            {activeTab === "accounting" ? (
              <div className="misa-voucher-table-wrapper">
                <table className="misa-voucher-table">
                  <thead>
                    <tr>
                      <th style={{ width: 40, textAlign: "center" }}>#</th>
                      <th>Diễn giải</th>
                      {showAccount && (
                        <th style={{ width: 75, textAlign: "center" }}>TK Nợ</th>
                      )}
                      {showAccount && (
                        <th style={{ width: 75, textAlign: "center" }}>TK Có</th>
                      )}
                      <th style={{ width: 130, textAlign: "right" }}>Số tiền</th>
                      {currentType.extraColumns?.includes("bankAccount") && (
                        <th style={{ width: 130 }}>TK ngân hàng</th>
                      )}
                      {currentType.extraColumns?.includes("bankName") && (
                        <th style={{ width: 160 }}>Tên ngân hàng</th>
                      )}
                      {currentType.extraColumns?.includes("partnerCode") && (
                        <th style={{ width: 110 }}>{!isBank&&currentType.id==="salary_payment"?"Mã nhân viên":"Đối tượng"}</th>
                      )}
                      {currentType.extraColumns?.includes("partnerName") && (
                        <th style={{ width: 150 }}>{!isBank&&currentType.id==="salary_payment"?"Tên nhân viên":"Tên đối tượng"}</th>
                      )}
                      {currentType.extraColumns?.includes("employeeCode") && (
                        <th style={{ width: 110 }}>{currentType.id==="salary_advance"?"Đối tượng":"Mã nhân viên"}</th>
                      )}
                      {currentType.extraColumns?.includes("employeeName") && (
                        <th style={{ width: 150 }}>{currentType.id==="salary_advance"?"Tên đối tượng":"Tên nhân viên"}</th>
                      )}
                      {currentType.extraColumns?.includes("loanContract") && (
                        <th style={{ width: 140 }}>{!isBank&&currentType.id==="loan_disbursement"?"Khế ước cho vay":"Khế ước đi vay"}</th>
                      )}
                      {currentType.extraColumns?.includes("loanDisbursementContract") && (
                        <th style={{ width: 140 }}>Khế ước cho vay</th>
                      )}
                      <th style={{ width: 40, textAlign: "center" }}></th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((row, idx) => (
                      <tr key={row.id}>
                        <td style={{ textAlign: "center", color: "#64748b" }}>
                          {idx + 1}
                        </td>


                        <td>
                          <input
                            type="text"
                            className="misa-voucher-cell-input"
                            value={row.description}
                            onChange={(e) =>
                              handleUpdateRow(row.id, "description", e.target.value)
                            }
                            placeholder="Diễn giải nghiệp vụ..."
                          />
                        </td>
                        {showAccount && (
                          <td>
                            <LedgerAccountField value={row.debit} onChange={value=>handleUpdateRow(row.id,"debit",value)} label="Tài khoản Nợ"/>
                          </td>
                        )}
                        {showAccount && (
                          <td>
                            <LedgerAccountField value={row.credit} onChange={value=>handleUpdateRow(row.id,"credit",value)} label="Tài khoản Có"/>
                          </td>
                        )}
                        <td>
                          <input
                            type="text"
                            className="misa-voucher-cell-input"
                            style={{ textAlign: "right", fontWeight: 500 }}
                            value={row.amount === 0 ? "0" : formatVND(row.amount)}
                            onChange={(e) => {
                              const raw = parseInt(e.target.value.replace(/\D/g, "") || "0", 10);
                              handleUpdateRow(row.id, "amount", raw);
                            }}
                          />
                        </td>
                        {currentType.extraColumns?.includes("bankAccount") && (
                          <td>
                            <input
                              type="text"
                              className="misa-voucher-cell-input"
                              value={row.bankAccount || ""}
                              onChange={(e) =>
                                handleUpdateRow(row.id, "bankAccount", e.target.value)
                              }
                            />
                          </td>
                        )}
                        {currentType.extraColumns?.includes("bankName") && (
                          <td>
                            <input
                              type="text"
                              className="misa-voucher-cell-input"
                              value={row.bankName || ""}
                              onChange={(e) =>
                                handleUpdateRow(row.id, "bankName", e.target.value)
                              }
                            />
                          </td>
                        )}
                        {currentType.extraColumns?.includes("partnerCode") && (
                          <td>
                            <input
                              type="text"
                              className="misa-voucher-cell-input"
                              value={row.partnerCode || ""}
                              onChange={(e) =>
                                handleUpdateRow(row.id, "partnerCode", e.target.value)
                              }
                            />
                          </td>
                        )}
                        {currentType.extraColumns?.includes("partnerName") && (
                          <td>
                            <input
                              type="text"
                              className="misa-voucher-cell-input"
                              value={row.partnerName || ""}
                              onChange={(e) =>
                                handleUpdateRow(row.id, "partnerName", e.target.value)
                              }
                            />
                          </td>
                        )}
                        {currentType.extraColumns?.includes("employeeCode") && (
                          <td>
                            <input
                              type="text"
                              className="misa-voucher-cell-input"
                              value={row.employeeCode || ""}
                              onChange={(e) =>
                                handleUpdateRow(row.id, "employeeCode", e.target.value)
                              }
                            />
                          </td>
                        )}
                        {currentType.extraColumns?.includes("employeeName") && (
                          <td>
                            <input
                              type="text"
                              className="misa-voucher-cell-input"
                              value={row.employeeName || ""}
                              onChange={(e) =>
                                handleUpdateRow(row.id, "employeeName", e.target.value)
                              }
                            />
                          </td>
                        )}
                        {currentType.extraColumns?.includes("loanContract") && (
                          <td>
                            <input
                              type="text"
                              className="misa-voucher-cell-input"
                              value={row.loanContract || ""}
                              onChange={(e) =>
                                handleUpdateRow(row.id, "loanContract", e.target.value)
                              }
                            />
                          </td>
                        )}
                        {currentType.extraColumns?.includes("loanDisbursementContract") && (
                          <td>
                            <input
                              type="text"
                              className="misa-voucher-cell-input"
                              value={row.loanDisbursementContract || ""}
                              onChange={(e) =>
                                handleUpdateRow(row.id, "loanDisbursementContract", e.target.value)
                              }
                            />
                          </td>
                        )}
                        <td style={{ textAlign: "center" }}>
                          <button
                            type="button"
                            className="misa-voucher-mini-btn"
                            style={{ color: "#ef4444" }}
                            title="Xóa dòng này"
                            onClick={() => handleDeleteRow(row.id)}
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr>
                      <td></td>
                      <td></td>
                      {showAccount && <td></td>}
                      {showAccount && <td></td>}
                      <td style={{ textAlign: "right", fontWeight: 700, color: "#0f172a" }}>
                        {totalAmount === 0 ? "0" : formatVND(totalAmount)}
                      </td>
                      {currentType.extraColumns?.map((col) => (
                        <td key={col}></td>
                      ))}
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            ) : (
              <div className="misa-voucher-table-wrapper">
                <table className="misa-voucher-table">
                  <thead>
                    <tr>
                      <th style={{ width: 40, textAlign: "center" }}>#</th>
<th>Diễn giải thuế</th>
<th style={{ width: 90 }}>Có hóa đơn</th>
<th style={{ width: 85, textAlign: "center" }}>% thuế GTGT</th>
<th style={{ width: 120, textAlign: "right" }}>Tiền thuế GTGT</th>
<th style={{ width: 75, textAlign: "center" }}>TK thuế GTGT</th>
<th style={{ width: 110 }}>Ngày hóa đơn</th>
<th style={{ width: 110 }}>Số hóa đơn</th>
<th style={{ width: 180 }}>Nhóm HHDV mua vào</th>
<th style={{ width: 110 }}>Mã NCC</th>
<th style={{ width: 150 }}>Tên NCC</th>
<th style={{ width: 120 }}>Mã số thuế NCC</th>
<th style={{ width: 100 }}>Ký hiệu HĐ</th>
<th style={{ width: 130, textAlign: "right" }}>Giá trị chưa thuế</th>
<th style={{ width: 40, textAlign: "center" }}></th>
                    </tr>
                  </thead>
                  <tbody>
                    {taxRows.map((tr, idx) => (
                      <tr key={tr.id}>
                        <td style={{ textAlign: "center", color: "#64748b" }}>
                          {idx + 1}
                        </td>
<td>
                          <input
                            type="text"
                            className="misa-voucher-cell-input"
                            value={tr.itemDescription}
                            onChange={(e) => handleUpdateTaxRow(tr.id, "itemDescription", e.target.value)}
                          />
                        </td>
<td style={{textAlign:"center"}}><input aria-label={`Có hóa đơn dòng ${idx+1}`} type="checkbox" checked={tr.hasInvoice !== false} onChange={e=>handleUpdateTaxRow(tr.id,"hasInvoice",e.target.checked)}/></td>
<td>
                          <select
                            className="misa-voucher-cell-input"
                            style={{ textAlign: "center", cursor: "pointer" }}
                            value={tr.taxRate}
                            onChange={(e) => handleUpdateTaxRow(tr.id, "taxRate", Number(e.target.value))}
                          >
                            <option value={0}>0%</option>
                            <option value={5}>5%</option>
                            <option value={8}>8%</option>
                            <option value={10}>10%</option>
                          </select>
                        </td>
<td>
                          <input
                            type="text"
                            className="misa-voucher-cell-input"
                            style={{ textAlign: "right", fontWeight: 600, color: "var(--brand)" }}
                            value={tr.taxAmount === 0 ? "0" : formatVND(tr.taxAmount)}
                            onChange={(e) => {
                              const raw = parseInt(e.target.value.replace(/\D/g, "") || "0", 10);
                              handleUpdateTaxRow(tr.id, "taxAmount", raw);
                            }}
                          />
                        </td>
<td>
                          <LedgerAccountField
                            value={tr.taxAccount}
                            onChange={(value) => handleUpdateTaxRow(tr.id, "taxAccount", value)}
                            label="TK thuế GTGT"
                          />
                        </td>
<td>
                          <input
                            type="text"
                            className="misa-voucher-cell-input"
                            value={tr.invoiceDate}
                            onChange={(e) => handleUpdateTaxRow(tr.id, "invoiceDate", e.target.value)}
                          />
                        </td>
<td>
                          <input
                            type="text"
                            className="misa-voucher-cell-input"
                            value={tr.invoiceNo}
                            onChange={(e) => handleUpdateTaxRow(tr.id, "invoiceNo", e.target.value)}
                            placeholder="0001234"
                          />
                        </td>
<td><input aria-label={`Nhóm HHDV mua vào dòng ${idx+1}`} className="misa-voucher-cell-input" value={tr.goodsGroup || "1"} onChange={e=>handleUpdateTaxRow(tr.id,"goodsGroup",e.target.value)}/></td>
<td>
                          <input
                            type="text"
                            className="misa-voucher-cell-input"
                            value={tr.partnerCode}
                            onChange={(e) => handleUpdateTaxRow(tr.id, "partnerCode", e.target.value)}
                          />
                        </td>
<td>
                          <input
                            type="text"
                            className="misa-voucher-cell-input"
                            value={tr.partnerName}
                            onChange={(e) => handleUpdateTaxRow(tr.id, "partnerName", e.target.value)}
                          />
                        </td>
<td>
                          <input
                            type="text"
                            className="misa-voucher-cell-input"
                            value={tr.taxCode}
                            onChange={(e) => handleUpdateTaxRow(tr.id, "taxCode", e.target.value)}
                            placeholder="MST..."
                          />
                        </td>
<td>
                          <input
                            type="text"
                            className="misa-voucher-cell-input"
                            value={tr.invoiceSeries}
                            onChange={(e) => handleUpdateTaxRow(tr.id, "invoiceSeries", e.target.value)}
                            placeholder="1C26TAA"
                          />
                        </td>
<td>
                          <input
                            type="text"
                            className="misa-voucher-cell-input"
                            style={{ textAlign: "right", fontWeight: 500 }}
                            value={tr.untaxedAmount === 0 ? "0" : formatVND(tr.untaxedAmount)}
                            onChange={(e) => {
                              const raw = parseInt(e.target.value.replace(/\D/g, "") || "0", 10);
                              handleUpdateTaxRow(tr.id, "untaxedAmount", raw);
                            }}
                          />
                        </td>
<td style={{ textAlign: "center" }}>
                          <button
                            type="button"
                            className="misa-voucher-mini-btn"
                            style={{ color: "#ef4444" }}
                            title="Xóa dòng hóa đơn này"
                            onClick={() => handleDeleteTaxRow(tr.id)}
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr>
                      <td></td>
<td style={{ textAlign: "right", fontWeight: 600 }}>Tổng cộng:</td>
<td></td>
<td></td>
<td style={{ textAlign: "right", fontWeight: 700, color: "var(--brand)" }}>
                        {totalTaxAmount === 0 ? "0" : formatVND(totalTaxAmount)}
                      </td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td style={{ textAlign: "right", fontWeight: 700, color: "#0f172a" }}>
                        {totalUntaxedAmount === 0 ? "0" : formatVND(totalUntaxedAmount)}
                      </td>
<td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}

            {/* Toolbar under table */}
            <div className="misa-voucher-table-toolbar">
              <div className="misa-voucher-toolbar-left">
                <span className="misa-voucher-count-badge">
                  Tổng số: {activeTab === "tax" ? taxRows.length : rows.length}
                </span>

                <button
                  type="button"
                  className="misa-voucher-tool-btn"
                  onClick={activeTab === "tax" ? handleAddTaxRow : handleAddRow}
                >
                  <Plus size={13} style={{ color: "var(--brand)", strokeWidth: 2.5 }} />
                  <span>Thêm dòng</span>
                </button>

                <button
                  type="button"
                  className="misa-voucher-tool-btn"
                  onClick={activeTab === "tax" ? handleClearAllTaxRows : handleClearAllRows}
                >
                  <Trash2 size={13} style={{ color: "#ef4444" }} />
                  <span>Xóa hết dòng</span>
                </button>

                {isReceipt && (
                  <button
                    type="button"
                    className="misa-voucher-tool-btn"
                    onClick={() => {
                      showPendingFeature("Ghi chú chứng từ");
                    }}
                  >
                    <FileText size={13} />
                    <span>Thêm ghi chú</span>
                  </button>
                )}
              </div>

              <div className="misa-voucher-toolbar-right">
                <span>Số dòng/trang</span>
                <select
                  style={{
                    height: 24,
                    border: "1px solid #cbd5e1",
                    borderRadius: 4,
                    fontSize: 12,
                    padding: "0 4px",
                  }}
                  defaultValue="20"
                >
                  <option value="10">10</option>
                  <option value="20">20</option>
                  <option value="50">50</option>
                </select>
                <div
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    color: "#64748b",
                    fontSize: 13,
                    userSelect: "none",
                  }}
                >
                  <span style={{ cursor: "pointer" }}>|&lt;</span>
                  <span style={{ cursor: "pointer" }}>&lt;</span>
                  <span style={{ fontWeight: 700, color: "var(--brand)" }}>1</span>
                  <span style={{ cursor: "pointer" }}>&gt;</span>
                  <span style={{ cursor: "pointer" }}>&gt;|</span>
                </div>
              </div>
            </div>

            {/* 4. Attachment Dropzone */}
            <div className="misa-voucher-attach-zone">
              <div className="misa-voucher-attach-header">
                <Paperclip size={13} style={{ color: "var(--brand)" }} />
                <span style={{ fontWeight: 600, color: "#1e293b" }}>Đính kèm</span>
                <span style={{ color: "#64748b", fontSize: 12, marginLeft: 6 }}>
                  Dung lượng tối đa 5MB
                </span>
              </div>

              <label className="misa-voucher-dropzone" onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();acceptAttachments(Array.from(e.dataTransfer.files));}}>
                <Upload size={16} style={{ color: "#64748b" }} />
                <span>
                  {attachedFiles.length > 0 ? (
                    `Đã đính kèm (${attachedFiles.length}): ${attachedFiles.join(", ")}`
                  ) : (
                    <>
                      <span style={{ color: "#2563eb", cursor: "pointer" }}>Chọn tệp</span> hoặc
                      kéo và thả tệp vào đây
                    </>
                  )}
                </span>
                <input
                  type="file"
                  multiple
                  style={{ display: "none" }}
                  onChange={handleFileUpload}
                />
              </label>
            </div>
          </div>
        </div>

        {/* Quick hint for format 2 matching Screenshot 2 */}
        {currentType.hasQuickAddHint && (
          <div
            style={{
              padding: "4px 20px",
              fontSize: 12,
              color: "#475569",
              background: "#f8fafc",
              borderTop: "1px solid #e2e8f0",
            }}
          >
            <span>F9 - Thêm nhanh</span>
          </div>
        )}

        {/* 5. Footer Action Bar (Matching Screenshot) */}
        <footer className="misa-voucher-footer">
          <div className="misa-voucher-footer-left" style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <label className="misa-voucher-ios-toggle">
              <input
                type="checkbox"
                checked={showAccount}
                onChange={(e) => setShowAccount(e.target.checked)}
              />
              <span className="misa-voucher-ios-slider" />
              <span className="misa-voucher-toggle-text">Hiển thị tài khoản</span>
            </label>
          </div>

          <div className="misa-voucher-footer-right">
            <button
              type="button"
              className="misa-voucher-btn-white"
              onClick={onClose}
            >
              Hủy
            </button>

            <button
              type="button"
              className="misa-voucher-btn-white"
              disabled={saving}
              onClick={() => handleSave(false, false)}
            >
              Lưu
            </button>

            {(!isReceipt || isBank) && <button
              type="button"
              className="misa-voucher-btn-white"
              onClick={() => handleSave(false, true)}
            >
              Lưu và In
            </button>}

            <MisaSaveSplitButton
              defaultMode="save_and_add"
              disabled={saving}
              onSaveAndClose={() => handleSave(false, false)}
              onSaveAndAdd={() => handleSave(true, false)}
              onSaveAndPrint={() => handleSave(false, true)}
            />
          </div>
        </footer>

        {/* Modal Tra cứu công nợ nhà cung cấp ($) */}
        {showDebtLookupModal && (
          <div className="misa-tax-modal-overlay" style={{ zIndex: 10000 }}>
            <div className="misa-tax-modal-window" style={{ maxWidth: 820 }}>
              <header className="misa-tax-modal-header">
                <div>
                  <h2 style={{ fontSize: 16 }}>Tra cứu công nợ nhà cung cấp</h2>
                  <small style={{ color: "#64748b" }}>
                    {partnerCode ? `${partnerCode} - ${partnerName}` : "Tất cả nhà cung cấp"}
                  </small>
                </div>
                <button
                  type="button"
                  className="misa-tax-icon-btn"
                  onClick={() => setShowDebtLookupModal(false)}
                >
                  <X size={18} />
                </button>
              </header>

              <div className="misa-tax-modal-body" style={{ padding: 16 }}>
                <table className="misa-voucher-table" style={{ border: "1px solid #e2e8f0" }}>
                  <thead>
                    <tr>
                      <th style={{ width: 40, textAlign: "center" }}>#</th>
                      <th style={{ width: 110 }}>Số hóa đơn</th>
                      <th style={{ width: 100 }}>Ngày HĐ</th>
                      <th>Nội dung</th>
                      <th style={{ width: 120, textAlign: "right" }}>Số tiền phải trả</th>
                      <th style={{ width: 120, textAlign: "right" }}>Đã trả</th>
                      <th style={{ width: 120, textAlign: "right" }}>Còn phải trả</th>
                      <th style={{ width: 70, textAlign: "center" }}>Chọn</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { no: "HĐ00291", date: "15/09/2026", desc: "Mua máy in và văn phòng phẩm", total: 18500000, paid: 5000000, remain: 13500000 },
                      { no: "HĐ00342", date: "22/09/2026", desc: "Giấy in A4 và mực in văn phòng", total: 9200000, paid: 0, remain: 9200000 },
                      { no: "HĐ00411", date: "28/09/2026", desc: "Bảo dưỡng máy photocopy định kỳ", total: 4500000, paid: 0, remain: 4500000 },
                    ].map((inv, idx) => (
                      <tr key={inv.no}>
                        <td style={{ textAlign: "center", color: "#64748b" }}>{idx + 1}</td>
                        <td><strong>{inv.no}</strong></td>
                        <td>{inv.date}</td>
                        <td>{inv.desc}</td>
                        <td style={{ textAlign: "right" }}>{formatVND(inv.total)}</td>
                        <td style={{ textAlign: "right", color: "var(--brand)" }}>{formatVND(inv.paid)}</td>
                        <td style={{ textAlign: "right", fontWeight: 700, color: "#dc2626" }}>{formatVND(inv.remain)}</td>
                        <td style={{ textAlign: "center" }}>
                          <button
                            type="button"
                            style={{
                              background: "var(--brand)",
                              color: "#ffffff",
                              border: "none",
                              borderRadius: 4,
                              padding: "4px 8px",
                              fontSize: 12,
                              cursor: "pointer",
                            }}
                            onClick={() => {
                              handleUpdateRow(rows[0].id, "amount", inv.remain);
                              handleUpdateRow(rows[0].id, "description", `Thanh toán ${inv.no} - ${inv.desc}`);
                              setShowDebtLookupModal(false);
                            }}
                          >
                            Trả nợ
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <footer className="misa-voucher-footer" style={{ borderTop: "1px solid #e2e8f0" }}>
                <div />
                <div style={{ display: "flex", gap: 8 }}>
                  <button
                    type="button"
                    className="misa-voucher-btn-white"
                    onClick={() => setShowDebtLookupModal(false)}
                  >
                    Đóng
                  </button>
                </div>
              </footer>
            </div>
          </div>
        )}

        {/* Modal Tham chiếu chứng từ */}
        {referenceCodes.length>0&&<p>Tham chiếu: {referenceCodes.join(", ")}</p>}
        <datalist id="voucher-ledger-account-options">{MISA_REPORT_ACCOUNTS.map(account=><option key={account.code} value={account.code}>{account.name}</option>)}</datalist>
        {quickDirectory&&<div style={{position:"fixed",inset:0,zIndex:11000,background:"transparent",overflow:"auto"}}><button style={{position:"fixed",right:16,top:12,zIndex:12000}} onClick={()=>setQuickDirectory(null)}>Đóng thêm nhanh</button>{quickDirectory==="Nhà cung cấp"?<SupplierModal onClose={()=>setQuickDirectory(null)} onSubmit={async data=>{let savedCode=data.code||"";let savedName=data.name||"";if(token&&companyId&&(savedCode||savedName)){try{const rawTax=String(data.taxCode||"").trim().replace(/[\s-]/g,"");const created=await request<any>(`/api/v1/master-data/parties/?company_id=${encodeURIComponent(companyId)}`,token,{method:"POST",body:JSON.stringify({company:companyId,code:savedCode||"AUTO",name:savedName||savedCode,legal_name:savedName||savedCode,party_type:"ORGANIZATION",status:"ACTIVE",tax_code:/^\d{10}(\d{3})?$/.test(rawTax)?rawTax:null})});if(created?.code)savedCode=String(created.code);if(created?.name)savedName=String(created.name);}catch{}}handleSelectPartner({code:savedCode,name:savedName,person:data.contactName||savedName,address:data.address||""});reloadReceiptCatalog();reloadBankPaymentCatalog();setQuickDirectory(null);}}/>:<MisaDirectoryWorkspace key={quickDirectory} initialName={quickDirectory} initialCreate legacy={null} notify={()=>{}} onEditorClose={()=>setQuickDirectory(null)} onEntrySaved={values=>{const code=Object.entries(values).find(([key])=>/^Mã(?! số)(?: |$)|^Số tài khoản/.test(key))?.[1]||values["Mã khách hàng"]||values["Mã nhà cung cấp"]||values["Mã"]||"";const name=Object.entries(values).find(([key])=>/^Tên(?: |$)|^Họ và tên$/.test(key))?.[1]||Object.entries(values).find(([key])=>/^Tên/.test(key))?.[1]||"";const addr=values["Địa chỉ"]||values["Thông tin liên hệ:Địa chỉ"]||"";if(quickDirectory==="Nhân viên")setEmployee(code);else if(quickDirectory==="Tài khoản ngân hàng")setBankAccount(code);else handleSelectPartner({code,name:name||partnerName,person:name||person||partnerName,address:addr||address});reloadReceiptCatalog();reloadBankPaymentCatalog();setQuickDirectory(null);}}/>}</div>}
        {showRefModal&&<CashReferencePicker onClose={()=>setShowRefModal(false)} onSelect={codes=>{setReferenceCodes(codes);setShowRefModal(false);}}/>}
      </div>
    </div>
  );
}


// ----------------------------------------------------------------------
// 4. MODAL "THÊM BẰNG AI" (AVA KẾ TOÁN)
// ----------------------------------------------------------------------
export function AIAssistantModal({
  onClose,
  onApply,
}: {
  onClose: () => void;
  onApply: (data: any) => void;
}) {
  const [prompt, setPrompt] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);

  const samplePrompts = [
    "Thu hoàn ứng sau khi quyết toán tạm ứng cho Hoàng Thiên Bảo số tiền 5 triệu",
    "Chi tiền nộp thuế GTGT tháng 8 số tiền 64.107.650 đồng",
    "Thu tiền bán hàng trực tiếp của Công ty Phúc Long 15.400.000 đồng",
    "Chi tiếp khách và mua quà tặng đối tác 3.250.000 đồng",
  ];

  const handleRun = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      onApply({
        code: "PT00005",
        partner: "Hoàng Thiên Bảo",
        description: prompt || "Thu hoàn ứng sau khi quyết toán tạm ứng cho Hoàng Thiên Bảo",
        amount: 5000000,
        debit: "1111",
        credit: "141",
      });
    }, 800);
  };

  return (
    <div className="misa-tax-modal-overlay">
      <div className="misa-tax-modal-window" style={{ maxWidth: 620 }}>
        <header
          className="misa-tax-modal-header"
          style={{
            background: "linear-gradient(135deg, #eff6ff 0%, #f5f3ff 100%)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div className="misa-ava-avatar">
              <Sparkles size={16} />
            </div>
            <div>
              <h2 style={{ fontSize: 16 }}>Nhập nhanh chứng từ từ tệp đính kèm</h2>
              <small style={{ color: "#6b7280" }}>
                Nhập câu lệnh tự nhiên, quét hóa đơn hoặc dán nội dung tin nhắn
              </small>
            </div>
          </div>
          <button className="misa-tax-icon-btn" onClick={onClose}>
            <X size={18} />
          </button>
        </header>

        <div className="misa-tax-modal-body">
          <div className="misa-tax-form-group">
            <label>Nội dung nghiệp vụ cần tạo</label>
            <textarea
              style={{
                width: "100%",
                height: 100,
                padding: 10,
                borderRadius: 6,
                border: "1px solid #d1d5db",
                fontSize: 13,
                fontFamily: "inherit",
              }}
              placeholder="Ví dụ: Thu tiền hoàn ứng cho Hoàng Thiên Bảo 5.000.000đ sau chuyến công tác..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
            />
          </div>

          <div>
            <span style={{ fontSize: 12, color: "#6b7280", fontWeight: 500 }}>
              Gợi ý nhanh từ mẫu Sổ Việt ERP:
            </span>
            <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: 6 }}>
              {samplePrompts.map((p, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setPrompt(p)}
                  style={{
                    textAlign: "left",
                    padding: "6px 10px",
                    background: "#f8fafc",
                    border: "1px solid #e2e8f0",
                    borderRadius: 4,
                    fontSize: 12,
                    cursor: "pointer",
                    color: "#334155",
                  }}
                >
                  <Sparkles size={14} className="ui-inline-icon" aria-hidden="true" /> {p}
                </button>
              ))}
            </div>
          </div>
        </div>

        <footer className="misa-tax-modal-footer">
          <div />
          <div className="misa-tax-footer-actions">
            <button className="misa-btn-secondary" onClick={onClose}>
              Hủy
            </button>
            <button
              className="misa-ai-add-btn"
              onClick={handleRun}
              disabled={isProcessing}
            >
              {isProcessing ? "Đang xử lý..." : "Trích xuất & Tạo chứng từ"}
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// 4.5. BÁO CÁO TIỀN MẶT CHUẨN MISA AMIS (CASH REPORTS HUB & VIEWER)
// ----------------------------------------------------------------------
export interface CashReportItem {
  id: string;
  code: string;
  name: string;
  circular: string;
  category: "ledger" | "cashflow" | "advance" | "inventory";
  categoryLabel: string;
  description: string;
  isFavorite: boolean;
}

export const MISA_CASH_REPORTS: CashReportItem[] = [
  {
    id: "s07a",
    code: "S07a-DN",
    name: "S07a-DN: Sổ kế toán chi tiết quỹ tiền mặt",
    circular: "Thông tư 99/2025/TT-BTC",
    category: "ledger",
    categoryLabel: "Sổ sách tiền mặt",
    description: "Phản ánh chi tiết tình hình thu, chi và tồn quỹ theo từng ngày trong tháng, theo chứng từ phát sinh và tài khoản đối ứng (thay thế mẫu S08a-DN của TT200).",
    isFavorite: true,
  },
  {
    id: "th_tc_t",
    code: "TH-TC-T",
    name: "Báo cáo tổng hợp tình hình thu, chi, tồn quỹ tiền mặt theo tháng (12 tháng)",
    circular: "Mẫu quản trị Sổ Việt ERP (Theo TT 99/2025/TT-BTC)",
    category: "cashflow",
    categoryLabel: "Thống kê cả tháng",
    description: "Bảng tổng hợp và biểu đồ dòng tiền thu - chi - tồn quỹ so sánh 12 tháng trong năm tài chính 2026, giúp kế toán trưởng và ban giám đốc đánh giá thanh khoản cả năm.",
    isFavorite: true,
  },
  {
    id: "s07",
    code: "S07-DN",
    name: "S07-DN: Sổ quỹ tiền mặt",
    circular: "Thông tư 99/2025/TT-BTC",
    category: "ledger",
    categoryLabel: "Sổ sách tiền mặt",
    description: "Dành cho Thủ quỹ ghi chép các nghiệp vụ thu, chi tiền mặt thực tế hàng ngày theo trình tự thời gian.",
    isFavorite: true,
  },
  {
    id: "bksd",
    code: "BK-SDT",
    name: "Bảng kê số dư tiền mặt theo ngày trong tháng",
    circular: "Mẫu biểu quản trị Sổ Việt ERP",
    category: "ledger",
    categoryLabel: "Sổ sách tiền mặt",
    description: "Theo dõi biến động số dư tồn quỹ tiền mặt từng ngày trong tháng, đối chiếu với định mức tồn quỹ an toàn.",
    isFavorite: true,
  },
  {
    id: "s03a1",
    code: "S03a1-DN",
    name: "S03a1-DN: Sổ nhật ký thu tiền",
    circular: "Thông tư 99/2025/TT-BTC",
    category: "ledger",
    categoryLabel: "Sổ sách tiền mặt",
    description: "Theo dõi tuần tự thời gian tất cả các nghiệp vụ thu tiền mặt phát sinh trong tháng theo chứng từ thu.",
    isFavorite: false,
  },
  {
    id: "s03a2",
    code: "S03a2-DN",
    name: "S03a2-DN: Sổ nhật ký chi tiền",
    circular: "Thông tư 99/2025/TT-BTC",
    category: "ledger",
    categoryLabel: "Sổ sách tiền mặt",
    description: "Theo dõi tuần tự thời gian tất cả các nghiệp vụ chi tiền mặt phát sinh trong tháng theo chứng từ chi.",
    isFavorite: false,
  },
  {
    id: "cashflow",
    code: "B03-DN",
    name: "B03-DN: Báo cáo lưu chuyển tiền tệ tiền mặt (Phương pháp trực tiếp)",
    circular: "Thông tư 99/2025/TT-BTC",
    category: "cashflow",
    categoryLabel: "Dòng tiền & Quản trị",
    description: "Phân tích các luồng tiền thu - chi theo 3 hoạt động: Hoạt động kinh doanh, Hoạt động đầu tư và Hoạt động tài chính theo quy định TT 99/2025/TT-BTC.",
    isFavorite: true,
  },
  {
    id: "advance141",
    code: "TH-TU-141",
    name: "Bảng tổng hợp tình hình tạm ứng theo nhân viên (TK 141)",
    circular: "Thông tư 99/2025/TT-BTC",
    category: "advance",
    categoryLabel: "Tạm ứng & Công nợ",
    description: "Tổng hợp số dư tạm ứng đầu kỳ, số đã tạm ứng trong tháng, số đã thanh toán quyết toán và số còn phải thu hoàn ứng của từng nhân viên.",
    isFavorite: false,
  },
  {
    id: "inventory",
    code: "BB-KK-01",
    name: "Biên bản kiểm kê quỹ tiền mặt & Bảng xử lý thừa thiếu",
    circular: "Mẫu số 01-VT / TT 99",
    category: "inventory",
    categoryLabel: "Kiểm kê quỹ",
    description: "Ghi nhận kết quả kiểm kê thực tế các loại tiền mặt tại két, đối chiếu số dư sổ sách và lập phương án xử lý chênh lệch.",
    isFavorite: false,
  },
  {id:'movement',code:'DONG-TIEN',name:'Dòng tiền',circular:'Mẫu quản trị Sổ Việt ERP',category:'cashflow',categoryLabel:'Dòng tiền',description:'Theo dõi tiền tồn đầu kỳ, thu, chi và tồn cuối kỳ.',isFavorite:false},
];

// Dữ liệu dòng tiền thống kê cả 12 tháng năm 2026 (Chuẩn Sổ Việt ERP)
export const MONTHLY_CASH_STATS_2026 = [
  { month: "Tháng 01/2026", mShort: "T1", opening: 32000000, inAmount: 58000000, outAmount: 51200000, diff: 6800000, closing: 38800000 },
  { month: "Tháng 02/2026", mShort: "T2", opening: 38800000, inAmount: 62500000, outAmount: 55000000, diff: 7500000, closing: 46300000 },
  { month: "Tháng 03/2026", mShort: "T3", opening: 46300000, inAmount: 71000000, outAmount: 68400000, diff: 2600000, closing: 48900000 },
  { month: "Tháng 04/2026", mShort: "T4", opening: 48900000, inAmount: 64200000, outAmount: 61000000, diff: 3200000, closing: 52100000 },
  { month: "Tháng 05/2026", mShort: "T5", opening: 52100000, inAmount: 83000000, outAmount: 74500000, diff: 8500000, closing: 60600000 },
  { month: "Tháng 06/2026", mShort: "T6", opening: 60600000, inAmount: 69000000, outAmount: 72000000, diff: -3000000, closing: 57600000 },
  { month: "Tháng 07/2026", mShort: "T7", opening: 57600000, inAmount: 76500000, outAmount: 69800000, diff: 6700000, closing: 64300000 },
  { month: "Tháng 08/2026", mShort: "T8", opening: 64300000, inAmount: 55900000, outAmount: 75000000, diff: -19100000, closing: 45200000 },
  { month: "Tháng 09/2026", mShort: "T9", opening: 45200000, inAmount: 70000000, outAmount: 18400000, diff: 51600000, closing: 96800000, isCurrent: true },
  { month: "Tháng 10/2026", mShort: "T10", opening: 96800000, inAmount: 68000000, outAmount: 62000000, diff: 6000000, closing: 102800000, isPlan: true },
  { month: "Tháng 11/2026", mShort: "T11", opening: 102800000, inAmount: 75000000, outAmount: 69000000, diff: 6000000, closing: 108800000, isPlan: true },
  { month: "Tháng 12/2026", mShort: "T12", opening: 108800000, inAmount: 92000000, outAmount: 85000000, diff: 7000000, closing: 115800000, isPlan: true },
];

export function CashReportsTab({ notify,entries=[],companyId,initialReport }: { notify: (msg: string) => void;entries?:CashEntry[];companyId?:string;initialReport?:string|null }) {
  const [search, setSearch] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [favorites, setFavorites] = useState<Set<string>>(
    new Set(["s07a", "th_tc_t", "s07", "bksd", "cashflow"]),
  );
  const [activeReport, setActiveReport] = useState<CashReportItem | null>(() => { if (!initialReport) return null; const id = initialReport.includes("S03a1") ? "s03a1" : initialReport.includes("S03a2") ? "s03a2" : initialReport.includes("Bảng kê số dư") ? "bksd" : initialReport === "Dòng tiền" ? "movement" : "s07a"; return MISA_CASH_REPORTS.find(report => report.id === id) || null; });
  const [selectedMonth, setSelectedMonth] = useState("Tháng 09/2026");
  const [viewMode, setViewMode] = useState<"detail" | "monthly_summary">("detail");

  const toggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
        notify("Đã bỏ ghim báo cáo khỏi mục yêu thích.");
      } else {
        next.add(id);
        notify("Đã thêm báo cáo vào danh mục yêu thích ⭐.");
      }
      return next;
    });
  };

  const filteredReports = useMemo(() => {
    return MISA_CASH_REPORTS.filter((r) => {
      const matchSearch =
        r.name.toLowerCase().includes(search.toLowerCase()) ||
        r.code.toLowerCase().includes(search.toLowerCase()) ||
        r.description.toLowerCase().includes(search.toLowerCase());

      if (!matchSearch) return false;

      if (filterCategory === "favorite") return favorites.has(r.id);
      if (filterCategory === "ledger") return r.category === "ledger";
      if (filterCategory === "cashflow") return r.category === "cashflow" || r.category === "advance";
      return true;
    });
  }, [search, filterCategory, favorites]);

  const openReport = (rep: CashReportItem) => {
    setActiveReport(rep);
    if (rep.id === "th_tc_t") {
      setViewMode("monthly_summary");
    } else {
      setViewMode("detail");
    }
  };

  // If a report is selected, show the MISA Paper Report Viewer!
  if(activeReport && activeReport.id!=='th_tc_t') {
    return <MisaCashReportView key={activeReport.id} id={activeReport.id} entries={entries} companyId={companyId} onBack={()=>setActiveReport(null)} notify={notify}/>;
  }
  if(activeReport?.id==='th_tc_t'&&viewMode==='detail')return <><div className="ce-toolbar"><button onClick={()=>setViewMode('monthly_summary')}>Thống kê 12 tháng</button></div><MisaCashReportView id="s07a" entries={entries} onBack={()=>setActiveReport(null)} notify={notify}/></>;
  if (activeReport) {
    return (
      <div className="misa-report-viewer-container">
        {/* Viewer Toolbar */}
        <header className="misa-report-viewer-toolbar">
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            <button
              className="misa-tax-icon-btn"
              onClick={() => setActiveReport(null)}
              title="Quay lại danh sách báo cáo"
              style={{ display: "flex", alignItems: "center", gap: 6, width: "auto", padding: "0 10px" }}
            >
              <ArrowLeft size={16} />
              <span style={{ fontSize: 13, fontWeight: 500 }}>Danh sách báo cáo</span>
            </button>

            <div style={{ height: 20, width: 1, background: "#cbd5e1" }} />

            <span style={{ fontSize: 13, fontWeight: 600, color: "#1e293b" }}>
              {activeReport.name}
            </span>

            {/* Chế độ xem: Sổ chi tiết cả tháng vs Bảng thống kê 12 tháng */}
            <div className="misa-report-mode-toggle" style={{ marginLeft: 8 }}>
              <button
                type="button"
                className={`misa-report-mode-btn ${viewMode === "detail" ? "active" : ""}`}
                onClick={() => setViewMode("detail")}
              >
                <BookOpen size={14} className="ui-inline-icon" aria-hidden="true" /> Sổ chi tiết ({selectedMonth.replace("Tháng ", "T")})
              </button>
              <button
                type="button"
                className={`misa-report-mode-btn ${viewMode === "monthly_summary" ? "active" : ""}`}
                onClick={() => setViewMode("monthly_summary")}
              >
                <ChartNoAxesCombined size={14} className="ui-inline-icon" aria-hidden="true" /> Thống kê 12 tháng (Năm 2026)
              </button>
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            {/* Kỳ chọn tháng chuẩn MISA */}
            <div className="misa-period-select-box">
              <Calendar size={14} style={{ color: "var(--brand)" }} />
              <span>Kỳ:</span>
              <select
                value={selectedMonth}
                onChange={(e) => {
                  setSelectedMonth(e.target.value);
                  notify(`Đã cập nhật kỳ báo cáo: ${e.target.value}`);
                }}
              >
                <option value="Tháng 09/2026">Tháng 09/2026 (Kỳ hiện tại)</option>
                <option value="Tháng 08/2026">Tháng 08/2026</option>
                <option value="Tháng 07/2026">Tháng 07/2026</option>
                <option value="Tháng 06/2026">Tháng 06/2026</option>
                <option value="Tháng 05/2026">Tháng 05/2026</option>
                <option value="Tháng 04/2026">Tháng 04/2026</option>
                <option value="Tháng 03/2026">Tháng 03/2026</option>
                <option value="Tháng 02/2026">Tháng 02/2026</option>
                <option value="Tháng 01/2026">Tháng 01/2026</option>
                <option value="Tháng 10/2026">Tháng 10/2026 (Kế hoạch)</option>
                <option value="Tháng 11/2026">Tháng 11/2026 (Kế hoạch)</option>
                <option value="Tháng 12/2026">Tháng 12/2026 (Kế hoạch)</option>
              </select>
            </div>

            <button
              className="misa-btn-secondary"
              style={{ display: "inline-flex", alignItems: "center", gap: 6, height: 32, fontSize: 12.5 }}
              onClick={async (event) => { try { await exportVisibleTable(event.currentTarget, "Đang kết xuất tệp Excel báo cáo chuẩn Thông tư 99/2025/TT-BTC"); } catch (cause) { notify?.(cause instanceof Error ? cause.message : "Không thực hiện được thao tác."); } }}
            >
              <FileSpreadsheet size={15} style={{ color: "var(--brand)" }} />
              <span>Xuất khẩu Excel</span>
            </button>

            <button
              className="misa-btn-secondary"
              style={{ display: "inline-flex", alignItems: "center", gap: 6, height: 32, fontSize: 12.5 }}
              onClick={() => window.print()}
            >
              <Printer size={15} style={{ color: "var(--brand)" }} />
              <span>In (Ctrl+P)</span>
            </button>

            <button
              className="misa-btn-primary"
              style={{ height: 32, fontSize: 12.5 }}
              onClick={() => notify(`Thiết lập tham số: ${selectedMonth}, Tài khoản 1111, Mẫu Thông tư 99/2025/TT-BTC`)}
            >
              Chọn tham số
            </button>
          </div>
        </header>

        {/* Paper Sheet Content */}
        <div className="misa-report-viewer-content">
          <div className="misa-report-paper">
            {/* Header info */}
            <div className="misa-report-paper-header">
              <div className="misa-report-company-info">
                <strong>CÔNG TY CỔ PHẦN CÔNG NGHỆ MINH AN</strong>
                <div>Địa chỉ: Tòa nhà Sổ Việt, Cầu Giấy, Hà Nội</div>
                <div>Mã số thuế: <strong>0108923456</strong></div>
              </div>

              <div className="misa-report-template-code">
                <strong>{viewMode === "monthly_summary" ? "TH-TC-T" : (activeReport.code === "S08a-DN" ? "S07a-DN" : activeReport.code)}</strong>
                <div>(Ban hành theo Thông tư số 99/2025/TT-BTC ngày 27/10/2025 của Bộ Tài chính)</div>
              </div>
            </div>

            {/* =======================================================
                VIEW MODE 1: SỔ KẾ TOÁN CHI TIẾT CẢ THÁNG (MẪU S07a-DN)
                ======================================================= */}
            {viewMode === "detail" && (
              <>
                <div className="misa-report-paper-title">
                  <h1>SỔ KẾ TOÁN CHI TIẾT QUỸ TIỀN MẶT</h1>
                  <p>Tài khoản: <strong>1111 - Tiền Việt Nam</strong></p>
                  <p style={{ fontStyle: "italic", fontSize: 12.5, color: "#64748b" }}>
                    Kỳ báo cáo: Cả {selectedMonth} (Từ ngày 01/09/2026 đến ngày 30/09/2026)
                  </p>
                </div>

                {/* Data Table */}
                <table className="misa-report-data-table">
                  <thead>
                    <tr>
                      <th style={{ width: 40 }}>STT</th>
                      <th style={{ width: 85 }}>Ngày HT</th>
                      <th style={{ width: 85 }}>Ngày CT</th>
                      <th style={{ width: 90 }}>Số chứng từ</th>
                      <th>Diễn giải nghiệp vụ</th>
                      <th style={{ width: 75 }}>TK đối ứng</th>
                      <th style={{ width: 120, textAlign: "right" }}>Số tiền Thu</th>
                      <th style={{ width: 120, textAlign: "right" }}>Số tiền Chi</th>
                      <th style={{ width: 130, textAlign: "right" }}>Số dư Tồn quỹ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {/* Dòng Số dư đầu tháng */}
                    <tr style={{ background: "#f8fafc", fontWeight: 600 }}>
                      <td colSpan={6} style={{ textAlign: "left", paddingLeft: 14 }}>
                        <strong>Số dư đầu tháng 09/2026 (01/09/2026):</strong>
                      </td>
                      <td className="numeric">-</td>
                      <td className="numeric">-</td>
                      <td className="numeric" style={{ textAlign: "right", color: "var(--brand)", fontWeight: 700 }}>
                        45.200.000
                      </td>
                    </tr>

                    <tr>
                      <td style={{ textAlign: "center" }}>1</td>
                      <td style={{ textAlign: "center" }}>03/09/2026</td>
                      <td style={{ textAlign: "center" }}>03/09/2026</td>
                      <td style={{ textAlign: "center", color: "var(--brand)", fontWeight: 600 }}>PT00001</td>
                      <td>Thu tiền bán hàng trực tiếp tại quầy thu ngân</td>
                      <td style={{ textAlign: "center" }}>5111</td>
                      <td style={{ textAlign: "right" }}>15.000.000</td>
                      <td style={{ textAlign: "right" }}>-</td>
                      <td style={{ textAlign: "right", fontWeight: 600 }}>60.200.000</td>
                    </tr>

                    <tr>
                      <td style={{ textAlign: "center" }}>2</td>
                      <td style={{ textAlign: "center" }}>03/09/2026</td>
                      <td style={{ textAlign: "center" }}>03/09/2026</td>
                      <td style={{ textAlign: "center", color: "var(--brand)", fontWeight: 600 }}>PT00005</td>
                      <td>Thu hoàn ứng sau khi quyết toán tạm ứng cho Hoàng Thiên Bảo</td>
                      <td style={{ textAlign: "center" }}>141</td>
                      <td style={{ textAlign: "right" }}>5.000.000</td>
                      <td style={{ textAlign: "right" }}>-</td>
                      <td style={{ textAlign: "right", fontWeight: 600 }}>65.200.000</td>
                    </tr>

                    <tr>
                      <td style={{ textAlign: "center" }}>3</td>
                      <td style={{ textAlign: "center" }}>05/09/2026</td>
                      <td style={{ textAlign: "center" }}>05/09/2026</td>
                      <td style={{ textAlign: "center", color: "#ea580c", fontWeight: 600 }}>PC00001</td>
                      <td>Chi thanh toán tiền tiếp khách hội nghị khách hàng</td>
                      <td style={{ textAlign: "center" }}>6427</td>
                      <td style={{ textAlign: "right" }}>-</td>
                      <td style={{ textAlign: "right" }}>3.500.000</td>
                      <td style={{ textAlign: "right", fontWeight: 600 }}>61.700.000</td>
                    </tr>

                    <tr>
                      <td style={{ textAlign: "center" }}>4</td>
                      <td style={{ textAlign: "center" }}>08/09/2026</td>
                      <td style={{ textAlign: "center" }}>08/09/2026</td>
                      <td style={{ textAlign: "center", color: "#ea580c", fontWeight: 600 }}>PC00006</td>
                      <td>Chi thanh toán tiền mua văn phòng phẩm và vật tư văn phòng</td>
                      <td style={{ textAlign: "center" }}>6422</td>
                      <td style={{ textAlign: "right" }}>-</td>
                      <td style={{ textAlign: "right" }}>1.850.000</td>
                      <td style={{ textAlign: "right", fontWeight: 600 }}>59.850.000</td>
                    </tr>

                    <tr>
                      <td style={{ textAlign: "center" }}>5</td>
                      <td style={{ textAlign: "center" }}>15/09/2026</td>
                      <td style={{ textAlign: "center" }}>15/09/2026</td>
                      <td style={{ textAlign: "center", color: "var(--brand)", fontWeight: 600 }}>PT00008</td>
                      <td>Rút tiền gửi ngân hàng Vietcombank 1023847592 về nhập quỹ</td>
                      <td style={{ textAlign: "center" }}>1121</td>
                      <td style={{ textAlign: "right" }}>50.000.000</td>
                      <td style={{ textAlign: "right" }}>-</td>
                      <td style={{ textAlign: "right", fontWeight: 600 }}>109.850.000</td>
                    </tr>

                    <tr>
                      <td style={{ textAlign: "center" }}>6</td>
                      <td style={{ textAlign: "center" }}>20/09/2026</td>
                      <td style={{ textAlign: "center" }}>20/09/2026</td>
                      <td style={{ textAlign: "center", color: "#ea580c", fontWeight: 600 }}>PC00012</td>
                      <td>Tạm ứng công tác phí thị trường Hải Phòng cho Hoàng Thiên Bảo</td>
                      <td style={{ textAlign: "center" }}>141</td>
                      <td style={{ textAlign: "right" }}>-</td>
                      <td style={{ textAlign: "right" }}>13.050.000</td>
                      <td style={{ textAlign: "right", fontWeight: 600 }}>96.800.000</td>
                    </tr>

                    {/* Tổng phát sinh cả tháng */}
                    <tr style={{ background: "#f8fafc", fontWeight: 700 }}>
                      <td colSpan={6} style={{ textAlign: "right", paddingRight: 14 }}>
                        <strong>Cộng số phát sinh cả {selectedMonth}:</strong>
                      </td>
                      <td style={{ textAlign: "right", color: "var(--brand)" }}>70.000.000</td>
                      <td style={{ textAlign: "right", color: "#ea580c" }}>18.400.000</td>
                      <td style={{ textAlign: "right" }}>-</td>
                    </tr>

                    {/* Số dư cuối tháng */}
                    <tr style={{ background: "#ecfdf5", fontWeight: 800, fontSize: 13 }}>
                      <td colSpan={6} style={{ textAlign: "left", paddingLeft: 14, color: "#065f46" }}>
                        <strong>Số dư cuối {selectedMonth} (30/09/2026):</strong>
                      </td>
                      <td style={{ textAlign: "right" }}>-</td>
                      <td style={{ textAlign: "right" }}>-</td>
                      <td style={{ textAlign: "right", color: "var(--brand)", fontSize: 14 }}>
                        96.800.000
                      </td>
                    </tr>
                  </tbody>
                </table>
              </>
            )}

            {/* =======================================================
                VIEW MODE 2: BÁO CÁO TỔNG HỢP THU CHI TỒN 12 THÁNG
                ======================================================= */}
            {viewMode === "monthly_summary" && (
              <>
                <div className="misa-report-paper-title">
                  <h1>BÁO CÁO TỔNG HỢP TÌNH HÌNH THU, CHI, TỒN QUỸ TIỀN MẶT THEO THÁNG</h1>
                  <p>Tài khoản: <strong>1111 - Tiền Việt Nam</strong></p>
                  <p style={{ fontStyle: "italic", fontSize: 12.5, color: "#64748b" }}>
                    Năm tài chính 2026 (Từ ngày 01/01/2026 đến ngày 31/12/2026) — Đơn vị tính: VNĐ
                  </p>
                </div>

                {/* 4 Thẻ chỉ số tổng hợp cả năm */}
                <div className="misa-monthly-summary-kpis">
                  <div className="misa-monthly-kpi-card">
                    <span>Số dư đầu năm (01/01/2026)</span>
                    <strong>32.000.000 đ</strong>
                    <small>Chuyển từ năm 2025 sang</small>
                  </div>
                  <div className="misa-monthly-kpi-card">
                    <span>Tổng thu lũy kế (T1 - T9)</span>
                    <strong style={{ color: "var(--brand)" }}>586.500.000 đ</strong>
                    <small>Bán lẻ + rút NH + thu hồi nợ</small>
                  </div>
                  <div className="misa-monthly-kpi-card">
                    <span>Tổng chi lũy kế (T1 - T9)</span>
                    <strong style={{ color: "#ea580c" }}>521.700.000 đ</strong>
                    <small>Chi phí + tạm ứng + nộp thuế</small>
                  </div>
                  <div className="misa-monthly-kpi-card" style={{ background: "#ecfdf5", borderColor: "#a7f3d0" }}>
                    <span>Số dư tồn quỹ hiện tại (Tháng 9)</span>
                    <strong style={{ color: "#065f46" }}>96.800.000 đ</strong>
                    <small style={{ color: "#059669" }}>Khớp 100% két và biên bản</small>
                  </div>
                </div>

                {/* Biểu đồ trực quan so sánh 12 tháng */}
                <div className="misa-monthly-chart-box">
                  <div className="misa-monthly-chart-header">
                    <h4>Biểu đồ so sánh Dòng tiền Thu - Chi từng tháng trong năm 2026</h4>
                    <div className="misa-monthly-chart-legend">
                      <div className="misa-monthly-legend-item">
                        <span className="misa-legend-color" style={{ background: "var(--brand)" }} />
                        <span>Tiền thu vào (VNĐ)</span>
                      </div>
                      <div className="misa-monthly-legend-item">
                        <span className="misa-legend-color" style={{ background: "#ef4444" }} />
                        <span>Tiền chi ra (VNĐ)</span>
                      </div>
                    </div>
                  </div>

                  <div className="misa-monthly-bars">
                    {MONTHLY_CASH_STATS_2026.map((st) => {
                      const maxVal = 100000000;
                      const inPercent = Math.min(100, Math.round((st.inAmount / maxVal) * 100));
                      const outPercent = Math.min(100, Math.round((st.outAmount / maxVal) * 100));
                      const isSelected = st.month === selectedMonth;

                      return (
                        <div
                          key={st.mShort}
                          className={`misa-monthly-bar-group ${isSelected || st.isCurrent ? "current" : ""}`}
                          title={`${st.month}: Thu ${formatVND(st.inAmount)}đ | Chi ${formatVND(st.outAmount)}đ | Tồn cuối ${formatVND(st.closing)}đ (Nhấn để xem sổ chi tiết)`}
                          onClick={() => {
                            setSelectedMonth(st.month);
                            setViewMode("detail");
                            notify(`Đã chuyển sang xem sổ chi tiết của ${st.month}`);
                          }}
                        >
                          <div className="misa-monthly-bar-pair">
                            <div className="misa-bar-in" style={{ height: `${inPercent}%` }} />
                            <div className="misa-bar-out" style={{ height: `${outPercent}%` }} />
                          </div>
                          <span className="misa-monthly-bar-label">
                            {st.mShort}
                            {isSelected ? <MapPin size={12} aria-label="Tháng đang chọn" /> : st.isCurrent ? <Star size={12} aria-label="Tháng hiện tại" /> : null}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                  <div style={{ textAlign: "right", marginTop: 8, fontSize: 11.5, color: "#64748b" }}>
                    * Nhấn vào cột tháng bất kỳ trên biểu đồ để xem chi tiết từng chứng từ thu - chi của tháng đó.
                  </div>
                </div>

                {/* Bảng số liệu thống kê 12 tháng */}
                <table className="misa-report-data-table">
                  <thead>
                    <tr>
                      <th style={{ width: 45, textAlign: "center" }}>STT</th>
                      <th style={{ width: 110 }}>Kỳ kế toán</th>
                      <th style={{ width: 130, textAlign: "right" }}>Số dư đầu tháng</th>
                      <th style={{ width: 130, textAlign: "right" }}>Thu trong tháng</th>
                      <th style={{ width: 130, textAlign: "right" }}>Chi trong tháng</th>
                      <th style={{ width: 130, textAlign: "right" }}>Chênh lệch (Thu - Chi)</th>
                      <th style={{ width: 130, textAlign: "right" }}>Số dư cuối tháng</th>
                      <th style={{ width: 90, textAlign: "center" }}>Thao tác</th>
                    </tr>
                  </thead>
                  <tbody>
                    {MONTHLY_CASH_STATS_2026.map((row, idx) => {
                      const isSelected = row.month === selectedMonth;
                      return (
                        <tr
                          key={row.mShort}
                          style={{
                            background: isSelected ? "#f0fdf4" : (row.isCurrent ? "#f8fafc" : undefined),
                            fontWeight: isSelected || row.isCurrent ? 600 : 400,
                          }}
                        >
                          <td style={{ textAlign: "center" }}>{idx + 1}</td>
                          <td>
                            <strong>{row.month}</strong>
                            {row.isCurrent && (
                              <span style={{ marginLeft: 6, fontSize: 11, color: "#15803d", background: "#dcfce7", padding: "1px 6px", borderRadius: 4 }}>
                                Hiện tại
                              </span>
                            )}
                            {row.isPlan && (
                              <span style={{ marginLeft: 6, fontSize: 11, color: "#64748b", background: "#f1f5f9", padding: "1px 6px", borderRadius: 4 }}>
                                Kế hoạch
                              </span>
                            )}
                          </td>
                          <td style={{ textAlign: "right" }}>{formatVND(row.opening)}</td>
                          <td style={{ textAlign: "right", color: "var(--brand)" }}>{formatVND(row.inAmount)}</td>
                          <td style={{ textAlign: "right", color: "#ea580c" }}>{formatVND(row.outAmount)}</td>
                          <td style={{ textAlign: "right", color: row.diff >= 0 ? "var(--brand)" : "#dc2626" }}>
                            {row.diff >= 0 ? `+${formatVND(row.diff)}` : `(${formatVND(Math.abs(row.diff))})`}
                          </td>
                          <td style={{ textAlign: "right", fontWeight: 700 }}>{formatVND(row.closing)}</td>
                          <td style={{ textAlign: "center" }}>
                            <button
                              type="button"
                              className="misa-drilldown-btn"
                              onClick={() => {
                                setSelectedMonth(row.month);
                                setViewMode("detail");
                                notify(`Mở sổ chi tiết ${row.month}`);
                              }}
                            >
                              <span>Chi tiết</span>
                              <ChevronRight size={12} />
                            </button>
                          </td>
                        </tr>
                      );
                    })}

                    {/* Tổng cộng lũy kế cả năm 2026 */}
                    <tr style={{ background: "#ecfdf5", fontWeight: 800, fontSize: 13 }}>
                      <td colSpan={2} style={{ textAlign: "left", paddingLeft: 14, color: "#065f46" }}>
                        <strong>TỔNG CỘNG LŨY KẾ CẢ NĂM 2026:</strong>
                      </td>
                      <td style={{ textAlign: "right" }}>32.000.000</td>
                      <td style={{ textAlign: "right", color: "var(--brand)" }}>821.500.000</td>
                      <td style={{ textAlign: "right", color: "#ea580c" }}>737.700.000</td>
                      <td style={{ textAlign: "right", color: "var(--brand)" }}>+83.800.000</td>
                      <td style={{ textAlign: "right", color: "#065f46", fontSize: 14 }}>115.800.000</td>
                      <td style={{ textAlign: "center" }}>-</td>
                    </tr>
                  </tbody>
                </table>
              </>
            )}

            {/* Signatures block theo Thông tư 99/2025/TT-BTC */}
            <div className="misa-report-signatures">
              <div className="misa-report-sign-col">
                <strong>Người lập biểu</strong>
                <small>(Ký, họ tên)</small>
                <div className="misa-report-sign-name">Nguyễn Văn Kế Toán</div>
              </div>

              <div className="misa-report-sign-col">
                <strong>Thủ quỹ</strong>
                <small>(Ký, họ tên)</small>
                <div className="misa-report-sign-name">Vũ Thị Mai</div>
              </div>

              <div className="misa-report-sign-col">
                <strong>Kế toán trưởng</strong>
                <small>(Ký, họ tên)</small>
                <div className="misa-report-sign-name">Trương Thị B</div>
              </div>

              <div className="misa-report-sign-col">
                <strong>Giám đốc</strong>
                <small>(Ký, họ tên, đóng dấu)</small>
                <div className="misa-report-sign-name">Nguyễn Văn A</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Reports Hub Grid View
  return (
    <div className="misa-cash-reports-wrapper">
      {/* Header */}
      <header className="misa-cash-reports-header">
        <div className="misa-cash-reports-title">
          <h2>
            <BookOpen size={20} style={{ color: "var(--brand)" }} />
            <span>Báo cáo Tiền mặt</span>
          </h2>
          <p>
            Hệ thống sổ kế toán, sổ quỹ và báo cáo dòng tiền theo <strong>Thông tư 99/2025/TT-BTC</strong> & Chuẩn quản trị Sổ Việt ERP
          </p>
        </div>

        <div style={{ display: "flex", gap: 10, flexShrink: 0, alignItems: "center" }}>
          <button
            className="misa-btn-secondary"
            style={{ height: 34, fontSize: 13, whiteSpace: "nowrap", flexShrink: 0 }}
            onClick={() => openReport(MISA_CASH_REPORTS.find(report=>report.id==='s07a')!)}
          >
            <Printer size={15} style={{ marginRight: 6 }} />
            In nhanh sổ chi tiết (S07a-DN)
          </button>
          <button
            className="misa-btn-primary"
            style={{ height: 34, fontSize: 13, whiteSpace: "nowrap", flexShrink: 0 }}
            onClick={() => openReport(MISA_CASH_REPORTS.find(report=>report.id==='th_tc_t')!)}
          >
            <BarChart3 size={15} style={{ marginRight: 6 }} />
            Thống kê 12 tháng (Năm 2026)
          </button>
        </div>
      </header>

      {/* Toolbar */}
      <div className="misa-cash-reports-toolbar">
        <div className="misa-reports-search-box">
          <Search size={16} />
          <input
            type="text"
            placeholder="Tìm theo tên, mã hoặc nội dung báo cáo..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="misa-reports-filter-chips">
          <button
            className={`misa-reports-chip ${filterCategory === "all" ? "active" : ""}`}
            onClick={() => setFilterCategory("all")}
          >
            Tất cả ({MISA_CASH_REPORTS.length})
          </button>

          <button
            className={`misa-reports-chip ${filterCategory === "favorite" ? "active" : ""}`}
            onClick={() => setFilterCategory("favorite")}
          >
            ⭐ Yêu thích ({favorites.size})
          </button>

          <button
            className={`misa-reports-chip ${filterCategory === "ledger" ? "active" : ""}`}
            onClick={() => setFilterCategory("ledger")}
          >
            Sổ sách tiền mặt (5)
          </button>

          <button
            className={`misa-reports-chip ${filterCategory === "cashflow" ? "active" : ""}`}
            onClick={() => setFilterCategory("cashflow")}
          >
            Dòng tiền & Thống kê tháng (4)
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="misa-reports-grid">
        {filteredReports.map((rep) => {
          const isFav = favorites.has(rep.id);
          return (
            <div
              key={rep.id}
              className="misa-report-card"
              onClick={() => openReport(rep)}
            >
              <div>
                <div className="misa-report-card-top">
                  <div className="misa-report-icon-box">
                    {rep.category === "cashflow" ? (
                      <BarChart3 size={20} />
                    ) : (
                      <BookOpen size={20} />
                    )}
                  </div>

                  <div className="misa-report-info">
                    <div className="misa-report-title-row">
                      <span className="misa-report-title">{rep.name}</span>
                      <button
                        className={`misa-report-star ${isFav ? "starred" : ""}`}
                        title={isFav ? "Bỏ ghim yêu thích" : "Ghim báo cáo yêu thích"}
                        onClick={(e) => toggleFavorite(e, rep.id)}
                      >
                        <Star size={16} fill={isFav ? "#eab308" : "none"} />
                      </button>
                    </div>

                    <span className="misa-report-circular">{rep.circular}</span>
                    <p className="misa-report-desc">{rep.description}</p>
                  </div>
                </div>
              </div>

              <div className="misa-report-card-footer">
                <span className="misa-report-category-badge">{rep.categoryLabel}</span>
                <button
                  className="misa-report-view-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    openReport(rep);
                  }}
                >
                  <span>Xem báo cáo</span>
                  <ChevronRight size={13} />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// 4.6. DỰ BÁO DÒNG TIỀN CHUẨN MISA AMIS (CASH FLOW FORECAST WORKSPACE)
// ----------------------------------------------------------------------
export interface ForecastItem {
  id: string;
  date: string;
  kind: "in" | "out";
  category: string;
  partner: string;
  documentRef: string;
  amount: number;
  probability: number;
}

export const INITIAL_FORECAST_ITEMS: ForecastItem[] = [
  {
    id: "fc-01",
    date: "26/09/2026",
    kind: "in",
    category: "Thu bán lẻ tại quầy",
    partner: "Khách lẻ vãng lai",
    documentRef: "Hóa đơn bán lẻ quầy thu ngân",
    amount: 12000000,
    probability: 95,
  },
  {
    id: "fc-02",
    date: "28/09/2026",
    kind: "in",
    category: "Thu hồi nợ bán hàng quá hạn",
    partner: "Công ty Cổ phần Hoàng Gia",
    documentRef: "HĐBH-2026-00129",
    amount: 25000000,
    probability: 85,
  },
  {
    id: "fc-03",
    date: "30/09/2026",
    kind: "out",
    category: "Cước viễn thông & Internet",
    partner: "Tập đoàn VNPT Hà Nội",
    documentRef: "Hóa đơn GTGT tiền cước T8",
    amount: 3500000,
    probability: 100,
  },
  {
    id: "fc-04",
    date: "01/10/2026",
    kind: "in",
    category: "Dịch vụ bảo trì phần mềm",
    partner: "Công ty TNHH Ánh Dương",
    documentRef: "Hợp đồng dịch vụ 18/HD-DV",
    amount: 15000000,
    probability: 90,
  },
  {
    id: "fc-05",
    date: "05/10/2026",
    kind: "out",
    category: "Chi tạm ứng lương đợt 1",
    partner: "Cán bộ nhân viên công ty",
    documentRef: "Bảng thanh toán lương đợt 1/10",
    amount: 20000000,
    probability: 100,
  },
  {
    id: "fc-06",
    date: "08/10/2026",
    kind: "out",
    category: "Tiền điện nước & Dịch vụ tòa nhà",
    partner: "BQL Tòa nhà Sổ Việt Cầu Giấy",
    documentRef: "Thông báo cước định kỳ",
    amount: 4500000,
    probability: 100,
  },
  {
    id: "fc-07",
    date: "10/10/2026",
    kind: "in",
    category: "Thu tiền bán hàng đại lý",
    partner: "Công ty TNHH Phúc Long",
    documentRef: "HĐBH-2026-00142",
    amount: 18500000,
    probability: 85,
  },
  {
    id: "fc-08",
    date: "12/10/2026",
    kind: "out",
    category: "Trả tiền nhà cung cấp vật tư",
    partner: "Công ty TNHH Minh Phát",
    documentRef: "Hóa đơn mua hàng 00214",
    amount: 8200000,
    probability: 100,
  },
  {
    id: "fc-09",
    date: "15/10/2026",
    kind: "out",
    category: "Nộp tiền BHXH, BHYT, BHTN T9",
    partner: "Bảo hiểm xã hội quận Cầu Giấy",
    documentRef: "Thông báo nộp tiền BHXH tháng 9",
    amount: 11700000,
    probability: 100,
  },
  {
    id: "fc-10",
    date: "18/10/2026",
    kind: "in",
    category: "Thu hoàn ứng công tác phí",
    partner: "Lê Thị Mai (Phòng KD)",
    documentRef: "Giấy thanh toán tạm ứng",
    amount: 3000000,
    probability: 90,
  },
  {
    id: "fc-11",
    date: "20/10/2026",
    kind: "out",
    category: "Nộp tạm tính thuế GTGT và TNDN Q3",
    partner: "Chi cục Thuế quận Cầu Giấy",
    documentRef: "Tờ khai thuế quý 3/2026",
    amount: 15800000,
    probability: 100,
  },
  {
    id: "fc-12",
    date: "25/10/2026",
    kind: "in",
    category: "Thu tiền bán hàng dự án đợt 2",
    partner: "Công ty CP Đầu tư An Phát",
    documentRef: "Biên bản nghiệm thu bàn giao",
    amount: 15000000,
    probability: 80,
  },
];

export function CashForecastTab({ notify }: { notify: (msg: string) => void }) {
  const [period, setPeriod] = useState("30days");
  const [typeFilter, setTypeFilter] = useState<"all" | "in" | "out" | "sure">("all");
  const [search, setSearch] = useState("");
  const [items, setItems] = useState<ForecastItem[]>(INITIAL_FORECAST_ITEMS);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showAdvisorModal, setShowAdvisorModal] = useState(false);

  // New item form state
  const [newItem, setNewItem] = useState({
    date: "2026-10-02",
    kind: "in" as "in" | "out",
    category: "Thu tiền bán hàng dự án",
    partner: "",
    documentRef: "",
    amount: 10000000,
    probability: 90,
  });

  const startingBalance = 96800000;
  const safetyThreshold = 25000000;

  // Running cumulative balance calculation
  const timelineData = useMemo(() => {
    let running = startingBalance;
    return items.map((it) => {
      if (it.kind === "in") {
        running += it.amount;
      } else {
        running -= it.amount;
      }
      return {
        ...it,
        balanceAfter: running,
        isSafe: running >= safetyThreshold,
      };
    });
  }, [items, startingBalance, safetyThreshold]);

  const totalIn = useMemo(
    () => items.filter((i) => i.kind === "in").reduce((s, i) => s + i.amount, 0),
    [items]
  );

  const totalOut = useMemo(
    () => items.filter((i) => i.kind === "out").reduce((s, i) => s + i.amount, 0),
    [items]
  );

  const netCashflow = totalIn - totalOut;
  const finalBalance = startingBalance + netCashflow;
  const minBalance = useMemo(
    () => Math.min(startingBalance, ...timelineData.map((d) => d.balanceAfter)),
    [timelineData, startingBalance]
  );

  const filteredItems = useMemo(() => {
    return timelineData.filter((i) => {
      const matchSearch =
        i.category.toLowerCase().includes(search.toLowerCase()) ||
        i.partner.toLowerCase().includes(search.toLowerCase()) ||
        i.documentRef.toLowerCase().includes(search.toLowerCase()) ||
        i.date.includes(search);

      if (!matchSearch) return false;

      if (typeFilter === "in") return i.kind === "in";
      if (typeFilter === "out") return i.kind === "out";
      if (typeFilter === "sure") return i.probability === 100;
      return true;
    });
  }, [timelineData, typeFilter, search]);

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItem.partner || !newItem.amount) {
      notify("Vui lòng nhập đầy đủ đối tác và số tiền!");
      return;
    }
    const dParts = newItem.date.split("-");
    const formattedDate = `${dParts[2]}/${dParts[1]}/${dParts[0]}`;
    const created: ForecastItem = {
      id: crypto.randomUUID(),
      date: formattedDate,
      kind: newItem.kind,
      category: newItem.category,
      partner: newItem.partner,
      documentRef: newItem.documentRef || "Kế hoạch bổ sung",
      amount: Number(newItem.amount),
      probability: Number(newItem.probability),
    };
    setItems((prev) => [...prev, created]);
    setShowAddModal(false);
    notify(
      `Đã bổ sung khoản dự kiến ${created.kind === "in" ? "Thu" : "Chi"} ${formatVND(created.amount)}đ vào kế hoạch dòng tiền!`
    );
  };

  const handleDeleteItem = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
    notify("Đã xóa khoản dự kiến khỏi kế hoạch dòng tiền.");
  };

  return (
    <div className="misa-forecast-wrapper">
      {/* 1. Header Toolbar */}
      <header className="misa-forecast-toolbar">
        <div className="misa-forecast-title-group">
          <h2>
            <TrendingUp size={20} style={{ color: "var(--brand)" }} />
            <span>Dự báo dòng tiền (Cash Flow Forecast)</span>
            <span style={{ fontSize: 11, background: "#ecfdf5", color: "#065f46", border: "1px solid #a7f3d0", padding: "2px 8px", borderRadius: 12 }}>
              Chuẩn Sổ Việt ERP
            </span>
          </h2>
          <p>
            Phân tích tự động từ Hóa đơn bán hàng, Hóa đơn mua hàng, Lương, BHXH và Thuế để dự báo thanh khoản quỹ tiền mặt
          </p>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
          {/* Period selector */}
          <div className="misa-period-select-box">
            <Calendar size={14} style={{ color: "var(--brand)" }} />
            <span>Kỳ dự báo:</span>
            <select
              value={period}
              onChange={(e) => {
                setPeriod(e.target.value);
                notify(`Đã cập nhật kỳ dự báo dòng tiền: ${e.target.value}`);
              }}
            >
              <option value="30days">30 ngày tới (26/09/2026 - 25/10/2026)</option>
              <option value="60days">60 ngày tới (26/09/2026 - 24/11/2026)</option>
              <option value="nextMonth">Tháng tới (Tháng 10/2026)</option>
              <option value="q4">Quý 4/2026 (01/10/2026 - 31/12/2026)</option>
            </select>
          </div>

          <button
            type="button"
            className="misa-btn-secondary"
            style={{ display: "inline-flex", alignItems: "center", gap: 6, height: 32, fontSize: 12.5 }}
            onClick={() => setShowAdvisorModal(true)}
          >
            <Sparkles size={15} style={{ color: "#8b5cf6" }} />
            <span>Phân tích dòng tiền</span>
          </button>

          <button
            type="button"
            className="misa-btn-secondary"
            style={{ display: "inline-flex", alignItems: "center", gap: 6, height: 32, fontSize: 12.5 }}
            onClick={async (event) => { try { await exportVisibleTable(event.currentTarget, "kế hoạch dòng tiền ra tệp Excel"); } catch (cause) { notify?.(cause instanceof Error ? cause.message : "Không thực hiện được thao tác."); } }}
          >
            <FileSpreadsheet size={15} style={{ color: "var(--brand)" }} />
            <span>Xuất khẩu Excel</span>
          </button>

          <button
            type="button"
            className="misa-btn-primary"
            style={{ display: "inline-flex", alignItems: "center", gap: 6, height: 32, fontSize: 12.5 }}
            onClick={() => setShowAddModal(true)}
          >
            <Plus size={15} />
            <span>Thêm khoản dự kiến</span>
          </button>
        </div>
      </header>

      {/* 2. KPI Cards */}
      <div className="misa-forecast-kpis">
        <div className="misa-forecast-kpi-card">
          <div className="misa-forecast-kpi-icon" style={{ background: "#f0fdf4", color: "var(--brand)", border: "1px solid #bbf7d0" }}>
            <Coins size={22} />
          </div>
          <div className="misa-forecast-kpi-info">
            <span>Tiền mặt hiện có (25/09)</span>
            <strong>{formatVND(startingBalance)} đ</strong>
            <small>Sẵn sàng chi trả tức thì</small>
          </div>
        </div>

        <div className="misa-forecast-kpi-card">
          <div className="misa-forecast-kpi-icon" style={{ background: "#eff6ff", color: "var(--brand)", border: "1px solid #bfdbfe" }}>
            <TrendingUp size={22} />
          </div>
          <div className="misa-forecast-kpi-info">
            <span>Dự kiến thu tiền (+)</span>
            <strong style={{ color: "var(--brand)" }}>+{formatVND(totalIn)} đ</strong>
            <small>{items.filter((i) => i.kind === "in").length} khoản thu (HĐ bán lẻ + nợ KH)</small>
          </div>
        </div>

        <div className="misa-forecast-kpi-card">
          <div className="misa-forecast-kpi-icon" style={{ background: "#fff1f2", color: "#e11d48", border: "1px solid #fecdd3" }}>
            <TrendingDown size={22} />
          </div>
          <div className="misa-forecast-kpi-info">
            <span>Dự kiến chi tiền (-)</span>
            <strong style={{ color: "#ea580c" }}>-{formatVND(totalOut)} đ</strong>
            <small>{items.filter((i) => i.kind === "out").length} khoản chi (Lương + Thuế + BHXH)</small>
          </div>
        </div>

        <div className="misa-forecast-kpi-card" style={{ background: "#ecfdf5", borderColor: "#a7f3d0" }}>
          <div className="misa-forecast-kpi-icon" style={{ background: "var(--brand)", color: "#ffffff" }}>
            <ShieldCheck size={22} />
          </div>
          <div className="misa-forecast-kpi-info">
            <span>Dự báo tồn quỹ cuối kỳ (25/10)</span>
            <strong style={{ color: "#065f46" }}>{formatVND(finalBalance)} đ</strong>
            <small style={{ color: "#059669", fontWeight: 600 }}>
              ✓ An toàn thanh khoản (Thấp nhất: {formatVND(minBalance)}đ)
            </small>
          </div>
        </div>
      </div>

      {/* 3. AVA Smart Advisor Banner */}
      <div className="misa-forecast-advisor">
        <div className="misa-forecast-advisor-icon">
          <Sparkles size={20} />
        </div>
        <div className="misa-forecast-advisor-body" style={{ flex: 1 }}>
          <h4>
            <span>Nhận định & Khuyến nghị quản trị dòng tiền:</span>
            <span style={{ fontSize: 11, background: "#dcfce7", color: "#15803d", padding: "1px 6px", borderRadius: 4 }}>
              Độ tin cậy 96%
            </span>
          </h4>
          <p>
            Quỹ tiền mặt duy trì khả năng thanh khoản an toàn trong suốt 30 ngày tới. Điểm trũng tồn quỹ thấp nhất là <strong>{formatVND(minBalance)} đ</strong>, cao hơn định mức an toàn tối thiểu (25.000.000 đ). Các mốc chi tập trung lớn: Ngày <strong>05/10</strong> (chi tạm ứng lương 20.000.000 đ) và Ngày <strong>20/10</strong> (nộp thuế tạm tính quý 3: 15.800.000 đ). Đề xuất ưu tiên đôn đốc Công ty Hoàng Gia thu hồi nợ 25.000.000 đ đúng hạn ngày 28/09.
          </p>
        </div>
        <button
          type="button"
          className="misa-btn-secondary"
          style={{ height: 28, fontSize: 11.5, background: "#ffffff", borderColor: "#86efac", color: "#15803d" }}
          onClick={() => setShowAdvisorModal(true)}
        >
          Xem chi tiết phân tích
        </button>
      </div>

      {/* 4. Interactive Timeline & Bar Chart */}
      <div className="misa-forecast-chart-card">
        <div className="misa-forecast-chart-header">
          <div>
            <h3>Biểu đồ biến động dòng tiền và số dư quỹ tiền mặt dự báo (30 ngày tới)</h3>
            <span style={{ fontSize: 12, color: "#64748b" }}>
              Đơn vị: VNĐ — Tồn đầu kỳ: {formatVND(startingBalance)} đ | Định mức an toàn tối thiểu: {formatVND(safetyThreshold)} đ
            </span>
          </div>

          <div className="misa-monthly-chart-legend">
            <div className="misa-monthly-legend-item">
              <span className="misa-legend-color" style={{ background: "var(--brand)" }} />
              <span>Tiền thu vào (+)</span>
            </div>
            <div className="misa-monthly-legend-item">
              <span className="misa-legend-color" style={{ background: "#ef4444" }} />
              <span>Tiền chi ra (-)</span>
            </div>
            <div className="misa-monthly-legend-item">
              <span className="misa-legend-color" style={{ background: "var(--brand)" }} />
              <span>Số dư quỹ dự báo</span>
            </div>
          </div>
        </div>

        <div className="misa-forecast-timeline-bars">
          {/* Safety line */}
          <div
            className="misa-forecast-safety-line"
            style={{ bottom: `${Math.round((safetyThreshold / 160000000) * 100)}%` }}
          >
            <span className="misa-forecast-safety-label">
              Ngưỡng tồn quỹ an toàn: 25.000.000 đ
            </span>
          </div>

          {timelineData.map((d) => {
            const maxVal = 160000000;
            const inH = d.kind === "in" ? Math.min(100, Math.round((d.amount / maxVal) * 100)) : 0;
            const outH = d.kind === "out" ? Math.min(100, Math.round((d.amount / maxVal) * 100)) : 0;
            const balH = Math.min(100, Math.round((d.balanceAfter / maxVal) * 100));

            return (
              <div
                key={d.id}
                className="misa-forecast-col-group"
                title={`${d.date} — ${d.category}\n${d.kind === "in" ? "Thu: +" : "Chi: -"}${formatVND(d.amount)}đ\nSố dư quỹ sau phát sinh: ${formatVND(d.balanceAfter)}đ\nKhả năng xảy ra: ${d.probability}%`}
              >
                <div className="misa-forecast-col-bars">
                  {d.kind === "in" && <div className="misa-fbar-in" style={{ height: `${Math.max(14, inH * 2.8)}px` }} />}
                  {d.kind === "out" && <div className="misa-fbar-out" style={{ height: `${Math.max(14, outH * 2.8)}px` }} />}
                  <div className="misa-fbar-balance" style={{ height: `${Math.max(20, balH * 1.1)}px` }} />
                </div>
                <span className="misa-forecast-col-date">{d.date.slice(0, 5)}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. Detailed Schedule Table */}
      <div className="misa-forecast-table-card">
        <div className="misa-forecast-table-toolbar">
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            <h3 style={{ margin: 0, fontSize: 14, fontWeight: 700, color: "#1e293b" }}>
              Bảng kế hoạch thu - chi tiền mặt chi tiết ({filteredItems.length} khoản)
            </h3>

            <div className="misa-reports-search-box" style={{ width: 230, height: 30 }}>
              <Search size={14} />
              <input
                type="text"
                placeholder="Tìm khoản thu, chi, đối tác..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{ fontSize: 12.5 }}
              />
            </div>
          </div>

          <div className="misa-reports-filter-chips">
            <button
              className={`misa-reports-chip ${typeFilter === "all" ? "active" : ""}`}
              onClick={() => setTypeFilter("all")}
            >
              Tất cả ({timelineData.length})
            </button>
            <button
              className={`misa-reports-chip ${typeFilter === "in" ? "active" : ""}`}
              onClick={() => setTypeFilter("in")}
            >
              Tiền thu (+{formatVND(totalIn)})
            </button>
            <button
              className={`misa-reports-chip ${typeFilter === "out" ? "active" : ""}`}
              onClick={() => setTypeFilter("out")}
            >
              Tiền chi (-{formatVND(totalOut)})
            </button>
            <button
              className={`misa-reports-chip ${typeFilter === "sure" ? "active" : ""}`}
              onClick={() => setTypeFilter("sure")}
            >
              Chắc chắn 100%
            </button>
          </div>
        </div>

        <table className="misa-report-data-table">
          <thead>
            <tr>
              <th style={{ width: 40, textAlign: "center" }}>STT</th>
              <th style={{ width: 90 }}>Ngày dự kiến</th>
              <th>Nội dung / Hạng mục dòng tiền</th>
              <th style={{ width: 180 }}>Đối tác / Đơn vị</th>
              <th style={{ width: 170 }}>Căn cứ chứng từ</th>
              <th style={{ width: 125, textAlign: "right" }}>Dự kiến Thu (+)</th>
              <th style={{ width: 125, textAlign: "right" }}>Dự kiến Chi (-)</th>
              <th style={{ width: 135, textAlign: "right" }}>Dự báo tồn quỹ</th>
              <th style={{ width: 100, textAlign: "center" }}>Mức độ khả thi</th>
              <th style={{ width: 50, textAlign: "center" }}>Xóa</th>
            </tr>
          </thead>
          <tbody>
            {filteredItems.map((item, idx) => {
              return (
                <tr key={item.id}>
                  <td style={{ textAlign: "center" }}>{idx + 1}</td>
                  <td style={{ textAlign: "center", fontWeight: 600, color: "#1e293b" }}>{item.date}</td>
                  <td>
                    <strong>{item.category}</strong>
                  </td>
                  <td>{item.partner}</td>
                  <td style={{ color: "#64748b", fontSize: 12 }}>{item.documentRef}</td>
                  <td style={{ textAlign: "right", color: item.kind === "in" ? "var(--brand)" : "#94a3b8", fontWeight: item.kind === "in" ? 700 : 400 }}>
                    {item.kind === "in" ? `+${formatVND(item.amount)}` : "-"}
                  </td>
                  <td style={{ textAlign: "right", color: item.kind === "out" ? "#ea580c" : "#94a3b8", fontWeight: item.kind === "out" ? 700 : 400 }}>
                    {item.kind === "out" ? `-${formatVND(item.amount)}` : "-"}
                  </td>
                  <td style={{ textAlign: "right", fontWeight: 700, color: item.balanceAfter >= safetyThreshold ? "#0f172a" : "#dc2626" }}>
                    {formatVND(item.balanceAfter)}
                  </td>
                  <td style={{ textAlign: "center" }}>
                    <span
                      className={`misa-forecast-prob-badge ${item.probability === 100
                        ? "misa-forecast-prob-100"
                        : item.probability >= 85
                          ? "misa-forecast-prob-high"
                          : "misa-forecast-prob-medium"
                        }`}
                    >
                      {item.probability}% {item.probability === 100 ? "✓" : ""}
                    </span>
                  </td>
                  <td style={{ textAlign: "center" }}>
                    <button
                      type="button"
                      onClick={() => handleDeleteItem(item.id)}
                      style={{ background: "none", border: "none", color: "#94a3b8", cursor: "pointer", padding: 4 }}
                      title="Xóa khỏi kế hoạch"
                    >
                      <Trash2 size={13} />
                    </button>
                  </td>
                </tr>
              );
            })}

            {/* Dòng tổng kết */}
            <tr style={{ background: "#ecfdf5", fontWeight: 800, fontSize: 13 }}>
              <td colSpan={5} style={{ textAlign: "left", paddingLeft: 14, color: "#065f46" }}>
                <strong>TỔNG HỢP KẾ HOẠCH DÒNG TIỀN (30 NGÀY TỚI):</strong>
              </td>
              <td style={{ textAlign: "right", color: "var(--brand)" }}>+{formatVND(totalIn)}</td>
              <td style={{ textAlign: "right", color: "#ea580c" }}>-{formatVND(totalOut)}</td>
              <td style={{ textAlign: "right", color: "#065f46", fontSize: 14 }}>{formatVND(finalBalance)}</td>
              <td colSpan={2} style={{ textAlign: "center", color: "#059669", fontSize: 11.5 }}>
                Dòng tiền ròng: +{formatVND(netCashflow)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* 6. Modal Thêm khoản dự kiến */}
      {showAddModal && (
        <div className="misa-modal-backdrop" onClick={() => setShowAddModal(false)}>
          <div
            className="misa-modal-box"
            style={{ width: 520, maxWidth: "90vw" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="misa-modal-header">
              <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, display: "flex", alignItems: "center", gap: 8 }}>
                <Plus size={18} style={{ color: "var(--brand)" }} />
                <span>Thêm khoản dự kiến thu / chi tiền mặt</span>
              </h3>
              <button
                type="button"
                className="misa-tax-icon-btn"
                onClick={() => setShowAddModal(false)}
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleAddItem} style={{ padding: 20 }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
                <div>
                  <label style={{ display: "block", fontSize: 12.5, fontWeight: 600, marginBottom: 6, color: "#334155" }}>
                    Loại dòng tiền
                  </label>
                  <select
                    value={newItem.kind}
                    onChange={(e) => setNewItem({ ...newItem, kind: e.target.value as "in" | "out" })}
                    style={{ width: "100%", height: 34, borderRadius: 6, border: "1px solid #cbd5e1", padding: "0 8px", fontSize: 13 }}
                  >
                    <option value="in">Tiền thu vào (+)</option>
                    <option value="out">Tiền chi ra (-)</option>
                  </select>
                </div>

                <div>
                  <label style={{ display: "block", fontSize: 12.5, fontWeight: 600, marginBottom: 6, color: "#334155" }}>
                    Ngày dự kiến phát sinh
                  </label>
                  <input
                    type="date"
                    value={newItem.date}
                    onChange={(e) => setNewItem({ ...newItem, date: e.target.value })}
                    style={{ width: "100%", height: 34, borderRadius: 6, border: "1px solid #cbd5e1", padding: "0 8px", fontSize: 13 }}
                    required
                  />
                </div>
              </div>

              <div style={{ marginBottom: 14 }}>
                <label style={{ display: "block", fontSize: 12.5, fontWeight: 600, marginBottom: 6, color: "#334155" }}>
                  Hạng mục thu / chi
                </label>
                <input
                  type="text"
                  placeholder="Ví dụ: Thu tiền bán hàng theo hợp đồng, Chi mua văn phòng phẩm..."
                  value={newItem.category}
                  onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
                  style={{ width: "100%", height: 34, borderRadius: 6, border: "1px solid #cbd5e1", padding: "0 10px", fontSize: 13 }}
                  required
                />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }}>
                <div>
                  <label style={{ display: "block", fontSize: 12.5, fontWeight: 600, marginBottom: 6, color: "#334155" }}>
                    Đối tác / Khách hàng / NCC
                  </label>
                  <input
                    type="text"
                    placeholder="Tên công ty hoặc người nộp/nhận..."
                    value={newItem.partner}
                    onChange={(e) => setNewItem({ ...newItem, partner: e.target.value })}
                    style={{ width: "100%", height: 34, borderRadius: 6, border: "1px solid #cbd5e1", padding: "0 10px", fontSize: 13 }}
                    required
                  />
                </div>

                <div>
                  <label style={{ display: "block", fontSize: 12.5, fontWeight: 600, marginBottom: 6, color: "#334155" }}>
                    Số tiền dự kiến (VNĐ)
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={formatMoneyInput(newItem.amount)}
                    onChange={(e) => setNewItem({ ...newItem, amount: parseMoneyInput(e.target.value) })}
                    style={{ width: "100%", height: 34, borderRadius: 6, border: "1px solid #cbd5e1", padding: "0 10px", fontSize: 13 }}
                    required
                  />
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 20 }}>
                <div>
                  <label style={{ display: "block", fontSize: 12.5, fontWeight: 600, marginBottom: 6, color: "#334155" }}>
                    Căn cứ chứng từ / Hợp đồng
                  </label>
                  <input
                    type="text"
                    placeholder="Số hóa đơn, hợp đồng hoặc quyết định..."
                    value={newItem.documentRef}
                    onChange={(e) => setNewItem({ ...newItem, documentRef: e.target.value })}
                    style={{ width: "100%", height: 34, borderRadius: 6, border: "1px solid #cbd5e1", padding: "0 10px", fontSize: 13 }}
                  />
                </div>

                <div>
                  <label style={{ display: "block", fontSize: 12.5, fontWeight: 600, marginBottom: 6, color: "#334155" }}>
                    Mức độ khả thi (%)
                  </label>
                  <select
                    value={newItem.probability}
                    onChange={(e) => setNewItem({ ...newItem, probability: Number(e.target.value) })}
                    style={{ width: "100%", height: 34, borderRadius: 6, border: "1px solid #cbd5e1", padding: "0 8px", fontSize: 13 }}
                  >
                    <option value={100}>100% - Chắc chắn (Cam kết/Quy định)</option>
                    <option value={90}>90% - Rất cao (Đã xác nhận thanh toán)</option>
                    <option value={85}>85% - Khả năng cao (Theo hạn nợ HĐ)</option>
                    <option value={70}>70% - Dự kiến (Đang đàm phán)</option>
                  </select>
                </div>
              </div>

              <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, paddingTop: 14, borderTop: "1px solid #e2e8f0" }}>
                <button
                  type="button"
                  className="misa-btn-secondary"
                  onClick={() => setShowAddModal(false)}
                >
                  Hủy bỏ
                </button>
                <button type="submit" className="misa-btn-primary">
                  Lưu vào kế hoạch dòng tiền
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 7. Modal Phân tích dòng tiền dòng tiền */}
      {showAdvisorModal && (
        <div className="misa-modal-backdrop" onClick={() => setShowAdvisorModal(false)}>
          <div
            className="misa-modal-box"
            style={{ width: 640, maxWidth: "92vw" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="misa-modal-header">
              <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, display: "flex", alignItems: "center", gap: 8 }}>
                <Sparkles size={18} style={{ color: "#8b5cf6" }} />
                <span>Báo cáo phân tích & dự báo thanh khoản dòng tiền</span>
              </h3>
              <button
                type="button"
                className="misa-tax-icon-btn"
                onClick={() => setShowAdvisorModal(false)}
              >
                <X size={16} />
              </button>
            </div>

            <div style={{ padding: 22 }}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 18 }}>
                <div style={{ background: "#f8fafc", padding: 12, borderRadius: 6, border: "1px solid #e2e8f0" }}>
                  <div style={{ fontSize: 11.5, color: "#64748b" }}>Tồn quỹ thấp nhất</div>
                  <strong style={{ fontSize: 17, color: "var(--brand)" }}>{formatVND(minBalance)} đ</strong>
                  <div style={{ fontSize: 11, color: "var(--brand)" }}>Vào ngày 08/10/2026</div>
                </div>
                <div style={{ background: "#f8fafc", padding: 12, borderRadius: 6, border: "1px solid #e2e8f0" }}>
                  <div style={{ fontSize: 11.5, color: "#64748b" }}>Hệ số an toàn dòng tiền</div>
                  <strong style={{ fontSize: 17, color: "var(--brand)" }}>3.87x</strong>
                  <div style={{ fontSize: 11, color: "#64748b" }}>Trên định mức tối thiểu</div>
                </div>
                <div style={{ background: "#f8fafc", padding: 12, borderRadius: 6, border: "1px solid #e2e8f0" }}>
                  <div style={{ fontSize: 11.5, color: "#64748b" }}>Dòng tiền thuần (Net)</div>
                  <strong style={{ fontSize: 17, color: "var(--brand)" }}>+{formatVND(netCashflow)} đ</strong>
                  <div style={{ fontSize: 11, color: "var(--brand)" }}>Thặng dư tiền mặt</div>
                </div>
              </div>

              <h4 style={{ margin: "0 0 8px 0", fontSize: 13.5, color: "#0f172a" }}>
                3 Điểm lưu ý trọng yếu về thanh khoản:
              </h4>
              <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13, color: "#334155", display: "flex", flexDirection: "column", gap: 8, lineHeight: 1.45 }}>
                <li>
                  <strong>Tập trung thu hồi nợ ngày 28/09:</strong> Khoản nợ 25.000.000 đ từ Công ty Hoàng Gia là nguồn tiền then chốt để phục vụ chi trả lương đầu tháng 10. Kế toán nên gửi thông báo nhắc nợ sớm trước 2 ngày.
                </li>
                <li>
                  <strong>Dự phòng chi nộp thuế quý 3 ngày 20/10:</strong> Doanh nghiệp dự kiến nộp 15.800.000 đ thuế GTGT & TNDN. Quỹ tiền mặt hoàn toàn đủ năng lực chi trả mà không cần rút thêm tiền gửi ngân hàng.
                </li>
                <li>
                  <strong>Tối ưu hóa lãi suất tiền gửi:</strong> Tồn quỹ cuối kỳ dự kiến đạt 121.600.000 đ, vượt xa định mức an toàn 25.000.000 đ. Đề xuất chuyển 50.000.000 đ từ quỹ tiền mặt sang tiền gửi ngân hàng có kỳ hạn ngắn (1 tháng) để sinh lời.
                </li>
              </ul>

              <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 22, paddingTop: 14, borderTop: "1px solid #e2e8f0" }}>
                <button
                  type="button"
                  className="misa-btn-primary"
                  onClick={() => setShowAdvisorModal(false)}
                >
                  Đã ghi nhận khuyến nghị
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------
// 4A. PAYMENT REQUESTS TAB ("Đề nghị chi tiền")
// ----------------------------------------------------------------------
export type PaymentRequestDoc = {
  id: string;
  code: string;
  date: string;
  requester: string;
  dept: string;
  beneficiary?: string;
  paymentMethod?: string;
  purpose: string;
  amount: number;
  status: "pending" | "approved" | "paid" | "rejected";
  voucherCode: string;
  branchId?: string;
};

export function PaymentRequestsTab({
  notify,
  onOpenCreatePayment,
}: {
  notify: (msg: string) => void;
  onOpenCreatePayment: () => void;
}) {
  const { token, companyId: sessionCompanyId } = useApiSession();
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [branchScope, setBranchScope] = useState<string>(() => resolveActiveBranchScope());
  const [requests, setRequests] = useState<PaymentRequestDoc[]>([
    {
      id: "dnc-01",
      code: "ĐNC00012",
      date: "18/12/2026",
      requester: "Nguyễn Văn Hải",
      dept: "Phòng Kinh doanh",
      beneficiary: "Công ty CP Minh Khang",
      paymentMethod: "Tiền mặt",
      purpose: "Chi tiếp khách đoàn đối tác Công ty CP Minh Khang ký kết HĐ",
      amount: 4500000,
      status: "approved",
      voucherCode: "",
    },
    {
      id: "dnc-02",
      code: "ĐNC00011",
      date: "15/12/2026",
      requester: "Lê Hoàng Yến",
      dept: "Phòng Hành chính - Nhân sự",
      beneficiary: "Công ty VPP Hồng Hà",
      paymentMethod: "Tiền mặt",
      purpose: "Mua văn phòng phẩm và vật dụng tiêu hao quý 4/2026",
      amount: 3200000,
      status: "paid",
      voucherCode: "PC00004",
    },
    {
      id: "dnc-03",
      code: "ĐNC00010",
      date: "12/12/2026",
      requester: "Trần Quốc Tuấn",
      dept: "Phòng Kỹ thuật",
      beneficiary: "Trung tâm Kỹ thuật Điện lạnh",
      paymentMethod: "Tiền mặt",
      purpose: "Bảo dưỡng sửa chữa đột xuất hệ thống máy in và điều hòa",
      amount: 5800000,
      status: "pending",
      voucherCode: "",
    },
    {
      id: "dnc-04",
      code: "ĐNC00009",
      date: "10/12/2026",
      requester: "Phạm Hải Đăng",
      dept: "Ban Giám đốc",
      beneficiary: "Phạm Hải Đăng",
      paymentMethod: "Chuyển khoản",
      purpose: "Chi phí công tác phí dự hội thảo chuyển đổi số tại TP.HCM",
      amount: 12000000,
      status: "approved",
      voucherCode: "",
    },
    {
      id: "dnc-05",
      code: "ĐNC00008",
      date: "05/12/2026",
      requester: "Vũ Thị Mai",
      dept: "Phòng Kế toán",
      beneficiary: "Ngân hàng TMCP Ngoại thương",
      paymentMethod: "Tiền mặt",
      purpose: "Chi nộp phí dịch vụ ngân hàng và chứng thư số điện tử",
      amount: 1540000,
      status: "paid",
      voucherCode: "PC00002",
    },
  ]);

  const [editingDoc, setEditingDoc] = useState<PaymentRequestDoc | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<"view" | "edit">("view");
  const [searchParams, setSearchParams] = useSearchParams();
  const dismissedOpenDocRef = useRef<string | null>(null);

  const clearOpenDocParam = () => {
    const cur = searchParams.get("openDoc");
    if (cur) {
      dismissedOpenDocRef.current = cur;
      const next = new URLSearchParams(searchParams);
      next.delete("openDoc");
      setSearchParams(next, { replace: true });
    }
  };

  useEffect(() => {
    const openDocParam = searchParams.get("openDoc");
    if (!openDocParam) {
      dismissedOpenDocRef.current = null;
      return;
    }
    if (requests.length === 0) return;
    if (dismissedOpenDocRef.current === openDocParam) return;
    const matched =
      requests.find(
        (r) =>
          r.code.toLowerCase() === openDocParam.toLowerCase() ||
          r.id.toLowerCase() === openDocParam.toLowerCase(),
      ) ||
      (openDocParam === "pending" ? requests.find((r) => r.status === "pending") : undefined);
    if (matched) {
      setEditingDoc({ ...matched });
      setModalMode("view");
      setIsModalOpen(true);
    }
  }, [searchParams, requests]);

  useEffect(() => {
    const handleOpenNotif = (ev: Event) => {
      const detail = (ev as CustomEvent)?.detail || {};
      if (detail.notifTarget && detail.notifTarget !== "payment-requests") return;
      dismissedOpenDocRef.current = null;
      const targetKey = String(detail.openDoc || detail.code || "pending").toLowerCase();
      const matched =
        requests.find(
          (r) =>
            r.code.toLowerCase() === targetKey ||
            r.id.toLowerCase() === targetKey,
        ) ||
        (targetKey === "pending" ? requests.find((r) => r.status === "pending") : undefined);
      if (matched) {
        setEditingDoc({ ...matched });
        setModalMode("view");
        setIsModalOpen(true);
      }
    };
    window.addEventListener("sv_open_voucher_notif", handleOpenNotif);
    return () => window.removeEventListener("sv_open_voucher_notif", handleOpenNotif);
  }, [requests]);

  const effectiveCompanyId = useMemo(() => {
    const urlComp = searchParams.get("company");
    if (urlComp) return urlComp;
    try {
      return localStorage.getItem("ref_company_id") || sessionCompanyId || "";
    } catch {
      return sessionCompanyId || "";
    }
  }, [searchParams, sessionCompanyId]);

  useEffect(() => {
    const onCtxChange = () => setBranchScope(resolveActiveBranchScope());
    window.addEventListener("erp_context_changed", onCtxChange);
    window.addEventListener("popstate", onCtxChange);
    return () => {
      window.removeEventListener("erp_context_changed", onCtxChange);
      window.removeEventListener("popstate", onCtxChange);
    };
  }, []);

  useEffect(() => {
    if (!token || !effectiveCompanyId) return;
    let active = true;
    const branchParam = branchScope && branchScope !== "all" ? `&branch_id=${encodeURIComponent(branchScope)}` : "";
    request<{ docs?: PaymentRequestDoc[]; results?: PaymentRequestDoc[] }>(
      `/api/v1/cash/payment-requests/?company_id=${encodeURIComponent(effectiveCompanyId)}${branchParam}`,
      token,
    )
      .then((res) => {
        if (!active) return;
        const list = res?.docs || res?.results;
        if (Array.isArray(list) && list.length > 0) {
          setRequests(list);
        }
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [token, effectiveCompanyId, branchScope]);

  useEffect(() => {
    try {
      localStorage.setItem("sv_pr_docs_sync", JSON.stringify(requests));
      window.dispatchEvent(new CustomEvent("sv_vouchers_updated", { detail: { type: "pr", docs: requests } }));
    } catch {}
  }, [requests]);

  const persistDoc = async (doc: PaymentRequestDoc, successMsg: string) => {
    clearOpenDocParam();
    try {
      const rawMap = localStorage.getItem("sv_voucher_status_overrides");
      const map = rawMap ? JSON.parse(rawMap) : {};
      map[doc.code] = {
        status: doc.status,
        voucherCode: doc.voucherCode || "",
        revertedUnread: doc.status === "pending",
      };
      localStorage.setItem("sv_voucher_status_overrides", JSON.stringify(map));
    } catch {}
    setRequests((prev) => {
      const idx = prev.findIndex((item) => item.id === doc.id || item.code === doc.code);
      const next = idx >= 0 ? prev.map((item, i) => (i === idx ? doc : item)) : [doc, ...prev];
      try {
        localStorage.setItem("sv_pr_docs_sync", JSON.stringify(next));
      } catch {}
      return next;
    });
    if (token && effectiveCompanyId) {
      const branchParam = branchScope && branchScope !== "all" ? `&branch_id=${encodeURIComponent(branchScope)}` : "";
      try {
        const res = await request<{ docs?: PaymentRequestDoc[] }>(
          `/api/v1/cash/payment-requests/?company_id=${encodeURIComponent(effectiveCompanyId)}${branchParam}`,
          token,
          {
            method: "POST",
            body: JSON.stringify({ doc }),
          },
        );
        if (Array.isArray(res?.docs)) {
          setRequests(res.docs);
        }
      } catch {}
    }
    window.dispatchEvent(new CustomEvent("sv_vouchers_updated", { detail: { type: "pr", doc } }));
    notify(successMsg);
  };

  const openNewModal = () => {
    const nextNum = requests.length + 13;
    setEditingDoc({
      id: `dnc-${Date.now()}`,
      code: `ĐNC${String(nextNum).padStart(5, "0")}`,
      date: "20/12/2026",
      requester: "Đỗ Đức Tùng",
      dept: "Phòng Kế toán",
      beneficiary: "Công ty TNHH Giải pháp Số Việt",
      paymentMethod: "Tiền mặt",
      purpose: "Chi thanh toán chi phí dịch vụ vận hành văn phòng tháng 12/2026",
      amount: 6500000,
      status: "pending",
      voucherCode: "",
      branchId: branchScope !== "all" ? branchScope : undefined,
    });
    setModalMode("edit");
    setIsModalOpen(true);
  };

  const filtered = requests.filter((r) => {
    const matchSearch =
      !search ||
      r.code.toLowerCase().includes(search.toLowerCase()) ||
      r.requester.toLowerCase().includes(search.toLowerCase()) ||
      r.purpose.toLowerCase().includes(search.toLowerCase()) ||
      (r.beneficiary || "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === "all" || r.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const kpiStats = useMemo(() => {
    const totalAmt = requests.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
    const pendingCount = requests.filter((r) => r.status === "pending").length;
    const approvedCount = requests.filter((r) => r.status === "approved").length;
    const paidCount = requests.filter((r) => r.status === "paid").length;
    return { totalAmt, pendingCount, approvedCount, paidCount };
  }, [requests]);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#f8fafc", padding: 14 }}>
      {/* KPI Header */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 14 }}>
        <div style={{ background: "#ffffff", padding: "12px 14px", borderRadius: 8, border: "1px solid #e2e8f0" }}>
          <div style={{ fontSize: 12, color: "#64748b", marginBottom: 4 }}>Tổng tiền đề nghị</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: "#0f172a" }}>{formatVND(kpiStats.totalAmt)} đ</div>
        </div>
        <div style={{ background: "#ffffff", padding: "12px 14px", borderRadius: 8, border: "1px solid #e2e8f0" }}>
          <div style={{ fontSize: 12, color: "#64748b", marginBottom: 4 }}>Chờ duyệt</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: "#f59e0b" }}>{kpiStats.pendingCount} đề nghị</div>
        </div>
        <div style={{ background: "#ffffff", padding: "12px 14px", borderRadius: 8, border: "1px solid #e2e8f0" }}>
          <div style={{ fontSize: 12, color: "#64748b", marginBottom: 4 }}>Đã duyệt (Chờ chi)</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: "var(--brand)" }}>{kpiStats.approvedCount} đề nghị</div>
        </div>
        <div style={{ background: "#ffffff", padding: "12px 14px", borderRadius: 8, border: "1px solid #e2e8f0" }}>
          <div style={{ fontSize: 12, color: "#64748b", marginBottom: 4 }}>Đã chi tiền</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: "var(--brand)" }}>{kpiStats.paidCount} đề nghị</div>
        </div>
      </div>

      {/* Toolbar */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, gap: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ position: "relative", width: 240 }}>
            <Search size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "#94a3b8" }} />
            <input
              type="text"
              placeholder="Tìm theo số đề nghị, người lập, nội dung..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{
                width: "100%",
                height: 32,
                paddingLeft: 30,
                paddingRight: 10,
                fontSize: 12.5,
                border: "1px solid #d1d5db",
                borderRadius: 6,
                outline: "none",
              }}
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            style={{
              height: 32,
              padding: "0 10px",
              border: "1px solid #d1d5db",
              borderRadius: 6,
              fontSize: 12.5,
              background: "#ffffff",
              cursor: "pointer",
            }}
          >
            <option value="all">Tất cả trạng thái</option>
            <option value="pending">Chờ duyệt</option>
            <option value="approved">Đã duyệt (Chờ chi)</option>
            <option value="paid">Đã chi tiền</option>
            <option value="rejected">Từ chối</option>
          </select>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button
            type="button"
            className="misa-btn-primary"
            style={{ height: 34, padding: "0 14px", fontSize: 12.5, fontWeight: 600, background: "var(--brand)", color: "#ffffff", border: "1px solid var(--brand)", borderRadius: 6, display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}
            onClick={openNewModal}
          >
            <Plus size={14} />
            Thêm đề nghị chi
          </button>
          <button
            type="button"
            className="misa-btn-secondary"
            style={{ height: 34, padding: "0 14px", fontSize: 12.5, fontWeight: 600, background: "#ffffff", color: "#1e293b", border: "1px solid #cbd5e1", borderRadius: 6, display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}
            onClick={onOpenCreatePayment}
          >
            Lập phiếu chi từ đề nghị
          </button>
        </div>
      </div>

      {/* Table */}
      <div style={{ flex: 1, overflowX: "auto", overflowY: "auto", background: "#ffffff", borderRadius: 8, border: "1px solid #e2e8f0" }}>
        <table className="misa-tax-table" style={{ width: "100%", minWidth: 1260, borderCollapse: "collapse", tableLayout: "auto" }}>
          <thead>
            <tr>
              <th style={{ width: 32, textAlign: "center" }}><input type="checkbox" aria-label="Chọn tất cả" /></th>
              <th style={{ whiteSpace: "nowrap" }}>Số / Ngày ĐN</th>
              <th style={{ whiteSpace: "nowrap" }}>Người đề nghị / Bộ phận</th>
              <th>Nội dung chi</th>
              <th className="numeric" style={{ whiteSpace: "nowrap" }}>Số tiền đề nghị</th>
              <th style={{ textAlign: "center", whiteSpace: "nowrap" }}>Trạng thái</th>
              <th style={{ whiteSpace: "nowrap" }}>Chứng từ chi</th>
              <th style={{ textAlign: "center", whiteSpace: "nowrap" }}>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <tr key={r.id}>
                <td style={{ textAlign: "center" }}><input type="checkbox" aria-label={`Chọn ${r.code}`} /></td>
                <td style={{ whiteSpace: "nowrap" }}>
                  <strong
                    style={{ color: "var(--brand)", cursor: "pointer", textDecoration: "underline", textUnderlineOffset: 2 }}
                    onClick={() => {
                      setEditingDoc({ ...r });
                      setModalMode("view");
                      setIsModalOpen(true);
                    }}
                  >
                    {r.code}
                  </strong>
                  <div style={{ fontSize: 11.5, color: "#64748b", marginTop: 1 }}>{r.date}</div>
                </td>
                <td style={{ whiteSpace: "nowrap" }}>
                  <strong>{r.requester}</strong>
                  <div style={{ fontSize: 11.5, color: "#64748b", marginTop: 1 }}>{r.dept}</div>
                </td>
                <td style={{ whiteSpace: "normal", lineHeight: 1.45, color: "#1e293b", padding: "9px 10px" }}>
                  <div>{r.purpose}</div>
                  {r.beneficiary && (
                    <div style={{ fontSize: 11.5, color: "#64748b", marginTop: 2 }}>
                      Đơn vị nhận: <strong style={{ fontWeight: 600, color: "#475569" }}>{r.beneficiary}</strong> · {r.paymentMethod || "Tiền mặt"}
                    </div>
                  )}
                </td>
                <td className="numeric" style={{ whiteSpace: "nowrap" }}><strong>{formatVND(r.amount)} đ</strong></td>
                <td style={{ textAlign: "center", whiteSpace: "nowrap" }}>
                  {r.status === "paid" ? (
                    <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", minWidth: 96, background: "#dcfce7", color: "#15803d", padding: "4px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 600, whiteSpace: "nowrap" }}>Đã chi tiền</span>
                  ) : r.status === "approved" ? (
                    <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", minWidth: 96, background: "#e0f2fe", color: "var(--brand-hover)", padding: "4px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 600, whiteSpace: "nowrap" }}>Đã duyệt</span>
                  ) : r.status === "rejected" ? (
                    <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", minWidth: 96, background: "#fee2e2", color: "#b91c1c", padding: "4px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 600, whiteSpace: "nowrap" }}>Từ chối</span>
                  ) : (
                    <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", minWidth: 96, background: "#fef3c7", color: "#b45309", padding: "4px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 600, whiteSpace: "nowrap" }}>Chờ duyệt</span>
                  )}
                </td>
                <td style={{ whiteSpace: "nowrap" }}>
                  {r.voucherCode ? (
                    <strong
                      style={{ color: "var(--brand)", cursor: "pointer" }}
                      onClick={() => {
                        setEditingDoc({ ...r });
                        setModalMode("view");
                        setIsModalOpen(true);
                      }}
                    >
                      {r.voucherCode}
                    </strong>
                  ) : (
                    <span style={{ color: "#94a3b8" }}>-</span>
                  )}
                </td>
                <td style={{ textAlign: "center", whiteSpace: "nowrap", width: 224 }}>
                  <div style={{ display: "inline-flex", alignItems: "center", justifyContent: "flex-start", gap: 6, width: 210 }}>
                    <button
                      type="button"
                      onClick={() => {
                        setEditingDoc({ ...r });
                        setModalMode("view");
                        setIsModalOpen(true);
                      }}
                      style={{ width: 92, height: 26, display: "inline-flex", alignItems: "center", justifyContent: "center", padding: 0, fontSize: 11.5, fontWeight: 600, borderRadius: 5, border: "1px solid #cbd5e1", background: "#ffffff", color: "#334155", cursor: "pointer" }}
                    >
                      Xem chi tiết
                    </button>
                    {r.status === "pending" && (
                      <>
                        <button
                          type="button"
                          onClick={() => void persistDoc({ ...r, status: "approved" }, `✓ Đã phê duyệt đề nghị chi ${r.code}`)}
                          style={{ width: 53, height: 26, display: "inline-flex", alignItems: "center", justifyContent: "center", padding: 0, fontSize: 11.5, fontWeight: 600, borderRadius: 5, border: "1px solid var(--brand)", background: "#f0f9ff", color: "var(--brand-hover)", cursor: "pointer" }}
                        >
                          Duyệt
                        </button>
                        <button
                          type="button"
                          onClick={() => void persistDoc({ ...r, status: "rejected" }, `Đã từ chối đề nghị chi ${r.code}`)}
                          style={{ width: 53, height: 26, display: "inline-flex", alignItems: "center", justifyContent: "center", padding: 0, fontSize: 11.5, fontWeight: 600, borderRadius: 5, border: "1px solid #fca5a5", background: "#fef2f2", color: "#dc2626", cursor: "pointer" }}
                        >
                          Từ chối
                        </button>
                      </>
                    )}
                    {r.status === "approved" && (
                      <button
                        type="button"
                        onClick={() => {
                          const autoVoucher = r.paymentMethod === "Chuyển khoản" ? `UNC-${r.code.replace(/[^0-9]/g, "").slice(-4) || "001"}` : `PC-${r.code.replace(/[^0-9]/g, "").slice(-4) || "001"}`;
                          void persistDoc(
                            { ...r, status: "paid", voucherCode: autoVoucher },
                            `✓ Đã sinh chứng từ chi ${autoVoucher} từ đề nghị ${r.code}`,
                          );
                          onOpenCreatePayment();
                        }}
                        style={{ width: 112, height: 26, display: "inline-flex", alignItems: "center", justifyContent: "center", padding: 0, fontSize: 11.5, fontWeight: 600, borderRadius: 5, border: "1px solid #16a34a", background: "#f0fdf4", color: "#15803d", cursor: "pointer" }}
                      >
                        Lập phiếu chi
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal Xem chi tiết / Thêm / Sửa Giấy Đề Nghị Chi Tiền */}
      {isModalOpen && editingDoc && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            zIndex: 9999,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 16,
          }}
        >
          <div
            style={{
              width: "100%",
              maxWidth: 740,
              background: "#ffffff",
              borderRadius: 12,
              boxShadow: "0 20px 50px rgba(15,23,42,0.22)",
              overflow: "hidden",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "16px 22px", borderBottom: "1px solid #e2e8f0", background: "#f8fafc" }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: "#0f172a" }}>
                    Giấy đề nghị chi tiền — {editingDoc.code}
                  </h3>
                  {editingDoc.status === "paid" ? (
                    <span style={{ background: "#dcfce7", color: "#15803d", padding: "3px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 700 }}>Đã chi tiền</span>
                  ) : editingDoc.status === "approved" ? (
                    <span style={{ background: "#e0f2fe", color: "var(--brand-hover)", padding: "3px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 700 }}>Đã phê duyệt</span>
                  ) : editingDoc.status === "rejected" ? (
                    <span style={{ background: "#fee2e2", color: "#b91c1c", padding: "3px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 700 }}>Từ chối</span>
                  ) : (
                    <span style={{ background: "#fef3c7", color: "#b45309", padding: "3px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 700 }}>Chờ phê duyệt</span>
                  )}
                </div>
                <div style={{ fontSize: 12, color: "#64748b", marginTop: 3 }}>
                  Biểu mẫu đề nghị thanh toán nội bộ &amp; kiểm soát hạn mức chi quỹ (Thông tư 99/2025/TT-BTC)
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  clearOpenDocParam();
                  setIsModalOpen(false);
                }}
                style={{ border: "none", background: "transparent", cursor: "pointer", color: "#64748b" }}
              >
                <X size={18} />
              </button>
            </div>

            {modalMode === "view" ? (
              <div style={{ padding: "18px 22px" }}>
                {/* Tiến trình phê duyệt 3 bước */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 16 }}>
                  <div style={{ padding: "10px 12px", borderRadius: 8, background: "#f0fdf4", border: "1px solid #bbf7d0" }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: "#15803d", textTransform: "uppercase" }}>Bước 1 · Đã lập đề nghị</div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: "#0f172a", marginTop: 2 }}>{editingDoc.requester}</div>
                    <div style={{ fontSize: 11.5, color: "#64748b" }}>{editingDoc.dept} · {editingDoc.date}</div>
                  </div>
                  <div style={{ padding: "10px 12px", borderRadius: 8, background: editingDoc.status === "pending" ? "#fffbeb" : editingDoc.status === "rejected" ? "#fef2f2" : "#f0f9ff", border: `1px solid ${editingDoc.status === "pending" ? "#fde68a" : editingDoc.status === "rejected" ? "#fecaca" : "#bae6fd"}` }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: editingDoc.status === "pending" ? "#b45309" : editingDoc.status === "rejected" ? "#dc2626" : "var(--brand-hover)", textTransform: "uppercase" }}>
                      Bước 2 · {editingDoc.status === "pending" ? "Đang chờ phê duyệt" : editingDoc.status === "rejected" ? "Đã từ chối" : "Kế toán trưởng đã duyệt"}
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: "#0f172a", marginTop: 2 }}>
                      {editingDoc.status === "pending" ? "Chờ Kế toán trưởng / Giám đốc" : "Đỗ Đức Tùng (Kế toán trưởng)"}
                    </div>
                    <div style={{ fontSize: 11.5, color: "#64748b" }}>Kiểm soát ngân sách &amp; chứng từ gốc</div>
                  </div>
                  <div style={{ padding: "10px 12px", borderRadius: 8, background: editingDoc.status === "paid" ? "#f0fdf4" : "#f8fafc", border: `1px solid ${editingDoc.status === "paid" ? "#bbf7d0" : "#e2e8f0"}` }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: editingDoc.status === "paid" ? "#15803d" : "#64748b", textTransform: "uppercase" }}>
                      Bước 3 · {editingDoc.status === "paid" ? "Đã lập chứng từ chi" : "Chưa giải ngân"}
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: "#0f172a", marginTop: 2 }}>
                      {editingDoc.voucherCode ? `Chứng từ: ${editingDoc.voucherCode}` : "Chờ Thủ quỹ / Ngân hàng chi"}
                    </div>
                    <div style={{ fontSize: 11.5, color: "#64748b" }}>Hình thức: {editingDoc.paymentMethod || "Tiền mặt"}</div>
                  </div>
                </div>

                {/* Thông tin chi tiết đầy đủ */}
                <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 10, padding: 16, marginBottom: 16 }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px 24px", fontSize: 13 }}>
                    <div>
                      <span style={{ color: "#64748b", display: "block", fontSize: 11.5 }}>Số giấy đề nghị chi</span>
                      <strong style={{ color: "#0f172a", fontSize: 14 }}>{editingDoc.code}</strong>
                    </div>
                    <div>
                      <span style={{ color: "#64748b", display: "block", fontSize: 11.5 }}>Ngày lập đề nghị</span>
                      <strong style={{ color: "#0f172a", fontSize: 14 }}>{editingDoc.date}</strong>
                    </div>
                    <div>
                      <span style={{ color: "#64748b", display: "block", fontSize: 11.5 }}>Người đề nghị thanh toán</span>
                      <strong style={{ color: "#0f172a" }}>{editingDoc.requester}</strong>
                    </div>
                    <div>
                      <span style={{ color: "#64748b", display: "block", fontSize: 11.5 }}>Bộ phận / Đơn vị công tác</span>
                      <strong style={{ color: "#0f172a" }}>{editingDoc.dept}</strong>
                    </div>
                    <div>
                      <span style={{ color: "#64748b", display: "block", fontSize: 11.5 }}>Đơn vị / Cá nhân nhận tiền</span>
                      <strong style={{ color: "#0f172a" }}>{editingDoc.beneficiary || editingDoc.requester}</strong>
                    </div>
                    <div>
                      <span style={{ color: "#64748b", display: "block", fontSize: 11.5 }}>Phương thức chi trả &amp; Chứng từ</span>
                      <strong style={{ color: "var(--brand)" }}>
                        {editingDoc.paymentMethod || "Tiền mặt"} {editingDoc.voucherCode ? `· Mã CT: ${editingDoc.voucherCode}` : ""}
                      </strong>
                    </div>
                    <div style={{ gridColumn: "1 / -1", paddingTop: 6, borderTop: "1px dashed #cbd5e1" }}>
                      <span style={{ color: "#64748b", display: "block", fontSize: 11.5, marginBottom: 3 }}>Nội dung chi tiết khoản đề nghị thanh toán</span>
                      <div style={{ color: "#0f172a", fontWeight: 600, fontSize: 13.5, lineHeight: 1.5 }}>{editingDoc.purpose}</div>
                    </div>
                  </div>
                </div>

                {/* Bảng định khoản & chi tiết số tiền */}
                <div style={{ border: "1px solid #e2e8f0", borderRadius: 8, overflow: "hidden" }}>
                  <table className="misa-tax-table" style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                      <tr>
                        <th style={{ width: 42, textAlign: "center" }}>STT</th>
                        <th>Diễn giải chi tiết khoản chi</th>
                        <th style={{ width: 85, textAlign: "center" }}>TK Nợ</th>
                        <th style={{ width: 85, textAlign: "center" }}>TK Có</th>
                        <th className="numeric" style={{ width: 150 }}>Số tiền (VND)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td style={{ textAlign: "center" }}>1</td>
                        <td style={{ whiteSpace: "normal", lineHeight: 1.45 }}>{editingDoc.purpose}</td>
                        <td style={{ textAlign: "center", fontWeight: 600 }}>6422</td>
                        <td style={{ textAlign: "center", fontWeight: 600 }}>{editingDoc.paymentMethod === "Chuyển khoản" ? "1121" : "1111"}</td>
                        <td className="numeric" style={{ fontWeight: 700, color: "#0f172a" }}>{formatVND(editingDoc.amount)} đ</td>
                      </tr>
                    </tbody>
                    <tfoot>
                      <tr>
                        <td colSpan={4} style={{ textAlign: "right", fontWeight: 700 }}>Tổng số tiền đề nghị thanh toán:</td>
                        <td className="numeric" style={{ fontWeight: 800, color: "var(--brand)", fontSize: 14 }}>{formatVND(editingDoc.amount)} đ</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            ) : (
              <div style={{ padding: 20, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Số đề nghị *</label>
                  <input
                    type="text"
                    value={editingDoc.code}
                    onChange={(e) => setEditingDoc({ ...editingDoc, code: e.target.value })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13 }}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Ngày đề nghị *</label>
                  <input
                    type="text"
                    value={editingDoc.date}
                    onChange={(e) => setEditingDoc({ ...editingDoc, date: e.target.value })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13 }}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Người đề nghị *</label>
                  <input
                    type="text"
                    value={editingDoc.requester}
                    onChange={(e) => setEditingDoc({ ...editingDoc, requester: e.target.value })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13 }}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Bộ phận / Phòng ban *</label>
                  <input
                    type="text"
                    value={editingDoc.dept}
                    onChange={(e) => setEditingDoc({ ...editingDoc, dept: e.target.value })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13 }}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Đơn vị / Người nhận tiền</label>
                  <input
                    type="text"
                    value={editingDoc.beneficiary || ""}
                    onChange={(e) => setEditingDoc({ ...editingDoc, beneficiary: e.target.value })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13 }}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Hình thức thanh toán</label>
                  <select
                    value={editingDoc.paymentMethod || "Tiền mặt"}
                    onChange={(e) => setEditingDoc({ ...editingDoc, paymentMethod: e.target.value })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13, background: "#ffffff" }}
                  >
                    <option value="Tiền mặt">Tiền mặt (Phiếu chi)</option>
                    <option value="Chuyển khoản">Chuyển khoản (Ủy nhiệm chi)</option>
                  </select>
                </div>
                <div style={{ gridColumn: "1 / -1" }}>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Nội dung đề nghị chi *</label>
                  <input
                    type="text"
                    value={editingDoc.purpose}
                    onChange={(e) => setEditingDoc({ ...editingDoc, purpose: e.target.value })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13 }}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Số tiền đề nghị (VND) *</label>
                  <input
                    type="number"
                    value={editingDoc.amount}
                    onChange={(e) => setEditingDoc({ ...editingDoc, amount: Number(e.target.value) || 0 })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13, fontWeight: 700 }}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Trạng thái phê duyệt</label>
                  <select
                    value={editingDoc.status}
                    onChange={(e) => setEditingDoc({ ...editingDoc, status: e.target.value as PaymentRequestDoc["status"] })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13, background: "#ffffff" }}
                  >
                    <option value="pending">Chờ duyệt</option>
                    <option value="approved">Đã duyệt (Chờ chi)</option>
                    <option value="paid">Đã chi tiền</option>
                    <option value="rejected">Từ chối</option>
                  </select>
                </div>
              </div>
            )}

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, padding: "14px 22px", borderTop: "1px solid #e2e8f0", background: "#f8fafc" }}>
              <div style={{ display: "flex", gap: 8 }}>
                {modalMode === "view" && (
                  <>
                    <button
                      type="button"
                      className="misa-btn-secondary"
                      style={{ padding: "7px 14px", fontSize: 12.5, fontWeight: 600, background: "#ffffff", color: "var(--brand)", border: "1px solid #bae6fd", borderRadius: 6, cursor: "pointer" }}
                      onClick={() => setModalMode("edit")}
                    >
                      ✎ Chỉnh sửa thông tin
                    </button>
                    {(editingDoc.status === "approved" || editingDoc.status === "rejected") && (
                      <button
                        type="button"
                        className="misa-btn-secondary"
                        style={{ padding: "7px 14px", fontSize: 12.5, fontWeight: 600, background: "#fffbeb", color: "#b45309", border: "1px solid #fde68a", borderRadius: 6, cursor: "pointer" }}
                        onClick={() => {
                          const updated = { ...editingDoc, status: "pending" as const, voucherCode: "" };
                          setEditingDoc(updated);
                          void persistDoc(updated, `↺ Đã chuyển đề nghị chi ${editingDoc.code} về trạng thái Chờ duyệt`);
                        }}
                      >
                        ↺ Chuyển về Chờ duyệt
                      </button>
                    )}
                  </>
                )}
              </div>
              <div style={{ display: "flex", gap: 10 }}>
                <button
                  type="button"
                  className="misa-btn-secondary"
                  style={{ padding: "7px 14px", fontSize: 12.5, fontWeight: 600, background: "#ffffff", color: "#334155", border: "1px solid #cbd5e1", borderRadius: 6, cursor: "pointer" }}
                  onClick={() => {
                    clearOpenDocParam();
                    setIsModalOpen(false);
                  }}
                >
                  Đóng
                </button>
                {modalMode === "edit" ? (
                  <>
                    <button
                      type="button"
                      className="misa-btn-secondary"
                      style={{ padding: "7px 14px", fontSize: 12.5, fontWeight: 600, background: "#ffffff", color: "#0f172a", border: "1px solid #cbd5e1", borderRadius: 6, cursor: "pointer" }}
                      onClick={() => {
                        void persistDoc(editingDoc, `✓ Đã lưu giấy đề nghị chi ${editingDoc.code}`);
                        setIsModalOpen(false);
                      }}
                    >
                      Lưu đề nghị
                    </button>
                    <button
                      type="button"
                      className="misa-btn-primary"
                      style={{ padding: "7px 16px", fontSize: 12.5, fontWeight: 600, background: "var(--brand)", color: "#ffffff", border: "1px solid var(--brand)", borderRadius: 6, cursor: "pointer" }}
                      onClick={() => {
                        void persistDoc({ ...editingDoc, status: "approved" }, `✓ Đã lưu và phê duyệt đề nghị chi ${editingDoc.code}`);
                        setIsModalOpen(false);
                      }}
                    >
                      Lưu &amp; Phê duyệt ngay
                    </button>
                  </>
                ) : (
                  <>
                    {editingDoc.status === "pending" && (
                      <>
                        <button
                          type="button"
                          className="misa-btn-secondary"
                          style={{ padding: "7px 14px", fontSize: 12.5, fontWeight: 600, background: "#fef2f2", color: "#dc2626", border: "1px solid #fca5a5", borderRadius: 6, cursor: "pointer" }}
                          onClick={() => {
                            void persistDoc({ ...editingDoc, status: "rejected" }, `Đã từ chối đề nghị chi ${editingDoc.code}`);
                            setIsModalOpen(false);
                          }}
                        >
                          Từ chối
                        </button>
                        <button
                          type="button"
                          className="misa-btn-primary"
                          style={{ padding: "7px 16px", fontSize: 12.5, fontWeight: 600, background: "var(--brand)", color: "#ffffff", border: "1px solid var(--brand)", borderRadius: 6, cursor: "pointer" }}
                          onClick={() => {
                            void persistDoc({ ...editingDoc, status: "approved" }, `✓ Đã phê duyệt đề nghị chi ${editingDoc.code}`);
                            setIsModalOpen(false);
                          }}
                        >
                          Phê duyệt đề nghị
                        </button>
                      </>
                    )}
                    {editingDoc.status === "approved" && (
                      <button
                        type="button"
                        className="misa-btn-primary"
                        style={{ padding: "7px 16px", fontSize: 12.5, fontWeight: 600, background: "var(--brand)", color: "#ffffff", border: "1px solid var(--brand)", borderRadius: 6, cursor: "pointer" }}
                        onClick={() => {
                          const autoVoucher = editingDoc.paymentMethod === "Chuyển khoản" ? `UNC-${editingDoc.code.replace(/[^0-9]/g, "").slice(-4) || "001"}` : `PC-${editingDoc.code.replace(/[^0-9]/g, "").slice(-4) || "001"}`;
                          void persistDoc(
                            { ...editingDoc, status: "paid", voucherCode: autoVoucher },
                            `✓ Đã sinh chứng từ chi ${autoVoucher} từ đề nghị ${editingDoc.code}`,
                          );
                          setIsModalOpen(false);
                          onOpenCreatePayment();
                        }}
                      >
                        Lập phiếu chi ngay
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------
// 4B. ADVANCE SETTLEMENT TAB ("Đề nghị quyết toán tạm ứng")
// ----------------------------------------------------------------------
export type AdvanceSettlementDoc = {
  id: string;
  code: string;
  date: string;
  person: string;
  dept?: string;
  reason: string;
  advanceAmount: number;
  spentAmount: number;
  refundAmount: number;
  status: "pending" | "settled";
  receiptCode: string;
  branchId?: string;
};

export function AdvanceSettlementTab({
  notify,
  onOpenCreateReceipt,
}: {
  notify: (msg: string) => void;
  onOpenCreateReceipt: () => void;
}) {
  const { token, companyId: sessionCompanyId } = useApiSession();
  const [search, setSearch] = useState("");
  const [branchScope, setBranchScope] = useState<string>(() => resolveActiveBranchScope());
  const [settlements, setSettlements] = useState<AdvanceSettlementDoc[]>([
    {
      id: "qt-01",
      code: "QT00005",
      date: "16/12/2026",
      person: "Hoàng Thiên Bảo",
      dept: "Phòng Triển khai",
      reason: "Quyết toán tạm ứng công tác phí triển khai dự án miền Trung",
      advanceAmount: 25000000,
      spentAmount: 20000000,
      refundAmount: 5000000,
      status: "settled",
      receiptCode: "PT00005",
    },
    {
      id: "qt-02",
      code: "QT00004",
      date: "12/12/2026",
      person: "Nguyễn Văn Hải",
      dept: "Phòng Kỹ thuật",
      reason: "Tạm ứng mua sắm vật tư linh kiện thay thế phòng lab",
      advanceAmount: 15000000,
      spentAmount: 15000000,
      refundAmount: 0,
      status: "settled",
      receiptCode: "-",
    },
    {
      id: "qt-03",
      code: "QT00003",
      date: "08/12/2026",
      person: "Trương Thị Bích",
      dept: "Phòng Kinh doanh",
      reason: "Tạm ứng chi phí tiếp khách và hội nghị khách hàng thường niên",
      advanceAmount: 30000000,
      spentAmount: 28500000,
      refundAmount: 1500000,
      status: "pending",
      receiptCode: "",
    },
  ]);

  const [editingDoc, setEditingDoc] = useState<AdvanceSettlementDoc | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<"view" | "edit">("view");
  const [searchParams, setSearchParams] = useSearchParams();
  const dismissedOpenDocRef = useRef<string | null>(null);

  const clearOpenDocParam = () => {
    const cur = searchParams.get("openDoc");
    if (cur) {
      dismissedOpenDocRef.current = cur;
      const next = new URLSearchParams(searchParams);
      next.delete("openDoc");
      setSearchParams(next, { replace: true });
    }
  };

  useEffect(() => {
    const openDocParam = searchParams.get("openDoc");
    if (!openDocParam) {
      dismissedOpenDocRef.current = null;
      return;
    }
    if (settlements.length === 0) return;
    if (dismissedOpenDocRef.current === openDocParam) return;
    const matched =
      settlements.find(
        (s) =>
          s.code.toLowerCase() === openDocParam.toLowerCase() ||
          s.id.toLowerCase() === openDocParam.toLowerCase(),
      ) ||
      (openDocParam === "pending" ? settlements.find((s) => s.status === "pending") : undefined);
    if (matched) {
      setEditingDoc({ ...matched });
      setModalMode("view");
      setIsModalOpen(true);
    }
  }, [searchParams, settlements]);

  useEffect(() => {
    const handleOpenNotif = (ev: Event) => {
      const detail = (ev as CustomEvent)?.detail || {};
      if (detail.notifTarget && detail.notifTarget !== "advance-settlement") return;
      dismissedOpenDocRef.current = null;
      const targetKey = String(detail.openDoc || detail.code || "pending").toLowerCase();
      const matched =
        settlements.find(
          (s) =>
            s.code.toLowerCase() === targetKey ||
            s.id.toLowerCase() === targetKey,
        ) ||
        (targetKey === "pending" ? settlements.find((s) => s.status === "pending") : undefined);
      if (matched) {
        setEditingDoc({ ...matched });
        setModalMode("view");
        setIsModalOpen(true);
      }
    };
    window.addEventListener("sv_open_voucher_notif", handleOpenNotif);
    return () => window.removeEventListener("sv_open_voucher_notif", handleOpenNotif);
  }, [settlements]);

  const effectiveCompanyId = useMemo(() => {
    const urlComp = searchParams.get("company");
    if (urlComp) return urlComp;
    try {
      return localStorage.getItem("ref_company_id") || sessionCompanyId || "";
    } catch {
      return sessionCompanyId || "";
    }
  }, [searchParams, sessionCompanyId]);

  useEffect(() => {
    const onCtxChange = () => setBranchScope(resolveActiveBranchScope());
    window.addEventListener("erp_context_changed", onCtxChange);
    window.addEventListener("popstate", onCtxChange);
    return () => {
      window.removeEventListener("erp_context_changed", onCtxChange);
      window.removeEventListener("popstate", onCtxChange);
    };
  }, []);

  useEffect(() => {
    if (!token || !effectiveCompanyId) return;
    let active = true;
    const branchParam = branchScope && branchScope !== "all" ? `&branch_id=${encodeURIComponent(branchScope)}` : "";
    request<{ docs?: AdvanceSettlementDoc[]; results?: AdvanceSettlementDoc[] }>(
      `/api/v1/cash/advance-settlement-docs/?company_id=${encodeURIComponent(effectiveCompanyId)}${branchParam}`,
      token,
    )
      .then((res) => {
        if (!active) return;
        const list = res?.docs || res?.results;
        if (Array.isArray(list) && list.length > 0) {
          setSettlements(list);
        }
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [token, effectiveCompanyId, branchScope]);

  useEffect(() => {
    try {
      localStorage.setItem("sv_as_docs_sync", JSON.stringify(settlements));
      window.dispatchEvent(new CustomEvent("sv_vouchers_updated", { detail: { type: "as", docs: settlements } }));
    } catch {}
  }, [settlements]);

  const persistSettlement = async (doc: AdvanceSettlementDoc, successMsg: string) => {
    clearOpenDocParam();
    const computedRefund = Math.max(0, (Number(doc.advanceAmount) || 0) - (Number(doc.spentAmount) || 0));
    const normalized: AdvanceSettlementDoc = { ...doc, refundAmount: computedRefund };
    try {
      const rawMap = localStorage.getItem("sv_voucher_status_overrides");
      const map = rawMap ? JSON.parse(rawMap) : {};
      map[normalized.code] = {
        status: normalized.status,
        receiptCode: normalized.receiptCode || "",
        revertedUnread: normalized.status === "pending",
      };
      localStorage.setItem("sv_voucher_status_overrides", JSON.stringify(map));
    } catch {}
    setSettlements((prev) => {
      const idx = prev.findIndex((item) => item.id === normalized.id || item.code === normalized.code);
      const next = idx >= 0 ? prev.map((item, i) => (i === idx ? normalized : item)) : [normalized, ...prev];
      try {
        localStorage.setItem("sv_as_docs_sync", JSON.stringify(next));
      } catch {}
      return next;
    });
    if (token && effectiveCompanyId) {
      const branchParam = branchScope && branchScope !== "all" ? `&branch_id=${encodeURIComponent(branchScope)}` : "";
      try {
        const res = await request<{ docs?: AdvanceSettlementDoc[] }>(
          `/api/v1/cash/advance-settlement-docs/?company_id=${encodeURIComponent(effectiveCompanyId)}${branchParam}`,
          token,
          {
            method: "POST",
            body: JSON.stringify({ doc: normalized }),
          },
        );
        if (Array.isArray(res?.docs)) {
          setSettlements(res.docs);
        }
      } catch {}
    }
    window.dispatchEvent(new CustomEvent("sv_vouchers_updated", { detail: { type: "as", doc: normalized } }));
    notify(successMsg);
  };

  const openNewModal = () => {
    const nextNum = settlements.length + 6;
    setEditingDoc({
      id: `qt-${Date.now()}`,
      code: `QT${String(nextNum).padStart(5, "0")}`,
      date: "20/12/2026",
      person: "Đỗ Đức Tùng",
      dept: "Phòng Kinh doanh",
      reason: "Quyết toán tạm ứng công tác phí & tiếp khách hợp đồng T12/2026",
      advanceAmount: 20000000,
      spentAmount: 16500000,
      refundAmount: 3500000,
      status: "pending",
      receiptCode: "",
      branchId: branchScope !== "all" ? branchScope : undefined,
    });
    setModalMode("edit");
    setIsModalOpen(true);
  };

  const filtered = settlements.filter(
    (s) =>
      !search ||
      s.code.toLowerCase().includes(search.toLowerCase()) ||
      s.person.toLowerCase().includes(search.toLowerCase()) ||
      s.reason.toLowerCase().includes(search.toLowerCase()),
  );

  const kpiStats = useMemo(() => {
    const totalAdvance = settlements.reduce((sum, s) => sum + (Number(s.advanceAmount) || 0), 0);
    const totalSpent = settlements.reduce((sum, s) => sum + (Number(s.spentAmount) || 0), 0);
    const totalRefund = settlements.reduce((sum, s) => sum + (Number(s.refundAmount) || 0), 0);
    return { totalAdvance, totalSpent, totalRefund };
  }, [settlements]);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#f8fafc", padding: 14 }}>
      {/* KPI Header */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 14 }}>
        <div style={{ background: "#ffffff", padding: "12px 14px", borderRadius: 8, border: "1px solid #e2e8f0" }}>
          <div style={{ fontSize: 12, color: "#64748b", marginBottom: 4 }}>Tổng số tiền tạm ứng</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: "#0f172a" }}>{formatVND(kpiStats.totalAdvance)} đ</div>
        </div>
        <div style={{ background: "#ffffff", padding: "12px 14px", borderRadius: 8, border: "1px solid #e2e8f0" }}>
          <div style={{ fontSize: 12, color: "#64748b", marginBottom: 4 }}>Đã chi thực tế</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: "var(--brand)" }}>{formatVND(kpiStats.totalSpent)} đ</div>
        </div>
        <div style={{ background: "#ffffff", padding: "12px 14px", borderRadius: 8, border: "1px solid #e2e8f0" }}>
          <div style={{ fontSize: 12, color: "#64748b", marginBottom: 4 }}>Thu hồi hoàn ứng</div>
          <div style={{ fontSize: 18, fontWeight: 700, color: "var(--brand)" }}>{formatVND(kpiStats.totalRefund)} đ</div>
        </div>
      </div>

      {/* Toolbar */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, gap: 10 }}>
        <div style={{ position: "relative", width: 250 }}>
          <Search size={14} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "#94a3b8" }} />
          <input
            type="text"
            placeholder="Tìm kiếm quyết toán tạm ứng..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              width: "100%",
              height: 32,
              paddingLeft: 30,
              paddingRight: 10,
              fontSize: 12.5,
              border: "1px solid #d1d5db",
              borderRadius: 6,
              outline: "none",
            }}
          />
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button
            type="button"
            className="misa-btn-primary"
            style={{ height: 34, padding: "0 14px", fontSize: 12.5, fontWeight: 600, background: "var(--brand)", color: "#ffffff", border: "1px solid var(--brand)", borderRadius: 6, display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}
            onClick={openNewModal}
          >
            <Plus size={14} />
            Lập quyết toán tạm ứng
          </button>
          <button
            type="button"
            className="misa-btn-secondary"
            style={{ height: 34, padding: "0 14px", fontSize: 12.5, fontWeight: 600, background: "#ffffff", color: "#1e293b", border: "1px solid #cbd5e1", borderRadius: 6, display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}
            onClick={onOpenCreateReceipt}
          >
            Lập phiếu thu hoàn ứng
          </button>
        </div>
      </div>

      {/* Table */}
      <div style={{ flex: 1, overflowX: "auto", overflowY: "auto", background: "#ffffff", borderRadius: 8, border: "1px solid #e2e8f0" }}>
        <table className="misa-tax-table" style={{ width: "100%", minWidth: 1260, borderCollapse: "collapse", tableLayout: "auto" }}>
          <thead>
            <tr>
              <th style={{ width: 32, textAlign: "center" }}><input type="checkbox" aria-label="Chọn tất cả" /></th>
              <th style={{ whiteSpace: "nowrap" }}>Số / Ngày QT</th>
              <th style={{ whiteSpace: "nowrap" }}>Người tạm ứng</th>
              <th>Nội dung thanh toán tạm ứng</th>
              <th className="numeric" style={{ whiteSpace: "nowrap" }}>Số tạm ứng</th>
              <th className="numeric" style={{ whiteSpace: "nowrap" }}>Chi thực tế</th>
              <th className="numeric" style={{ whiteSpace: "nowrap" }}>Hoàn ứng</th>
              <th style={{ textAlign: "center", whiteSpace: "nowrap" }}>Phiếu thu</th>
              <th style={{ textAlign: "center", whiteSpace: "nowrap", width: 120 }}>Trạng thái</th>
              <th style={{ textAlign: "left", whiteSpace: "nowrap", width: 185, minWidth: 185, paddingLeft: 16 }}>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((s) => (
              <tr key={s.id}>
                <td style={{ textAlign: "center" }}><input type="checkbox" aria-label={`Chọn ${s.code}`} /></td>
                <td style={{ whiteSpace: "nowrap" }}>
                  <strong
                    style={{ color: "var(--brand)", cursor: "pointer", textDecoration: "underline", textUnderlineOffset: 2 }}
                    onClick={() => {
                      setEditingDoc({ ...s });
                      setModalMode("view");
                      setIsModalOpen(true);
                    }}
                  >
                    {s.code}
                  </strong>
                  <div style={{ fontSize: 11.5, color: "#64748b", marginTop: 1 }}>{s.date}</div>
                </td>
                <td style={{ whiteSpace: "nowrap" }}>
                  <strong>{s.person}</strong>
                  {s.dept && <div style={{ fontSize: 11.5, color: "#64748b" }}>{s.dept}</div>}
                </td>
                <td style={{ whiteSpace: "normal", lineHeight: 1.45, color: "#1e293b", padding: "9px 10px" }}>{s.reason}</td>
                <td className="numeric" style={{ whiteSpace: "nowrap" }}>{formatVND(s.advanceAmount)} đ</td>
                <td className="numeric" style={{ color: "#ea580c", fontWeight: 600, whiteSpace: "nowrap" }}>{formatVND(s.spentAmount)} đ</td>
                <td className="numeric" style={{ color: "var(--brand)", fontWeight: 700, whiteSpace: "nowrap" }}>{formatVND(s.refundAmount)} đ</td>
                <td style={{ textAlign: "center", whiteSpace: "nowrap" }}>
                  {s.receiptCode && s.receiptCode !== "-" ? (
                    <strong
                      style={{ color: "var(--brand)", cursor: "pointer", fontSize: 12, textDecoration: "underline", textUnderlineOffset: 2 }}
                      onClick={() => {
                        setEditingDoc({ ...s });
                        setModalMode("view");
                        setIsModalOpen(true);
                      }}
                      title="Xem phiếu thu hoàn ứng"
                    >
                      {s.receiptCode}
                    </strong>
                  ) : (
                    <span style={{ color: "#94a3b8" }}>-</span>
                  )}
                </td>
                <td style={{ textAlign: "center", whiteSpace: "nowrap" }}>
                  {s.status === "settled" ? (
                    <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", minWidth: 92, background: "#dcfce7", color: "#15803d", padding: "4px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 600, whiteSpace: "nowrap" }}>
                      Đã quyết toán
                    </span>
                  ) : (
                    <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", minWidth: 92, background: "#fef3c7", color: "#b45309", padding: "4px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 600, whiteSpace: "nowrap" }}>
                      Chờ duyệt
                    </span>
                  )}
                </td>
                <td style={{ textAlign: "left", whiteSpace: "nowrap", width: 185, minWidth: 185, paddingLeft: 16 }}>
                  <div style={{ display: "inline-flex", alignItems: "center", justifyContent: "flex-start", gap: 6 }}>
                    <button
                      type="button"
                      onClick={() => {
                        setEditingDoc({ ...s });
                        setModalMode("view");
                        setIsModalOpen(true);
                      }}
                      style={{ width: 92, height: 26, display: "inline-flex", alignItems: "center", justifyContent: "center", padding: 0, fontSize: 11.5, fontWeight: 600, borderRadius: 5, border: "1px solid #cbd5e1", background: "#ffffff", color: "#334155", cursor: "pointer", flexShrink: 0 }}
                    >
                      Xem chi tiết
                    </button>
                    {s.status === "pending" && (
                      <button
                        type="button"
                        onClick={() => {
                          const autoReceipt = s.refundAmount > 0 ? `PT-HU-${s.code.replace(/[^0-9]/g, "").slice(-3) || "001"}` : "-";
                          void persistSettlement(
                            { ...s, status: "settled", receiptCode: autoReceipt },
                            `✓ Đã duyệt quyết toán ${s.code}${autoReceipt !== "-" ? ` & lập phiếu thu hoàn ứng ${autoReceipt}` : ""}`,
                          );
                        }}
                        style={{ width: 58, height: 26, display: "inline-flex", alignItems: "center", justifyContent: "center", padding: 0, fontSize: 11.5, fontWeight: 600, borderRadius: 5, border: "1px solid #16a34a", background: "#f0fdf4", color: "#15803d", cursor: "pointer", flexShrink: 0 }}
                      >
                        Duyệt
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal Xem chi tiết / Lập Bảng Quyết Toán Tạm Ứng (Mẫu 04-TT) */}
      {isModalOpen && editingDoc && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            zIndex: 9999,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 16,
          }}
        >
          <div
            style={{
              width: "100%",
              maxWidth: 740,
              background: "#ffffff",
              borderRadius: 12,
              boxShadow: "0 20px 50px rgba(15,23,42,0.22)",
              overflow: "hidden",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "16px 22px", borderBottom: "1px solid #e2e8f0", background: "#f8fafc" }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: "#0f172a" }}>
                    Bảng thanh toán tiền tạm ứng — {editingDoc.code}
                  </h3>
                  {editingDoc.status === "settled" ? (
                    <span style={{ background: "#dcfce7", color: "#15803d", padding: "3px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 700 }}>Đã quyết toán</span>
                  ) : (
                    <span style={{ background: "#fef3c7", color: "#b45309", padding: "3px 10px", borderRadius: 12, fontSize: 11.5, fontWeight: 700 }}>Chờ phê duyệt</span>
                  )}
                </div>
                <div style={{ fontSize: 12, color: "#64748b", marginTop: 3 }}>
                  Mẫu số 04-TT (Ban hành theo Thông tư 99/2025/TT-BTC) · Đối chiếu TK 141
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  clearOpenDocParam();
                  setIsModalOpen(false);
                }}
                style={{ border: "none", background: "transparent", cursor: "pointer", color: "#64748b" }}
              >
                <X size={18} />
              </button>
            </div>

            {modalMode === "view" ? (
              <div style={{ padding: "18px 22px" }}>
                <div style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 10, padding: 16, marginBottom: 16 }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px 24px", fontSize: 13 }}>
                    <div>
                      <span style={{ color: "#64748b", display: "block", fontSize: 11.5 }}>Số chứng từ quyết toán</span>
                      <strong style={{ color: "#0f172a", fontSize: 14 }}>{editingDoc.code}</strong>
                    </div>
                    <div>
                      <span style={{ color: "#64748b", display: "block", fontSize: 11.5 }}>Ngày lập quyết toán</span>
                      <strong style={{ color: "#0f172a", fontSize: 14 }}>{editingDoc.date}</strong>
                    </div>
                    <div>
                      <span style={{ color: "#64748b", display: "block", fontSize: 11.5 }}>Họ và tên người thanh toán tạm ứng</span>
                      <strong style={{ color: "#0f172a" }}>{editingDoc.person}</strong>
                    </div>
                    <div>
                      <span style={{ color: "#64748b", display: "block", fontSize: 11.5 }}>Bộ phận / Phòng ban</span>
                      <strong style={{ color: "#0f172a" }}>{editingDoc.dept || "Phòng Kinh doanh"}</strong>
                    </div>
                    <div style={{ gridColumn: "1 / -1", paddingTop: 6, borderTop: "1px dashed #cbd5e1" }}>
                      <span style={{ color: "#64748b", display: "block", fontSize: 11.5, marginBottom: 3 }}>Nội dung thanh toán tạm ứng</span>
                      <div style={{ color: "#0f172a", fontWeight: 600, fontSize: 13.5, lineHeight: 1.5 }}>{editingDoc.reason}</div>
                    </div>
                  </div>
                </div>

                {/* Bảng đối chiếu I - II - III chuẩn Mẫu 04-TT */}
                <div style={{ border: "1px solid #e2e8f0", borderRadius: 8, overflow: "hidden" }}>
                  <table className="misa-tax-table" style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                      <tr>
                        <th style={{ width: 55, textAlign: "center" }}>Mục</th>
                        <th>Chỉ tiêu thanh toán tạm ứng (Mẫu 04-TT)</th>
                        <th style={{ width: 95, textAlign: "center" }}>Định khoản</th>
                        <th className="numeric" style={{ width: 160 }}>Số tiền (VND)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td style={{ textAlign: "center", fontWeight: 700 }}>I</td>
                        <td>Số tiền tạm ứng đã nhận (dư Nợ TK 141)</td>
                        <td style={{ textAlign: "center", color: "#475569" }}>Nợ 141 / Có 111</td>
                        <td className="numeric" style={{ fontWeight: 700 }}>{formatVND(editingDoc.advanceAmount)} đ</td>
                      </tr>
                      <tr>
                        <td style={{ textAlign: "center", fontWeight: 700 }}>II</td>
                        <td style={{ whiteSpace: "normal", lineHeight: 1.45 }}>Số tiền đã chi theo chứng từ gốc đính kèm ({editingDoc.reason})</td>
                        <td style={{ textAlign: "center", color: "#ea580c", fontWeight: 600 }}>Nợ 642 / Có 141</td>
                        <td className="numeric" style={{ fontWeight: 700, color: "#ea580c" }}>{formatVND(editingDoc.spentAmount)} đ</td>
                      </tr>
                      <tr style={{ background: "#f0fdf4" }}>
                        <td style={{ textAlign: "center", fontWeight: 700, color: "#15803d" }}>III</td>
                        <td style={{ fontWeight: 700, color: "#166534" }}>
                          Chênh lệch tạm ứng thu hồi nhập lại quỹ (I - II) {editingDoc.receiptCode && editingDoc.receiptCode !== "-" ? `· Phiếu thu: ${editingDoc.receiptCode}` : ""}
                        </td>
                        <td style={{ textAlign: "center", color: "#15803d", fontWeight: 700 }}>Nợ 1111 / Có 141</td>
                        <td className="numeric" style={{ fontWeight: 800, color: "#15803d", fontSize: 14 }}>{formatVND(editingDoc.refundAmount)} đ</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div style={{ padding: 20, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Số quyết toán *</label>
                  <input
                    type="text"
                    value={editingDoc.code}
                    onChange={(e) => setEditingDoc({ ...editingDoc, code: e.target.value })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13 }}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Ngày quyết toán *</label>
                  <input
                    type="text"
                    value={editingDoc.date}
                    onChange={(e) => setEditingDoc({ ...editingDoc, date: e.target.value })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13 }}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Người tạm ứng *</label>
                  <input
                    type="text"
                    value={editingDoc.person}
                    onChange={(e) => setEditingDoc({ ...editingDoc, person: e.target.value })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13 }}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Bộ phận / Phòng ban</label>
                  <input
                    type="text"
                    value={editingDoc.dept || ""}
                    onChange={(e) => setEditingDoc({ ...editingDoc, dept: e.target.value })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13 }}
                  />
                </div>
                <div style={{ gridColumn: "1 / -1" }}>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>Nội dung thanh toán tạm ứng *</label>
                  <input
                    type="text"
                    value={editingDoc.reason}
                    onChange={(e) => setEditingDoc({ ...editingDoc, reason: e.target.value })}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13 }}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>I. Số tiền đã tạm ứng (VND) *</label>
                  <input
                    type="number"
                    value={editingDoc.advanceAmount}
                    onChange={(e) => {
                      const adv = Number(e.target.value) || 0;
                      setEditingDoc({
                        ...editingDoc,
                        advanceAmount: adv,
                        refundAmount: Math.max(0, adv - (Number(editingDoc.spentAmount) || 0)),
                      });
                    }}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13, fontWeight: 700 }}
                  />
                </div>
                <div>
                  <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: "#334155", marginBottom: 4 }}>II. Số tiền đã chi theo CT (VND) *</label>
                  <input
                    type="number"
                    value={editingDoc.spentAmount}
                    onChange={(e) => {
                      const spent = Number(e.target.value) || 0;
                      setEditingDoc({
                        ...editingDoc,
                        spentAmount: spent,
                        refundAmount: Math.max(0, (Number(editingDoc.advanceAmount) || 0) - spent),
                      });
                    }}
                    style={{ width: "100%", height: 34, padding: "0 10px", border: "1px solid #cbd5e1", borderRadius: 6, fontSize: 13, fontWeight: 700, color: "#ea580c" }}
                  />
                </div>
                <div style={{ gridColumn: "1 / -1", background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: 8, padding: "10px 14px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 12.5, fontWeight: 600, color: "#166534" }}>
                    III. Chênh lệch tạm ứng thu hồi hoàn quỹ (I - II):
                  </span>
                  <strong style={{ fontSize: 15, color: "#15803d" }}>
                    {formatVND(Math.max(0, (Number(editingDoc.advanceAmount) || 0) - (Number(editingDoc.spentAmount) || 0)))} đ
                  </strong>
                </div>
              </div>
            )}

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, padding: "14px 22px", borderTop: "1px solid #e2e8f0", background: "#f8fafc" }}>
              <div style={{ display: "flex", gap: 8 }}>
                {modalMode === "view" && (
                  <>
                    <button
                      type="button"
                      className="misa-btn-secondary"
                      style={{ padding: "7px 14px", fontSize: 12.5, fontWeight: 600, background: "#ffffff", color: "var(--brand)", border: "1px solid #bae6fd", borderRadius: 6, cursor: "pointer" }}
                      onClick={() => setModalMode("edit")}
                    >
                      ✎ Chỉnh sửa bảng quyết toán
                    </button>
                    {editingDoc.status === "settled" && (
                      <button
                        type="button"
                        className="misa-btn-secondary"
                        style={{ padding: "7px 14px", fontSize: 12.5, fontWeight: 600, background: "#fffbeb", color: "#b45309", border: "1px solid #fde68a", borderRadius: 6, cursor: "pointer" }}
                        onClick={() => {
                          const updated = { ...editingDoc, status: "pending" as const, receiptCode: "" };
                          setEditingDoc(updated);
                          void persistSettlement(updated, `↺ Đã chuyển quyết toán ${editingDoc.code} về trạng thái Chờ duyệt`);
                        }}
                      >
                        ↺ Chuyển về Chờ duyệt
                      </button>
                    )}
                  </>
                )}
              </div>
              <div style={{ display: "flex", gap: 10 }}>
                <button
                  type="button"
                  className="misa-btn-secondary"
                  style={{ padding: "7px 14px", fontSize: 12.5, fontWeight: 600, background: "#ffffff", color: "#334155", border: "1px solid #cbd5e1", borderRadius: 6, cursor: "pointer" }}
                  onClick={() => {
                    clearOpenDocParam();
                    setIsModalOpen(false);
                  }}
                >
                  Đóng
                </button>
                {modalMode === "edit" ? (
                  <>
                    <button
                      type="button"
                      className="misa-btn-secondary"
                      style={{ padding: "7px 14px", fontSize: 12.5, fontWeight: 600, background: "#ffffff", color: "#0f172a", border: "1px solid #cbd5e1", borderRadius: 6, cursor: "pointer" }}
                      onClick={() => {
                        void persistSettlement(editingDoc, `✓ Đã lưu bảng quyết toán tạm ứng ${editingDoc.code}`);
                        setIsModalOpen(false);
                      }}
                    >
                      Lưu nháp
                    </button>
                    <button
                      type="button"
                      className="misa-btn-primary"
                      style={{ padding: "7px 16px", fontSize: 12.5, fontWeight: 600, background: "var(--brand)", color: "#ffffff", border: "1px solid var(--brand)", borderRadius: 6, cursor: "pointer" }}
                      onClick={() => {
                        const refund = Math.max(0, (Number(editingDoc.advanceAmount) || 0) - (Number(editingDoc.spentAmount) || 0));
                        const autoReceipt = refund > 0 ? (editingDoc.receiptCode || `PT-HU-${editingDoc.code.replace(/[^0-9]/g, "").slice(-3) || "006"}`) : "-";
                        void persistSettlement(
                          { ...editingDoc, status: "settled", receiptCode: autoReceipt },
                          `✓ Đã ghi nhận quyết toán ${editingDoc.code}`,
                        );
                        setIsModalOpen(false);
                      }}
                    >
                      Lưu &amp; Ghi nhận quyết toán
                    </button>
                  </>
                ) : (
                  editingDoc.status === "pending" && (
                    <button
                      type="button"
                      className="misa-btn-primary"
                      style={{ padding: "7px 16px", fontSize: 12.5, fontWeight: 600, background: "var(--brand)", color: "#ffffff", border: "1px solid var(--brand)", borderRadius: 6, cursor: "pointer" }}
                      onClick={() => {
                        const refund = Math.max(0, (Number(editingDoc.advanceAmount) || 0) - (Number(editingDoc.spentAmount) || 0));
                        const autoReceipt = refund > 0 ? (editingDoc.receiptCode || `PT-HU-${editingDoc.code.replace(/[^0-9]/g, "").slice(-3) || "006"}`) : "-";
                        void persistSettlement(
                          { ...editingDoc, status: "settled", receiptCode: autoReceipt },
                          `✓ Đã duyệt quyết toán ${editingDoc.code}${autoReceipt !== "-" ? ` & lập phiếu thu hoàn ứng ${autoReceipt}` : ""}`,
                        );
                        setIsModalOpen(false);
                      }}
                    >
                      Duyệt &amp; Hoàn ứng ngay
                    </button>
                  )
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------
// 5. MAIN MISA TIỀN MẶT WORKSPACE COMPONENT
// ----------------------------------------------------------------------
type ApiCashTransaction = {
  id: string;
  number: string;
  transaction_date: string;
  transaction_type: string;
  payer_payee: string;
  description: string;
  amount: string | number;
  status: string;
  business_type?: string;
  fund?: string;
  currency?: string;
  currency_code?: string;
  party?: string | null;
  party_code?: string;
  party_name?: string;
  party_tax_code?: string;
  party_address?: string;
  gl_reference?: string;
  created_by_name?: string;
  created_at?: string;
  updated_at?: string;
  receipt_details?: Record<string, any> & { lines?: Array<{ description: string; debit_code?: string; credit_code?: string; amount: string | number; partner_code?: string; partner_name?: string }> };
};

type ApiCashFund = { id: string; currency: string; status: string; balance: string | number; branch?: string | null };

function mapCashTransaction(row: ApiCashTransaction) {
  const rawDesc = (row.description || "").trim();
  const firstLineDesc = (row.receipt_details?.lines?.[0]?.description || "").trim();
  const isBarePrefix = !rawDesc || /^(thu tiền của|chi tiền cho|tạm ứng cho|thu hoàn ứng sau khi quyết toán tạm ứng cho|chi mua ngoài có hóa đơn cho|trả các khoản vay cho)$/i.test(rawDesc);
  const resolvedDesc = isBarePrefix && firstLineDesc && firstLineDesc.length > rawDesc.length
    ? firstLineDesc
    : (isBarePrefix && row.payer_payee && /\b(của|cho)$/i.test(rawDesc) ? `${rawDesc} ${row.payer_payee}` : (row.description || firstLineDesc || ""));
  const resolvedPartner = row.payer_payee || row.party_name || (row.receipt_details as any)?.partner_name || "";
  const resolvedPartnerCode =
    row.party_code ||
    (row.receipt_details as any)?.partner_code ||
    (row.receipt_details?.lines?.[0] as any)?.partner_code ||
    (row.party ? `DT-${String(row.party).slice(0, 6).toUpperCase()}` : resolvedPartner ? "DT001" : "");
  const resolvedAddress =
    (row.receipt_details as any)?.payer_address ||
    row.party_address ||
    "Hà Nội";
  const resolvedEmployee =
    (row.receipt_details as any)?.employee_name ||
    row.created_by_name ||
    "Đỗ Đức Tùng";
  const postingDate = (row.receipt_details as any)?.posting_date || row.transaction_date;
  return {
    id: row.id,
    code: row.number,
    date: row.transaction_date,
    postingDate,
    partner: resolvedPartner,
    partnerCode: resolvedPartnerCode,
    person: (row.receipt_details as any)?.payer_name || resolvedPartner,
    address: resolvedAddress,
    taxCode: row.party_tax_code || "",
    employee: resolvedEmployee,
    originalDocuments: (row.receipt_details as any)?.original_documents || "",
    glReference: row.gl_reference || (row.status === "POSTED" ? `GL-${row.number}` : "Chưa ghi sổ cái"),
    currencyCode: row.currency_code || "VND",
    createdBy: row.created_by_name || "Đỗ Đức Tùng",
    createdAt: row.created_at ? row.created_at.slice(0, 10).split("-").reverse().join("/") : "",
    updatedAt: row.updated_at ? row.updated_at.slice(0, 10).split("-").reverse().join("/") : "",
    description: resolvedDesc,
    amount: Number(row.amount),
    kind: ["RECEIPT", "ADVANCE_RETURN", "ADJUSTMENT_IN"].includes(row.transaction_type) ? "receipt" : "payment",
    debit: row.receipt_details?.lines?.[0]?.debit_code || (["RECEIPT", "ADVANCE_RETURN", "ADJUSTMENT_IN"].includes(row.transaction_type) ? "1111" : "331"),
    credit: row.receipt_details?.lines?.[0]?.credit_code || (["RECEIPT", "ADVANCE_RETURN", "ADJUSTMENT_IN"].includes(row.transaction_type) ? "131" : "1111"),
    status: row.status === "POSTED" ? "posted" : "draft",
    rawStatus: row.status,
    businessType: row.business_type,
    transactionType: row.transaction_type,
    fundId: row.fund,
    currencyId: row.currency,
    partyId: row.party,
    rawReceiptDetails: row.receipt_details,
    rows: (row.receipt_details?.lines || []).map((line, index) => {
      const lDesc = (line.description || "").trim();
      const lIsBare = !lDesc || /^(thu tiền của|chi tiền cho|tạm ứng cho|thu hoàn ứng sau khi quyết toán tạm ứng cho|chi mua ngoài có hóa đơn cho|trả các khoản vay cho)$/i.test(lDesc);
      return {
        id: `${row.id}-${index}`,
        description: lIsBare && resolvedDesc ? resolvedDesc : (line.description || resolvedDesc),
        debit: line.debit_code || (["RECEIPT", "ADVANCE_RETURN", "ADJUSTMENT_IN"].includes(row.transaction_type) ? "1111" : "331"),
        credit: line.credit_code || (["RECEIPT", "ADVANCE_RETURN", "ADJUSTMENT_IN"].includes(row.transaction_type) ? "131" : "1111"),
        amount: Number(line.amount),
        bankAccount: "",
        bankName: "",
        partnerCode: (line as any).partner_code || resolvedPartnerCode,
        partnerName: resolvedPartner || (line as any).partner_name || "",
        employeeCode: "",
        employeeName: resolvedEmployee,
        loanContract: "",
        loanDisbursementContract: "",
      };
    }),
  };
}

const cashDataCache = new Map<string, {
  transactions: any[];
  cashBalance: number;
  cashFunds: ApiCashFund[];
  timestamp: number;
}>();

export default function MisaCashWorkspace({
  tab = "transactions",
  company,
  period,
  href,
  notify,
}: {
  company?: { id: string; name: string };
  period?: string;
  tab: string;
  href?: (path: string) => string;
  notify: (msg: string) => void;
}) {
  const navigate = useNavigate();
  const { token } = useApiSession();
  const [cashParams] = useSearchParams();
  const cashReportsUrl = (report?: string) => { const url = href?.("/cash/reports") || "/cash/reports"; return report ? `${url}${url.includes("?") ? "&" : "?"}report=${encodeURIComponent(report)}` : url; };
  const [cashOptionsOpen,setCashOptionsOpen]=useState(false);
  // Modal states
  const [showTaxModal, setShowTaxModal] = useState(false);
  const [showSupplierPayment, setShowSupplierPayment] = useState(false);
  const [showCustomerCollection, setShowCustomerCollection] = useState(false);
  const [showMultiCustomerCollection, setShowMultiCustomerCollection] = useState(false);
  const [showVoucherPrint, setShowVoucherPrint] = useState(false);
  const [viewingCashVoucher, setViewingCashVoucher] = useState<any | null>(null);
  const [editCashCode, setEditCashCode] = useState("");
  const [editCashDate, setEditCashDate] = useState("");
  const [editCashPartner, setEditCashPartner] = useState("");
  const [editCashPerson, setEditCashPerson] = useState("");
  const [editCashDescription, setEditCashDescription] = useState("");
  const [editCashRows, setEditCashRows] = useState<VoucherDetailRow[]>([]);
  const [isSavingCashEdit, setIsSavingCashEdit] = useState(false);
  const [showCreateVoucher, setShowCreateVoucher] = useState<"receipt" | "payment" | null>(null);
  const [voucherCategoryChoice, setVoucherCategoryChoice] = useState<"cash" | "bank">("cash");
  const [createVoucherTypeIndex, setCreateVoucherTypeIndex] = useState<number>(0);
  const [showCashPaymentSubmenu, setShowCashPaymentSubmenu] = useState(false);
  const [showAIModal, setShowAIModal] = useState(false);
  const [showInsuranceModal, setShowInsuranceModal] = useState(false);
  const [showSalaryModal, setShowSalaryModal] = useState(false);
  const [showInternalTransfer, setShowInternalTransfer] = useState(false);

  // Dropdown menus (Mutually exclusive to prevent multiple open menus)
  const [activeToolbarMenu, setActiveToolbarMenu] = useState<"receipt" | "payment" | null>(null);
  const [activeFlowchartMenu, setActiveFlowchartMenu] = useState<"receipt" | "payment" | null>(null);
  const flowchartMenuTimer = useRef<number | null>(null);

  const handleFlowchartMouseEnter = (menu: "receipt" | "payment") => {
    if (flowchartMenuTimer.current) {
      clearTimeout(flowchartMenuTimer.current);
      flowchartMenuTimer.current = null;
    }
    setActiveFlowchartMenu(menu);
  };

  const handleFlowchartMouseLeave = () => {
    flowchartMenuTimer.current = window.setTimeout(() => {
      setActiveFlowchartMenu(null);
    }, 220);
  };

  const [cashImportKind,setCashImportKind]=useState<"receipt"|"payment"|null>(null);
  const [cashRowMenuId, setCashRowMenuId] = useState<string | null>(null);
  const [cashExcelMenuOpen, setCashExcelMenuOpen] = useState(false);
  const exportCashExcel=async()=>{const XLSX=await import("xlsx");const book=XLSX.utils.book_new();XLSX.utils.book_append_sheet(book,XLSX.utils.aoa_to_sheet([["Ngày hạch toán","Số chứng từ","Diễn giải","Số tiền","Đối tượng","Trạng thái"],...filteredList.map(row=>[row.date,row.code,row.description,row.amount,row.partner,row.status==='posted'?'Đã ghi sổ':'Chưa ghi sổ'])]),"Thu-chi");XLSX.writeFileXLSX(book,"Thu-chi-tien-mat.xlsx");};
  // Filter state
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter,setStatusFilter] = useState("all");
  const [cashFilter,setCashFilter]=useState<CashFilter>(defaultCashFilter);
  const [cashControlPanel,setCashControlPanel]=useState<'filters'|'columns'|null>(null);
  const cashColumnsKey = `soviet:cash-columns:${company?.id || "default"}`;
  const [cashColumns,setCashColumns]=useState<CashColumn[]>(()=>{try{return readCashColumns(localStorage.getItem(cashColumnsKey));}catch{return readCashColumns(null);}});
  useEffect(()=>{try{setCashColumns(readCashColumns(localStorage.getItem(cashColumnsKey)));}catch{setCashColumns(readCashColumns(null));}},[cashColumnsKey]);
  const [cashSortAscending,setCashSortAscending]=useState(false);
  const [cashInventoryMode,setCashInventoryMode]=useState<'misa'|'legacy'>('misa');
  const [cashForecastMode,setCashForecastMode]=useState<'misa'|'legacy'>('misa');
  const [voucherTypeFilter, setVoucherTypeFilter] = useState("all");
  const [filterPeriod, setFilterPeriod] = useState("ytd");
  const [kpiCollapsed, setKpiCollapsed] = useState(false);
  const [checkedCashRows, setCheckedCashRows] = useState<string[]>([]);
  const [cashPageSize, setCashPageSize] = useState(20);
  const [cashDetailSize,setCashDetailSize]=useState(20);
  const [cashDetailPage,setCashDetailPage]=useState(1);
  const [cashPage, setCashPage] = useState(1);

  // Selected voucher for print preview (Default matching Image 5)
  const [selectedVoucher, setSelectedVoucher] = useState({
    code: "PT00005",
    date: "2026-09-03",
    person: "Hoàng Thiên Bảo",
    address: "Tòa nhà Sổ Việt, Cầu Giấy, Hà Nội",
    reason: "Thu hoàn ứng sau khi quyết toán tạm ứng cho Hoàng Thiên Bảo",
    debitAccount: "111",
    creditAccount: "141",
    amount: 5000000,
    amountInWords: "Năm triệu đồng chẵn",
    notes: "Kèm theo giấy đề nghị thanh toán tạm ứng số 05/QTTU",
    chiefAccountant: "Trương Thị B",
    director: "Nguyễn Văn A",
  });

  const [activeBranchScope, setActiveBranchScope] = useState<string>(() => resolveActiveBranchScope());
  const cashCacheKey = company?.id ? `${company.id}::${activeBranchScope}` : "";
  const cachedCash = cashCacheKey ? cashDataCache.get(cashCacheKey) : undefined;
  const [transactions, setTransactions] = useState<any[]>(() => cachedCash?.transactions || []);
  const [cashBalance, setCashBalance] = useState(() => cachedCash?.cashBalance || 0);
  const [cashApiRevision, setCashApiRevision] = useState(0);
  const reloadCashApi = () => {
    if (cashCacheKey) cashDataCache.delete(cashCacheKey);
    setCashApiRevision((value) => value + 1);
  };
  const apiSave = useMisaApiSave(company?.id || "", notify, reloadCashApi);
  const { rows: debtCatalog } = useMisaApiLists(company?.id || "", { customers: "/api/v1/master-data/customers/" }, notify);
  const { rows: payableCatalog } = useMisaApiLists(company?.id || "", {
    suppliers: "/api/v1/master-data/parties/", bankAccounts: "/api/v1/master-data/company-bank-accounts/",
  }, notify);
  const payableSource: CollectionDebtSource | undefined = token ? {
    customers: (payableCatalog.suppliers || []).map((row) => ({ code: row.code, name: row.name })),
    load: (supplierCode?: string) => openPayables(createApiWriter(company?.id || "", (path, init) => request(path, token, init)), supplierCode),
  } : undefined;
  const debtSource: CollectionDebtSource | undefined = token ? {
    customers: (debtCatalog.customers || []).map((row) => ({ code: row.code, name: row.name })),
    load: (customerCode?: string) => openReceivables(createApiWriter(company?.id || "", (path, init) => request(path, token, init)), customerCode),
  } : undefined;
  const [cashFunds, setCashFunds] = useState<ApiCashFund[]>(() => cachedCash?.cashFunds || []);

  useEffect(() => {
    if (!token || !company?.id) {
      setTransactions([]);
      setCashBalance(0);
      setCashFunds([]);
      return;
    }
    let active = true;
    const branchParam = activeBranchScope !== "all" ? `&branch_id=${encodeURIComponent(activeBranchScope)}` : "";
    const hasCache = cashDataCache.has(cashCacheKey);
    if (!hasCache) {
      setTransactions([]);
      setCashBalance(0);
      setCashFunds([]);
    } else {
      const hit = cashDataCache.get(cashCacheKey)!;
      setTransactions(hit.transactions);
      setCashBalance(hit.cashBalance);
      setCashFunds(hit.cashFunds);
    }
    request<ApiCashFund[] | { results: ApiCashFund[] }>(
      `/api/v1/cash/funds/?company_id=${encodeURIComponent(company.id)}${branchParam}&page_size=100`,
      token,
    ).then((response) => {
      if (!active) return;
      const funds = Array.isArray(response) ? response : response.results;
      const totalBalance = funds.reduce((total, fund) => total + Number(fund.balance), 0);
      setCashFunds(funds);
      setCashBalance(totalBalance);
      const prev = cashDataCache.get(cashCacheKey);
      cashDataCache.set(cashCacheKey, {
        transactions: prev?.transactions || [],
        cashBalance: totalBalance,
        cashFunds: funds,
        timestamp: Date.now(),
      });
    }).catch((error) => {
      if (active && !hasCache) notify(error instanceof Error ? error.message : "Không tải được số dư quỹ tiền mặt.");
    });
    request<ApiCashTransaction[] | { results: ApiCashTransaction[] }>(
      `/api/v1/cash/transactions/?company_id=${encodeURIComponent(company.id)}${branchParam}&page_size=100`,
      token,
    ).then((response) => {
      if (!active) return;
      const records = Array.isArray(response) ? response : response.results;
      const mapped = records.map(mapCashTransaction);
      setTransactions(mapped);
      const prev = cashDataCache.get(cashCacheKey);
      cashDataCache.set(cashCacheKey, {
        transactions: mapped,
        cashBalance: prev?.cashBalance || 0,
        cashFunds: prev?.cashFunds || [],
        timestamp: Date.now(),
      });
      // Internal transfers are listed with the vouchers so they can be reviewed after saving.
      internalTransfers(createApiWriter(company.id, (path, init) => request(path, token, init)), "cash").then((transfers) => {
        if (!active) return;
        setTransactions((rows) => {
          const next = [...rows.filter((row) => !String(row.id).startsWith("transfer:")), ...transfers.map((row) => ({
            id: `transfer:${row.id}`, code: row.number, date: row.transfer_date, partner: "Nội bộ", person: "",
            description: row.description || "Chuyển tiền nội bộ", amount: Number(row.amount), kind: "payment",
            debit: "", credit: "", status: String(row.status || "").toLowerCase(), reasonLabel: "Chuyển tiền nội bộ",
          }))];
          const curr = cashDataCache.get(cashCacheKey);
          if (curr) curr.transactions = next;
          return next;
        });
      }).catch(() => undefined);
    }).catch((error) => {
      if (active && !hasCache) notify(error instanceof Error ? error.message : "Không tải được giao dịch tiền mặt.");
    });
    return () => { active = false; };
  }, [token, company?.id, activeBranchScope, cashCacheKey, notify, cashApiRevision]);

  // Selected row for inline detail
  const [selectedRowId, setSelectedRowId] = useState<string>("pt-05");
  useEffect(()=>setCashDetailPage(1),[selectedRowId]);
  const [cashTrash,setCashTrash]=useState<typeof transactions>([]);
  const [cashPendingDeletion,setCashPendingDeletion]=useState<string[]|null>(null);

  // Filtered list
  const [activeDatasetYear, setActiveDatasetYear] = useState<number>(() => resolveActiveDatasetYear());
  const [activeBookType, setActiveBookType] = useState<"accounting" | "management">(() => resolveActiveDatasetBookType());
  const [activeHeaderPeriod, setActiveHeaderPeriod] = useState<string>(() => resolveActiveHeaderPeriod());
  useEffect(() => {
    const syncCtx = () => {
      setActiveDatasetYear(resolveActiveDatasetYear());
      setActiveBranchScope(resolveActiveBranchScope());
      setActiveBookType(resolveActiveDatasetBookType());
      setActiveHeaderPeriod(resolveActiveHeaderPeriod());
    };
    window.addEventListener("erp_context_changed", syncCtx);
    window.addEventListener("popstate", syncCtx);
    return () => {
      window.removeEventListener("erp_context_changed", syncCtx);
      window.removeEventListener("popstate", syncCtx);
    };
  }, []);
  useEffect(() => {
    if (period) {
      setActiveHeaderPeriod(period);
      setActiveDatasetYear(resolveActiveDatasetYear());
    }
  }, [period]);
  const bookFilteredTransactions = useMemo(
    () =>
      transactions.filter((item) => {
        const codeStr = String(item.code || "").trim().toUpperCase();
        if (activeBookType === "accounting" && codeStr.startsWith("QT-")) {
          return false;
        }
        return true;
      }),
    [transactions, activeBookType],
  );
  const filteredList = useMemo(() => {
    const refToday = new Date(activeDatasetYear, 11, 31);
    const periodRange = resolveActivePeriodRange(activeDatasetYear);
    const baseMatches = bookFilteredTransactions.filter((item) => {
      const matchQuery =
        !searchQuery ||
        item.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.partner.toLowerCase().includes(searchQuery.toLowerCase());
      const matchStatus =
        statusFilter === "all" || item.status === statusFilter;
      const matchKind =
        voucherTypeFilter === "all" || item.kind === voucherTypeFilter;
      const matchReason=cashFilter.reason==='all'||(item.reasonLabel||cashReason(item.kind,item.description)).replace(/^\d+\.\s*/,'')===cashFilter.reason;
      return matchQuery && matchStatus && matchKind && matchReason;
    });
    let dateMatched = baseMatches.filter((item) =>
      filterPeriod === "custom"
        ? isCashDateInRange(item.date, cashFilter.from, cashFilter.to)
        : matchesTransactionPeriod(item.date, filterPeriod, refToday),
    );
    if (dateMatched.length === 0 && filterPeriod === "ytd" && (periodRange.month !== null || periodRange.quarter !== null)) {
      dateMatched = baseMatches.filter((item) => {
        const iso = parseReportDate(item.date);
        return iso >= `${activeDatasetYear}-01-01` && iso <= periodRange.toDate;
      });
    }
    return dateMatched.sort((a,b)=>(cashDateValue(a.date)-cashDateValue(b.date))*(cashSortAscending?1:-1));
  }, [bookFilteredTransactions, searchQuery, statusFilter, voucherTypeFilter, filterPeriod, cashFilter, cashSortAscending, activeDatasetYear, activeHeaderPeriod]);
  const cashPageCount = Math.max(1, Math.ceil(filteredList.length / cashPageSize));
  const visibleCashPage = Math.min(cashPage, cashPageCount);
  const selectedTransaction = useMemo(
    () => filteredList.find((item) => item.id === selectedRowId) || filteredList[0],
    [filteredList, selectedRowId],
  );
  const cashDetailRows:VoucherDetailRow[]=selectedTransaction?.rows?.length ? selectedTransaction.rows : selectedTransaction ? [{id:selectedTransaction.id,description:selectedTransaction.description,debit:selectedTransaction.debit||"1111",credit:selectedTransaction.credit||"141",amount:selectedTransaction.amount,partnerCode:selectedTransaction.partnerCode||selectedTransaction.partner,partnerName:selectedTransaction.partner}] : [];
  const cashDetailPages=Math.max(1,Math.ceil(cashDetailRows.length/cashDetailSize));
  const cashDetailVisiblePage=Math.min(cashDetailPage,cashDetailPages);
  const cashCurrentLedger=useMemo(()=>{
    const periodRange = resolveActivePeriodRange(activeDatasetYear);
    const mapped = bookFilteredTransactions.map(row=>({...row,date:parseReportDate(row.date)}));
    const exact = cashLedger(mapped, periodRange.fromDate, periodRange.toDate);
    if (exact.receipt === 0 && exact.payment === 0 && (periodRange.month !== null || periodRange.quarter !== null)) {
      return cashLedger(mapped, `${activeDatasetYear}-01-01`, periodRange.toDate);
    }
    return exact;
  },[bookFilteredTransactions, activeDatasetYear, activeHeaderPeriod]);
  useEffect(()=>{setCheckedCashRows(ids=>ids.filter(id=>filteredList.some(row=>row.id===id)));},[filteredList]);
  useEffect(() => {
    if (!viewingCashVoucher) return;
    const v = transactions.find((item) => item.id === viewingCashVoucher.id) || viewingCashVoucher;
    setEditCashCode(v.code || "");
    setEditCashDate(v.date ? String(v.date).slice(0, 10) : currentCashDate());
    setEditCashPartner(v.partner || "");
    setEditCashPerson(v.person || v.partner || "");
    setEditCashDescription(v.description || "");
    const initialRows: VoucherDetailRow[] = v.rows?.length
      ? v.rows.map((r: any, i: number) => ({
          id: r.id || `${v.id}-${i}`,
          description: r.description || v.description || "",
          debit: r.debit || (v.kind === "receipt" ? "1111" : "331"),
          credit: r.credit || (v.kind === "receipt" ? "131" : "1111"),
          amount: Number(r.amount) || 0,
          partnerCode: r.partnerCode || v.partnerCode || "",
          partnerName: r.partnerName || v.partner || "",
        }))
      : [
          {
            id: `${v.id}-0`,
            description: v.description || "",
            debit: v.debit || (v.kind === "receipt" ? "1111" : "331"),
            credit: v.credit || (v.kind === "receipt" ? "131" : "1111"),
            amount: Number(v.amount) || 0,
            partnerCode: v.partnerCode || "",
            partnerName: v.partner || "",
          },
        ];
    setEditCashRows(initialRows);
  }, [viewingCashVoucher?.id]);

  const handleSaveCashVoucherEdit = async (andPost = false) => {
    if (!viewingCashVoucher || !token || !company?.id) return;
    const v = transactions.find((item) => item.id === viewingCashVoucher.id) || viewingCashVoucher;
    if (String(v.id).startsWith("transfer:")) {
      notify("Chứng từ chuyển tiền nội bộ không sửa tại màn hình này.");
      return;
    }
    const totalAmount = editCashRows.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
    if (!(totalAmount > 0)) {
      notify("Số tiền chứng từ phải lớn hơn 0.");
      return;
    }
    if (!editCashDescription.trim()) {
      notify("Vui lòng nhập lý do / diễn giải chứng từ.");
      return;
    }
    setIsSavingCashEdit(true);
    try {
      const payload: Record<string, any> = {
        number: editCashCode.trim() || v.code,
        transaction_date: editCashDate || v.date,
        payer_payee: editCashPartner.trim() || editCashPerson.trim() || v.partner || "",
        description: editCashDescription.trim(),
        amount: String(totalAmount),
      };
      if (v.rawReceiptDetails && typeof v.rawReceiptDetails === "object" && Object.keys(v.rawReceiptDetails).length > 0) {
        const existingLines = Array.isArray(v.rawReceiptDetails.lines) ? v.rawReceiptDetails.lines : [];
        payload.receipt_details = {
          ...v.rawReceiptDetails,
          posting_date: editCashDate || v.rawReceiptDetails.posting_date || v.date,
          lines: editCashRows.map((r, idx) => ({
            ...(existingLines[idx] || {}),
            description: (r.description || editCashDescription || "").trim(),
            debit_code: (r.debit || (v.kind === "receipt" ? "1111" : "331")).trim(),
            credit_code: (r.credit || (v.kind === "receipt" ? "131" : "1111")).trim(),
            amount: String(Number(r.amount) || 0),
          })),
        };
      }
      const updatedRaw = await request<ApiCashTransaction>(
        `/api/v1/cash/transactions/${v.id}/?company_id=${encodeURIComponent(company.id)}`,
        token,
        {
          method: "PATCH",
          body: JSON.stringify(payload),
        },
      );
      const mapped = mapCashTransaction(updatedRaw);
      if (!updatedRaw.receipt_details?.lines?.length) {
        mapped.rows = editCashRows.map((r, idx) => ({
          ...r,
          id: `${v.id}-${idx}`,
          description: (r.description || editCashDescription || "").trim(),
          partnerName: editCashPartner.trim() || r.partnerName || "",
          bankAccount: r.bankAccount || "",
          bankName: r.bankName || "",
          partnerCode: r.partnerCode || "",
          employeeCode: r.employeeCode || "",
          employeeName: r.employeeName || "",
          loanContract: r.loanContract || "",
          loanDisbursementContract: r.loanDisbursementContract || "",
        }));
        mapped.debit = editCashRows[0]?.debit || mapped.debit;
        mapped.credit = editCashRows[0]?.credit || mapped.credit;
      }
      setTransactions((rows) => {
        const next = rows.map((row) => (row.id === v.id ? mapped : row));
        const curr = cashDataCache.get(company.id);
        if (curr) curr.transactions = next;
        return next;
      });
      if (andPost) {
        await cashRowAction("post", [v.id]);
      } else {
        notify(`Đã cập nhật chứng từ ${mapped.code} thành công.`);
      }
      setViewingCashVoucher(null);
    } catch (error) {
      notify(error instanceof Error ? error.message : "Không lưu được thay đổi chứng từ.");
    } finally {
      setIsSavingCashEdit(false);
    }
  };

  const cashRowAction = async (action: "post" | "unpost" | "delete" | "clone", ids = checkedCashRows) => {
    if (!ids.length) {
      notify("Vui lòng chọn chứng từ.");
      return;
    }
    if (!token || !company?.id) return false;
    if (action === "delete") {
      try {
        for (const id of ids) {
          if (String(id).startsWith("transfer:")) {
            const writer = createApiWriter(company.id, (path, init) => request(path, token, init));
            await writer.action("/api/v1/bank/transfers/", String(id).slice("transfer:".length), "cancel", {});
          } else {
            await request(
              `/api/v1/cash/transactions/${id}/?company_id=${encodeURIComponent(company.id)}`,
              token,
              { method: "DELETE" },
            );
          }
        }
        setTransactions((rows) => {
          const next = rows.filter((row) => !ids.includes(row.id));
          const curr = cashDataCache.get(company.id);
          if (curr) curr.transactions = next;
          return next;
        });
        setCheckedCashRows((prev) => prev.filter((id) => !ids.includes(id)));
        if (viewingCashVoucher && ids.includes(viewingCashVoucher.id)) {
          setViewingCashVoucher(null);
        }
        notify(`Đã xóa ${ids.length} chứng từ thành công.`);
        return true;
      } catch (error) {
        notify(error instanceof Error ? error.message : "Không thể xóa chứng từ.");
        return false;
      }
    }
    if (action === "clone") {
      const src = transactions.find((r) => r.id === ids[0]);
      if (!src || String(src.id).startsWith("transfer:")) {
        notify("Không thể nhân bản chứng từ này.");
        return false;
      }
      try {
        const writer = createApiWriter(company.id, (path, init) => request(path, token, init));
        const fund = cashFunds.find((f) => f.id === src.fundId) || cashFunds[0];
        if (!fund) throw new Error("Chưa có quỹ tiền mặt đang hoạt động.");
        const prefix = src.kind === "receipt" ? "PT" : "PC";
        const newNumber = await nextVoucherNumber(writer, "/api/v1/cash/transactions/", prefix);
        const clonePayload: Record<string, any> = {
          fund: fund.id,
          currency: src.currencyId || fund.currency,
          number: newNumber,
          transaction_date: currentCashDate(),
          transaction_type: src.transactionType || (src.kind === "receipt" ? "RECEIPT" : "PAYMENT"),
          payer_payee: src.partner || src.person || "",
          description: src.description || "",
          amount: String(src.amount),
        };
        if (src.businessType) clonePayload.business_type = src.businessType;
        if (src.partyId) clonePayload.party = src.partyId;
        if (src.rawReceiptDetails && Object.keys(src.rawReceiptDetails).length > 0) {
          clonePayload.receipt_details = {
            ...src.rawReceiptDetails,
            posting_date: currentCashDate(),
          };
        }
        const saved = (await writer.post("/api/v1/cash/transactions/", clonePayload)) as ApiCashTransaction;
        const mapped = mapCashTransaction(saved);
        setTransactions((rows) => {
          const next = [mapped, ...rows];
          const curr = cashDataCache.get(company.id);
          if (curr) curr.transactions = next;
          return next;
        });
        setSelectedRowId(mapped.id);
        setViewingCashVoucher(mapped);
        notify(`Đã nhân bản thành chứng từ mới ${mapped.code}. Bạn có thể chỉnh sửa ngay.`);
        return true;
      } catch (error) {
        notify(error instanceof Error ? error.message : "Không thể nhân bản chứng từ.");
        return false;
      }
    }
    try {
      const writer = createApiWriter(company.id, (path, init) => request(path, token, init));
      const transferIds = ids.filter((id) => String(id).startsWith("transfer:"));
      if (transferIds.length && action !== "post") throw new Error("Lệnh chuyển tiền nội bộ đã thực hiện không bỏ ghi được từ danh sách.");
      for (const id of transferIds) await completeTransfer(writer, "cash", String(id).slice("transfer:".length));
      if (transferIds.length) reloadCashApi();
      const updated: ApiCashTransaction[] = [];
      for (const id of ids.filter((value) => !String(value).startsWith("transfer:"))) {
        updated.push(action === "post" ? await postMoneyTransaction(writer, "cash", id) : await reverseMoneyTransaction(writer, "cash", id));
      }
      const byId = new Map(updated.map((row) => [row.id, mapCashTransaction(row)]));
      setTransactions((rows) => {
        const next = rows.map((row) => byId.get(row.id) || row);
        const curr = cashDataCache.get(company.id);
        if (curr) curr.transactions = next;
        return next;
      });
      setCheckedCashRows([]);
      notify(`Đã ${action === "post" ? "ghi sổ" : "bỏ ghi sổ"} ${updated.length} chứng từ.`);
      try {
        const response = await request<ApiCashFund[] | { results: ApiCashFund[] }>(
          `/api/v1/cash/funds/?company_id=${encodeURIComponent(company.id)}`, token,
        );
        const funds = Array.isArray(response) ? response : response.results;
        setCashBalance(funds.reduce((total, fund) => total + Number(fund.balance), 0));
      } catch {
        notify("Giao dịch đã cập nhật, nhưng chưa tải lại được số dư tiền mặt.");
      }
    } catch (error) {
      notify(error instanceof Error ? error.message : "Không thực hiện được thao tác tiền mặt.");
    }
  };

  // Total summary
  const totalReceipt = cashCurrentLedger.receipt;
  const totalPayment = cashCurrentLedger.payment;
  const effectiveCashBalance = transactions.length > 0 ? cashCurrentLedger.closing : cashBalance;

  // Handler for Tax payment submission
  const handleTaxPayment = async (taxData: any) => {
    if (token) {
      const saved = await apiSave((writer) => saveMoneyVoucher(writer, "cash", {
        kind: "payment",
        date: taxData.taxDate,
        postDate: taxData.taxDate,
        partner: "Kho bạc Nhà nước / Chi cục Thuế",
        person: "Thủ quỹ Vũ Thị Mai",
        description: `Nộp ${taxData.taxType} vào NSNN`,
        amount: taxData.totalAmount,
        debit: "33311",
        credit: "1111",
        lines: (taxData.items || []).filter((r: any) => Number(r.payThisTime || r.amount || 0) > 0).map((r: any) => ({
          description: r.description || `Nộp ${taxData.taxType} vào NSNN`,
          debitAccount: r.account || "33311",
          creditAccount: "1111",
          amount: Number(r.payThisTime || r.amount || 0),
        })),
      }));
      if (saved) setShowTaxModal(false);
      return saved;
    }
    const newDoc = {
      id: crypto.randomUUID(),
      code: `PC${String(transactions.length + 1).padStart(5, "0")}`,
      date: taxData.taxDate,
      partner: "Kho bạc Nhà nước / Chi cục Thuế",
      person: "Thủ quỹ Vũ Thị Mai",
      description: `Nộp ${taxData.taxType} vào NSNN`,
      amount: taxData.totalAmount,
      kind: "payment",
      debit: "33311",
      credit: "1111",
      status: "posted",
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowTaxModal(false);
    notify(`Đã lập thành công chứng từ ${newDoc.code} - Nộp thuế ${formatVND(taxData.totalAmount)}đ!`);
  };

  // Handler for Supplier payment submission
  const handleSupplierPayment = async (data: any) => {
    if (token) {
      const saved = await apiSave((writer) => saveSupplierPayment(writer, data));
      if (saved) setShowSupplierPayment(false);
      return saved;
    }
    const newDoc = {
      id: crypto.randomUUID(),
      code: `PC${String(transactions.length + 1).padStart(5, "0")}`,
      date: data.payDate,
      partner: data.supplier,
      person: data.employee,
      description: `Trả tiền nhà cung cấp ${data.supplier} theo hóa đơn`,
      amount: data.totalAmount,
      kind: "payment",
      debit: "331",
      credit: "1111",
      status: "posted",
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowSupplierPayment(false);
    notify(
      `Đã lập thành công chứng từ ${newDoc.code} - Trả tiền NCC ${formatVND(data.totalAmount)}đ!`,
    );
  };

  const handleCustomerCollection = async (data: any) => {
    if (token) {
      const saved = await apiSave((writer) => saveCustomerReceipts(writer, data));
      if (saved) setShowCustomerCollection(false);
      return saved;
    }
    const ptCode = `PT${String(transactions.length + 1).padStart(5, "0")}`;
    const newDoc = {
      id: crypto.randomUUID(),
      code: ptCode,
      date: data.collectDate,
      partner: data.customer,
      person: data.employee || data.customer,
      description: `Thu tiền bán hàng từ khách hàng ${data.customer} theo hóa đơn`,
      amount: data.totalAmount,
      kind: "receipt",
      debit: "1111",
      credit: "131",
      status: "posted",
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowCustomerCollection(false);
    notify(
      `Đã lập thành công chứng từ ${newDoc.code} - Thu nợ khách hàng ${formatVND(data.totalAmount)}đ!`,
    );
  };

  const handleMultiCustomerCollection = async (data: any) => {
    if (token) {
      const saved = await apiSave((writer) => saveCustomerReceipts(writer, data));
      if (saved) setShowMultiCustomerCollection(false);
      return saved;
    }
    const nextNum = transactions.length + 1;
    const docCode = `PT${String(nextNum).padStart(5, "0")}`;
    const newDoc: any = {
      id: `pt-${Date.now()}`,
      code: docCode,
      date: data.collectDate || "30/09/2026",
      postDate: data.collectDate || "30/09/2026",
      partner: "Nhiều khách hàng",
      person: data.employee || "Thủ quỹ",
      description: `Thu tiền theo hóa đơn nhiều khách hàng (${data.invoices?.length || 0} hóa đơn)`,
      amount: data.totalAmount,
      kind: "receipt",
      debit: "1111",
      credit: "131",
      status: "posted",
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowMultiCustomerCollection(false);
    notify(
      `Đã lập thành công chứng từ ${newDoc.code} - Thu nợ nhiều khách hàng ${formatVND(data.totalAmount)}đ!`,
    );
  };

  // Handler for saving voucher
  const handleSaveVoucher = async (doc: any) => {
    if (!token || !company?.id) return false;
    if (doc.kind === "receipt" && doc.receiptType && doc.voucherCategory !== "bank") {
      return apiSave((writer) => saveCashReceiptDraft(writer, doc));
    }
    return apiSave((writer) => saveMoneyVoucher(writer, "cash", doc));
  };

  const handleInsurancePayment = async (data: any) => {
    if (token) {
      // Pays the insurance of the latest posted salary sheet and links the voucher to it.
      const saved = await apiSave((writer) => savePayrollPayment(writer, { ...data, payMethod: "cash" }, true));
      if (saved) { setShowInsuranceModal(false); reloadCashApi(); }
      return saved;
    }
    const nextNum = transactions.length + 1;
    const docCode = `PC${String(nextNum).padStart(5, "0")}`;
    const newDoc = {
      id: `pc-${Date.now()}`,
      code: docCode,
      date: data.payDate || "30/09/2026",
      postDate: data.payDate || "30/09/2026",
      partner: data.insuranceUnit || "Cơ quan Bảo hiểm Xã hội",
      person: "Kế toán tiền mặt",
      description: `Chi nộp BHXH, BHYT, BHTN tháng ${data.payDate?.substring(3, 5) || "09"}/2026`,
      amount: data.totalAmount,
      kind: "payment",
      debit: "3383",
      credit: "1111",
      status: "posted",
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowInsuranceModal(false);
    notify(`Đã lập thành công chứng từ ${docCode} - Nộp bảo hiểm ${formatVND(data.totalAmount)}đ!`);
  };

  const handleSalaryPayment = async (data: any) => {
    if (token) {
      const saved = await apiSave((writer) => savePayrollPayment(writer, { ...data, payMethod: "cash" }, false));
      if (saved) { setShowSalaryModal(false); reloadCashApi(); }
      return saved;
    }
    const nextNum = transactions.length + 1;
    const docCode = `PC${String(nextNum).padStart(5, "0")}`;
    const newDoc = {
      id: `pc-${Date.now()}`,
      code: docCode,
      date: data.payDate || "30/09/2026",
      postDate: data.payDate || "30/09/2026",
      partner: "Cán bộ nhân viên",
      person: "Thủ quỹ",
      description: `Chi trả lương nhân viên tháng ${data.payDate?.substring(3, 5) || "09"}/2026 (${data.employees?.length || 4} nhân viên)`,
      amount: data.totalAmount,
      kind: "payment",
      debit: "3341",
      credit: "1111",
      status: "posted",
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowSalaryModal(false);
    notify(`Đã lập thành công chứng từ ${docCode} - Trả lương ${formatVND(data.totalAmount)}đ!`);
  };

  const handleInternalTransfer = async (data: any) => {
    if (token) {
      try {
        const source = String(data.sourceAccount || "");
        const target = String(data.targetAccount || "");
        const sourceFund = source.startsWith("CASH:") ? source.slice(5) : "";
        const targetFund = target.startsWith("CASH:") ? target.slice(5) : "";
        const bankAccount = source.startsWith("BANK:") ? source.slice(5) : target.startsWith("BANK:") ? target.slice(5) : "";
        const transferType = sourceFund && targetFund ? "FUND_TO_FUND" : sourceFund && bankAccount ? "CASH_TO_BANK" : bankAccount && targetFund ? "BANK_TO_CASH" : "";
        if (!transferType || source === target) throw new Error("Chọn hai quỹ hoặc một quỹ và một tài khoản ngân hàng khác nhau.");
        if (!(Number(data.amount) > 0)) throw new Error("Số tiền chuyển phải lớn hơn 0.");
        const writer = createApiWriter(company?.id || "", (path, init) => request(path, token, init));
        const record = await writer.post("/api/v1/cash/transfers/", {
          number: await nextVoucherNumber(writer, "/api/v1/cash/transfers/", "CK"),
          transfer_type: transferType, source_fund: sourceFund || null,
          destination_fund: targetFund || null, bank_account: bankAccount || null,
          transfer_date: toApiDate(data.transferDate), amount: String(data.amount),
          description: data.reason || "Chuyển tiền nội bộ",
        });
        setShowInternalTransfer(false);
        reloadCashApi();
        notify(`Đã lưu lệnh chuyển ${record.number}; lệnh hiện trong danh sách chứng từ.`);
      } catch (error) {
        notify(error instanceof Error ? error.message : "Không lưu được lệnh chuyển tiền nội bộ.");
      }
      return;
    }
    const nextNum = transactions.length + 1;
    const docCode = `CK${String(nextNum).padStart(5, "0")}`;
    const newDoc = {
      id: `ck-${Date.now()}`,
      code: docCode,
      date: data.transferDate || "29/09/2026",
      partner: "Nội bộ",
      person: "Thủ quỹ",
      description: data.reason || "Chuyển tiền nội bộ",
      amount: data.amount,
      kind: "payment",
      debit: "1111",
      credit: "1121",
      status: "posted",
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowInternalTransfer(false);
    notify(`Đã lập thành công lệnh chuyển tiền nội bộ ${formatVND(data.amount)}đ!`);
  };

  // --------------------------------------------------------------------
  // RENDER TAB: "Thu, chi tiền"
  // --------------------------------------------------------------------
  if (tab === "transactions" || tab === "all") {
    return (
      <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#f8fafc" }}>
        {cashImportKind&&<CashExcelImport kind={cashImportKind} existingCodes={transactions.map(row=>row.code)} onClose={()=>setCashImportKind(null)} onImport={documents=>{setTransactions(previous=>[...documents,...previous]);setCashPage(1);setSelectedRowId(documents[0]?.id||selectedRowId);notify(`Đã nhập ${documents.length} chứng từ từ Excel vào frontend.`);}}/>}
        {cashControlPanel==='filters'&&<CashAdvancedPanel mode="filters" filter={cashFilter} hidden={[]} reasons={[...MISA_RECEIPT_TYPES,...MISA_PAYMENT_TYPES].map(type=>type.label.replace(/^\d+\.\s*/,''))} onClose={()=>setCashControlPanel(null)} onColumns={()=>{}} onFilter={value=>{setCashFilter(value);setStatusFilter(value.status);setFilterPeriod('custom');setCashPage(1);}}/>}
        {cashControlPanel==='columns'&&<CashColumnDialog value={cashColumns} onClose={()=>setCashControlPanel(null)} onSave={value=>{setCashColumns(value);try{localStorage.setItem(cashColumnsKey,JSON.stringify(value));}catch{notify('Đã áp dụng cột, nhưng trình duyệt không lưu được tùy chọn.');}}}/>}
        {cashPendingDeletion&&<div className="ce-overlay"><section role="alertdialog" aria-modal="true" aria-label="Xác nhận xóa chứng từ" className="ce-form" style={{position:'absolute',left:'50%',top:'50%',transform:'translate(-50%,-50%)',width:380,maxWidth:'90vw'}}><h2>Xác nhận xóa chứng từ</h2><p>Xóa {cashPendingDeletion.length} chứng từ khỏi danh sách frontend? Bạn có thể hoàn tác sau khi xóa.</p><div className="ce-toolbar"><button autoFocus onClick={()=>setCashPendingDeletion(null)}>Hủy xóa</button><button className="ce-primary" onClick={()=>{setCashTrash(transactions.filter(row=>cashPendingDeletion.includes(row.id)));setTransactions(rows=>rows.filter(row=>!cashPendingDeletion.includes(row.id)));setCashPendingDeletion(null);setCheckedCashRows([]);notify('Đã xóa khỏi danh sách frontend.');}}>Xác nhận xóa</button></div></section></div>}

        {(checkedCashRows.length>0||cashTrash.length>0)&&<div className="ce-toolbar" style={{padding:'8px 14px',background:'white'}}><strong>Đã chọn {checkedCashRows.length}</strong><button onClick={()=>setCheckedCashRows([])}>Bỏ chọn</button><button onClick={()=>cashRowAction('post')}>Ghi sổ</button><button onClick={()=>cashRowAction('unpost')}>Bỏ ghi</button><button onClick={()=>cashRowAction('delete')}>Xóa</button>{cashTrash.length>0&&<button onClick={()=>{setTransactions(rows=>[...cashTrash,...rows]);setCashTrash([]);}}>Hoàn tác xóa</button>}</div>}
        {/* KPI Strip (Matching user screenshot) */}
        {!kpiCollapsed && (
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(3, 1fr)",
              gap: 12,
              padding: "10px 14px 4px 14px",
              background: "#ffffff",
            }}
          >
            {/* Card 1: Tổng thu */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: 8,
                padding: "10px 14px",
                display: "flex",
                alignItems: "center",
                gap: 12,
                boxShadow: "0 1px 3px rgba(0,0,0,0.02)",
              }}
            >
              <div
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 8,
                  background: "#ecfdf5",
                  border: "1px solid #a7f3d0",
                  display: "grid",
                  placeItems: "center",
                  color: "var(--brand)",
                  flexShrink: 0,
                }}
              >
                <Coins size={22} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: "#334155", fontWeight: 500, marginBottom: 2 }}>
                  Tổng thu đầu năm đến hiện tại
                </div>
                <div style={{ fontSize: 18, fontWeight: 700, color: "var(--brand)" }}>
                  {formatVND(totalReceipt)}
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 3, fontSize: 11.5, color: "#94a3b8" }}>
                <Clock size={12} />
                <span>{new Date().toLocaleTimeString("vi-VN",{hour:"2-digit",minute:"2-digit"})}</span>
              </div>
            </div>

            {/* Card 2: Tổng chi */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: 8,
                padding: "10px 14px",
                display: "flex",
                alignItems: "center",
                gap: 12,
                boxShadow: "0 1px 3px rgba(0,0,0,0.02)",
              }}
            >
              <div
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 8,
                  background: "#fff7ed",
                  border: "1px solid #fed7aa",
                  display: "grid",
                  placeItems: "center",
                  color: "#ea580c",
                  flexShrink: 0,
                }}
              >
                <Coins size={22} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: "#334155", fontWeight: 500, marginBottom: 2 }}>
                  Tổng chi đầu năm đến hiện tại
                </div>
                <div style={{ fontSize: 18, fontWeight: 700, color: "#ea580c" }}>
                  {formatVND(totalPayment)}
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 3, fontSize: 11.5, color: "#94a3b8" }}>
                <Clock size={12} />
                <span>{new Date().toLocaleTimeString("vi-VN",{hour:"2-digit",minute:"2-digit"})}</span>
              </div>
            </div>

            {/* Card 3: Tồn quỹ */}
            <div
              style={{
                background: "#ffffff",
                border: "1px solid #e2e8f0",
                borderRadius: 8,
                padding: "10px 14px",
                display: "flex",
                alignItems: "center",
                gap: 12,
                boxShadow: "0 1px 3px rgba(0,0,0,0.02)",
              }}
            >
              <div
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 8,
                  background: "#f5f3ff",
                  border: "1px solid #ddd6fe",
                  display: "grid",
                  placeItems: "center",
                  color: "#7c3aed",
                  flexShrink: 0,
                }}
              >
                <Coins size={22} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: "#334155", fontWeight: 500, marginBottom: 2 }}>
                  Tồn quỹ đến ngày {currentCashDate()}
                </div>
                <div style={{ fontSize: 18, fontWeight: 700, color: "#dc2626" }}>
                  {effectiveCashBalance<0?`(${formatVND(Math.abs(effectiveCashBalance))})`:formatVND(effectiveCashBalance)}
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 3, fontSize: 11.5, color: "#94a3b8" }}>
                <Clock size={12} />
                <span>{new Date().toLocaleTimeString("vi-VN",{hour:"2-digit",minute:"2-digit"})}</span>
              </div>
            </div>
          </div>
        )}

        {/* Center Collapse/Expand Button for KPI strip */}
        <div style={{ display: "flex", justifyContent: "center", background: "#ffffff", borderBottom: "1px solid #e5e7eb", paddingBottom: 2 }}>
          <button
            type="button"
            onClick={() => setKpiCollapsed(!kpiCollapsed)}
            style={{
              width: 32,
              height: 16,
              background: "#ffffff",
              border: "1px solid #cbd5e1",
              borderBottom: "none",
              borderRadius: "6px 6px 0 0",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: "#64748b",
              boxShadow: "0 -1px 2px rgba(0,0,0,0.04)",
            }}
            title={kpiCollapsed ? "Mở rộng thẻ chỉ số" : "Thu gọn thẻ chỉ số"}
          >
            {kpiCollapsed ? <ChevronDown size={12} /> : <ChevronUp size={12} />}
          </button>
        </div>

        {/* Click outside backdrop for toolbar dropdowns */}
        {activeToolbarMenu && (
          <div
            style={{ position: "fixed", inset: 0, zIndex: 18 }}
            onClick={() => setActiveToolbarMenu(null)}
          />
        )}

        {/* Action Toolbar (Exact layout from user screenshot) */}
        <div
          className="misa-toolbar"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "8px 14px",
            background: "#ffffff",
            borderBottom: "1px solid #e2e8f0",
            position: "relative",
            zIndex: 19,
            gap: 8,
          }}
        >
          {/* Left Controls: Search, Loại phiếu, Period, Utility Icons */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            {/* Search Box */}
            <div style={{ position: "relative", width: 200 }}>
              <Search
                size={14}
                style={{
                  position: "absolute",
                  left: 9,
                  top: "50%",
                  transform: "translateY(-50%)",
                  color: "#8b5cf6",
                }}
              />
              <input
                type="text"
                placeholder="Tìm kiếm"
                value={searchQuery}
                onInput={e=>setSearchQuery(e.currentTarget.value)}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  width: "100%",
                  height: 32,
                  paddingLeft: 28,
                  paddingRight: 8,
                  borderRadius: 6,
                  border: "1px solid #d1d5db",
                  fontSize: 13,
                  outline: "none",
                  background: "#ffffff",
                }}
              />
            </div>

            {/* Loại phiếu dropdown */}
            <MisaDropdownSelect
              value={voucherTypeFilter}
              onChange={(val) => setVoucherTypeFilter(val)}
              title="LOẠI PHIẾU"
              options={[
                { value: "all", label: "Loại phiếu: Tất cả" },
                { value: "receipt", label: "Loại phiếu: Thu tiền" },
                { value: "payment", label: "Loại phiếu: Chi tiền" },
              ]}
              ariaLabel="Lọc theo loại phiếu"
            />

            {/* Period select: Đầu năm tới hiện tại */}
            <MisaDropdownSelect
              value={filterPeriod}
              onChange={(val) => setFilterPeriod(val)}
              title="KỲ THỜI GIAN"
              options={[
                { value: "ytd", label: "Kỳ: Đầu năm tới hiện tại" },
                { value: "month", label: "Kỳ: Tháng này" },
                { value: "quarter", label: "Kỳ: Quý này" },
                { value: "year", label: "Kỳ: Năm nay" },
                { value: "custom", label: "Kỳ: Tùy chọn" },
                ...CASH_PERIODS.filter(
                  (period) =>
                    ![
                      "Đầu năm đến hiện tại",
                      "Tháng này",
                      "Quý này",
                      "Năm nay",
                      "Tùy chọn",
                    ].includes(period)
                ).map((period) => ({ value: period, label: `Kỳ: ${period}` })),
              ]}
              ariaLabel="Kỳ thu chi tiền mặt"
            />

            {/* Icon buttons group */}
            <button
              type="button"
              className="misa-tax-icon-btn"
              title="Làm mới dữ liệu"
              onClick={() => {setTransactions(rows=>[...rows]);setCashPage(1);notify("Đã cập nhật danh sách.");}}
              style={{
                width: 32,
                height: 32,
                border: "1px solid #d1d5db",
                borderRadius: 6,
                background: "#ffffff",
                display: "grid",
                placeItems: "center",
                color: "#64748b",
                cursor: "pointer",
              }}
            >
              <RefreshCw size={15} />
            </button>

            <button
              type="button"
              className="misa-tax-icon-btn"
              title="Tùy chọn điều chuyển / sắp xếp"
              onClick={() => setCashSortAscending(value=>!value)}
              style={{
                width: 32,
                height: 32,
                border: "1px solid #d1d5db",
                borderRadius: 6,
                background: "#ffffff",
                display: "grid",
                placeItems: "center",
                color: "#64748b",
                cursor: "pointer",
              }}
            >
              <SlidersHorizontal size={15} />
            </button>

            <button
              type="button"
              className="misa-tax-icon-btn"
              title="Xuất khẩu / Nhập khẩu"
              onClick={() => downloadCashCsv('Thu-chi-tien-mat', [['Ngày hạch toán','Số chứng từ','Diễn giải','Số tiền','Đối tượng','Trạng thái'],...filteredList.map(row=>[row.date,row.code,row.description,row.amount,row.partner,row.status==='posted'?'Đã ghi sổ':'Chưa ghi sổ'])])}
              style={{
                width: 32,
                height: 32,
                border: "1px solid #d1d5db",
                borderRadius: 6,
                background: "#ffffff",
                display: "grid",
                placeItems: "center",
                color: "#64748b",
                cursor: "pointer",
              }}
            >
              <FileSpreadsheet size={15} />
            </button>
            <div style={{ position: "relative" }}>
              <button
                type="button"
                onClick={() => setCashExcelMenuOpen((prev) => !prev)}
                style={{
                  height: 32,
                  padding: "0 10px",
                  border: "1px solid #d1d5db",
                  borderRadius: 6,
                  background: cashExcelMenuOpen ? "#f0fdf4" : "#ffffff",
                  borderColor: cashExcelMenuOpen ? "var(--brand)" : "#d1d5db",
                  color: cashExcelMenuOpen ? "var(--brand)" : "#334155",
                  fontSize: 12.5,
                  fontWeight: 500,
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  cursor: "pointer",
                }}
              >
                <span>Nhập/Xuất Excel</span>
                <ChevronDown size={13} style={{ transform: cashExcelMenuOpen ? "rotate(180deg)" : "none", transition: "transform 0.15s" }} />
              </button>
              {cashExcelMenuOpen && (
                <>
                  <div
                    style={{ position: "fixed", inset: 0, zIndex: 45 }}
                    onClick={() => setCashExcelMenuOpen(false)}
                  />
                  <div className="misa-row-action-menu" style={{ minWidth: 195, zIndex: 50 }}>
                    <button
                      type="button"
                      className="misa-row-action-item"
                      onClick={() => {
                        setCashExcelMenuOpen(false);
                        void exportCashExcel();
                      }}
                    >
                      Xuất ra file Excel (.xlsx)
                    </button>
                    <div className="misa-row-action-divider" />
                    <button
                      type="button"
                      className="misa-row-action-item"
                      onClick={() => {
                        setCashExcelMenuOpen(false);
                        setCashImportKind("receipt");
                      }}
                    >
                      Nhập phiếu thu từ Excel
                    </button>
                    <button
                      type="button"
                      className="misa-row-action-item"
                      onClick={() => {
                        setCashExcelMenuOpen(false);
                        setCashImportKind("payment");
                      }}
                    >
                      Nhập phiếu chi từ Excel
                    </button>
                  </div>
                </>
              )}
            </div>

            <button
              type="button"
              className="misa-tax-icon-btn"
              title="Tùy chọn cột và thiết lập"
              onClick={() => setCashControlPanel('columns')}
              style={{
                width: 32,
                height: 32,
                border: "1px solid #d1d5db",
                borderRadius: 6,
                background: "#ffffff",
                display: "grid",
                placeItems: "center",
                color: "#64748b",
                cursor: "pointer",
              }}
            >
              <Settings size={15} />
            </button>

            <button
              type="button"
              className="misa-tax-icon-btn"
              title="Bộ lọc nâng cao"
              onClick={() => setCashControlPanel('filters')}
              style={{
                width: 32,
                height: 32,
                border: "1px solid #d1d5db",
                borderRadius: 6,
                background: "#ffffff",
                display: "grid",
                placeItems: "center",
                color: "#64748b",
                cursor: "pointer",
              }}
            >
              <Filter size={15} />
            </button>
          </div>

          {/* Right Buttons: Thêm thu tiền, Thêm chi tiền */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
            {/* Thêm thu tiền Dropdown Button (Screenshot 3) */}
            <div style={{ position: "relative" }}>
              <button
                type="button"
                onClick={() =>
                  setActiveToolbarMenu((prev) => (prev === "receipt" ? null : "receipt"))
                }
                style={{
                  height: 34,
                  padding: "0 14px",
                  background: "var(--brand)",
                  color: "#ffffff",
                  border: "none",
                  borderRadius: 6,
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  fontSize: 13,
                  fontWeight: 600,
                  cursor: "pointer",
                  boxShadow: "0 1px 3px rgba(0, 176, 107, 0.3)",
                }}
              >
                <span>Thêm thu tiền</span>
                <ChevronDown size={14} />
              </button>

              {activeToolbarMenu === "receipt" && (
                <div
                  style={{
                    position: "absolute",
                    top: "calc(100% + 4px)",
                    right: 0,
                    minWidth: 295,
                    width: "max-content",
                    background: "#ffffff",
                    borderRadius: 8,
                    boxShadow: "0 10px 25px rgba(0, 0, 0, 0.12)",
                    border: "1px solid #e2e8f0",
                    padding: "6px 0",
                    zIndex: 50,
                    display: "flex",
                    flexDirection: "column",
                  }}
                >
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setVoucherCategoryChoice("cash");
                      setShowCreateVoucher("receipt");
                    }}
                  >
                    Thu tiền
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setShowCustomerCollection(true);
                    }}
                  >
                    Thu tiền theo hóa đơn
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setShowMultiCustomerCollection(true);
                    }}
                  >
                    Thu tiền theo nhiều hóa đơn
                  </button>
                </div>
              )}
              {activeToolbarMenu && (
                <div
                  style={{ position: "fixed", inset: 0, zIndex: 40 }}
                  onClick={() => setActiveToolbarMenu(null)}
                />
              )}
            </div>

            {/* Thêm chi tiền Dropdown Button (Screenshot 4) */}
            <div style={{ position: "relative" }}>
              <button
                type="button"
                onClick={() =>
                  setActiveToolbarMenu((prev) => (prev === "payment" ? null : "payment"))
                }
                style={{
                  height: 34,
                  padding: "0 14px",
                  background: "var(--brand)",
                  color: "#ffffff",
                  border: "none",
                  borderRadius: 6,
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  fontSize: 13,
                  fontWeight: 600,
                  cursor: "pointer",
                  boxShadow: "0 1px 3px rgba(0, 176, 107, 0.3)",
                }}
              >
                <span>Thêm chi tiền</span>
                <ChevronDown size={14} />
              </button>

              {activeToolbarMenu === "payment" && (
                <div
                  style={{
                    position: "absolute",
                    top: "calc(100% + 4px)",
                    right: 0,
                    minWidth: 220,
                    background: "#ffffff",
                    borderRadius: 8,
                    boxShadow: "0 10px 25px rgba(0, 0, 0, 0.12)",
                    border: "1px solid #e2e8f0",
                    padding: "6px 0",
                    zIndex: 50,
                    display: "flex",
                    flexDirection: "column",
                  }}
                >
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setVoucherCategoryChoice("cash");
                      setShowCreateVoucher("payment");
                    }}
                  >
                    Phiếu chi
                  </button>
                  <div
                    style={{ position: "relative" }}
                    onMouseEnter={() => setShowCashPaymentSubmenu(true)}
                    onMouseLeave={() => setShowCashPaymentSubmenu(false)}
                  >
                    <button
                      type="button"
                      style={{
                        textAlign: "left",
                        padding: "10px 18px",
                        border: "none",
                        background: showCashPaymentSubmenu ? "#f1f5f9" : "transparent",
                        fontSize: 13.5,
                        color: "#1e293b",
                        cursor: "pointer",
                        width: "100%",
                        fontFamily: "inherit",
                        whiteSpace: "nowrap",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                      onClick={() => {
                        setActiveToolbarMenu(null);
                        setShowCashPaymentSubmenu(false);
                        setVoucherCategoryChoice("bank");
                        setCreateVoucherTypeIndex(0);
                        setShowCreateVoucher("payment");
                      }}
                    >
                      <span>Chi tiền</span>
                      <ChevronRight size={14} style={{ color: "#64748b" }} />
                    </button>

                    {showCashPaymentSubmenu && (
                      <div
                        style={{
                          position: "absolute",
                          top: 0,
                          right: "100%",
                          marginRight: 4,
                          minWidth: 320,
                          background: "#ffffff",
                          borderRadius: 8,
                          boxShadow: "0 10px 25px rgba(0, 0, 0, 0.15)",
                          border: "1px solid #e2e8f0",
                          padding: "6px 0",
                          zIndex: 60,
                        }}
                      >
                        {MISA_BANK_PAYMENT_TYPES.map((t, idx) => (
                          <button
                            key={t.id}
                            type="button"
                            style={{
                              textAlign: "left",
                              padding: "8px 16px",
                              border: "none",
                              background: "transparent",
                              fontSize: 13,
                              color: "#1e293b",
                              cursor: "pointer",
                              width: "100%",
                              fontFamily: "inherit",
                              whiteSpace: "nowrap",
                              display: "block",
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.background = "#dbece2";
                              e.currentTarget.style.color = "#047857";
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.background = "transparent";
                              e.currentTarget.style.color = "#1e293b";
                            }}
                            onClick={() => {
                              setActiveToolbarMenu(null);
                              setShowCashPaymentSubmenu(false);
                              setVoucherCategoryChoice("bank");
                              setCreateVoucherTypeIndex(idx);
                              setShowCreateVoucher("payment");
                            }}
                          >
                            {t.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setShowSupplierPayment(true);
                    }}
                  >
                    Trả tiền theo hóa đơn
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setShowTaxModal(true);
                    }}
                  >
                    Nộp thuế
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setShowInsuranceModal(true);
                    }}
                  >
                    Nộp bảo hiểm
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setShowSalaryModal(true);
                    }}
                  >
                    Trả lương
                  </button>
                </div>
              )}
              {activeToolbarMenu && (
                <div
                  style={{ position: "fixed", inset: 0, zIndex: 40 }}
                  onClick={() => setActiveToolbarMenu(null)}
                />
              )}
            </div>
          </div>
        </div>

        {/* Data Table */}
        <div style={{ flex: 1, overflowY: "auto", padding: "0 14px", background: "#ffffff" }}>
          <table className="misa-tax-table cash-transactions-table" style={{ marginTop: 8 }}>
            <thead>
              <tr>
                <th style={{ width: 36, textAlign: "center" }}>
                  <input type="checkbox" aria-label="Chọn tất cả" checked={filteredList.length > 0 && filteredList.every(t => checkedCashRows.includes(t.id))} onChange={event => setCheckedCashRows(event.target.checked ? filteredList.map(t => t.id) : [])} />
                </th>
                {cashColumns.filter(column=>column.visible).map(column=><th key={column.id} style={{width:column.width,minWidth:column.width}}>{column.name}</th>)}
              </tr>
            </thead>
            <tbody>
              {filteredList.slice((visibleCashPage - 1) * cashPageSize, visibleCashPage * cashPageSize).map((t) => (
                <tr
                  key={t.id}
                  className={selectedTransaction?.id === t.id ? "selected" : ""}
                  onClick={() => setSelectedRowId(t.id)}
                  style={{ cursor: "pointer" }}
                >
                  <td style={{ textAlign: "center" }} onClick={(e) => e.stopPropagation()}>
                    <input type="checkbox" aria-label={`Chọn ${t.code}`} checked={checkedCashRows.includes(t.id)} onChange={event => setCheckedCashRows(previous => event.target.checked ? [...previous, t.id] : previous.filter(id => id !== t.id))} />
                  </td>
                  {cashColumns.filter(column=>column.visible).map(column=>{const cells:React.ReactElement<any>[]=[<td>{t.date.split("-").reverse().join("/")}</td>,
<td>{t.date.split("-").reverse().join("/")}</td>,
<td>
                    <strong
                      style={{ color: "var(--brand)", cursor: "pointer", textDecoration: "underline", textUnderlineOffset: 2 }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedRowId(t.id);
                        setViewingCashVoucher(t);
                      }}
                      title={`Xem chi tiết chứng từ ${t.code}`}
                    >
                      {t.code}
                    </strong>
                  </td>,
<td title={t.description}>{t.description}</td>,
<td
                    className="numeric"
                    style={{
                      fontWeight: 600,
                      color: t.kind === "receipt" ? "#059669" : "#111827",
                    }}
                  >
                    {formatVND(t.amount)}
                  </td>,
<td title={t.partner}>{t.partner}</td>,
<td>{t.reasonLabel || cashReason(t.kind,t.description)}</td>,
<td>{t.kind === "receipt" ? "Phiếu thu" : "Phiếu chi"}</td>,
<td>{t.combineInvoices ? "Có" : ""}</td>,
<td>
                    <span
                      style={{
                        padding: "2px 8px",
                        borderRadius: 12,
                        fontSize: 11,
                        fontWeight: 600,
                        background: t.status === "posted" ? "#ecfdf5" : "#fffbeb",
                        color: t.status === "posted" ? "#047857" : "#b45309",
                        border: t.status === "posted" ? "1px solid #a7f3d0" : "1px solid #fde68a",
                      }}
                    >
                      {t.status==='posted'?'Đã ghi sổ':'Chưa ghi sổ'}
                    </span>
                  </td>,
<td style={{ textAlign: "center", position: "relative" }} onClick={(e) => e.stopPropagation()}>
                    <div className="misa-row-action-cell">
                      <button
                        type="button"
                        className="misa-row-action-link print"
                        title={`Mở mẫu in giấy A4 cho chứng từ ${t.code}`}
                        onClick={() => {
                          setSelectedVoucher({
                            code: t.code,
                            date: t.date,
                            person: t.person || t.partner,
                            address: t.address || "Hà Nội",
                            reason: t.description,
                            debitAccount: t.rows?.[0]?.debit || t.debit || "1111",
                            creditAccount: t.rows?.[0]?.credit || t.credit || "131",
                            amount: t.amount,
                            amountInWords: convertNumberToVietnameseWords(t.amount),
                            notes: "Chứng từ kèm theo quyết toán",
                            chiefAccountant: "Trương Thị B",
                            director: "Nguyễn Văn A",
                          });
                          setShowVoucherPrint(true);
                        }}
                      >
                        In
                      </button>
                      <button
                        type="button"
                        className="misa-row-action-link view"
                        title={`Xem chi tiết định khoản chứng từ ${t.code}`}
                        onClick={() => {
                          setSelectedRowId(t.id);
                          setViewingCashVoucher(t);
                        }}
                      >
                        Xem
                      </button>
                      <button
                        type="button"
                        aria-label={`Thao tác ${t.code}`}
                        aria-expanded={cashRowMenuId === t.id}
                        className={`misa-row-action-trigger ${cashRowMenuId === t.id ? "active" : ""}`}
                        onClick={() => setCashRowMenuId((prev) => (prev === t.id ? null : t.id))}
                        title="Thêm thao tác"
                      >
                        <ChevronDown size={13} style={{ transform: cashRowMenuId === t.id ? "rotate(180deg)" : "none", transition: "transform 0.15s" }} />
                      </button>
                      {cashRowMenuId === t.id && (
                        <>
                          <div
                            style={{ position: "fixed", inset: 0, zIndex: 70 }}
                            onClick={() => setCashRowMenuId(null)}
                          />
                          <div className="misa-row-action-menu" role="menu" aria-label={`Menu thao tác ${t.code}`}>
                            <button
                              type="button"
                              role="menuitem"
                              className="misa-row-action-item"
                              onClick={() => {
                                setCashRowMenuId(null);
                                setSelectedRowId(t.id);
                                setViewingCashVoucher(t);
                              }}
                            >
                              {t.status === "posted" ? "Xem chứng từ" : "Sửa chứng từ"}
                            </button>
                            <button
                              type="button"
                              role="menuitem"
                              className="misa-row-action-item"
                              onClick={() => {
                                setCashRowMenuId(null);
                                void cashRowAction(t.status === "posted" ? "unpost" : "post", [t.id]);
                              }}
                            >
                              {t.status === "posted" ? "Bỏ ghi sổ" : "Ghi sổ"}
                            </button>
                            <button
                              type="button"
                              role="menuitem"
                              className="misa-row-action-item"
                              onClick={() => {
                                setCashRowMenuId(null);
                                void cashRowAction("clone", [t.id]);
                              }}
                            >
                              Nhân bản
                            </button>
                            <div className="misa-row-action-divider" />
                            <button
                              type="button"
                              role="menuitem"
                              className="misa-row-action-item danger"
                              onClick={() => {
                                setCashRowMenuId(null);
                                void cashRowAction("delete", [t.id]);
                              }}
                            >
                              Xóa
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  </td>,
<td>{t.partnerCode || ""}</td>,
<td>{t.person || ""}</td>,
<td>{t.address || ""}</td>,
<td>{t.employee || ""}</td>,
<td>{t.cashBookDate || ""}</td>,
<td>{t.settled ? "Có" : ""}</td>,
<td>{t.extraFields?.[0] || ""}</td>,
<td>{t.extraFields?.[1] || ""}</td>,
<td>{t.extraFields?.[2] || ""}</td>,
<td>{t.extraFields?.[3] || ""}</td>,
<td>{t.extraFields?.[4] || ""}</td>,
<td>{t.extraFields?.[5] || ""}</td>,
<td>{t.extraFields?.[6] || ""}</td>,
<td>{t.extraFields?.[7] || ""}</td>,
<td>{t.extraFields?.[8] || ""}</td>,
<td>{t.extraFields?.[9] || ""}</td>,
<td>{t.createdBy || ""}</td>,
<td>{t.createdAt || ""}</td>,
<td>{t.updatedBy || ""}</td>,
<td>{t.updatedAt || ""}</td>];const cell=cells[column.id-2];return React.cloneElement(cell,{key:column.id,style:{...cell.props.style,width:column.width,minWidth:column.width}});})}
                </tr>
              ))}
              {!filteredList.length && <tr><td colSpan={1+cashColumns.filter(column=>column.visible).length} style={{textAlign: 'center', padding: 24}}>Không có chứng từ phù hợp với điều kiện tìm kiếm</td></tr>}
            </tbody>
            <tfoot><tr><td/>{cashColumns.filter(column=>column.visible).map(column=><td key={column.id}><strong>{column.id===6?formatVND(filteredList.reduce((sum,t)=>sum+t.amount,0)):column.id===2?'Tổng':''}</strong></td>)}</tr></tfoot>
          </table>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 0',fontSize:13}}>
            <span>Tổng số: <strong>{filteredList.length}</strong>{checkedCashRows.length > 0 && ` · Đã chọn ${checkedCashRows.length}`}</span>
            <div style={{display:'flex',alignItems:'center',gap:10}}>
              <div style={{display:'flex',alignItems:'center',gap:6}}>
                <span>Số dòng/trang:</span>
                <MisaDropdownSelect
                  value={cashPageSize}
                  onChange={(val) => {
                    setCashPageSize(Number(val));
                    setCashPage(1);
                  }}
                  options={[
                    { value: 20, label: "20" },
                    { value: 50, label: "50" },
                    { value: 100, label: "100" },
                  ]}
                  minWidth={90}
                  buttonStyle={{ height: 26, padding: "0 8px", fontSize: 12 }}
                  ariaLabel="Số dòng/trang"
                />
              </div>
              <button aria-label="Trang trước thu chi" disabled={visibleCashPage===1} onClick={()=>setCashPage(visibleCashPage-1)}>‹</button>
              <span>{visibleCashPage}/{cashPageCount}</span>
              <button aria-label="Trang sau thu chi" disabled={visibleCashPage===cashPageCount} onClick={()=>setCashPage(visibleCashPage+1)}>›</button>
            </div>
          </div>
        </div>

        {/* Split Detail Pane (Bottom Tab) */}
        {selectedTransaction && (
          <div
            style={{
              height: 265,
              minHeight: 245,
              borderTop: "1px solid #e5e7eb",
              background: "#ffffff",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "6px 14px",
                background: "#f8fafc",
                borderBottom: "1px solid #e2e8f0",
                flexWrap: "wrap",
                gap: 8,
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                <strong style={{ fontSize: 13, color: "#0f172a" }}>
                  Chi tiết hạch toán: <span style={{ color: "var(--brand)" }}>{selectedTransaction.code}</span> — {selectedTransaction.description}
                </strong>
                <span
                  style={{
                    padding: "2px 8px",
                    borderRadius: 12,
                    fontSize: 11,
                    fontWeight: 600,
                    background: selectedTransaction.status === "posted" ? "#ecfdf5" : "#fffbeb",
                    color: selectedTransaction.status === "posted" ? "#047857" : "#b45309",
                    border: selectedTransaction.status === "posted" ? "1px solid #a7f3d0" : "1px solid #fde68a",
                  }}
                >
                  {selectedTransaction.status === "posted" ? "Đã ghi sổ" : "Chưa ghi sổ"}
                </span>
                <span style={{ fontSize: 12, color: "#475569" }}>
                  · <strong>Loại phiếu:</strong> {selectedTransaction.kind === "receipt" ? "Phiếu thu tiền mặt" : "Phiếu chi tiền mặt"}
                </span>
                <span style={{ fontSize: 12, color: "#475569" }}>
                  · <strong>Nghiệp vụ:</strong> {selectedTransaction.reasonLabel || cashReason(selectedTransaction.kind, selectedTransaction.description)}
                </span>
                <span style={{ fontSize: 12, color: "#475569" }}>
                  · <strong>Người lập:</strong> {selectedTransaction.employee || selectedTransaction.createdBy || "Đỗ Đức Tùng"}
                </span>
                <span style={{ fontSize: 12, color: "#475569" }}>
                  · <strong>Sổ cái:</strong> <span style={{ color: "#2563eb", fontWeight: 600 }}>{selectedTransaction.glReference || (selectedTransaction.status === "posted" ? `GL-${selectedTransaction.code}` : "Chưa lên sổ cái")}</span>
                </span>
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button
                  type="button"
                  className="misa-btn-secondary"
                  style={{ height: 26, padding: "0 10px", fontSize: 11.5, fontWeight: 600, color: "var(--brand)", borderColor: "#bae6fd", background: "#f0f9ff" }}
                  onClick={() => setViewingCashVoucher(selectedTransaction)}
                >
                  {selectedTransaction.status === "posted" ? `Xem chi tiết (${selectedTransaction.code})` : `Sửa chứng từ (${selectedTransaction.code})`}
                </button>
                <button
                  type="button"
                  className="misa-btn-secondary"
                  style={{ height: 26, padding: "0 10px", fontSize: 11.5 }}
                  onClick={() => {
                    setSelectedVoucher({
                      code: selectedTransaction.code,
                      date: selectedTransaction.date,
                      person: selectedTransaction.person || selectedTransaction.partner,
                      address: selectedTransaction.address || "Cầu Giấy, Hà Nội",
                      reason: selectedTransaction.description,
                      debitAccount: cashDetailRows[0]?.debit || selectedTransaction.debit || "1111",
                      creditAccount: cashDetailRows[0]?.credit || selectedTransaction.credit || "131",
                      amount: selectedTransaction.amount,
                      amountInWords: convertNumberToVietnameseWords(selectedTransaction.amount),
                      notes: selectedTransaction.originalDocuments || "Chứng từ gốc kèm theo quyết toán",
                      chiefAccountant: "Trương Thị B",
                      director: "Nguyễn Văn A",
                    });
                    setShowVoucherPrint(true);
                  }}
                >
                  <Printer size={12} style={{ marginRight: 4 }} />
                  In chứng từ ({selectedTransaction.code})
                </button>
              </div>
            </div>

            <div style={{ flex: 1, overflowY: "auto", padding: "6px 14px" }}>
              <table className="misa-tax-table">
                <thead>
                  <tr>
                    <th style={{ width: 38 }}>STT</th>
                    <th style={{ width: 92 }}>Ngày HT</th>
                    <th style={{ width: 88 }}>Số CT</th>
                    <th>Diễn giải chi tiết</th>
                    <th style={{ width: 72 }}>TK Nợ</th>
                    <th style={{ width: 72 }}>TK Có</th>
                    <th className="numeric" style={{ width: 135 }}>Số tiền (VND)</th>
                    <th style={{ width: 95 }}>Mã đối tượng</th>
                    <th>Tên đối tượng</th>
                    <th>Người nộp/nhận</th>
                    <th>Địa chỉ</th>
                    <th style={{ width: 110 }}>Nghiệp vụ</th>
                  </tr>
                </thead>
                <tbody>
                  {cashDetailRows.slice((cashDetailVisiblePage - 1) * cashDetailSize, cashDetailVisiblePage * cashDetailSize).map((row, index) => (
                    <tr key={row.id}>
                      <td>{(cashDetailVisiblePage - 1) * cashDetailSize + index + 1}</td>
                      <td>{(selectedTransaction.postingDate || selectedTransaction.date || "").split("-").reverse().join("/")}</td>
                      <td><strong style={{ color: "var(--brand)" }}>{selectedTransaction.code}</strong></td>
                      <td>{row.description || selectedTransaction.description}</td>
                      <td><strong style={{ color: "#2563eb" }}>{row.debit || (selectedTransaction.kind === "receipt" ? "1111" : "331")}</strong></td>
                      <td><strong style={{ color: "#7c3aed" }}>{row.credit || (selectedTransaction.kind === "receipt" ? "131" : "1111")}</strong></td>
                      <td className="numeric"><strong>{formatVND(Number(row.amount) || 0)}</strong></td>
                      <td><span style={{ fontWeight: 600, color: "#334155" }}>{row.partnerCode || selectedTransaction.partnerCode || "DT001"}</span></td>
                      <td>{selectedTransaction.partner || row.partnerName || "—"}</td>
                      <td>{selectedTransaction.person || selectedTransaction.partner || "—"}</td>
                      <td>{selectedTransaction.address || "Hà Nội"}</td>
                      <td>{selectedTransaction.reasonLabel || cashReason(selectedTransaction.kind, selectedTransaction.description)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td />
                    <td colSpan={3}><strong>Tổng cộng định khoản ({cashDetailRows.length} dòng)</strong></td>
                    <td />
                    <td />
                    <td className="numeric"><strong>{formatVND(cashDetailRows.reduce((sum, row) => sum + (Number(row.amount) || 0), 0))}</strong></td>
                    <td colSpan={5} />
                  </tr>
                </tfoot>
              </table>
              <div
                className="ce-toolbar"
                style={{
                  justifyContent: "space-between",
                  alignItems: "center",
                  padding: "6px 0 2px",
                  margin: "6px 0 0",
                  fontSize: 12.5,
                }}
              >
                <span>Tổng số: <strong>{cashDetailRows.length}</strong> bản ghi chi tiết</span>
                <div style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
                  <div style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                    <span>Số dòng/trang:</span>
                    <MisaDropdownSelect
                      value={cashDetailSize}
                      onChange={(val) => {
                        setCashDetailSize(Number(val));
                        setCashDetailPage(1);
                      }}
                      options={[
                        { value: 20, label: "20" },
                        { value: 50, label: "50" },
                        { value: 100, label: "100" },
                      ]}
                      minWidth={86}
                      buttonStyle={{ height: 26, padding: "0 8px", fontSize: 12 }}
                      ariaLabel="Số dòng/trang chi tiết hạch toán"
                    />
                  </div>
                  <div style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                    <button
                      type="button"
                      aria-label="Trang trước chi tiết"
                      disabled={cashDetailVisiblePage === 1}
                      onClick={() => setCashDetailPage(cashDetailVisiblePage - 1)}
                      style={{ padding: "2px 8px", minWidth: 26, fontSize: 13, height: 26 }}
                    >
                      ‹
                    </button>
                    <span>
                      {cashDetailVisiblePage}/{cashDetailPages}
                    </span>
                    <button
                      type="button"
                      aria-label="Trang sau chi tiết"
                      disabled={cashDetailVisiblePage === cashDetailPages}
                      onClick={() => setCashDetailPage(cashDetailVisiblePage + 1)}
                      style={{ padding: "2px 8px", minWidth: 26, fontSize: 13, height: 26 }}
                    >
                      ›
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* MODALS */}
        {showTaxModal && (
          <TaxPaymentModal
            onClose={() => setShowTaxModal(false)}
            onSubmit={handleTaxPayment}
          />
        )}

        {showSupplierPayment && (
          <SupplierPaymentModal
            onClose={() => setShowSupplierPayment(false)}
            onSubmit={handleSupplierPayment}
            debtSource={payableSource}
          />
        )}

        {showCustomerCollection && (
          <SingleCustomerInvoiceCollectionModal
            initialMethod="cash"
            onClose={() => setShowCustomerCollection(false)}
            onSubmit={handleCustomerCollection}
            debtSource={debtSource}
          />
        )}

        {showMultiCustomerCollection && (
          <MultiCustomerInvoiceCollectionModal
            initialMethod="cash"
            onClose={() => setShowMultiCustomerCollection(false)}
            onSubmit={handleMultiCustomerCollection}
            debtSource={debtSource}
          />
        )}

        {showInsuranceModal && (
          <InsurancePaymentModal
            onClose={() => setShowInsuranceModal(false)}
            onSubmit={handleInsurancePayment}
            loadRecords={token ? () => insurancePaymentRows(createApiWriter(company?.id || "", (path, init) => request(path, token, init))) : undefined}
          />
        )}

        {showSalaryModal && (
          <SalaryPaymentModal
            onClose={() => setShowSalaryModal(false)}
            onSubmit={handleSalaryPayment}
            loadRecords={token ? () => salaryPaymentRows(createApiWriter(company?.id || "", (path, init) => request(path, token, init))) : undefined}
          />
        )}

        {showInternalTransfer && (
          <InternalTransferModal
            accounts={token ? [
              ...cashFunds.filter((fund) => fund.status === "ACTIVE").map((fund) => ({ value: `CASH:${fund.id}`, label: `Quỹ tiền mặt ${fund.id.slice(0, 8)}` })),
              ...(payableCatalog.bankAccounts || []).filter((account) => account.status === "ACTIVE").map((account) => ({ value: `BANK:${account.id}`, label: `${account.account_number} - ${account.bank_name || "Ngân hàng"}` })),
            ] : undefined}
            onClose={() => setShowInternalTransfer(false)}
            onSubmit={handleInternalTransfer}
          />
        )}

        {showVoucherPrint && (
          <AccountingVoucherModal
            voucher={selectedVoucher}
            onClose={() => setShowVoucherPrint(false)}
          />
        )}

        {viewingCashVoucher && (() => {
          const v = transactions.find((item) => item.id === viewingCashVoucher.id) || viewingCashVoucher;
          const isPosted = v.status === "posted";
          const activeRows: VoucherDetailRow[] = editCashRows.length
            ? editCashRows
            : [
                {
                  id: `${v.id}-0`,
                  description: v.description || "",
                  debit: v.debit || (v.kind === "receipt" ? "1111" : "331"),
                  credit: v.credit || (v.kind === "receipt" ? "131" : "1111"),
                  amount: Number(v.amount) || 0,
                  partnerCode: v.partnerCode || "",
                  partnerName: v.partner || "",
                },
              ];
          const computedTotal = activeRows.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
          return (
            <div className="misa-modal-overlay" onClick={() => setViewingCashVoucher(null)}>
              <div
                className="misa-voucher-window"
                style={{ width: "min(1180px, 95vw)", height: "auto", maxHeight: "90vh" }}
                onClick={(e) => e.stopPropagation()}
              >
                <div className="misa-voucher-header">
                  <div className="misa-voucher-header-left">
                    <h2 className="misa-voucher-title">
                      {v.kind === "receipt" ? "Phiếu thu tiền mặt" : "Phiếu chi tiền mặt"} — {editCashCode || v.code}
                    </h2>
                    <span
                      style={{
                        padding: "3px 10px",
                        borderRadius: 12,
                        fontSize: 12,
                        fontWeight: 600,
                        background: isPosted ? "#ecfdf5" : "#fffbeb",
                        color: isPosted ? "#047857" : "#b45309",
                        border: isPosted ? "1px solid #a7f3d0" : "1px solid #fde68a",
                      }}
                    >
                      {isPosted ? "Đã ghi sổ (Chỉ xem)" : "Chưa ghi sổ (Cho phép sửa)"}
                    </span>
                  </div>
                  <div className="misa-voucher-header-tools">
                    <button
                      type="button"
                      className="misa-voucher-close-btn"
                      onClick={() => setViewingCashVoucher(null)}
                      title="Đóng (ESC)"
                    >
                      <X size={18} />
                    </button>
                  </div>
                </div>

                <div className="misa-voucher-body" style={{ paddingBottom: 12 }}>
                  {isPosted && (
                    <div
                      style={{
                        margin: "10px 20px 0",
                        padding: "8px 14px",
                        borderRadius: 8,
                        background: "#fffbeb",
                        border: "1px solid #fde68a",
                        color: "#92400e",
                        fontSize: 12.5,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        gap: 12,
                      }}
                    >
                      <span>
                        Chứng từ này <strong>đã ghi sổ</strong> nên đang được khóa chỉnh sửa để đảm bảo an toàn số liệu kế toán. Bấm <strong>"Bỏ ghi sổ để sửa"</strong> nếu bạn muốn chỉnh sửa nội dung.
                      </span>
                      <button
                        type="button"
                        className="misa-btn-secondary"
                        style={{ height: 28, padding: "0 12px", fontSize: 12, fontWeight: 600, background: "#fef3c7", borderColor: "#f59e0b", color: "#92400e", flexShrink: 0 }}
                        onClick={() => void cashRowAction("unpost", [v.id])}
                      >
                        Bỏ ghi sổ để sửa
                      </button>
                    </div>
                  )}

                  <div className="misa-voucher-master-grid">
                    <div className="misa-voucher-master-left">
                      <div className="misa-voucher-row-main">
                        <div className="misa-voucher-field" style={{ flex: 1 }}>
                          <label>{v.kind === "receipt" ? "Đối tượng nộp" : "Đối tượng nhận"}</label>
                          <input
                            className="misa-voucher-input"
                            value={editCashPartner}
                            readOnly={isPosted}
                            placeholder="Nhập tên đối tượng..."
                            onChange={(e) => {
                              const nextPartner = e.target.value;
                              setEditCashPartner(nextPartner);
                              if (!editCashPerson || editCashPerson === editCashPartner) {
                                setEditCashPerson(nextPartner);
                              }
                              setEditCashRows((rows) =>
                                rows.map((r, i) => (i === 0 ? { ...r, partnerName: nextPartner } : r)),
                              );
                            }}
                          />
                        </div>
                        <div className="misa-voucher-field" style={{ width: 240 }}>
                          <label>{v.kind === "receipt" ? "Người nộp" : "Người nhận"}</label>
                          <input
                            className="misa-voucher-input"
                            value={editCashPerson}
                            readOnly={isPosted}
                            placeholder="Nhập người giao dịch..."
                            onChange={(e) => setEditCashPerson(e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="misa-voucher-row-main">
                        <div className="misa-voucher-field" style={{ flex: 1 }}>
                          <label>{v.kind === "receipt" ? "Lý do nộp (Diễn giải)" : "Lý do chi (Diễn giải)"}</label>
                          <input
                            className="misa-voucher-input"
                            value={editCashDescription}
                            readOnly={isPosted}
                            placeholder="Nhập lý do thu/chi..."
                            onChange={(e) => {
                              const nextDesc = e.target.value;
                              const prevDesc = editCashDescription;
                              setEditCashDescription(nextDesc);
                              setEditCashRows((rows) =>
                                rows.map((r, i) =>
                                  i === 0 && (!r.description || r.description === prevDesc)
                                    ? { ...r, description: nextDesc }
                                    : r,
                                ),
                              );
                            }}
                          />
                        </div>
                        <div className="misa-voucher-field" style={{ width: 240 }}>
                          <label>Loại nghiệp vụ</label>
                          <input
                            className="misa-voucher-input"
                            value={v.reasonLabel || cashReason(v.kind, editCashDescription || v.description)}
                            readOnly
                            style={{ background: "#f8fafc", color: "#64748b" }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="misa-voucher-master-right">
                      <div className="misa-voucher-total-block">
                        <div className="misa-voucher-total-label">Tổng tiền</div>
                        <div className="misa-voucher-total-number" style={{ fontSize: 26 }}>
                          {formatVND(computedTotal)}
                        </div>
                      </div>
                      <div className="misa-voucher-meta-stack">
                        <div className="misa-voucher-meta-row">
                          <label>Ngày hạch toán</label>
                          <div className="misa-voucher-meta-control">
                            <input
                              type={isPosted ? "text" : "date"}
                              className="misa-voucher-input"
                              value={isPosted ? editCashDate.split("-").reverse().join("/") : editCashDate}
                              readOnly={isPosted}
                              onChange={(e) => setEditCashDate(e.target.value)}
                            />
                          </div>
                        </div>
                        <div className="misa-voucher-meta-row">
                          <label>Ngày chứng từ</label>
                          <div className="misa-voucher-meta-control">
                            <input
                              type={isPosted ? "text" : "date"}
                              className="misa-voucher-input"
                              value={isPosted ? editCashDate.split("-").reverse().join("/") : editCashDate}
                              readOnly={isPosted}
                              onChange={(e) => setEditCashDate(e.target.value)}
                            />
                          </div>
                        </div>
                        <div className="misa-voucher-meta-row">
                          <label>Số chứng từ</label>
                          <div className="misa-voucher-meta-control">
                            <input
                              className="misa-voucher-input"
                              value={editCashCode}
                              readOnly={isPosted}
                              onChange={(e) => setEditCashCode(e.target.value)}
                              style={{ fontWeight: 700, color: "var(--brand)" }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="misa-voucher-details-section" style={{ padding: "12px 20px" }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                      <div style={{ fontWeight: 700, fontSize: 13, color: "#0f172a" }}>
                        Chi tiết hạch toán định khoản
                      </div>
                      {!isPosted && (
                        <button
                          type="button"
                          className="misa-btn-secondary"
                          style={{ height: 26, padding: "0 10px", fontSize: 12 }}
                          onClick={() =>
                            setEditCashRows((rows) => [
                              ...rows,
                              {
                                id: `${v.id}-${rows.length}-${Date.now()}`,
                                description: editCashDescription,
                                debit: rows[0]?.debit || (v.kind === "receipt" ? "1111" : "331"),
                                credit: rows[0]?.credit || (v.kind === "receipt" ? "131" : "1111"),
                                amount: 0,
                                partnerCode: "",
                                partnerName: editCashPartner,
                              },
                            ])
                          }
                        >
                          + Thêm dòng hạch toán
                        </button>
                      )}
                    </div>
                    <table className="misa-tax-table">
                      <thead>
                        <tr>
                          <th style={{ width: 44 }}>STT</th>
                          <th>Diễn giải</th>
                          <th style={{ width: 100 }}>TK Nợ</th>
                          <th style={{ width: 100 }}>TK Có</th>
                          <th className="numeric" style={{ width: 170 }}>Số tiền</th>
                          <th>Tên đối tượng</th>
                          {!isPosted && <th style={{ width: 44 }} />}
                        </tr>
                      </thead>
                      <tbody>
                        {activeRows.map((row, idx) => (
                          <tr key={row.id || idx}>
                            <td>{idx + 1}</td>
                            <td>
                              {isPosted ? (
                                row.description || editCashDescription
                              ) : (
                                <input
                                  className="misa-voucher-input"
                                  style={{ height: 28, width: "100%" }}
                                  value={row.description}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setEditCashRows((rows) =>
                                      rows.map((r, i) => (i === idx ? { ...r, description: val } : r)),
                                    );
                                    if (idx === 0 && activeRows.length === 1) {
                                      setEditCashDescription(val);
                                    }
                                  }}
                                />
                              )}
                            </td>
                            <td>
                              {isPosted ? (
                                <strong style={{ color: "#2563eb" }}>{row.debit}</strong>
                              ) : (
                                <input
                                  className="misa-voucher-input"
                                  style={{ height: 28, width: "100%", fontWeight: 700, color: "#2563eb" }}
                                  value={row.debit}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setEditCashRows((rows) =>
                                      rows.map((r, i) => (i === idx ? { ...r, debit: val } : r)),
                                    );
                                  }}
                                />
                              )}
                            </td>
                            <td>
                              {isPosted ? (
                                <strong style={{ color: "#7c3aed" }}>{row.credit}</strong>
                              ) : (
                                <input
                                  className="misa-voucher-input"
                                  style={{ height: 28, width: "100%", fontWeight: 700, color: "#7c3aed" }}
                                  value={row.credit}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setEditCashRows((rows) =>
                                      rows.map((r, i) => (i === idx ? { ...r, credit: val } : r)),
                                    );
                                  }}
                                />
                              )}
                            </td>
                            <td className="numeric">
                              {isPosted ? (
                                <strong>{formatVND(Number(row.amount) || 0)}</strong>
                              ) : (
                                <input
                                  type="text"
                                  inputMode="numeric"
                                  className="misa-voucher-input"
                                  style={{ height: 28, width: "100%", textAlign: "right", fontWeight: 700 }}
                                  value={formatMoneyInput(row.amount)}
                                  onChange={(e) => {
                                    const val = parseMoneyInput(e.target.value);
                                    setEditCashRows((rows) =>
                                      rows.map((r, i) => (i === idx ? { ...r, amount: val } : r)),
                                    );
                                  }}
                                />
                              )}
                            </td>
                            <td>
                              {isPosted ? (
                                row.partnerName || editCashPartner || ""
                              ) : (
                                <input
                                  className="misa-voucher-input"
                                  style={{ height: 28, width: "100%" }}
                                  value={row.partnerName || editCashPartner}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setEditCashRows((rows) =>
                                      rows.map((r, i) => (i === idx ? { ...r, partnerName: val } : r)),
                                    );
                                  }}
                                />
                              )}
                            </td>
                            {!isPosted && (
                              <td style={{ textAlign: "center" }}>
                                {activeRows.length > 1 && (
                                  <button
                                    type="button"
                                    onClick={() => setEditCashRows((rows) => rows.filter((_, i) => i !== idx))}
                                    style={{ border: "none", background: "transparent", color: "#dc2626", cursor: "pointer", padding: 4 }}
                                    title="Xóa dòng"
                                  >
                                    <Trash2 size={14} />
                                  </button>
                                )}
                              </td>
                            )}
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr>
                          <td />
                          <td><strong>Cộng</strong></td>
                          <td />
                          <td />
                          <td className="numeric"><strong>{formatVND(computedTotal)}</strong></td>
                          <td />
                          {!isPosted && <td />}
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>

                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "10px 20px",
                    background: "#0f172a",
                    borderTop: "1px solid #1e293b",
                  }}
                >
                  <button
                    type="button"
                    className="misa-btn-secondary"
                    style={{ background: "#1e293b", color: "#f8fafc", border: "1px solid #334155" }}
                    onClick={() => setViewingCashVoucher(null)}
                  >
                    Đóng
                  </button>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <button
                      type="button"
                      className="misa-btn-secondary"
                      style={{ background: "#ffffff", color: "#0f172a", display: "inline-flex", alignItems: "center", gap: 6 }}
                      onClick={() => {
                        setViewingCashVoucher(null);
                        setSelectedVoucher({
                          code: editCashCode || v.code,
                          date: editCashDate || v.date,
                          person: editCashPerson || editCashPartner || v.person || v.partner,
                          address: v.address || "Hà Nội",
                          reason: editCashDescription || v.description,
                          debitAccount: activeRows[0]?.debit || v.debit || "1111",
                          creditAccount: activeRows[0]?.credit || v.credit || "131",
                          amount: computedTotal,
                          amountInWords: convertNumberToVietnameseWords(computedTotal),
                          notes: "Chứng từ kèm theo quyết toán",
                          chiefAccountant: "Trương Thị B",
                          director: "Nguyễn Văn A",
                        });
                        setShowVoucherPrint(true);
                      }}
                    >
                      <Printer size={14} />
                      <span>In biểu mẫu A4 ({editCashCode || v.code})</span>
                    </button>
                    {!isPosted ? (
                      <>
                        <button
                          type="button"
                          className="misa-btn-secondary"
                          disabled={isSavingCashEdit}
                          style={{ background: "#3b82f6", color: "#ffffff", border: "none", fontWeight: 700 }}
                          onClick={() => void handleSaveCashVoucherEdit(false)}
                        >
                          {isSavingCashEdit ? "Đang lưu..." : "Lưu thay đổi (Cất)"}
                        </button>
                        <button
                          type="button"
                          className="misa-btn-primary"
                          disabled={isSavingCashEdit}
                          style={{ background: "var(--brand)", border: "none", fontWeight: 700 }}
                          onClick={() => void handleSaveCashVoucherEdit(true)}
                        >
                          Cất & Ghi sổ
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        className="misa-btn-primary"
                        style={{ background: "#f59e0b", border: "none", fontWeight: 700 }}
                        onClick={async () => {
                          await cashRowAction("unpost", [v.id]);
                        }}
                      >
                        Bỏ ghi sổ để sửa
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })()}

        {showCreateVoucher && (
          <CreateVoucherModal
            kind={showCreateVoucher}
            existingCodes={transactions.map(item=>item.code)}
            suggestedCode={voucherCategoryChoice === "cash" ? nextCashCode(showCreateVoucher, transactions.map(item => item.code)) : undefined}
            voucherCategory={voucherCategoryChoice}
            initialTypeIndex={createVoucherTypeIndex}
            onClose={() => {
              setShowCreateVoucher(null);
              setCreateVoucherTypeIndex(0);
            }}
            onSave={handleSaveVoucher}
          />
        )}

        {showAIModal && (
          <AIAssistantModal
            onClose={() => setShowAIModal(false)}
            onApply={(doc) => {
              setShowAIModal(false);
              handleSaveVoucher(doc);
            }}
          />
        )}
      </div>
    );
  }

  // --------------------------------------------------------------------
  // RENDER TAB: "Kiểm kê" (INVENTORY AUDIT)
  // --------------------------------------------------------------------
  if(tab==='inventory'&&cashInventoryMode==='misa')return <MisaCashInventoryWorkspace key={company?.id} companyId={company?.id} bookBalance={cashBalance} onLegacy={()=>setCashInventoryMode('legacy')}/>;
  if (tab === "inventory") {
    return (
      <div style={{ padding: 16, background: "#f8fafc", overflowY: "auto", height: "100%" }}>
        <div className="ce-toolbar"><button onClick={()=>setCashInventoryMode('misa')}>Lập biên bản kiểm kê theo Sổ Việt ERP</button></div>
        {/* KPI Grid */}
        <div className="misa-kpi-grid">
          <div className="misa-kpi-card highlight">
            <span>Tổng tiền kiểm kê thực tế</span>
            <strong>96.800.000 đ</strong>
            <small>Đã kiểm kê lúc 17:30 ngày 25/09/2026</small>
          </div>
          <div className="misa-kpi-card">
            <span>Tiền theo sổ kế toán (1111)</span>
            <strong>96.800.000 đ</strong>
            <small>Khớp 100% không chênh lệch</small>
          </div>
          <div className="misa-kpi-card">
            <span>Chênh lệch thừa / thiếu</span>
            <strong style={{ color: "#059669" }}>0 đ</strong>
            <small>Quỹ tiền mặt chuẩn xác</small>
          </div>
          <div className="misa-kpi-card">
            <span>Số biên bản kiểm kê</span>
            <strong>2 biên bản</strong>
            <small>Kỳ tháng 9/2026</small>
          </div>
        </div>

        {/* Actions bar */}
        <div style={{ display: "flex", gap: 10, marginBottom: 14 }}>
          <button
            className="misa-btn-primary"
            onClick={() => notify("Đã mở phiếu tạo biên bản kiểm kê quỹ mới.")}
          >
            <Plus size={14} style={{ marginRight: 4 }} />
            Thêm bảng kiểm kê
          </button>
          <button
            className="misa-btn-secondary"
            onClick={async (event) => { try { await printVisibleTable(event.currentTarget, "biên bản kiểm kê quỹ tiền mặt"); } catch (cause) { notify?.(cause instanceof Error ? cause.message : "Không thực hiện được thao tác."); } }}
          >
            <Printer size={14} style={{ marginRight: 4 }} />
            In biên bản kiểm kê
          </button>
          <button
            className="misa-btn-secondary"
            onClick={() => notify("Không có chênh lệch quỹ cần xử lý.")}
          >
            Xử lý chênh lệch quỹ
          </button>
        </div>

        {/* Table 1: Danh sách biên bản */}
        <div style={{ background: "#ffffff", padding: 14, borderRadius: 8, marginBottom: 16, border: "1px solid #e5e7eb" }}>
          <h3 style={{ margin: "0 0 10px 0", fontSize: 14 }}>Danh sách biên bản kiểm kê quỹ</h3>
          <table className="misa-tax-table">
            <thead>
              <tr>
                <th>Số biên bản</th>
                <th>Ngày kiểm kê</th>
                <th>Mục đích kiểm kê</th>
                <th className="numeric">Tiền sổ sách</th>
                <th className="numeric">Tiền thực tế</th>
                <th className="numeric">Chênh lệch</th>
                <th>Kết luận</th>
                <th>Trạng thái</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong style={{ color: "var(--brand)" }}>KK00002</strong></td>
                <td>25/09/2026</td>
                <td>Kiểm kê đột xuất quỹ tiền mặt định kỳ</td>
                <td className="numeric">96.800.000</td>
                <td className="numeric">96.800.000</td>
                <td className="numeric" style={{ color: "#059669" }}>0</td>
                <td>Khớp sổ kế toán</td>
                <td><span style={{ background: "#dcfce7", color: "#15803d", padding: "2px 8px", borderRadius: 10, fontSize: 11 }}>Đã duyệt</span></td>
              </tr>
              <tr>
                <td><strong style={{ color: "var(--brand)" }}>KK00001</strong></td>
                <td>31/08/2026</td>
                <td>Kiểm kê chốt quỹ tiền mặt cuối tháng 8</td>
                <td className="numeric">85.200.000</td>
                <td className="numeric">85.200.000</td>
                <td className="numeric" style={{ color: "#059669" }}>0</td>
                <td>Khớp sổ kế toán</td>
                <td><span style={{ background: "#dcfce7", color: "#15803d", padding: "2px 8px", borderRadius: 10, fontSize: 11 }}>Đã duyệt</span></td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Table 2: Chi tiết mệnh giá tiền */}
        <div style={{ background: "#ffffff", padding: 14, borderRadius: 8, border: "1px solid #e5e7eb" }}>
          <h3 style={{ margin: "0 0 10px 0", fontSize: 14 }}>
            Bảng kê chi tiết phân tích mệnh giá tiền thực tế (Biên bản KK00002)
          </h3>
          <table className="misa-denominations-table">
            <thead>
              <tr>
                <th>Mệnh giá</th>
                <th className="numeric" style={{ width: 150 }}>Số tờ</th>
                <th className="numeric" style={{ width: 200 }}>Thành tiền (VNĐ)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>500.000 đ</strong> (Năm trăm nghìn đồng)</td>
                <td className="numeric">120 tờ</td>
                <td className="numeric">60.000.000 đ</td>
              </tr>
              <tr>
                <td><strong>200.000 đ</strong> (Hai trăm nghìn đồng)</td>
                <td className="numeric">85 tờ</td>
                <td className="numeric">17.000.000 đ</td>
              </tr>
              <tr>
                <td><strong>100.000 đ</strong> (Một trăm nghìn đồng)</td>
                <td className="numeric">140 tờ</td>
                <td className="numeric">14.000.000 đ</td>
              </tr>
              <tr>
                <td><strong>50.000 đ</strong> (Năm mươi nghìn đồng)</td>
                <td className="numeric">90 tờ</td>
                <td className="numeric">4.500.000 đ</td>
              </tr>
              <tr>
                <td><strong>20.000 đ</strong> (Hai mươi nghìn đồng)</td>
                <td className="numeric">50 tờ</td>
                <td className="numeric">1.000.000 đ</td>
              </tr>
              <tr>
                <td><strong>10.000 đ</strong> (Mười nghìn đồng)</td>
                <td className="numeric">30 tờ</td>
                <td className="numeric">300.000 đ</td>
              </tr>
              <tr>
                <td><strong>Cộng tiền mặt thực tế</strong></td>
                <td className="numeric"><strong>515 tờ</strong></td>
                <td className="numeric"><strong style={{ color: "var(--brand)" }}>96.800.000 đ</strong></td>
              </tr>
            </tbody>
          </table>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginTop: 20, textAlign: "center" }}>
            <div>
              <strong>Trưởng ban kiểm kê</strong>
              <div style={{ color: "#6b7280", fontSize: 12 }}>Giám đốc: Nguyễn Văn A</div>
            </div>
            <div>
              <strong>Kế toán trưởng</strong>
              <div style={{ color: "#6b7280", fontSize: 12 }}>Trương Thị B</div>
            </div>
            <div>
              <strong>Thủ quỹ</strong>
              <div style={{ color: "#6b7280", fontSize: 12 }}>Vũ Thị Mai</div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // --------------------------------------------------------------------
  // RENDER TAB: "Đề nghị chi tiền"
  // --------------------------------------------------------------------
  if (tab === "payment-requests") {
    return (
      <><MisaPaymentWorkflow notify={notify}>
      <PaymentRequestsTab
        notify={notify}
        onOpenCreatePayment={() => setShowCreateVoucher("payment")}
      />
      </MisaPaymentWorkflow>{showCreateVoucher && <CreateVoucherModal kind={showCreateVoucher} existingCodes={transactions.map(item=>item.code)} suggestedCode={nextCashCode(showCreateVoucher,transactions.map(item=>item.code))} onClose={()=>setShowCreateVoucher(null)} onSave={handleSaveVoucher}/>}</>
    );
  }

  // --------------------------------------------------------------------
  // RENDER TAB: "Đề nghị quyết toán tạm ứng"
  // --------------------------------------------------------------------
  if (tab === "advance-settlement" || tab === "advance-settlement-request") {
    return (
      <><MisaPaymentWorkflow variant="settlement" notify={notify}><AdvanceSettlementTab
        notify={notify}
        onOpenCreateReceipt={() => setShowCreateVoucher("receipt")}
      /></MisaPaymentWorkflow>{showCreateVoucher && <CreateVoucherModal kind={showCreateVoucher} suggestedCode={nextCashCode(showCreateVoucher,transactions.map(item=>item.code))} onClose={()=>setShowCreateVoucher(null)} onSave={handleSaveVoucher}/>}</>
    );
  }

  // --------------------------------------------------------------------
  // RENDER TAB: "Dự báo dòng tiền" (CASHFLOW FORECAST - CHUẨN MISA AMIS)
  // --------------------------------------------------------------------
  if (tab === "cashflow") {
    return <><nav className="ce-toolbar" aria-label="Chế độ dự báo dòng tiền"><button onClick={()=>setCashForecastMode('misa')}>Bảng dự báo theo Sổ Việt ERP</button><button onClick={()=>setCashForecastMode('legacy')}>Kế hoạch và biểu đồ hiện có</button></nav><div hidden={cashForecastMode!=='misa'}><MisaCashForecastWorkspace key={company?.id} companyId={company?.id} entries={transactions}/></div><div hidden={cashForecastMode!=='legacy'}><CashForecastTab notify={notify}/></div></>;
  }

  // --------------------------------------------------------------------
  // RENDER TAB: "Báo cáo" (CASH REPORTS HUB - CHUẨN MISA AMIS)
  // --------------------------------------------------------------------
  if (tab === "reports") {
    return <CashReportsTab key={cashParams.get("report") || "list"} initialReport={cashParams.get("report")} notify={notify} entries={transactions} companyId={company?.id}/>;
  }

  // --------------------------------------------------------------------
  // RENDER TAB: "Quy trình" (Flowchart matching MISA AMIS)
  // --------------------------------------------------------------------
  return (
    <div
      className="ref-process-wrapper"
      style={{
        background: "#f1f5f9",
        height: "100%",
        padding: "10px 16px",
        overflowY: "auto",
        overflowX: "hidden",
      }}
    >
      <div
        className="ref-process-layout"
        style={{
          maxWidth: 1080,
          display: "grid",
          gridTemplateColumns: "minmax(0, 2.3fr) minmax(250px, 1fr)",
          gap: 14,
          margin: "0 auto",
        }}
      >
        {/* Panel 1: NGHIỆP VỤ TIỀN MẶT (Standard Flowchart format) */}
        <section
          className="ref-process-panel"
          style={{
            background: "#ffffff",
            borderRadius: 8,
            border: "1px solid #e2e8f0",
            boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
            overflow: "visible",
            position: "relative",
            zIndex: 20,
          }}
        >
          <h2
            style={{
              fontSize: 13,
              fontWeight: 700,
              textAlign: "center",
              margin: 0,
              padding: "14px 10px",
              borderBottom: "1px solid #f1f5f9",
              color: "#1e293b",
              letterSpacing: "0.5px",
            }}
          >
            NGHIỆP VỤ TIỀN MẶT
          </h2>

          <div
            className="ref-process-canvas sv-flow-nodes"
            style={{
              position: "relative",
              height: 310,
              margin: "0 10px",
              overflow: "visible",
            }}
          >
            {/* SVG Connecting Flow Lines with Arrows */}
            <svg
              className="ref-flow-lines sv-flow-connector"
              viewBox="0 0 650 300"
              preserveAspectRatio="none"
              aria-hidden="true"
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: 300,
                pointerEvents: "none",
                overflow: "visible",
              }}
            >
              <defs>
                <marker
                  id="ref-arrow-cash"
                  markerWidth="7"
                  markerHeight="7"
                  refX="6"
                  refY="3.5"
                  orient="auto"
                >
                  <polygon points="0 0, 7 3.5, 0 7" fill="#94a3b8" />
                </marker>
              </defs>

              {/* 1. Horizontal arrow from Đề nghị chi tiền (13% = 85) to Chi tiền (38% = 247) */}
              <path
                d="M 125 188 L 200 188"
                stroke="#cbd5e1"
                strokeWidth="1.5"
                fill="none"
                markerEnd="url(#ref-arrow-cash)"
              />

              {/* 2. Vertical T-junction line between Thu tiền and Chi tiền */}
              <path
                d="M 305 75 L 305 188"
                stroke="#cbd5e1"
                strokeWidth="1.5"
                fill="none"
              />
              <path
                d="M 290 75 L 305 75 M 290 188 L 305 188"
                stroke="#cbd5e1"
                strokeWidth="1.5"
                fill="none"
              />

              {/* 3. Horizontal branch from midpoint between Thu and Chi to Kiểm kê quỹ (63% = 410) */}
              <path
                d="M 305 136 L 365 136"
                stroke="#cbd5e1"
                strokeWidth="1.5"
                fill="none"
                markerEnd="url(#ref-arrow-cash)"
              />

              {/* 4. Horizontal arrow going right from Kiểm kê quỹ to Dự báo dòng tiền (87% = 566) */}
              <path
                d="M 455 136 L 520 136"
                stroke="#cbd5e1"
                strokeWidth="1.5"
                fill="none"
                markerEnd="url(#ref-arrow-cash)"
              />
            </svg>

            {/* Click outside backdrop for flowchart dropdowns */}
            {activeFlowchartMenu && (
              <div
                style={{ position: "fixed", inset: 0, zIndex: 18 }}
                onClick={() => setActiveFlowchartMenu(null)}
              />
            )}

            {/* Node 1: Đề nghị chi tiền (Left, aligned with Chi tiền) */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "13%",
                transform: "translateX(-50%)",
                top: 145,
                width: 100,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 2,
              }}
              onClick={() => {
                navigate(href ? href("/cash/payment-requests") : "/reference/cash/payment-requests");
              }}
              title="Lập giấy đề nghị chi tiền"
            >
              <span className="ref-business-icon request" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>ĐN</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "#f59e0b", borderColor: "#fbbf24" }}
                >
                  <ArrowRight size={14} strokeWidth={2.5} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3 }}>
                Đề nghị chi tiền
              </span>
            </div>

            {/* Node 2: Thu tiền (Top Center) */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "38%",
                transform: "translateX(-50%)",
                top: 25,
                width: 100,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                zIndex: activeFlowchartMenu === "receipt" ? 60 : 10,
              }}
              onMouseEnter={() => handleFlowchartMouseEnter("receipt")}
              onMouseLeave={handleFlowchartMouseLeave}
            >
              <div
                style={{
                  cursor: "pointer",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
                onClick={() => setActiveFlowchartMenu("receipt")}
                title="Lập phiếu thu tiền mặt"
              >
                <span className="ref-business-icon receive" style={{ marginBottom: 6 }}>
                  <span
                    className="ref-document-sheet"
                    style={{
                      background: "linear-gradient(90deg, #10b981, #059669)",
                      border: "1px solid #34d399",
                    }}
                  >
                    <b style={{ color: "#ffffff", fontWeight: 800 }}>THU</b>
                    <i /><i /><i />
                  </span>
                  <span
                    className="ref-gold-icon"
                    style={{ background: "#ea580c", borderColor: "#f97316" }}
                  >
                    <Coins size={16} />
                  </span>
                </span>
                <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500 }}>
                  Thu tiền
                </span>
              </div>

              {activeFlowchartMenu === "receipt" && (
                <div
                  className="ref-action-options"
                  style={{
                    position: "absolute",
                    top: "calc(100% + 4px)",
                    left: "50%",
                    transform: "translateX(-50%)",
                    minWidth: 240,
                    zIndex: 100,
                    background: "#ffffff",
                    boxShadow: "0 12px 28px rgba(0,0,0,0.18), 0 3px 8px rgba(0,0,0,0.06)",
                    borderRadius: 6,
                    border: "1px solid #cbd5e1",
                    padding: "4px 0",
                  }}
                  onMouseEnter={() => handleFlowchartMouseEnter("receipt")}
                  onMouseLeave={handleFlowchartMouseLeave}
                >
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      display: "block",
                    }}
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setVoucherCategoryChoice("cash");
                      setShowCreateVoucher("receipt");
                    }}
                  >
                    Thu tiền
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      display: "block",
                    }}
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowCustomerCollection(true);
                    }}
                  >
                    Thu tiền theo hóa đơn
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      display: "block",
                    }}
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowMultiCustomerCollection(true);
                    }}
                  >
                    Thu tiền theo hóa đơn nhiều khách hàng
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      display: "block",
                    }}
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowInternalTransfer(true);
                    }}
                  >
                    Chuyển tiền nội bộ
                  </button>
                </div>
              )}
            </div>

            {/* Node 3: Chi tiền (Bottom Center) */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "38%",
                transform: "translateX(-50%)",
                top: 145,
                width: 100,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                zIndex: activeFlowchartMenu === "payment" ? 60 : 10,
              }}
              onMouseEnter={() => handleFlowchartMouseEnter("payment")}
              onMouseLeave={handleFlowchartMouseLeave}
            >
              <div
                style={{
                  cursor: "pointer",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
                onClick={() => setActiveFlowchartMenu("payment")}
                title="Lập phiếu chi tiền mặt"
              >
                <span className="ref-business-icon pay" style={{ marginBottom: 6 }}>
                  <span
                    className="ref-document-sheet"
                    style={{
                      background: "linear-gradient(90deg, #10b981, #059669)",
                      border: "1px solid #34d399",
                    }}
                  >
                    <b style={{ color: "#ffffff", fontWeight: 800 }}>CHI</b>
                    <i /><i /><i />
                  </span>
                  <span
                    className="ref-gold-icon"
                    style={{ background: "#ea580c", borderColor: "#f97316" }}
                  >
                    <Coins size={16} />
                  </span>
                </span>
                <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500 }}>
                  Chi tiền
                </span>
              </div>

              {activeFlowchartMenu === "payment" && (
                <div
                  className="ref-action-options"
                  style={{
                    position: "absolute",
                    top: "calc(100% + 4px)",
                    left: "50%",
                    transform: "translateX(-50%)",
                    minWidth: 240,
                    zIndex: 100,
                    background: "#ffffff",
                    boxShadow: "0 12px 28px rgba(0,0,0,0.18), 0 3px 8px rgba(0,0,0,0.06)",
                    borderRadius: 6,
                    border: "1px solid #cbd5e1",
                    padding: "4px 0",
                  }}
                  onMouseEnter={() => handleFlowchartMouseEnter("payment")}
                  onMouseLeave={handleFlowchartMouseLeave}
                >
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      display: "block",
                    }}
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setVoucherCategoryChoice("cash");
                      setShowCreateVoucher("payment");
                    }}
                  >
                    Chi tiền
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      display: "block",
                    }}
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowSupplierPayment(true);
                    }}
                  >
                    Trả tiền theo hóa đơn
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      display: "block",
                    }}
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowTaxModal(true);
                    }}
                  >
                    Nộp thuế
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      display: "block",
                    }}
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowInsuranceModal(true);
                    }}
                  >
                    Nộp bảo hiểm
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      display: "block",
                    }}
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowSalaryModal(true);
                    }}
                  >
                    Trả lương
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "9px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      display: "block",
                    }}
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowInternalTransfer(true);
                    }}
                  >
                    Chuyển tiền nội bộ
                  </button>
                </div>
              )}
            </div>

            {/* Node 4: Kiểm kê quỹ (Right, middle vertical) */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "63%",
                transform: "translateX(-50%)",
                top: 96,
                width: 100,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 2,
              }}
              onClick={() => {
                navigate(href ? href("/cash/inventory") : "/reference/cash/inventory");
              }}
              role="button"
              tabIndex={0}
              onKeyDown={(event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  navigate(href ? href("/cash/inventory") : "/reference/cash/inventory");
                }
              }}
              title="Kiểm kê quỹ tiền mặt"
            >
              <span className="ref-business-icon audit" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>KK</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "#f59e0b", borderColor: "#fbbf24" }}
                >
                  <FileText size={14} strokeWidth={2.2} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3 }}>
                Kiểm kê quỹ
              </span>
            </div>

            {/* Node 5: Dự báo dòng tiền (Right, connected to arrow) */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "87%",
                transform: "translateX(-50%)",
                top: 96,
                width: 110,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 2,
              }}
              onClick={() => {
                navigate(href ? href("/cash/cashflow") : "/reference/cash/cashflow");
              }}
              title="Dự báo dòng tiền"
            >
              <span className="ref-business-icon forecast" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>DB</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "var(--brand)", borderColor: "#38bdf8" }}
                >
                  <Calculator size={14} strokeWidth={2.2} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3 }}>
                Dự báo dòng tiền
              </span>
            </div>
          </div>
        </section>

        {/* Panel 2: BÁO CÁO (Right Column - Screenshot 2) */}
        <aside
          className="ref-process-reports"
          style={{
            background: "#ffffff",
            borderRadius: 8,
            border: "1px solid #e2e8f0",
            boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
          }}
        >
          <h2
            style={{
              fontSize: 13,
              fontWeight: 700,
              textAlign: "center",
              margin: 0,
              padding: "14px 10px",
              borderBottom: "1px solid #f1f5f9",
              color: "#1e293b",
              letterSpacing: "0.5px",
            }}
          >
            BÁO CÁO
          </h2>
          <ul
            style={{
              padding: "8px 16px",
              margin: 0,
              flex: 1,
              display: "flex",
              flexDirection: "column",
              listStyle: "none",
            }}
          >
            {[
              "Bảng kê số dư tiền theo ngày",
              "Dòng tiền",
              "S03a1 - DN: Sổ nhật ký thu tiền",
              "Sổ kế toán chi tiết quỹ tiền mặt",
              "S03a2 - DN: Sổ nhật ký chi tiền",
            ].map((repName) => (
              <li
                key={repName}
                style={{
                  borderBottom: "1px solid #f1f5f9",
                  display: "flex",
                  alignItems: "center",
                  minHeight: 46,
                  fontSize: 12,
                  color: "#334155",
                  padding: "6px 0 6px 14px",
                  position: "relative",
                  cursor: "pointer",
                }}
                onClick={() => navigate(cashReportsUrl(repName))}
              >
                <span
                  style={{
                    position: "absolute",
                    left: 0,
                    top: "50%",
                    transform: "translateY(-50%)",
                    width: 4,
                    height: 4,
                    borderRadius: "50%",
                    background: "#000000",
                  }}
                />
                <span style={{ transition: "color 0.15s ease" }} className="hover-link">
                  {repName}
                </span>
              </li>
            ))}
          </ul>
          <div
            style={{
              textAlign: "center",
              padding: "12px",
              borderTop: "1px solid #f1f5f9",
            }}
          >
            <span
              style={{
                color: "var(--brand)",
                fontSize: 12,
                fontWeight: 600,
                cursor: "pointer",
              }}
              onClick={() => navigate(cashReportsUrl())}
            >
              Tất cả báo cáo
            </span>
          </div>
        </aside>

        {/* Panel 3: Master Data / Shortcuts (Screenshot 2 - Exactly 4 buttons) */}
        <div
          className="ref-shortcuts"
          style={{
            gridColumn: "1 / -1",
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            background: "#ffffff",
            borderRadius: 8,
            border: "1px solid #e2e8f0",
            overflow: "hidden",
            boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
            position: "relative",
            zIndex: 1,
          }}
        >
          <button
            type="button"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              padding: "14px 8px",
              background: "#ffffff",
              border: "none",
              borderRight: "1px solid #f1f5f9",
              cursor: "pointer",
              fontSize: 12,
              color: "#334155",
            }}
            onClick={() => navigate((href?.("/directory") || "/directory") + ((href?.("/directory") || "/directory").includes("?") ? "&" : "?") + "directory=" + encodeURIComponent("Khách hàng"))}
          >
            <UserRound size={20} style={{ color: "#f59e0b" }} />
            <span>Khách hàng</span>
          </button>

          <button
            type="button"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              padding: "14px 8px",
              background: "#ffffff",
              border: "none",
              borderRight: "1px solid #f1f5f9",
              cursor: "pointer",
              fontSize: 12,
              color: "#334155",
            }}
            onClick={() => navigate((href?.("/directory") || "/directory") + ((href?.("/directory") || "/directory").includes("?") ? "&" : "?") + "directory=" + encodeURIComponent("Nhà cung cấp"))}
          >
            <Building2 size={20} style={{ color: "var(--brand)" }} />
            <span>Nhà cung cấp</span>
          </button>

          <button
            type="button"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              padding: "14px 8px",
              background: "#ffffff",
              border: "none",
              borderRight: "1px solid #f1f5f9",
              cursor: "pointer",
              fontSize: 12,
              color: "#334155",
            }}
            onClick={() => navigate((href?.("/directory") || "/directory") + ((href?.("/directory") || "/directory").includes("?") ? "&" : "?") + "directory=" + encodeURIComponent("Nhân viên"))}
          >
            <Users size={20} style={{ color: "#10b981" }} />
            <span>Nhân viên</span>
          </button>

          <button
            type="button"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              padding: "14px 8px",
              background: "#ffffff",
              border: "none",
              cursor: "pointer",
              fontSize: 12,
              color: "#334155",
            }}
            onClick={() => setCashOptionsOpen(true)}
          >
            <SlidersHorizontal size={20} style={{ color: "#f59e0b" }} />
            <span>Tùy chọn</span>
          </button>
        </div>
      </div>

      {showTaxModal && (
        <TaxPaymentModal
          onClose={() => setShowTaxModal(false)}
          onSubmit={handleTaxPayment}
        />
      )}

      {showSupplierPayment && (
        <SupplierPaymentModal
          onClose={() => setShowSupplierPayment(false)}
          onSubmit={handleSupplierPayment}
            debtSource={payableSource}
        />
      )}

      {showCustomerCollection && (
        <SingleCustomerInvoiceCollectionModal
          initialMethod="cash"
          onClose={() => setShowCustomerCollection(false)}
          onSubmit={handleCustomerCollection}
            debtSource={debtSource}
        />
      )}

      {showMultiCustomerCollection && (
        <MultiCustomerInvoiceCollectionModal
          initialMethod="cash"
          onClose={() => setShowMultiCustomerCollection(false)}
          onSubmit={handleMultiCustomerCollection}
            debtSource={debtSource}
        />
      )}

      {showInsuranceModal && (
        <InsurancePaymentModal
          onClose={() => setShowInsuranceModal(false)}
          onSubmit={handleInsurancePayment}
            loadRecords={token ? () => insurancePaymentRows(createApiWriter(company?.id || "", (path, init) => request(path, token, init))) : undefined}
        />
      )}

      {showSalaryModal && (
        <SalaryPaymentModal
          onClose={() => setShowSalaryModal(false)}
          onSubmit={handleSalaryPayment}
            loadRecords={token ? () => salaryPaymentRows(createApiWriter(company?.id || "", (path, init) => request(path, token, init))) : undefined}
        />
      )}

      {showInternalTransfer && (
        <InternalTransferModal
          accounts={token ? [
            ...cashFunds.filter((fund) => fund.status === "ACTIVE").map((fund) => ({ value: `CASH:${fund.id}`, label: `Quỹ tiền mặt ${fund.id.slice(0, 8)}` })),
            ...(payableCatalog.bankAccounts || []).filter((account) => account.status === "ACTIVE").map((account) => ({ value: `BANK:${account.id}`, label: `${account.account_number} - ${account.bank_name || "Ngân hàng"}` })),
          ] : undefined}
          onClose={() => setShowInternalTransfer(false)}
          onSubmit={handleInternalTransfer}
        />
      )}

      {showVoucherPrint && (
        <AccountingVoucherModal
          voucher={selectedVoucher}
          onClose={() => setShowVoucherPrint(false)}
        />
      )}

      {cashOptionsOpen&&<CashOptionsDialog companyId={company?.id} onClose={()=>setCashOptionsOpen(false)}/>}
      {showCreateVoucher && (
        <CreateVoucherModal
          kind={showCreateVoucher}
            suggestedCode={voucherCategoryChoice === "cash" ? nextCashCode(showCreateVoucher, transactions.map(item => item.code)) : undefined}
          voucherCategory={voucherCategoryChoice}
          initialTypeIndex={createVoucherTypeIndex}
          onClose={() => {
            setShowCreateVoucher(null);
            setCreateVoucherTypeIndex(0);
          }}
          onSave={handleSaveVoucher}
        />
      )}

      {showAIModal && (
        <AIAssistantModal
          onClose={() => setShowAIModal(false)}
          onApply={(doc) => {
            setShowAIModal(false);
            handleSaveVoucher(doc);
          }}
        />
      )}
    </div>
  );
}
