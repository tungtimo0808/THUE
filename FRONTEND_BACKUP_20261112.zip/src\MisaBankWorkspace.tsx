import {CASH_PERIODS} from "./cash-report-periods";
import {formatMoneyInput,parseMoneyInput} from "./formatMoney";
import MisaDropdownSelect from "./MisaDropdownSelect";
import CashColumnDialog from "./CashColumnDialog";
import {defaultBankColumns,readBankColumns} from "./bank-columns";
import {parseReportDate} from "./report-date";
import CashExcelImport from "./CashExcelImport";
import BankAccountingDetail from "./BankAccountingDetail";
import type {VoucherDetailRow} from "./MisaCashWorkspace";
import CashAdvancedPanel,{defaultCashFilter,type CashFilter} from "./CashAdvancedPanel";
import {currentCashDate,isCashDateInRange} from "./cash-date";
import {cashLedger,nextCashCode} from "./cash-operations";
import MisaBankElectronicWorkspace from "./MisaBankElectronicWorkspace";
import MisaReportCenterWorkspace from "./MisaReportCenterWorkspace";
import MisaCashForecastWorkspace from "./MisaCashForecastWorkspace";
import CashOptionsDialog from "./CashOptionsDialog";
import {AdvanceSettlementTab} from "./MisaCashWorkspace";
import { useState, useMemo, useRef, useEffect, cloneElement, type ReactElement } from "react";
import {useNavigate,useSearchParams} from 'react-router-dom';
import { useApiSession } from "./ApiSession";
import { request } from "./live-api";
import {
  completeTransfer, createApiWriter, internalTransfers, openPayables, postMoneyTransaction, reverseMoneyTransaction,
  insurancePaymentRows, salaryPaymentRows, saveBankPaymentDraft, saveCreditContract, saveLoanAgreement, savePayrollPayment, saveSupplierPayment, saveMoneyVoucher, nextVoucherNumber, toApiDate,
} from "./misa-api-writes";
import { useMisaApiLists, useMisaApiSave } from "./misa-api-lists";
import type { CollectionDebtSource } from "./MisaInvoiceCollectionModals";
import {
  Filter,
  Search,
  RefreshCw,
  FileSpreadsheet,
  Settings,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Landmark,
  Coins,
  Clock,
  CreditCard,
  UserRound,
  Building2,
  Users,
  Calculator,
  SlidersHorizontal,
  FileCheck,
  ArrowRight,
  ChevronRight,
  Printer,
  X,
} from "lucide-react";
import {
  TaxPaymentModal,
  PaymentRequestsTab,
  SupplierPaymentModal,
  AccountingVoucherModal,
  CreateVoucherModal,
  AIAssistantModal,
  MISA_BANK_RECEIPT_TYPES,
  MISA_BANK_PAYMENT_TYPES,
  formatVND,
  convertNumberToVietnameseWords,
} from "./MisaCashWorkspace";
import {
  SingleCustomerInvoiceCollectionModal,
  MultiCustomerInvoiceCollectionModal,
  InsurancePaymentModal,
  SalaryPaymentModal,
  InternalTransferModal,
  ExcelImportModal,
} from "./MisaBankModals";
import {
  LoanContractModal,
  BorrowingContractModal,
  CreditContractModal,
  CreditOverviewView,
  type CreditOverviewViewProps,
} from "./MisaCreditModals";
import "./misa-cash.css";
import MisaBankReconciliation from './MisaBankReconciliation';
import MisaPaymentWorkflow from './MisaPaymentWorkflow';
import {
  matchesTransactionPeriod,
  resolveActiveBranchScope,
  resolveActiveDatasetBookType,
  resolveActiveDatasetYear,
  resolveActiveHeaderPeriod,
  resolveActivePeriodRange,
} from './transaction-period';

type BankTransaction = { id:string; dateHachToan:string; dateChungTu:string; code:string; description:string; amount:number; partner:string; kind:string; status:string; rawPaymentDetails?:Record<string,any>; bankAccount?:string;branchId?:string;partnerCode?:string;beneficiaryAccount?:string;beneficiaryBank?:string;address?:string;employee?:string;bankName?:string;combinedInvoices?:string;settled?:string;extended1?:string;extended2?:string;extended3?:string;extended4?:string;extended5?:string;extended6?:string;extended7?:string;extended8?:string;extended9?:string;extended10?:string;createdBy?:string;createdAt?:string;updatedBy?:string;updatedAt?:string; reasonLabel?:string; documentType?:string; rows?:VoucherDetailRow[]; debit?:string; credit?:string; items:{code?:string;name:string;taxDesc:string;taxRate:number;taxAmount:number;taxAccount:string;invoiceCode:string;invoiceDate:string}[]; };
type ApiBankProfile = { id: string; currency_id: string; account_number: string; account_name: string; bank_name: string; bank_branch?: string; branch_id?: string; branch_name?: string; gl_account_id?: string; gl_code?: string; currency_code: string; balance: string | number };

type ApiBankTransaction = {
  id: string;
  number: string;
  transaction_date: string;
  value_date?: string | null;
  description: string;
  amount: string | number;
  counterparty_name: string;
  transaction_type: string;
  status: string;
  bank_reference?: string;
  counterparty_account?: string;
  source_account_number?: string;
  source_bank_name?: string;
  currency_code?: string;
  payment_details?: { posting_date?: string; branch?: string; beneficiary_name?: string; beneficiary_account?: string;
    beneficiary_bank?: string; lines?: Array<{ description: string; debit_code: string; credit_code: string; amount: string | number }> };
};

function mapBankTransaction(row: ApiBankTransaction): BankTransaction {
  const date = (value?: string | null) => value ? value.slice(0, 10).split("-").reverse().join("/") : "";
  const rawDesc = (row.description || "").trim();
  const firstLineDesc = (row.payment_details?.lines?.[0]?.description || "").trim();
  const isBarePrefix = !rawDesc || /^(thu tiền của|chi tiền cho|tạm ứng cho|thu hoàn ứng sau khi quyết toán tạm ứng cho|chi mua ngoài có hóa đơn cho|trả các khoản vay cho)$/i.test(rawDesc);
  const resolvedDesc = isBarePrefix && firstLineDesc && firstLineDesc.length > rawDesc.length
    ? firstLineDesc
    : (isBarePrefix && row.counterparty_name && /\b(của|cho)$/i.test(rawDesc) ? `${rawDesc} ${row.counterparty_name}` : (row.description || firstLineDesc || ""));
  return {
    id: row.id,
    dateHachToan: date(row.payment_details?.posting_date || row.transaction_date),
    dateChungTu: date(row.value_date || row.transaction_date),
    code: row.number,
    description: resolvedDesc,
    amount: Number(row.amount),
    partner: row.counterparty_name || "",
    kind: ["RECEIPT", "INTEREST", "OTHER_IN"].includes(row.transaction_type) ? "receipt" : "payment",
    status: row.status === "POSTED" ? "posted" : "draft",
    rawPaymentDetails: row.payment_details,
    bankAccount: row.source_account_number || "",
    branchId: row.payment_details?.branch,
    bankName: row.source_bank_name || "",
    beneficiaryAccount: row.payment_details?.beneficiary_account || row.counterparty_account || "",
    beneficiaryBank: row.payment_details?.beneficiary_bank || "",
    rows: row.payment_details?.lines?.map((line,index) => {
      const lDesc = (line.description || "").trim();
      const lIsBare = !lDesc || /^(thu tiền của|chi tiền cho|tạm ứng cho|thu hoàn ứng sau khi quyết toán tạm ứng cho|chi mua ngoài có hóa đơn cho|trả các khoản vay cho)$/i.test(lDesc);
      return {
        id: String(index + 1), description: lIsBare && resolvedDesc ? resolvedDesc : (line.description || resolvedDesc), debit: line.debit_code,
        credit: line.credit_code, amount: Number(line.amount),
        bankAccount: "", bankName: "", partnerCode: "", partnerName: "",
        employeeCode: "", employeeName: "", loanContract: "", loanDisbursementContract: "",
      };
    }),
    items: [],
  };
}

const bankDataCache = new Map<string, {
  transactions: BankTransaction[];
  bankAccounts: { account: string; name: string }[];
  bankProfiles: ApiBankProfile[];
  bankBalance: number;
  timestamp: number;
}>();

export default function MisaBankWorkspace({
  tab = "transactions",
  company,
  period,
  notify,
  href,
}: {
  company: { id: string; name: string };
  period: string;
  tab: string;
  href: (path: string) => string;
  notify: (msg: string) => void;
}) {
  const navigate=useNavigate();
  const { token } = useApiSession();
  const { rows: supplierCatalog } = useMisaApiLists(company.id, { suppliers: "/api/v1/master-data/parties/" }, notify);
  const supplierDebtSource: CollectionDebtSource | undefined = token ? {
    customers: (supplierCatalog.suppliers || []).map((row) => ({ code: row.code, name: row.name })),
    load: (supplierCode?: string) => openPayables(createApiWriter(company.id, (path, init) => request(path, token, init)), supplierCode),
  } : undefined;
  const [bankParams]=useSearchParams();
  const [bankOptionsOpen,setBankOptionsOpen]=useState(false);
  const bankColumnsKey=`soviet:bank-columns:${company.id}`;
  const [bankColumns,setBankColumns]=useState(()=>{try{return readBankColumns(localStorage.getItem(bankColumnsKey));}catch{return defaultBankColumns();}});
  const [bankColumnsOpen,setBankColumnsOpen]=useState(false);
  useEffect(()=>{try{setBankColumns(readBankColumns(localStorage.getItem(bankColumnsKey)));}catch{setBankColumns(defaultBankColumns());}},[bankColumnsKey]);
  // Modal states
  const [showTaxModal, setShowTaxModal] = useState(false);
  const [showSupplierModal, setShowSupplierModal] = useState(false);
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [showMultiCustomerModal, setShowMultiCustomerModal] = useState(false);
  const [showInsuranceModal, setShowInsuranceModal] = useState(false);
  const [showSalaryModal, setShowSalaryModal] = useState(false);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [editingTransfer, setEditingTransfer] = useState<Record<string, any> | null>(null);
  const [viewingTransfer, setViewingTransfer] = useState(false);
  const [bankTransferRecords, setBankTransferRecords] = useState<Record<string, any>[]>([]);
  const [showExcelModal, setShowExcelModal] = useState(false);
  const [bankImportKind,setBankImportKind]=useState<"receipt"|"payment"|null>(null);
  const [showVoucherModal, setShowVoucherModal] = useState(false);
  const [viewingBankVoucher, setViewingBankVoucher] = useState<BankTransaction | null>(null);
  const [editBankCode, setEditBankCode] = useState("");
  const [editBankDate, setEditBankDate] = useState("");
  const [editBankPartner, setEditBankPartner] = useState("");
  const [editBankDescription, setEditBankDescription] = useState("");
  const [editBankRows, setEditBankRows] = useState<VoucherDetailRow[]>([]);
  const [isSavingBankEdit, setIsSavingBankEdit] = useState(false);
  const [showCreateVoucher, setShowCreateVoucher] = useState<"receipt" | "payment" | null>(null);
  const [statementVoucherSource, setStatementVoucherSource] = useState<{ account: string; accountNumber: string; date: string; amount: number; description: string; counterparty: string; counterpartyAccount: string; reference: string } | null>(null);
  const [createVoucherTypeIndex, setCreateVoucherTypeIndex] = useState(0);
  const [showBankReceiptSubmenu, setShowBankReceiptSubmenu] = useState(false);
  const [showBankPaymentSubmenu, setShowBankPaymentSubmenu] = useState(false);
  const [showAIModal, setShowAIModal] = useState(false);
  const [showLoanModal, setShowLoanModal] = useState(false);
  const [showBorrowModal, setShowBorrowModal] = useState(false);
  const [creditContractModalKind, setCreditContractModalKind] = useState<"borrowing" | "lending" | null>(null);

  // Dropdowns (Mutually exclusive to prevent multiple menus open simultaneously)
  const [activeToolbarMenu, setActiveToolbarMenu] = useState<"receipt" | "payment" | null>(null);
  const [activeFlowchartMenu, setActiveFlowchartMenu] = useState<"receipt" | "payment" | null>(null);
  const flowchartMenuTimer = useRef<number | null>(null);

  const handleFlowchartMouseEnter = (menu: "receipt" | "payment") => {
    if (flowchartMenuTimer.current) {
      clearTimeout(flowchartMenuTimer.current);
      flowchartMenuTimer.current = null;
    }
    setActiveFlowchartMenu(menu);
  };

  const handleFlowchartMouseLeave = () => {
    flowchartMenuTimer.current = window.setTimeout(() => {
      setActiveFlowchartMenu(null);
    }, 220);
  };

  // Filter state
  const [searchQuery, setSearchQuery] = useState(bankParams.get("voucherCode") || "");
  const [filterType, setFilterType] = useState("all");
  const [filterPeriod,setFilterPeriod]=useState(bankParams.get("voucher") ? 'all' : 'ytd');
  const [bankFilter,setBankFilter]=useState<CashFilter>(defaultCashFilter);
  const [bankFilterOpen,setBankFilterOpen]=useState(false);
  const [bankPage,setBankPage]=useState(1);
  const [bankPageSize,setBankPageSize]=useState(20);
  const [showAvaBanner, setShowAvaBanner] = useState(false);
  const [detailExpanded, setDetailExpanded] = useState(true);
  const [bankDetailTab,setBankDetailTab]=useState("accounting");
  const [kpiCollapsed, setKpiCollapsed] = useState(false);

  // Selected voucher for print preview
  const [selectedVoucher, setSelectedVoucher] = useState({
    code: "UNC00028",
    date: "2026-09-02",
    person: "TRUNG TÂM KIỂM DỊCH THỰC VẬT SAU NHẬP KHẨU",
    address: "Hà Nội",
    reason: "Chi tiền mua dịch vụ của TRUNG TÂM KIỂM DỊCH THỰC VẬT SAU NHẬP KHẨU",
    debitAccount: "6427",
    creditAccount: "1121",
    amount: 2317000,
    amountInWords: convertNumberToVietnameseWords(2317000),
    notes: "Kèm theo Hóa đơn điện tử số 34221 ngày 02/09/2026",
    chiefAccountant: "Trương Thị B",
    director: "Nguyễn Văn A",
  });

  const [activeBranchScope, setActiveBranchScope] = useState<string>(() => resolveActiveBranchScope());
  const bankCacheKey = company?.id ? `${company.id}::${activeBranchScope}` : "";
  const cachedBank = bankCacheKey ? bankDataCache.get(bankCacheKey) : undefined;
  const [transactions, setTransactions] = useState<BankTransaction[]>(() => cachedBank?.transactions || []);
  const [bankAccounts, setBankAccounts] = useState<{ account: string; name: string }[]>(() => cachedBank?.bankAccounts || []);
  const [bankProfiles, setBankProfiles] = useState<ApiBankProfile[]>(() => cachedBank?.bankProfiles || []);
  const [bankBalance, setBankBalance] = useState(() => cachedBank?.bankBalance || 0);

  const [bankApiRevision, setBankApiRevision] = useState(0);
  const reloadBankApi = () => {
    if (bankCacheKey) bankDataCache.delete(bankCacheKey);
    setBankApiRevision((value) => value + 1);
  };
  const apiSaveBank = useMisaApiSave(company.id, notify, reloadBankApi);
  const [loanRecords, setLoanRecords] = useState<NonNullable<CreditOverviewViewProps["records"]> | undefined>(undefined);
  useEffect(() => {
    if (!token || !company.id || !["loans", "borrowings"].includes(tab)) return;
    const date = (value?: string | null) => value ? value.slice(0, 10).split("-").reverse().join("/") : "";
    createApiWriter(company.id, (path, init) => request(path, token, init))
      .list(`/api/v1/bank/loans/?direction=${tab === "loans" ? "LENDING" : "BORROWING"}`)
      .then((rows) => setLoanRecords(rows.map((row) => ({
        id: row.id, code: row.number, date: date(row.disbursement_date), dueDate: date(row.due_date),
        partner: row.counterparty_name, amount: Number(row.amount), rate: Number(row.interest_rates?.[0]?.rate || 0),
        status: row.status === "ACTIVE" ? "Đang thực hiện" : "Đã tất toán",
      }))))
      .catch((error) => notify(`Không tải được khế ước: ${error instanceof Error ? error.message : String(error)}`));
  }, [token, company.id, tab, bankApiRevision]);

  useEffect(() => {
    if (!token || !company.id) {
      setTransactions([]);
      setBankTransferRecords([]);
      setBankAccounts([]);
      setBankProfiles([]);
      setBankBalance(0);
      return;
    }
    let active = true;
    const branchParam = activeBranchScope !== "all" ? `&branch_id=${encodeURIComponent(activeBranchScope)}` : "";
    const hasCache = bankDataCache.has(bankCacheKey);
    if (!hasCache) {
      setTransactions([]);
      setBankTransferRecords([]);
      setBankAccounts([]);
      setBankProfiles([]);
      setBankBalance(0);
    } else {
      const hit = bankDataCache.get(bankCacheKey)!;
      setTransactions(hit.transactions);
      setBankAccounts(hit.bankAccounts);
      setBankProfiles(hit.bankProfiles);
      setBankBalance(hit.bankBalance);
    }
    const path = `/api/v1/bank/transactions/?company_id=${encodeURIComponent(company.id)}${branchParam}&page_size=100`;
    request<ApiBankProfile[] | { results: ApiBankProfile[] }>(
      `/api/v1/bank/accounts/?company_id=${encodeURIComponent(company.id)}${branchParam}&page_size=100`, token,
    ).then((response) => {
      if (!active) return;
      const records = Array.isArray(response) ? response : response.results;
      const totalBalance = records.reduce((total, row) => total + Number(row.balance), 0);
      const accounts = records.map((row) => ({
        account: row.account_number,
        name: `${row.bank_name} - ${row.account_name} (${row.currency_code})`,
      }));
      setBankProfiles(records);
      setBankBalance(totalBalance);
      setBankAccounts(accounts);
      const prev = bankDataCache.get(bankCacheKey);
      bankDataCache.set(bankCacheKey, {
        transactions: prev?.transactions || [],
        bankAccounts: accounts,
        bankProfiles: records,
        bankBalance: totalBalance,
        timestamp: Date.now(),
      });
    }).catch((error) => {
      if (active && !hasCache) notify(error instanceof Error ? error.message : "Không tải được tài khoản ngân hàng.");
    });
    request<ApiBankTransaction[] | { results: ApiBankTransaction[] }>(path, token)
      .then((response) => {
        if (!active) return;
        const records = Array.isArray(response) ? response : response.results;
        const mapped = records.map(mapBankTransaction);
        setTransactions(mapped);
        const prev = bankDataCache.get(bankCacheKey);
        bankDataCache.set(bankCacheKey, {
          transactions: mapped,
          bankAccounts: prev?.bankAccounts || [],
          bankProfiles: prev?.bankProfiles || [],
          bankBalance: prev?.bankBalance || 0,
          timestamp: Date.now(),
        });
        // Internal transfers are listed with the vouchers so they can be reviewed after saving.
        internalTransfers(createApiWriter(company.id, (apiPath, init) => request(apiPath, token, init)), "bank").then((transfers) => {
          if (!active) return;
          setBankTransferRecords(transfers);
          const date = (value?: string | null) => value ? value.slice(0, 10).split("-").reverse().join("/") : "";
          setTransactions((rows) => {
            const next = [...rows.filter((row) => !String(row.id).startsWith("transfer:")), ...transfers.map((row) => ({
              id: `transfer:${row.id}`, dateHachToan: date(row.posting_date || row.transfer_date), dateChungTu: date(row.transfer_date), code: row.number,
              description: row.description || "Chuyển tiền nội bộ", amount: Number(row.source_amount ?? row.amount),
              partner: `${row.source_account_number || ""} → ${row.destination_account_number || ""}`, kind: "transfer" as const,
              status: row.status === "CONFIRMED" ? "posted" : row.status === "CANCELLED" ? "cancelled" : row.status === "REVERSED" ? "reversed" : "draft",
              bankAccount: row.source_account_number || "", debit: row.destination_gl_code || "", credit: row.source_gl_code || "", items: [],
            }) as BankTransaction)];
            const curr = bankDataCache.get(bankCacheKey);
            if (curr) curr.transactions = next;
            return next;
          });
        }).catch(() => undefined);
      })
      .catch((error) => {
        if (active && !hasCache) notify(error instanceof Error ? error.message : "Không tải được giao dịch ngân hàng.");
      });
    return () => { active = false; };
  }, [token, company.id, activeBranchScope, bankCacheKey, notify, bankApiRevision]);

  const [bankRowMenu,setBankRowMenu]=useState<string|null>(null);
  const [bankExcelMenuOpen, setBankExcelMenuOpen] = useState(false);
  const [selectedRowId, setSelectedRowId] = useState(bankParams.get("voucher") || "unc-028");
  const [bankCheckedIds,setBankCheckedIds]=useState<string[]>([]);
  const [bankDeletePending,setBankDeletePending]=useState(false);
  const [bankDeletedRows,setBankDeletedRows]=useState<BankTransaction[]>([]);

  const [activeDatasetYear, setActiveDatasetYear] = useState<number>(() => resolveActiveDatasetYear());
  const [activeBookType, setActiveBookType] = useState<"accounting" | "management">(() => resolveActiveDatasetBookType());
  const [activeHeaderPeriod, setActiveHeaderPeriod] = useState<string>(() => resolveActiveHeaderPeriod());
  useEffect(() => {
    const syncCtx = () => {
      setActiveDatasetYear(resolveActiveDatasetYear());
      setActiveBranchScope(resolveActiveBranchScope());
      setActiveBookType(resolveActiveDatasetBookType());
      setActiveHeaderPeriod(resolveActiveHeaderPeriod());
    };
    window.addEventListener("erp_context_changed", syncCtx);
    window.addEventListener("popstate", syncCtx);
    return () => {
      window.removeEventListener("erp_context_changed", syncCtx);
      window.removeEventListener("popstate", syncCtx);
    };
  }, []);
  useEffect(() => {
    if (period) {
      setActiveHeaderPeriod(period);
      setActiveDatasetYear(resolveActiveDatasetYear());
    }
  }, [period]);
  const bookFilteredTransactions = useMemo(
    () =>
      transactions.filter((t) => {
        const codeStr = String(t.code || "").trim().toUpperCase();
        if (activeBookType === "accounting" && codeStr.startsWith("QT-")) {
          return false;
        }
        return true;
      }),
    [transactions, activeBookType],
  );
  const bankLedger = useMemo(() => {
    const periodRange = resolveActivePeriodRange(activeDatasetYear);
    const mapped = bookFilteredTransactions
      .filter((transaction) => transaction.kind !== "transfer")
      .map((transaction) => ({
        date: parseReportDate(transaction.dateHachToan),
        kind: transaction.kind,
        amount: transaction.amount,
        status: transaction.status,
      }));
    const exact = cashLedger(mapped, periodRange.fromDate, periodRange.toDate, 0);
    if (exact.receipt === 0 && exact.payment === 0 && (periodRange.month !== null || periodRange.quarter !== null)) {
      return cashLedger(mapped, `${activeDatasetYear}-01-01`, periodRange.toDate, 0);
    }
    return exact;
  }, [bookFilteredTransactions, activeDatasetYear, activeHeaderPeriod]);
  const totalPayment = bankLedger.payment;

  const totalReceipt = bankLedger.receipt;

  const currentBalance = bankBalance;

  const filteredTransactions = useMemo(() => {
    const refToday = new Date(activeDatasetYear, 11, 31);
    const periodRange = resolveActivePeriodRange(activeDatasetYear);
    const baseMatches = bookFilteredTransactions.filter((t) => {
      const matchQuery =
        !searchQuery ||
        t.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        t.partner.toLowerCase().includes(searchQuery.toLowerCase());
      const matchType =
        filterType === "all" ||
        (filterType === "receipt" && t.kind === "receipt") ||
        (filterType === "payment" && t.kind === "payment") ||
        (filterType === "transfer" && t.kind === "transfer");
      const matchStatus=bankFilter.status==='all'||t.status===bankFilter.status;
      const matchReason=bankFilter.reason==='all'||t.reasonLabel===bankFilter.reason;
      const matchAccount=!bankFilter.bankAccount||bankFilter.bankAccount==='all'||t.bankAccount===bankFilter.bankAccount;
      return matchQuery && matchType && matchStatus && matchReason && matchAccount;
    });
    let dateMatched = baseMatches.filter((t) =>
      filterPeriod === "custom"
        ? isCashDateInRange(t.dateHachToan, bankFilter.from, bankFilter.to)
        : matchesTransactionPeriod(t.dateHachToan, filterPeriod, refToday),
    );
    if (dateMatched.length === 0 && filterPeriod === "ytd" && (periodRange.month !== null || periodRange.quarter !== null)) {
      dateMatched = baseMatches.filter((t) => {
        const iso = parseReportDate(t.dateHachToan);
        return iso >= `${activeDatasetYear}-01-01` && iso <= periodRange.toDate;
      });
    }
    return dateMatched;
  }, [bookFilteredTransactions, searchQuery, filterType, filterPeriod, bankFilter, activeDatasetYear, activeHeaderPeriod]);
  const bankPages=Math.max(1,Math.ceil(filteredTransactions.length/bankPageSize));
  const bankVisiblePage=Math.min(bankPage,bankPages);
  const bankVisibleRows=filteredTransactions.slice((bankVisiblePage-1)*bankPageSize,bankVisiblePage*bankPageSize);
  const selectedTransaction = useMemo(
    () => bankVisibleRows.find((item) => item.id === selectedRowId) || bankVisibleRows[0],
    [filteredTransactions, selectedRowId,bankVisiblePage,bankPageSize],
  );

  const checkedBankRows=filteredTransactions.filter(transaction=>bankCheckedIds.includes(transaction.id));
  const toggleBankChecked=(id:string)=>setBankCheckedIds(previous=>previous.includes(id)?previous.filter(value=>value!==id):[...previous,id]);
  const editBankTransfer = (id: string) => {
    const record = bankTransferRecords.find((item) => String(item.id) === id);
    if (!record || record.status !== "DRAFT") { notify("Chỉ có thể sửa lệnh chuyển tiền chưa ghi sổ."); return; }
    setEditingTransfer(record);
    setViewingTransfer(false);
    setShowTransferModal(true);
    setBankRowMenu(null);
  };
  const viewBankTransfer = (id: string) => {
    const record = bankTransferRecords.find((item) => String(item.id) === id);
    if (!record) { notify("Không tải được chứng từ chuyển tiền."); return; }
    setEditingTransfer(record);
    setViewingTransfer(true);
    setShowTransferModal(true);
  };
  const cancelBankTransfer = async (id: string) => {
    if (!token || !company.id) return;
    try {
      const writer = createApiWriter(company.id, (path, init) => request(path, token, init));
      await writer.action("/api/v1/bank/transfers/", id, "cancel", {});
      setBankApiRevision((value) => value + 1);
      notify("Đã hủy lệnh chuyển tiền chưa ghi sổ.");
    } catch (error) { notify(error instanceof Error ? error.message : "Không hủy được lệnh chuyển tiền."); }
    setBankRowMenu(null);
  };
  const setBankPosting = async (status: BankTransaction["status"], selected = checkedBankRows) => {
    if (!token || !company.id || selected.length === 0) return;
    const action = status === "posted" ? "post" : "reverse";
    try {
      const writer = createApiWriter(company.id, (path, init) => request(path, token, init));
      const transfers = selected.filter((row) => String(row.id).startsWith("transfer:"));
      if (transfers.some((row) => row.status !== (action === "post" ? "draft" : "posted"))) {
        throw new Error(action === "post" ? "Chỉ ghi sổ lệnh chuyển tiền chưa ghi sổ." : "Chỉ bỏ ghi sổ lệnh chuyển tiền đã ghi sổ.");
      }
      let reversalReason = "";
      let reversalPeriod: any = null;
      let reversalDate = "";
      if (transfers.length && action === "reverse") {
        const entered = window.prompt("Nhập lý do bỏ ghi sổ lệnh chuyển tiền:");
        if (entered === null) return;
        reversalReason = entered.trim();
        if (!reversalReason) throw new Error("Vui lòng nhập lý do bỏ ghi sổ.");
        reversalDate = parseReportDate(currentCashDate());
        reversalPeriod = await writer.glPeriod(reversalDate);
      }
      for (const row of transfers) {
        const id = String(row.id).slice("transfer:".length);
        if (action === "post") await completeTransfer(writer, "bank", id);
        else await writer.action("/api/v1/bank/transfers/", id, "reverse", {reason: reversalReason, period: reversalPeriod.id, posting_date: reversalDate});
      }
      if (transfers.length) setBankApiRevision((value) => value + 1);
      const updated: ApiBankTransaction[] = [];
      for (const transaction of selected.filter((row) => !String(row.id).startsWith("transfer:"))) {
        updated.push(action === "post" ? await postMoneyTransaction(writer, "bank", transaction.id, transaction.branchId) : await reverseMoneyTransaction(writer, "bank", transaction.id, undefined, transaction.branchId));
      }
      const byId = new Map(updated.map((row) => [row.id, mapBankTransaction(row)]));
      setTransactions((previous) => previous.map((row) => byId.get(row.id) || row));
      setBankCheckedIds([]);
      notify(`Đã ${action === "post" ? "ghi sổ" : "bỏ ghi sổ"} ${updated.length + transfers.length} chứng từ.`);
      try {
        const profiles = await request<ApiBankProfile[] | { results: ApiBankProfile[] }>(
          `/api/v1/bank/accounts/?company_id=${encodeURIComponent(company.id)}`, token,
        );
        const accounts = Array.isArray(profiles) ? profiles : profiles.results;
        setBankBalance(accounts.reduce((total, profile) => total + Number(profile.balance), 0));
      } catch {
        notify("Giao dịch đã cập nhật, nhưng chưa tải lại được số dư ngân hàng.");
      }
    } catch (error) {
      notify(error instanceof Error ? error.message : "Không thực hiện được thao tác ngân hàng.");
    }
  };

  useEffect(() => {
    if (!viewingBankVoucher) return;
    const v = transactions.find((item) => item.id === viewingBankVoucher.id) || viewingBankVoucher;
    setEditBankCode(v.code || "");
    setEditBankDate(parseReportDate(v.dateChungTu || v.dateHachToan || currentCashDate()));
    setEditBankPartner(v.partner || "");
    setEditBankDescription(v.description || "");
    const initialRows: VoucherDetailRow[] = v.rows?.length
      ? v.rows.map((r, i) => ({
          id: r.id || `${v.id}-${i}`,
          description: r.description || v.description || "",
          debit: r.debit || (v.kind === "receipt" ? "1121" : "6427"),
          credit: r.credit || (v.kind === "receipt" ? "131" : "1121"),
          amount: Number(r.amount) || 0,
          partnerCode: r.partnerCode || v.partnerCode || "",
          partnerName: r.partnerName || v.partner || "",
        }))
      : [
          {
            id: `${v.id}-0`,
            description: v.description || "",
            debit: v.debit || (v.kind === "receipt" ? "1121" : "6427"),
            credit: v.credit || (v.kind === "receipt" ? "131" : "1121"),
            amount: Number(v.amount) || 0,
            partnerCode: v.partnerCode || "",
            partnerName: v.partner || "",
          },
        ];
    setEditBankRows(initialRows);
  }, [viewingBankVoucher?.id]);

  const handleSaveBankVoucherEdit = async (andPost = false) => {
    if (!viewingBankVoucher || !token || !company?.id) return;
    const v = transactions.find((item) => item.id === viewingBankVoucher.id) || viewingBankVoucher;
    const totalAmount = editBankRows.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
    if (!(totalAmount > 0)) {
      notify("Số tiền chứng từ phải lớn hơn 0.");
      return;
    }
    if (!editBankDescription.trim()) {
      notify("Vui lòng nhập diễn giải chứng từ.");
      return;
    }
    setIsSavingBankEdit(true);
    try {
      const payload: Record<string, any> = {
        number: editBankCode.trim() || v.code,
        transaction_date: editBankDate || parseReportDate(v.dateChungTu),
        counterparty_name: editBankPartner.trim() || v.partner || "",
        description: editBankDescription.trim(),
        amount: String(totalAmount),
      };
      if (v.rawPaymentDetails && typeof v.rawPaymentDetails === "object" && Object.keys(v.rawPaymentDetails).length > 0) {
        const existingLines = Array.isArray(v.rawPaymentDetails.lines) ? v.rawPaymentDetails.lines : [];
        payload.payment_details = {
          ...v.rawPaymentDetails,
          posting_date: editBankDate || v.rawPaymentDetails.posting_date || parseReportDate(v.dateHachToan),
          lines: editBankRows.map((r, idx) => ({
            ...(existingLines[idx] || {}),
            description: (r.description || editBankDescription || "").trim(),
            debit_code: (r.debit || (v.kind === "receipt" ? "1121" : "6427")).trim(),
            credit_code: (r.credit || (v.kind === "receipt" ? "131" : "1121")).trim(),
            amount: String(Number(r.amount) || 0),
          })),
        };
      }
      const branchQuery = v.branchId ? `&branch_id=${encodeURIComponent(v.branchId)}` : "";
      const updatedRaw = await request<ApiBankTransaction>(
        `/api/v1/bank/transactions/${v.id}/?company_id=${encodeURIComponent(company.id)}${branchQuery}`,
        token,
        {
          method: "PATCH",
          body: JSON.stringify(payload),
        },
      );
      const mapped = mapBankTransaction(updatedRaw);
      if (!updatedRaw.payment_details?.lines?.length) {
        mapped.rows = editBankRows.map((r, idx) => ({
          ...r,
          id: `${v.id}-${idx}`,
          description: (r.description || editBankDescription || "").trim(),
          partnerName: editBankPartner.trim() || r.partnerName || "",
        }));
      }
      setTransactions((prev) => {
        const next = prev.map((row) => (row.id === v.id ? mapped : row));
        const curr = bankDataCache.get(company.id);
        if (curr) curr.transactions = next;
        return next;
      });
      if (andPost) {
        await setBankPosting("posted", [mapped]);
      } else {
        notify(`Đã cập nhật chứng từ ${mapped.code} thành công.`);
      }
      setViewingBankVoucher(null);
    } catch (error) {
      notify(error instanceof Error ? error.message : "Không lưu được thay đổi chứng từ ngân hàng.");
    } finally {
      setIsSavingBankEdit(false);
    }
  };

  const deleteBankTransaction = async (tx: BankTransaction) => {
    if (!token || !company?.id) return;
    try {
      await request(
        `/api/v1/bank/transactions/${tx.id}/?company_id=${encodeURIComponent(company.id)}`,
        token,
        { method: "DELETE" },
      );
      setTransactions((prev) => {
        const next = prev.filter((r) => r.id !== tx.id);
        const curr = bankDataCache.get(company.id);
        if (curr) curr.transactions = next;
        return next;
      });
      if (viewingBankVoucher?.id === tx.id) setViewingBankVoucher(null);
      notify(`Đã xóa chứng từ ${tx.code} thành công.`);
    } catch (error) {
      notify(error instanceof Error ? error.message : "Không thể xóa chứng từ ngân hàng.");
    }
  };

  // Handlers
  const saveSpecialBankPayment = async (date: string, name: string, description: string, amount: number) => {
    if (!token) return false;
    const profile = bankProfiles[0];
    if (!profile) { notify("Chưa có tài khoản ngân hàng đang hoạt động để lập chứng từ."); return false; }
    if (!(amount > 0)) { notify("Số tiền phải lớn hơn 0."); return false; }
    try {
      const writer = createApiWriter(company.id, (path, init) => request(path, token, init));
      const saved = await writer.post("/api/v1/bank/transactions/", {
        account: profile.id, currency: profile.currency_id,
        number: await nextVoucherNumber(writer, "/api/v1/bank/transactions/", "UNC"),
        transaction_type: "PAYMENT", business_type: "GENERAL",
        transaction_date: toApiDate(date), counterparty_name: name,
        description, amount: String(amount),
      }) as ApiBankTransaction;
      setTransactions((previous) => [mapBankTransaction(saved), ...previous]);
      setSelectedRowId(saved.id);
      notify(`Đã lưu chứng từ ${saved.number} dưới dạng dự thảo.`);
      return true;
    } catch (error) {
      notify(error instanceof Error ? error.message : "Không lưu được chứng từ ngân hàng.");
      return false;
    }
  };

  const handleTaxPayment = async (taxData: any) => {
    if (token) {
      const saved = await saveSpecialBankPayment(taxData.taxDate, "Kho bạc Nhà nước", `Nộp ${taxData.taxType}`, Number(taxData.totalAmount));
      if (saved) setShowTaxModal(false);
      return;
    }
    const newDoc = {
      id: crypto.randomUUID(),
      dateHachToan: taxData.taxDate.split("-").reverse().join("/"),
      dateChungTu: taxData.taxDate.split("-").reverse().join("/"),
      code: `UNC${String(transactions.length + 29).padStart(5, "0")}`,
      description: `Chi nộp ${taxData.taxType} qua ngân hàng`,
      amount: taxData.totalAmount,
      partner: "Kho bạc Nhà nước",
      kind: "payment",
      status: "posted",
      items: [
        {
          code: "THUE",
          name: taxData.taxType,
          taxDesc: "Nộp ngân sách nhà nước",
          taxRate: 0,
          taxAmount: 0,
          taxAccount: "33311",
          invoiceCode: "NSNN-01",
          invoiceDate: taxData.taxDate.split("-").reverse().join("/"),
        },
      ],
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowTaxModal(false);
    notify(`Đã lập thành công chứng từ ${newDoc.code} - Nộp thuế ${formatVND(taxData.totalAmount)}đ!`);
  };

  const handleSupplierPayment = async (data: any) => {
    if (token) {
      try {
        const writer = createApiWriter(company.id, (path, init) => request(path, token, init));
        const result = await saveSupplierPayment(writer, data);
        notify(result.message);
        setShowSupplierModal(false);
      } catch (error) {
        notify(error instanceof Error ? error.message : "Không lưu được phiếu trả nhà cung cấp.");
      }
      return;
    }
    const newDoc = {
      id: crypto.randomUUID(),
      dateHachToan: data.payDate.split("-").reverse().join("/"),
      dateChungTu: data.payDate.split("-").reverse().join("/"),
      code: `UNC${String(transactions.length + 29).padStart(5, "0")}`,
      description: `Ủy nhiệm chi trả tiền nhà cung cấp ${data.supplier} theo hóa đơn`,
      amount: data.totalAmount,
      partner: data.supplier,
      kind: "payment",
      status: "posted",
      items: [
        {
          code: "TT-NCC",
          name: `Thanh toán công nợ ${data.supplier}`,
          taxDesc: "Trả tiền nhà cung cấp",
          taxRate: 0,
          taxAmount: 0,
          taxAccount: "331",
          invoiceCode: "HD-00281",
          invoiceDate: data.payDate.split("-").reverse().join("/"),
        },
      ],
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowSupplierModal(false);
    notify(`Đã lập thành công chứng từ ${newDoc.code} - Trả tiền NCC ${formatVND(data.totalAmount)}đ!`);
  };

  const handleCustomerCollection = (data: any) => {
    const gbcCode = `GBC${String(transactions.length + 12).padStart(5, "0")}`;
    const newDoc = {
      id: crypto.randomUUID(),
      dateHachToan: data.collectDate.split("-").reverse().join("/"),
      dateChungTu: data.collectDate.split("-").reverse().join("/"),
      code: gbcCode,
      description: `Thu tiền gửi từ khách hàng ${data.customer} theo hóa đơn`,
      amount: data.totalAmount,
      partner: data.customer,
      kind: "receipt",
      status: "posted",
      items: data.invoices.map((inv: any) => ({
        code: inv.voucherCode,
        name: inv.description,
        taxDesc: "Thu tiền khách hàng theo hóa đơn",
        taxRate: 0,
        taxAmount: 0,
        taxAccount: "131.1",
        invoiceCode: inv.invoiceCode || inv.voucherCode,
        invoiceDate: data.collectDate.split("-").reverse().join("/"),
      })),
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowCustomerModal(false);
    notify(`Đã thu thành công ${formatVND(data.totalAmount)}đ từ ${data.customer} (${gbcCode})!`);
  };

  const handleMultiCustomerCollection = (data: any) => {
    const gbcCode = `GBC${String(transactions.length + 12).padStart(5, "0")}`;
    const newDoc = {
      id: crypto.randomUUID(),
      dateHachToan: data.collectDate.includes("/") ? data.collectDate : data.collectDate.split("-").reverse().join("/"),
      dateChungTu: data.collectDate.includes("/") ? data.collectDate : data.collectDate.split("-").reverse().join("/"),
      code: gbcCode,
      description: `Thu tiền gửi theo hóa đơn nhiều khách hàng (${data.invoices?.length || 0} hóa đơn)`,
      amount: data.totalAmount,
      partner: "Nhiều khách hàng",
      kind: "receipt",
      status: "posted",
      items: data.invoices.map((inv: any) => ({
        code: inv.voucherCode,
        name: inv.description,
        taxDesc: "Thu tiền khách hàng theo hóa đơn",
        taxRate: 0,
        taxAmount: 0,
        taxAccount: "131.1",
        invoiceCode: inv.invoiceCode || inv.voucherCode,
        invoiceDate: data.collectDate.includes("/") ? data.collectDate : data.collectDate.split("-").reverse().join("/"),
      })),
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowMultiCustomerModal(false);
    notify(`Đã thu thành công ${formatVND(data.totalAmount)}đ từ nhiều khách hàng (${gbcCode})!`);
  };

  const handleInsurancePayment = async (data: any) => {
    if (token) {
      // Pays the insurance of the latest posted salary sheet and links the voucher to it.
      const saved = await saveLoanDocument((writer) => savePayrollPayment(writer, { ...data, payMethod: "bank" }, true), () => setShowInsuranceModal(false));
      return saved;
    }
    const uncCode = `UNC${String(transactions.length + 29).padStart(5, "0")}`;
    const newDoc = {
      id: crypto.randomUUID(),
      dateHachToan: data.payDate.split("-").reverse().join("/"),
      dateChungTu: data.payDate.split("-").reverse().join("/"),
      code: uncCode,
      description: `Ủy nhiệm chi nộp BHXH, BHYT, BHTN tháng 08/2026 - ${data.insuranceUnit}`,
      amount: data.totalAmount,
      partner: data.insuranceUnit,
      kind: "payment",
      status: "posted",
      items: [
        {
          code: "BHXH-01",
          name: "Trích nộp BHXH, BHYT, BHTN",
          taxDesc: "Nộp cơ quan bảo hiểm xã hội",
          taxRate: 0,
          taxAmount: 0,
          taxAccount: "3383",
          invoiceCode: "BH-T08",
          invoiceDate: data.payDate.split("-").reverse().join("/"),
        },
      ],
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowInsuranceModal(false);
    notify(`Đã lập thành công chứng từ ${uncCode} - Nộp bảo hiểm ${formatVND(data.totalAmount)}đ!`);
  };

  const handleSalaryPayment = async (data: any) => {
    if (token) {
      const saved = await saveLoanDocument((writer) => savePayrollPayment(writer, { ...data, payMethod: "bank" }, false), () => setShowSalaryModal(false));
      return saved;
    }
    const uncCode = `UNC${String(transactions.length + 29).padStart(5, "0")}`;
    const newDoc = {
      id: crypto.randomUUID(),
      dateHachToan: "15/09/2026",
      dateChungTu: "15/09/2026",
      code: uncCode,
      description: `Ủy nhiệm chi chi trả lương CBNV ${data.payrollPeriod} qua ngân hàng`,
      amount: data.totalAmount,
      partner: "Cán bộ công nhân viên công ty",
      kind: "payment",
      status: "posted",
      items: [
        {
          code: "LUONG-T08",
          name: `Chi trả lương CBNV (${data.employeeCount} nhân viên)`,
          taxDesc: "Chi trả lương qua tài khoản",
          taxRate: 0,
          taxAmount: 0,
          taxAccount: "3341",
          invoiceCode: "BL-T08",
          invoiceDate: "15/09/2026",
        },
      ],
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowSalaryModal(false);
    notify(`Đã lập thành công chứng từ ${uncCode} - Chi lương ${formatVND(data.totalAmount)}đ!`);
  };

  const handleInternalTransfer = async (data: any) => {
    if (token) {
      try {
        const source = String(data.sourceAccount || "").replace(/^BANK:/, "");
        const destination = String(data.targetAccount || "").replace(/^BANK:/, "");
        const sourceProfile = bankProfiles.find((profile) => profile.id === source);
        const targetProfile = bankProfiles.find((profile) => profile.id === destination);
        if (!sourceProfile || !targetProfile || source === destination) throw new Error("Chọn hai tài khoản ngân hàng khác nhau trong danh mục.");
        if (sourceProfile.currency_id !== targetProfile.currency_id) throw new Error("Hai tài khoản phải cùng loại tiền.");
        if (sourceProfile.currency_code !== "VND") throw new Error("Chuyển ngoại tệ cần chính sách định giá riêng; hiện chỉ hỗ trợ VND.");
        if (sourceProfile.branch_id !== targetProfile.branch_id) throw new Error("Hai tài khoản phải cùng chi nhánh hạch toán.");
        if (!(Number(data.amount) > 0)) throw new Error("Số tiền chuyển phải lớn hơn 0.");
        if (!String(data.reason || "").trim()) throw new Error("Vui lòng nhập lý do chuyển.");
        if (!String(data.lineDescription || "").trim()) throw new Error("Vui lòng nhập diễn giải dòng hạch toán.");
        if (!parseReportDate(String(data.transferDate || "")) || !parseReportDate(String(data.postingDate || ""))) throw new Error("Ngày chứng từ hoặc ngày hạch toán không hợp lệ.");
        const writer = createApiWriter(company.id, (path, init) => request(path, token, init));
        const path = "/api/v1/bank/transfers/";
        const record = await (data.id ? writer.patch(`${path}${data.id}/`, {
          version: data.version,
          number: String(data.number || "").trim(),
          source_account: source, destination_account: destination,
          transfer_date: toApiDate(data.transferDate), posting_date: toApiDate(data.postingDate), source_amount: String(data.amount),
          destination_amount: String(data.amount), exchange_rate: "1", description: data.reason,
          details: { branch: sourceProfile.branch_id, outgoing_reference: data.outgoingReference || "", incoming_reference: data.incomingReference || "",
            lines: [{ description: data.lineDescription, debit_account: targetProfile.gl_account_id, credit_account: sourceProfile.gl_account_id, amount: String(data.amount) }] },
        }) : writer.post(path, {
          number: String(data.number || "").trim() || await nextVoucherNumber(writer, path, "CK"),
          source_account: source, destination_account: destination,
          transfer_date: toApiDate(data.transferDate), posting_date: toApiDate(data.postingDate), source_amount: String(data.amount),
          destination_amount: String(data.amount), exchange_rate: "1",
          description: data.reason,
          details: { branch: sourceProfile.branch_id, outgoing_reference: data.outgoingReference || "", incoming_reference: data.incomingReference || "",
            lines: [{ description: data.lineDescription, debit_account: targetProfile.gl_account_id, credit_account: sourceProfile.gl_account_id, amount: String(data.amount) }] },
        }));
        setShowTransferModal(false);
        setEditingTransfer(null);
        setBankApiRevision((value) => value + 1);
        notify(`Đã lưu lệnh chuyển ${record.number}; lệnh hiện trong danh sách chứng từ.`);
      } catch (error) {
        notify(error instanceof Error ? error.message : "Không lưu được lệnh chuyển tiền nội bộ.");
      }
      return;
    }
    const uncCode = `UNC${String(transactions.length + 29).padStart(5, "0")}`;
    const newDoc = {
      id: crypto.randomUUID(),
      dateHachToan: data.transferDate.split("-").reverse().join("/"),
      dateChungTu: data.transferDate.split("-").reverse().join("/"),
      code: uncCode,
      description: data.reason || `Chuyển tiền nội bộ từ ${data.sourceAccount} sang ${data.targetAccount}`,
      amount: data.amount,
      partner: data.targetAccount,
      kind: "transfer",
      status: "posted",
      items: [
        {
          code: "NB01",
          name: "Chuyển tiền nội bộ",
          taxDesc: "Chuyển tiền giữa các tài khoản",
          taxRate: 0,
          taxAmount: 0,
          taxAccount: "1121",
          invoiceCode: "NB-01",
          invoiceDate: data.transferDate.split("-").reverse().join("/"),
        },
      ],
    };
    setTransactions([newDoc, ...transactions]);
    setSelectedRowId(newDoc.id);
    setShowTransferModal(false);
    notify(`Đã thực hiện chuyển tiền nội bộ ${formatVND(data.amount)}đ!`);
  };

  const saveLoanDocument = async (save: (writer: ReturnType<typeof createApiWriter>) => Promise<{ message: string }>, close: () => void) => {
    if (!token || !company.id) return false;
    try {
      const result = await save(createApiWriter(company.id, (path, init) => request(path, token, init)));
      close();
      notify(result.message);
      setBankApiRevision((value) => value + 1);
      return true;
    } catch (error) {
      notify(error instanceof Error ? error.message : "Không lưu được.");
      return false;
    }
  };

  const handleSaveLoanContract = (data: any) => {
    if (token) return saveLoanDocument((writer) => saveLoanAgreement(writer, data, "LENDING"), () => setShowLoanModal(false));
    setShowLoanModal(false);
    notify(`Đã lưu thành công Khế ước cho vay ${data.code}!`);
  };

  const handleSaveBorrowContract = (data: any) => {
    if (token) return saveLoanDocument((writer) => saveLoanAgreement(writer, data, "BORROWING"), () => setShowBorrowModal(false));
    setShowBorrowModal(false);
    notify(`Đã lưu thành công Khế ước đi vay ${data.code}!`);
  };

  const handleSaveCreditContract = (data: any) => {
    if (token) return saveLoanDocument((writer) => saveCreditContract(writer, data), () => setCreditContractModalKind(null));
    setCreditContractModalKind(null);
    notify(`Đã lưu thành công Hợp đồng tín dụng ${data.contractNum || ""}!`);
  };

  // Common Modals Renderer
  const renderModals = () => (
    <>
      {bankColumnsOpen&&<CashColumnDialog value={bankColumns} defaults={defaultBankColumns} onClose={()=>setBankColumnsOpen(false)} onSave={value=>{setBankColumns(value);try{localStorage.setItem(bankColumnsKey,JSON.stringify(value));}catch{notify('Đã áp dụng cột nhưng chưa lưu được tùy chọn trên trình duyệt.');}}}/>}
      {bankImportKind&&<CashExcelImport category="bank" kind={bankImportKind} existingCodes={transactions.map(transaction=>transaction.code)} onClose={()=>setBankImportKind(null)} onImport={documents=>{setTransactions(previous=>[...documents.map(document=>({...document,dateHachToan:document.postDate.split('-').reverse().join('/'),dateChungTu:document.date.split('-').reverse().join('/'),items:[]})),...previous]);setSelectedRowId(documents[0]?.id||selectedRowId);notify(`Đã nhập ${documents.length} chứng từ tiền gửi vào frontend.`);}}/>}
      {bankFilterOpen&&<CashAdvancedPanel bankAccounts={bankAccounts} mode="filters" filter={bankFilter} hidden={[]} reasons={[...MISA_BANK_RECEIPT_TYPES,...MISA_BANK_PAYMENT_TYPES].map(type=>type.label.replace(/^\d+\.\s*/,''))} onClose={()=>setBankFilterOpen(false)} onColumns={()=>{}} onFilter={value=>{setBankFilter(value);setFilterPeriod('custom');}}/>}
      {bankOptionsOpen&&<CashOptionsDialog companyId={company.id} onClose={()=>setBankOptionsOpen(false)}/>}
      {showCustomerModal && (
        <SingleCustomerInvoiceCollectionModal
          initialMethod="bank"
          onClose={() => setShowCustomerModal(false)}
          onSubmit={handleCustomerCollection}
        />
      )}

      {showMultiCustomerModal && (
        <MultiCustomerInvoiceCollectionModal
          initialMethod="bank"
          onClose={() => setShowMultiCustomerModal(false)}
          onSubmit={handleMultiCustomerCollection}
        />
      )}

      {showInsuranceModal && (
        <InsurancePaymentModal initialMethod="bank"
          onClose={() => setShowInsuranceModal(false)}
          onSubmit={handleInsurancePayment}
          loadRecords={token ? () => insurancePaymentRows(createApiWriter(company.id, (path, init) => request(path, token, init))) : undefined}
        />
      )}

      {showSalaryModal && (
        <SalaryPaymentModal initialMethod="bank"
          onClose={() => setShowSalaryModal(false)}
          onSubmit={handleSalaryPayment}
          loadRecords={token ? () => salaryPaymentRows(createApiWriter(company.id, (path, init) => request(path, token, init))) : undefined}
        />
      )}

      {showTransferModal && (
        <InternalTransferModal
          initial={editingTransfer || undefined}
          readOnly={viewingTransfer}
          accounts={token ? bankProfiles.map((profile) => ({ value: `BANK:${profile.id}`, label: `${profile.account_number} - ${profile.bank_name}${profile.bank_branch ? ` (${profile.bank_branch})` : ""} · ${profile.branch_name || "Đơn vị chung"} · ${profile.currency_code} · ${profile.gl_code || "?"}`, currency: profile.currency_code, glCode: profile.gl_code, branchId: profile.branch_id })) : undefined}
          onClose={() => {setShowTransferModal(false);setEditingTransfer(null);setViewingTransfer(false);}}
          onSubmit={handleInternalTransfer}
        />
      )}

      {showExcelModal && (
        <ExcelImportModal
          companyId={company.id}
          token={token}
          profiles={bankProfiles}
          onClose={() => setShowExcelModal(false)}
          onImportSuccess={(cnt, reference) => {
            notify(`Đã nhập ${cnt} giao dịch sao kê (${reference}); chưa tạo chứng từ hoặc ghi sổ.`);
            setBankApiRevision((value) => value + 1);
          }}
        />
      )}

      {showTaxModal && (
        <TaxPaymentModal
          initialMethod="bank"
          onClose={() => setShowTaxModal(false)}
          onSubmit={handleTaxPayment}
        />
      )}

      {showSupplierModal && (
        <SupplierPaymentModal
          initialMethod="bank"
          debtSource={supplierDebtSource}
          onClose={() => setShowSupplierModal(false)}
          onSubmit={handleSupplierPayment}
        />
      )}

      {showVoucherModal && (
        <AccountingVoucherModal
          voucher={selectedVoucher}
          onClose={() => setShowVoucherModal(false)}
        />
      )}

      {viewingBankVoucher && (() => {
        const v = transactions.find((item) => item.id === viewingBankVoucher.id) || viewingBankVoucher;
        const isPosted = v.status === "posted";
        const activeRows: VoucherDetailRow[] = editBankRows.length
          ? editBankRows
          : [
              {
                id: `${v.id}-0`,
                description: v.description || "",
                debit: v.debit || (v.kind === "receipt" ? "1121" : "6427"),
                credit: v.credit || (v.kind === "receipt" ? "131" : "1121"),
                amount: Number(v.amount) || 0,
                partnerCode: v.partnerCode || "",
                partnerName: v.partner || "",
              },
            ];
        const computedTotal = activeRows.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
        return (
          <div className="misa-modal-overlay" onClick={() => setViewingBankVoucher(null)}>
            <div
              className="misa-voucher-window"
              style={{ width: "min(1180px, 95vw)", height: "auto", maxHeight: "90vh" }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="misa-voucher-header">
                <div className="misa-voucher-header-left">
                  <h2 className="misa-voucher-title">
                    {v.kind === "receipt" ? "Báo Có (Thu tiền gửi)" : "Ủy nhiệm chi (Chi tiền gửi)"} — {editBankCode || v.code}
                  </h2>
                  <span
                    style={{
                      padding: "3px 10px",
                      borderRadius: 12,
                      fontSize: 12,
                      fontWeight: 600,
                      background: isPosted ? "#ecfdf5" : "#fffbeb",
                      color: isPosted ? "#047857" : "#b45309",
                      border: isPosted ? "1px solid #a7f3d0" : "1px solid #fde68a",
                    }}
                  >
                    {isPosted ? "Đã ghi sổ (Chỉ xem)" : "Chưa ghi sổ (Cho phép sửa)"}
                  </span>
                </div>
                <div className="misa-voucher-header-tools">
                  <button
                    type="button"
                    className="misa-voucher-close-btn"
                    onClick={() => setViewingBankVoucher(null)}
                    title="Đóng (ESC)"
                  >
                    <X size={18} />
                  </button>
                </div>
              </div>

              <div className="misa-voucher-body" style={{ paddingBottom: 12 }}>
                {isPosted && (
                  <div
                    style={{
                      margin: "10px 20px 0",
                      padding: "8px 14px",
                      borderRadius: 8,
                      background: "#fffbeb",
                      border: "1px solid #fde68a",
                      color: "#92400e",
                      fontSize: 12.5,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      gap: 12,
                    }}
                  >
                    <span>
                      Chứng từ này <strong>đã ghi sổ</strong> nên đang được khóa chỉnh sửa. Bấm <strong>"Bỏ ghi sổ để sửa"</strong> nếu bạn muốn chỉnh sửa nội dung.
                    </span>
                    <button
                      type="button"
                      className="misa-btn-secondary"
                      style={{ height: 28, padding: "0 12px", fontSize: 12, fontWeight: 600, background: "#fef3c7", borderColor: "#f59e0b", color: "#92400e", flexShrink: 0 }}
                      onClick={() => void setBankPosting("draft", [v])}
                    >
                      Bỏ ghi sổ để sửa
                    </button>
                  </div>
                )}

                <div className="misa-voucher-master-grid">
                  <div className="misa-voucher-master-left">
                    <div className="misa-voucher-row-main">
                      <div className="misa-voucher-field" style={{ flex: 1 }}>
                        <label>Đối tượng</label>
                        <input
                          className="misa-voucher-input"
                          value={editBankPartner}
                          readOnly={isPosted}
                          onChange={(e) => {
                            const val = e.target.value;
                            setEditBankPartner(val);
                            setEditBankRows((rows) => rows.map((r, i) => (i === 0 ? { ...r, partnerName: val } : r)));
                          }}
                        />
                      </div>
                      <div className="misa-voucher-field" style={{ width: 240 }}>
                        <label>Tài khoản ngân hàng</label>
                        <input className="misa-voucher-input" value={v.bankAccount || "—"} readOnly style={{ background: "#f8fafc" }} />
                      </div>
                    </div>
                    <div className="misa-voucher-row-main">
                      <div className="misa-voucher-field" style={{ flex: 1 }}>
                        <label>Nội dung thanh toán (Diễn giải)</label>
                        <input
                          className="misa-voucher-input"
                          value={editBankDescription}
                          readOnly={isPosted}
                          onChange={(e) => {
                            const nextDesc = e.target.value;
                            const prevDesc = editBankDescription;
                            setEditBankDescription(nextDesc);
                            setEditBankRows((rows) =>
                              rows.map((r, i) =>
                                i === 0 && (!r.description || r.description === prevDesc) ? { ...r, description: nextDesc } : r,
                              ),
                            );
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="misa-voucher-master-right">
                    <div className="misa-voucher-total-block">
                      <div className="misa-voucher-total-label">Tổng tiền</div>
                      <div className="misa-voucher-total-number" style={{ fontSize: 26 }}>
                        {formatVND(computedTotal)}
                      </div>
                    </div>
                    <div className="misa-voucher-meta-stack">
                      <div className="misa-voucher-meta-row">
                        <label>Ngày chứng từ</label>
                        <div className="misa-voucher-meta-control">
                          <input
                            type={isPosted ? "text" : "date"}
                            className="misa-voucher-input"
                            value={isPosted ? editBankDate.split("-").reverse().join("/") : editBankDate}
                            readOnly={isPosted}
                            onChange={(e) => setEditBankDate(e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="misa-voucher-meta-row">
                        <label>Số chứng từ</label>
                        <div className="misa-voucher-meta-control">
                          <input
                            className="misa-voucher-input"
                            value={editBankCode}
                            readOnly={isPosted}
                            onChange={(e) => setEditBankCode(e.target.value)}
                            style={{ fontWeight: 700, color: "var(--brand)" }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="misa-voucher-details-section" style={{ padding: "12px 20px" }}>
                  <div style={{ fontWeight: 700, fontSize: 13, color: "#0f172a", marginBottom: 8 }}>
                    Chi tiết hạch toán định khoản
                  </div>
                  <table className="misa-tax-table">
                    <thead>
                      <tr>
                        <th style={{ width: 44 }}>STT</th>
                        <th>Diễn giải</th>
                        <th style={{ width: 100 }}>TK Nợ</th>
                        <th style={{ width: 100 }}>TK Có</th>
                        <th className="numeric" style={{ width: 170 }}>Số tiền</th>
                        <th>Tên đối tượng</th>
                      </tr>
                    </thead>
                    <tbody>
                      {activeRows.map((row, idx) => (
                        <tr key={row.id || idx}>
                          <td>{idx + 1}</td>
                          <td>
                            {isPosted ? (
                              row.description || editBankDescription
                            ) : (
                              <input
                                className="misa-voucher-input"
                                style={{ height: 28, width: "100%" }}
                                value={row.description}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setEditBankRows((rows) => rows.map((r, i) => (i === idx ? { ...r, description: val } : r)));
                                  if (idx === 0 && activeRows.length === 1) setEditBankDescription(val);
                                }}
                              />
                            )}
                          </td>
                          <td>
                            {isPosted ? (
                              <strong style={{ color: "#2563eb" }}>{row.debit}</strong>
                            ) : (
                              <input
                                className="misa-voucher-input"
                                style={{ height: 28, width: "100%", fontWeight: 700, color: "#2563eb" }}
                                value={row.debit}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setEditBankRows((rows) => rows.map((r, i) => (i === idx ? { ...r, debit: val } : r)));
                                }}
                              />
                            )}
                          </td>
                          <td>
                            {isPosted ? (
                              <strong style={{ color: "#7c3aed" }}>{row.credit}</strong>
                            ) : (
                              <input
                                className="misa-voucher-input"
                                style={{ height: 28, width: "100%", fontWeight: 700, color: "#7c3aed" }}
                                value={row.credit}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setEditBankRows((rows) => rows.map((r, i) => (i === idx ? { ...r, credit: val } : r)));
                                }}
                              />
                            )}
                          </td>
                          <td className="numeric">
                            {isPosted ? (
                              <strong>{formatVND(Number(row.amount) || 0)}</strong>
                            ) : (
                              <input
                                type="text"
                                inputMode="numeric"
                                className="misa-voucher-input"
                                style={{ height: 28, width: "100%", textAlign: "right", fontWeight: 700 }}
                                value={formatMoneyInput(row.amount)}
                                onChange={(e) => {
                                  const val = parseMoneyInput(e.target.value);
                                  setEditBankRows((rows) => rows.map((r, i) => (i === idx ? { ...r, amount: val } : r)));
                                }}
                              />
                            )}
                          </td>
                          <td>
                            {isPosted ? (
                              row.partnerName || editBankPartner || ""
                            ) : (
                              <input
                                className="misa-voucher-input"
                                style={{ height: 28, width: "100%" }}
                                value={row.partnerName || editBankPartner}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setEditBankRows((rows) => rows.map((r, i) => (i === idx ? { ...r, partnerName: val } : r)));
                                }}
                              />
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr>
                        <td />
                        <td><strong>Cộng</strong></td>
                        <td />
                        <td />
                        <td className="numeric"><strong>{formatVND(computedTotal)}</strong></td>
                        <td />
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "10px 20px",
                  background: "#0f172a",
                  borderTop: "1px solid #1e293b",
                }}
              >
                <button
                  type="button"
                  className="misa-btn-secondary"
                  style={{ background: "#1e293b", color: "#f8fafc", border: "1px solid #334155" }}
                  onClick={() => setViewingBankVoucher(null)}
                >
                  Đóng
                </button>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <button
                    type="button"
                    className="misa-btn-secondary"
                    style={{ background: "#ffffff", color: "#0f172a", display: "inline-flex", alignItems: "center", gap: 6 }}
                    onClick={() => {
                      setViewingBankVoucher(null);
                      setSelectedVoucher({
                        code: editBankCode || v.code,
                        date: editBankDate || parseReportDate(v.dateChungTu),
                        person: editBankPartner || v.partner,
                        address: "Hà Nội",
                        reason: editBankDescription || v.description,
                        debitAccount: activeRows[0]?.debit || v.debit || (v.kind === "receipt" ? "1121" : "6427"),
                        creditAccount: activeRows[0]?.credit || v.credit || (v.kind === "receipt" ? "131" : "1121"),
                        amount: computedTotal,
                        amountInWords: convertNumberToVietnameseWords(computedTotal),
                        notes: "Chứng từ ngân hàng",
                        chiefAccountant: "Trương Thị B",
                        director: "Nguyễn Văn A",
                      });
                      setShowVoucherModal(true);
                    }}
                  >
                    <Printer size={14} />
                    <span>In biểu mẫu A4 ({editBankCode || v.code})</span>
                  </button>
                  {!isPosted ? (
                    <>
                      <button
                        type="button"
                        className="misa-btn-secondary"
                        disabled={isSavingBankEdit}
                        style={{ background: "#3b82f6", color: "#ffffff", border: "none", fontWeight: 700 }}
                        onClick={() => void handleSaveBankVoucherEdit(false)}
                      >
                        {isSavingBankEdit ? "Đang lưu..." : "Lưu thay đổi (Cất)"}
                      </button>
                      <button
                        type="button"
                        className="misa-btn-primary"
                        disabled={isSavingBankEdit}
                        style={{ background: "var(--brand)", border: "none", fontWeight: 700 }}
                        onClick={() => void handleSaveBankVoucherEdit(true)}
                      >
                        Cất & Ghi sổ
                      </button>
                    </>
                  ) : (
                    <button
                      type="button"
                      className="misa-btn-primary"
                      style={{ background: "#f59e0b", border: "none", fontWeight: 700 }}
                      onClick={() => void setBankPosting("draft", [v])}
                    >
                      Bỏ ghi sổ để sửa
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {showCreateVoucher && (
        <CreateVoucherModal
          kind={showCreateVoucher}
          voucherCategory="bank"
          initialStatement={statementVoucherSource}
          existingCodes={transactions.map(row=>row.code)}
          suggestedCode={nextCashCode(showCreateVoucher,transactions.map(row=>row.code),"bank")}
          initialTypeIndex={createVoucherTypeIndex}
          onClose={() => {
            setShowCreateVoucher(null);
            setStatementVoucherSource(null);
            setCreateVoucherTypeIndex(0);
          }}
          onSave={(doc) => token ? apiSaveBank((writer) => doc.kind === "payment" &&
            ["supplier", "supplier_invoice", "advance", "other_expense"].includes(doc.receiptType)
            ? saveBankPaymentDraft(writer, doc) : saveMoneyVoucher(writer, "bank", doc)) : Promise.resolve(false)}
        />
      )}

      {showAIModal && (
        <AIAssistantModal
          onClose={() => setShowAIModal(false)}
          onApply={(doc) => {
            setShowAIModal(false);
            notify(`Hệ thống đã tạo dự thảo chứng từ chuyển khoản ${doc.code}.`);
          }}
        />
      )}

      {showLoanModal && (
        <LoanContractModal
          onClose={() => setShowLoanModal(false)}
          onSubmit={handleSaveLoanContract}
          onOpenCreditContract={() => setCreditContractModalKind("lending")}
        />
      )}

      {showBorrowModal && (
        <BorrowingContractModal
          onClose={() => setShowBorrowModal(false)}
          onSubmit={handleSaveBorrowContract}
          onOpenCreditContract={() => setCreditContractModalKind("borrowing")}
        />
      )}

      {creditContractModalKind && (
        <CreditContractModal
          kind={creditContractModalKind}
          onClose={() => setCreditContractModalKind(null)}
          onSubmit={handleSaveCreditContract}
        />
      )}
    </>
  );

  if(tab==='ebanking')return <><MisaBankElectronicWorkspace accounts={bankAccounts} companyId={company.id} onOpenVoucher={kind=>setShowCreateVoucher(kind)}/>{renderModals()}</>;
  if(tab==='reports')return <MisaReportCenterWorkspace key={bankParams.get('report')||'bank'} initialCategory="bank" initialReport={bankParams.get('report')} embedded notify={notify}/>;
  if(tab==='cashflow')return <MisaCashForecastWorkspace companyId={company.id} openingKind="bank" entries={transactions.map(row=>({date:row.dateHachToan,kind:row.kind,amount:row.amount,code:row.code,status:row.status}))}/>;
  if(tab==='advance-settlement' || tab==='advance-settlement-request')return <><MisaPaymentWorkflow variant="settlement" notify={notify}><AdvanceSettlementTab notify={notify} onOpenCreateReceipt={()=>setShowCreateVoucher('receipt')}/></MisaPaymentWorkflow>{renderModals()}</>;
  if (tab === 'reconciliation' || tab === 'reconcile') return <><MisaBankReconciliation companyId={company.id} transactions={transactions} notify={notify} onCreateVoucher={(kind, line) => { setStatementVoucherSource(line); setShowCreateVoucher(kind); }} onOpenVoucher={(id, code) => { setSelectedRowId(id); setSearchQuery(code); setFilterPeriod('all'); navigate(href(`/bank/transactions?voucher=${encodeURIComponent(id)}&voucherCode=${encodeURIComponent(code)}`)); }}/>{renderModals()}</>;
  if (tab === 'payment-requests') return <><MisaPaymentWorkflow notify={notify}><PaymentRequestsTab notify={notify} onOpenCreatePayment={()=>setShowCreateVoucher('payment')}/></MisaPaymentWorkflow>{renderModals()}</>;

  // --------------------------------------------------------------------
  // RENDER TAB: "Khế ước cho vay" & "Khế ước đi vay" (MATCHING SCREENSHOT 5)
  // --------------------------------------------------------------------
  if (tab === "loans" || tab === "borrowings") {
    return (
      <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#ffffff" }}>
        <CreditOverviewView
          type={tab === "loans" ? "loans" : "borrowings"}
          records={token ? loanRecords : undefined}
          onOpenLoanModal={() => setShowLoanModal(true)}
          onOpenBorrowModal={() => setShowBorrowModal(true)}
          onOpenCreditContractModal={(k) => setCreditContractModalKind(k)}
          onOpenAIModal={() => setShowAIModal(true)}
          onOpenExcelModal={() => setShowExcelModal(true)}
          notify={notify}
        />
        {renderModals()}
      </div>
    );
  }

  // --------------------------------------------------------------------
  // RENDER TAB: "Thu, chi tiền" (MATCHING SCREENSHOT 4 & 5)
  // --------------------------------------------------------------------
  if (tab === "transactions" || tab === "all") {
    return (
      <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "#f8fafc" }}>
        {/* Sổ Việt AI Smart Analysis Banner (Image 4 & 5) */}
        {showAvaBanner && (
          <div
            style={{
              margin: "10px 14px 0 14px",
              background: "linear-gradient(135deg, #f5f3ff 0%, #eff6ff 100%)",
              border: "1px solid #e0e7ff",
              borderRadius: 8,
              padding: "10px 14px",
              boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
            }}
          >
            {/* Header row */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 8,
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div
                  style={{
                    width: 22,
                    height: 22,
                    borderRadius: "50%",
                    background: "linear-gradient(135deg, #8b5cf6, #ec4899)",
                    display: "grid",
                    placeItems: "center",
                    color: "#ffffff",
                  }}
                >
                  <Sparkles size={13} />
                </div>
                <strong style={{ fontSize: 13, color: "#4338ca" }}>Phân tích dòng tiền</strong>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 12, fontSize: 11, color: "#6b7280" }}>
                <span>Tháng 8 Số liệu tính đến: 15h56</span>
                <span
                  style={{ color: "#4f46e5", cursor: "pointer", display: "inline-flex", alignItems: "center" }}
                  onClick={() => setShowAIModal(true)}
                >
                  Xem tất cả &gt;
                </span>
                <button
                  type="button"
                  style={{ border: "none", background: "none", cursor: "pointer", color: "#9ca3af", padding: 0 }}
                  onClick={() => setShowAvaBanner(false)}
                >
                  <X size={18} aria-hidden="true" />
                </button>
              </div>
            </div>

            {/* Analysis Grid (2 Columns matching Image 4 & 5) */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              {/* Column 1: Dòng tiền thuần */}
              <div style={{ background: "#ffffff", padding: "8px 12px", borderRadius: 6, border: "1px solid #e2e8f0" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                  <span style={{ fontSize: 12, fontWeight: 600, color: "#1e293b" }}>Dòng tiền thuần</span>
                  <span
                    style={{ fontSize: 11, color: "var(--brand)", cursor: "pointer" }}
                    onClick={() => notify("Mở phân tích chuyên sâu Dòng tiền thuần...")}
                  >
                    Phân tích chuyên sâu
                  </span>
                </div>
                <p style={{ margin: 0, fontSize: 12, color: "#475569", lineHeight: 1.4 }}>
                  Dòng tiền thuần <span style={{ color: "#dc2626", fontWeight: 600 }}>thâm hụt nghiêm trọng</span>, hệ số thu/chi = 0 lần, đang <span style={{ color: "#dc2626", fontWeight: 600 }}>mất đi</span> khả năng tự tài trợ vốn lưu động.
                </p>
              </div>

              {/* Column 2: Rủi ro & Khuyến nghị */}
              <div style={{ background: "#ffffff", padding: "8px 12px", borderRadius: 6, border: "1px solid #e2e8f0" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                  <span style={{ fontSize: 12, fontWeight: 600, color: "#1e293b" }}>Rủi ro &amp; Khuyến nghị</span>
                  <span
                    style={{ fontSize: 11, color: "var(--brand)", cursor: "pointer" }}
                    onClick={() => notify("Mở phân tích chuyên sâu Rủi ro & Khuyến nghị...")}
                  >
                    Phân tích chuyên sâu
                  </span>
                </div>
                <p style={{ margin: 0, fontSize: 12, color: "#475569", lineHeight: 1.4 }}>
                  Nguy cơ <span style={{ color: "#dc2626", fontWeight: 600 }}>cạn kiệt</span> thanh khoản, đối mặt với nợ xấu. Bạn nên xem xét tìm kiếm nguồn vốn vay bổ sung.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* 3 KPI Summary Cards (Image 4 & 5) */}
        {!kpiCollapsed && (
          <div className="misa-kpi-row" style={{ margin: "10px 14px 4px 14px" }}>
            {/* Card 1 */}
            <div
              className="misa-kpi-card"
              style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: 12, padding: "10px 14px" }}
            >
              <div
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 8,
                  background: "#f0fdf4",
                  border: "1px solid #bbf7d0",
                  display: "grid",
                  placeItems: "center",
                  color: "var(--brand)",
                  flexShrink: 0,
                }}
              >
                <Coins size={22} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: "#334155", fontWeight: 500, marginBottom: 2 }}>
                  Tổng thu đầu năm đến hiện tại
                </div>
                <strong style={{ fontSize: 18, color: totalReceipt > 0 ? "var(--brand)" : "#111827" }}>
                  {formatVND(totalReceipt)}
                </strong>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 3, fontSize: 11.5, color: "#94a3b8" }}>
                <Clock size={12} />
                <span>{new Date().toLocaleTimeString("vi-VN",{hour:"2-digit",minute:"2-digit"})}</span>
              </div>
            </div>

            {/* Card 2 */}
            <div
              className="misa-kpi-card"
              style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: 12, padding: "10px 14px" }}
            >
              <div
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 8,
                  background: "#fff7ed",
                  border: "1px solid #fed7aa",
                  display: "grid",
                  placeItems: "center",
                  color: "#ea580c",
                  flexShrink: 0,
                }}
              >
                <Coins size={22} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: "#334155", fontWeight: 500, marginBottom: 2 }}>
                  Tổng chi đầu năm đến hiện tại
                </div>
                <strong style={{ fontSize: 18, color: "#ea580c" }}>{formatVND(totalPayment)}</strong>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 3, fontSize: 11.5, color: "#94a3b8" }}>
                <Clock size={12} />
                <span>15:12</span>
              </div>
            </div>

            {/* Card 3 */}
            <div
              className="misa-kpi-card highlight"
              style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: 12, padding: "10px 14px" }}
            >
              <div
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 8,
                  background: "#f3e8ff",
                  border: "1px solid #ddd6fe",
                  display: "grid",
                  placeItems: "center",
                  color: "#7e22ce",
                  flexShrink: 0,
                }}
              >
                <Landmark size={22} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: "#334155", fontWeight: 500, marginBottom: 2 }}>
                  Số dư tiền gửi đến ngày {currentCashDate()}
                </div>
                <strong style={{ fontSize: 18, color: "var(--brand)" }}>{formatVND(currentBalance)}</strong>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 3, fontSize: 11.5, color: "#94a3b8" }}>
                <Clock size={12} />
                <span>15:12</span>
              </div>
            </div>
          </div>
        )}

        {/* Center Collapse/Expand Button for KPI strip */}
        <div style={{ display: "flex", justifyContent: "center", background: "#ffffff", borderBottom: "1px solid #e5e7eb", paddingBottom: 2 }}>
          <button
            type="button"
            onClick={() => setKpiCollapsed(!kpiCollapsed)}
            style={{
              width: 32,
              height: 16,
              background: "#ffffff",
              border: "1px solid #cbd5e1",
              borderBottom: "none",
              borderRadius: "6px 6px 0 0",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: "#64748b",
              boxShadow: "0 -1px 2px rgba(0,0,0,0.04)",
            }}
            title={kpiCollapsed ? "Mở rộng thẻ chỉ số" : "Thu gọn thẻ chỉ số"}
          >
            {kpiCollapsed ? <ChevronDown size={12} /> : <ChevronUp size={12} />}
          </button>
        </div>

        {/* Click outside backdrop for toolbar dropdowns */}
        {activeToolbarMenu && (
          <div
            style={{ position: "fixed", inset: 0, zIndex: 18 }}
            onClick={() => setActiveToolbarMenu(null)}
          />
        )}

        {/* Action Toolbar (Exact layout from user screenshot) */}
        <div
          className="misa-toolbar"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "8px 14px",
            background: "#ffffff",
            borderBottom: "1px solid #e2e8f0",
            position: "relative",
            zIndex: 19,
            gap: 8,
          }}
        >
          {/* Left Controls: Search, Loại phiếu, Period, Utility Icons */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            {/* Search Box */}
            <div style={{ position: "relative", width: 200 }}>
              <Search
                size={14}
                style={{
                  position: "absolute",
                  left: 9,
                  top: "50%",
                  transform: "translateY(-50%)",
                  color: "#8b5cf6",
                }}
              />
              <input
                type="text"
                placeholder="Tìm kiếm"
                value={searchQuery}
                onInput={e=>setSearchQuery(e.currentTarget.value)}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  width: "100%",
                  height: 32,
                  paddingLeft: 28,
                  paddingRight: 8,
                  borderRadius: 6,
                  border: "1px solid #d1d5db",
                  fontSize: 13,
                  outline: "none",
                  background: "#ffffff",
                }}
              />
            </div>

            {/* Loại chứng từ dropdown */}
            <MisaDropdownSelect
              value={filterType}
              onChange={(val) => setFilterType(val)}
              title="LOẠI PHIẾU"
              options={[
                { value: "all", label: "Loại phiếu: Tất cả" },
                { value: "receipt", label: "Loại phiếu: Thu tiền" },
                { value: "payment", label: "Loại phiếu: Chi tiền (UNC)" },
                { value: "transfer", label: "Loại phiếu: Chuyển tiền nội bộ" },
              ]}
              ariaLabel="Lọc theo loại phiếu"
            />

            {/* Period select: Đầu năm tới hiện tại */}
            <MisaDropdownSelect
              value={filterPeriod}
              onChange={(val) => setFilterPeriod(val)}
              title="KỲ THỜI GIAN"
              options={[
                { value: "ytd", label: "Kỳ: Đầu năm tới hiện tại" },
                { value: "month", label: "Kỳ: Tháng này" },
                { value: "quarter", label: "Kỳ: Quý này" },
                { value: "year", label: "Kỳ: Năm nay" },
                { value: "custom", label: "Kỳ: Tùy chọn" },
                ...CASH_PERIODS.filter(
                  (period) =>
                    ![
                      "Đầu năm đến hiện tại",
                      "Tháng này",
                      "Quý này",
                      "Năm nay",
                      "Tùy chọn",
                    ].includes(period)
                ).map((period) => ({ value: period, label: `Kỳ: ${period}` })),
              ]}
              ariaLabel="Kỳ thu chi tiền gửi"
            />

            {/* Icon buttons group */}
            <button
              type="button"
              className="misa-tax-icon-btn"
              title="Gợi ý & Kiểm tra nhanh"
              onClick={() => setShowAIModal(true)}
              style={{
                width: 32,
                height: 32,
                border: "1px solid #d1d5db",
                borderRadius: 6,
                background: "#ffffff",
                display: "grid",
                placeItems: "center",
                color: "#8b5cf6",
                cursor: "pointer",
              }}
            >
              <Sparkles size={15} />
            </button>

            <button
              type="button"
              className="misa-tax-icon-btn"
              title="Làm mới dữ liệu"
              onClick={reloadBankApi}
              style={{
                width: 32,
                height: 32,
                border: "1px solid #d1d5db",
                borderRadius: 6,
                background: "#ffffff",
                display: "grid",
                placeItems: "center",
                color: "#64748b",
                cursor: "pointer",
              }}
            >
              <RefreshCw size={15} />
            </button>

            <button
              type="button"
              className="misa-tax-icon-btn"
              title="Tùy chọn điều chuyển / sắp xếp"
              onClick={() => notify("Tùy chọn hiển thị chứng từ.")}
              style={{
                width: 32,
                height: 32,
                border: "1px solid #d1d5db",
                borderRadius: 6,
                background: "#ffffff",
                display: "grid",
                placeItems: "center",
                color: "#64748b",
                cursor: "pointer",
              }}
            >
              <SlidersHorizontal size={15} />
            </button>

            <button
              type="button"
              className="misa-tax-icon-btn"
              title="Xuất khẩu / Nhập khẩu"
              onClick={async()=>{const XLSX=await import("xlsx");const workbook=XLSX.utils.book_new();XLSX.utils.book_append_sheet(workbook,XLSX.utils.aoa_to_sheet([["Ngày hạch toán","Ngày chứng từ","Số chứng từ","Diễn giải","Số tiền","Đối tượng","Số tài khoản NH","Lý do thu/chi","Loại chứng từ"],...filteredTransactions.map(transaction=>[transaction.dateHachToan,transaction.dateChungTu,transaction.code,transaction.description,transaction.amount,transaction.partner,transaction.bankAccount||"",transaction.reasonLabel||"",transaction.documentType||""])]),"Tien-gui");XLSX.writeFileXLSX(workbook,"Thu-chi-tien-gui.xlsx");}}
              style={{
                width: 32,
                height: 32,
                border: "1px solid #d1d5db",
                borderRadius: 6,
                background: "#ffffff",
                display: "grid",
                placeItems: "center",
                color: "#64748b",
                cursor: "pointer",
              }}
            >
              <FileSpreadsheet size={15} />
            </button>

            <div style={{ position: "relative" }}>
              <button
                type="button"
                onClick={() => setBankExcelMenuOpen((prev) => !prev)}
                style={{
                  height: 32,
                  padding: "0 10px",
                  border: "1px solid #d1d5db",
                  borderRadius: 6,
                  background: bankExcelMenuOpen ? "#f0fdf4" : "#ffffff",
                  borderColor: bankExcelMenuOpen ? "var(--brand)" : "#d1d5db",
                  color: bankExcelMenuOpen ? "var(--brand)" : "#334155",
                  fontSize: 12.5,
                  fontWeight: 500,
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  cursor: "pointer",
                }}
              >
                <span>Nhập/Xuất Excel</span>
                <ChevronDown size={13} style={{ transform: bankExcelMenuOpen ? "rotate(180deg)" : "none", transition: "transform 0.15s" }} />
              </button>
              {bankExcelMenuOpen && (
                <>
                  <div
                    style={{ position: "fixed", inset: 0, zIndex: 45 }}
                    onClick={() => setBankExcelMenuOpen(false)}
                  />
                  <div className="misa-row-action-menu" style={{ minWidth: 195, zIndex: 50 }}>
                    <button
                      type="button"
                      className="misa-row-action-item"
                      onClick={async () => {
                        setBankExcelMenuOpen(false);
                        const XLSX = await import("xlsx");
                        const workbook = XLSX.utils.book_new();
                        XLSX.utils.book_append_sheet(
                          workbook,
                          XLSX.utils.aoa_to_sheet([
                            ["Ngày hạch toán", "Ngày chứng từ", "Số chứng từ", "Diễn giải", "Số tiền", "Đối tượng", "Số tài khoản NH", "Lý do thu/chi", "Loại chứng từ"],
                            ...filteredTransactions.map((transaction) => [
                              transaction.dateHachToan,
                              transaction.dateChungTu,
                              transaction.code,
                              transaction.description,
                              transaction.amount,
                              transaction.partner,
                              transaction.bankAccount || "",
                              transaction.reasonLabel || "",
                              transaction.documentType || "",
                            ]),
                          ]),
                          "Tien-gui"
                        );
                        XLSX.writeFileXLSX(workbook, "Thu-chi-tien-gui.xlsx");
                      }}
                    >
                      Xuất ra file Excel (.xlsx)
                    </button>
                    <div className="misa-row-action-divider" />
                    <button
                      type="button"
                      className="misa-row-action-item"
                      onClick={() => {
                        setBankExcelMenuOpen(false);
                        setBankImportKind("receipt");
                      }}
                    >
                      Nhập thu tiền gửi từ Excel
                    </button>
                    <button
                      type="button"
                      className="misa-row-action-item"
                      onClick={() => {
                        setBankExcelMenuOpen(false);
                        setBankImportKind("payment");
                      }}
                    >
                      Nhập chi tiền gửi từ Excel
                    </button>
                  </div>
                </>
              )}
            </div>

            <button
              type="button"
              className="misa-tax-icon-btn"
              title="Tùy chọn cột và thiết lập"
              onClick={() => setBankColumnsOpen(true)}
              style={{
                width: 32,
                height: 32,
                border: "1px solid #d1d5db",
                borderRadius: 6,
                background: "#ffffff",
                display: "grid",
                placeItems: "center",
                color: "#64748b",
                cursor: "pointer",
              }}
            >
              <Settings size={15} />
            </button>

            <button
              type="button"
              className="misa-filter-btn"
              title="Bộ lọc nâng cao"
              onClick={() => setBankFilterOpen(true)}
              style={{
                width: 32,
                height: 32,
                border: "1px solid #d1d5db",
                borderRadius: 6,
                background: "#ffffff",
                display: "grid",
                placeItems: "center",
                color: "#64748b",
                cursor: "pointer",
              }}
            >
              <Filter size={15} />
            </button>
          </div>

          {/* Right Buttons: Nhập nhanh, Thu tiền, Chi tiền */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0 }}>
            {/* Nhập nhanh Button */}
            <button
              type="button"
              onClick={() => setShowAIModal(true)}
              style={{
                height: 32,
                padding: "0 12px",
                background: "linear-gradient(135deg, #6366f1 0%, #a855f7 100%)",
                color: "#ffffff",
                border: "none",
                borderRadius: 6,
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                fontSize: 13,
                fontWeight: 600,
                cursor: "pointer",
                boxShadow: "0 1px 3px rgba(99, 102, 241, 0.25)",
              }}
            >
              <div
                style={{
                  width: 20,
                  height: 20,
                  borderRadius: "50%",
                  background: "rgba(255,255,255,0.25)",
                  display: "grid",
                  placeItems: "center",
                }}
              >
                <Sparkles size={12} />
              </div>
              <span className="misa-hidden-ai-marker" />
            </button>

            {/* Thêm thu tiền Dropdown Button (Matching Screenshot 3) */}
            <div style={{ position: "relative" }}>
              <button
                type="button"
                onClick={() =>
                  setActiveToolbarMenu((prev) => (prev === "receipt" ? null : "receipt"))
                }
                style={{
                  height: 32,
                  padding: "0 14px",
                  background: "var(--brand)",
                  color: "#ffffff",
                  border: "none",
                  borderRadius: 6,
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  fontSize: 13,
                  fontWeight: 600,
                  cursor: "pointer",
                  boxShadow: "0 1px 3px rgba(0, 176, 107, 0.3)",
                }}
              >
                <span>Thêm thu tiền</span>
                <ChevronDown size={14} />
              </button>

              {activeToolbarMenu === "receipt" && (
                <div
                  style={{
                    position: "absolute",
                    top: "calc(100% + 4px)",
                    right: 0,
                    minWidth: 220,
                    background: "#ffffff",
                    borderRadius: 8,
                    boxShadow: "0 10px 25px rgba(0, 0, 0, 0.12)",
                    border: "1px solid #e2e8f0",
                    padding: "6px 0",
                    zIndex: 50,
                    display: "flex",
                    flexDirection: "column",
                  }}
                >
                  <div
                    style={{ position: "relative" }}
                    onMouseEnter={() => setShowBankReceiptSubmenu(true)}
                    onMouseLeave={() => setShowBankReceiptSubmenu(false)}
                  >
                    <button
                      type="button"
                      style={{
                        textAlign: "left",
                        padding: "10px 18px",
                        border: "none",
                        background: showBankReceiptSubmenu ? "#f1f5f9" : "transparent",
                        fontSize: 13.5,
                        color: "#1e293b",
                        cursor: "pointer",
                        width: "100%",
                        fontFamily: "inherit",
                        whiteSpace: "nowrap",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                      onClick={() => {
                        setActiveToolbarMenu(null);
                        setShowBankReceiptSubmenu(false);
                        setCreateVoucherTypeIndex(0);
                        setShowCreateVoucher("receipt");
                      }}
                    >
                      <span>Thu tiền</span>
                      <ChevronRight size={14} style={{ color: "#94a3b8" }} />
                    </button>

                    {showBankReceiptSubmenu && (
                      <div
                        style={{
                          position: "absolute",
                          top: 0,
                          right: "100%",
                          minWidth: 260,
                          background: "#ffffff",
                          borderRadius: 8,
                          boxShadow: "0 10px 25px rgba(0, 0, 0, 0.15)",
                          border: "1px solid #e2e8f0",
                          padding: "6px 0",
                          zIndex: 60,
                        }}
                      >
                        {MISA_BANK_RECEIPT_TYPES.map((t, idx) => (
                          <button
                            key={t.id}
                            type="button"
                            style={{
                              textAlign: "left",
                              padding: "8px 16px",
                              border: "none",
                              background: "transparent",
                              fontSize: 13,
                              color: "#1e293b",
                              cursor: "pointer",
                              width: "100%",
                              fontFamily: "inherit",
                              whiteSpace: "nowrap",
                              display: "block",
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.background = "#dbece2";
                              e.currentTarget.style.color = "#047857";
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.background = "transparent";
                              e.currentTarget.style.color = "#1e293b";
                            }}
                            onClick={() => {
                              setActiveToolbarMenu(null);
                              setShowBankReceiptSubmenu(false);
                              setCreateVoucherTypeIndex(idx);
                              setShowCreateVoucher("receipt");
                            }}
                          >
                            {t.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setShowCustomerModal(true);
                    }}
                  >
                    Thu tiền theo hóa đơn
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setShowMultiCustomerModal(true);
                    }}
                  >
                    Thu tiền theo nhiều hóa đơn
                  </button>
                </div>
              )}
              {activeToolbarMenu && (
                <div
                  style={{ position: "fixed", inset: 0, zIndex: 40 }}
                  onClick={() => setActiveToolbarMenu(null)}
                />
              )}
            </div>

            {/* Thêm chi tiền Dropdown Button (Matching Screenshot 4) */}
            <div style={{ position: "relative" }}>
              <button
                type="button"
                onClick={() =>
                  setActiveToolbarMenu((prev) => (prev === "payment" ? null : "payment"))
                }
                style={{
                  height: 32,
                  padding: "0 14px",
                  background: "var(--brand)",
                  color: "#ffffff",
                  border: "none",
                  borderRadius: 6,
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  fontSize: 13,
                  fontWeight: 600,
                  cursor: "pointer",
                  boxShadow: "0 1px 3px rgba(0, 176, 107, 0.3)",
                }}
              >
                <span>Thêm chi tiền</span>
                <ChevronDown size={14} />
              </button>

              {activeToolbarMenu === "payment" && (
                <div
                  style={{
                    position: "absolute",
                    top: "calc(100% + 4px)",
                    right: 0,
                    minWidth: 220,
                    background: "#ffffff",
                    borderRadius: 8,
                    boxShadow: "0 10px 25px rgba(0, 0, 0, 0.12)",
                    border: "1px solid #e2e8f0",
                    padding: "6px 0",
                    zIndex: 50,
                    display: "flex",
                    flexDirection: "column",
                  }}
                >
                  <div
                    style={{ position: "relative" }}
                    onMouseEnter={() => setShowBankPaymentSubmenu(true)}
                    onMouseLeave={() => setShowBankPaymentSubmenu(false)}
                  >
                    <button
                      type="button"
                      style={{
                        textAlign: "left",
                        padding: "10px 18px",
                        border: "none",
                        background: showBankPaymentSubmenu ? "#f1f5f9" : "transparent",
                        fontSize: 13.5,
                        color: "#1e293b",
                        cursor: "pointer",
                        width: "100%",
                        fontFamily: "inherit",
                        whiteSpace: "nowrap",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                      onClick={() => {
                        setActiveToolbarMenu(null);
                        setShowBankPaymentSubmenu(false);
                        setCreateVoucherTypeIndex(0);
                        setShowCreateVoucher("payment");
                      }}
                    >
                      <span>Chi tiền</span>
                      <ChevronRight size={14} style={{ color: "#64748b" }} />
                    </button>

                    {showBankPaymentSubmenu && (
                      <div
                        style={{
                          position: "absolute",
                          top: 0,
                          right: "100%",
                          marginRight: 4,
                          minWidth: 320,
                          background: "#ffffff",
                          borderRadius: 8,
                          boxShadow: "0 10px 25px rgba(0, 0, 0, 0.15)",
                          border: "1px solid #e2e8f0",
                          padding: "6px 0",
                          zIndex: 60,
                        }}
                      >
                        {MISA_BANK_PAYMENT_TYPES.map((t, idx) => (
                          <button
                            key={t.id}
                            type="button"
                            style={{
                              textAlign: "left",
                              padding: "8px 16px",
                              border: "none",
                              background: "transparent",
                              fontSize: 13,
                              color: "#1e293b",
                              cursor: "pointer",
                              width: "100%",
                              fontFamily: "inherit",
                              whiteSpace: "nowrap",
                              display: "block",
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.background = "#dbece2";
                              e.currentTarget.style.color = "#047857";
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.background = "transparent";
                              e.currentTarget.style.color = "#1e293b";
                            }}
                            onClick={() => {
                              setActiveToolbarMenu(null);
                              setShowBankPaymentSubmenu(false);
                              setCreateVoucherTypeIndex(idx);
                              setShowCreateVoucher("payment");
                            }}
                          >
                            {t.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <button type="button" onClick={() => { setActiveToolbarMenu(null); setShowTransferModal(true); }}
                    style={{ textAlign: "left", padding: "10px 18px", border: "none", background: "transparent", fontSize: 13.5, color: "#1e293b", cursor: "pointer", width: "100%", fontFamily: "inherit" }}>
                    Chuyển tiền nội bộ
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setCreateVoucherTypeIndex(MISA_BANK_PAYMENT_TYPES.findIndex(type => type.id === "supplier_invoice"));
                      setShowCreateVoucher("payment");
                    }}
                  >
                    Trả tiền theo hóa đơn
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setShowTaxModal(true);
                    }}
                  >
                    Nộp thuế
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setShowInsuranceModal(true);
                    }}
                  >
                    Nộp bảo hiểm
                  </button>
                  <button
                    type="button"
                    style={{
                      textAlign: "left",
                      padding: "10px 18px",
                      border: "none",
                      background: "transparent",
                      fontSize: 13.5,
                      color: "#1e293b",
                      cursor: "pointer",
                      width: "100%",
                      fontFamily: "inherit",
                      whiteSpace: "nowrap",
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "#f1f5f9")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    onClick={() => {
                      setActiveToolbarMenu(null);
                      setShowSalaryModal(true);
                    }}
                  >
                    Trả lương
                  </button>
                </div>
              )}
              {activeToolbarMenu && (
                <div
                  style={{ position: "fixed", inset: 0, zIndex: 40 }}
                  onClick={() => setActiveToolbarMenu(null)}
                />
              )}
            </div>
          </div>
        </div>

        {/* Master Table (Image 4 & 5) */}
        <div style={{ flex: 1, minHeight: 220, overflow: "auto", background: "#ffffff", borderBottom: "1px solid #e5e7eb" }}>
          {checkedBankRows.length>0&&<div className="ce-toolbar" role="toolbar" aria-label="Thao tác chứng từ tiền gửi đã chọn"><strong>Đã chọn {checkedBankRows.length}</strong><button onClick={()=>setBankPosting('posted')}>Ghi sổ</button><button onClick={()=>setBankPosting('draft')}>Bỏ ghi sổ</button><button disabled title="Not supported by backend">Xóa</button><button onClick={()=>setBankCheckedIds([])}>Bỏ chọn</button></div>}
          {bankDeletedRows.length>0&&<div className="ce-toolbar" role="status">Đã xóa {bankDeletedRows.length} chứng từ trên frontend.<button onClick={()=>{setTransactions(previous=>[...bankDeletedRows.filter(row=>!previous.some(existing=>existing.id===row.id)),...previous]);setBankDeletedRows([]);}}>Hoàn tác</button></div>}
          {bankDeletePending&&<div className="ce-overlay"><section className="ce-panel" role="alertdialog" aria-modal="true" aria-label="Xóa chứng từ tiền gửi"><header><h2>Xóa chứng từ tiền gửi</h2></header><div className="ce-panel-body">Xóa {checkedBankRows.length} chứng từ đã chọn khỏi danh sách frontend?</div><footer><button onClick={()=>setBankDeletePending(false)}>Hủy</button><button className="ce-primary" onClick={()=>{const ids=new Set(checkedBankRows.map(row=>row.id));setBankDeletedRows(checkedBankRows);setTransactions(previous=>previous.filter(row=>!ids.has(row.id)));setBankCheckedIds(previous=>previous.filter(id=>!ids.has(id)));setBankDeletePending(false);}}>Xóa chứng từ</button></footer></section></div>}
          <table className="misa-table" style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
            <thead>
              <tr style={{ background: "#e6f4ea", borderBottom: "1px solid #cbd5e1" }}>
                <th style={{ width: 36, textAlign: "center", padding: "8px 4px" }}>
                  <input type="checkbox" aria-label="Chọn tất cả chứng từ trang hiện tại" checked={bankVisibleRows.length>0&&bankVisibleRows.every(row=>bankCheckedIds.includes(row.id))} onChange={event=>{const ids=bankVisibleRows.map(row=>row.id);setBankCheckedIds(previous=>event.target.checked?[...new Set([...previous,...ids])]:previous.filter(id=>!ids.includes(id)));}} style={{ accentColor: "var(--brand)" }} />
                </th>
                {bankColumns.filter(column=>column.visible).map(column=><th key={column.id} style={{width:column.width,minWidth:column.width,textAlign:column.id===6?'right':'left',padding:'8px 10px'}}>{column.name}</th>)}
              </tr>
            </thead>
            <tbody>
              {bankVisibleRows.map((tx) => {
                const isSelected = tx.id === selectedRowId;
                return (
                  <tr
                    key={tx.id}
                    onClick={() => setSelectedRowId(tx.id)}
                    style={{
                      borderBottom: "1px solid #f1f5f9",
                      background: isSelected ? "rgba(0, 176, 107, 0.08)" : "#ffffff",
                      cursor: "pointer",
                    }}
                  >
                    <td style={{ textAlign: "center", padding: "8px 4px" }}>
                      <input type="checkbox" aria-label={`Chọn chứng từ ${tx.code}`} checked={bankCheckedIds.includes(tx.id)} onClick={event=>event.stopPropagation()} onChange={()=>toggleBankChecked(tx.id)} />
                    </td>
                    {bankColumns.filter(column=>column.visible).map(column=>{const cells:ReactElement<any>[]=[<td style={{ padding: "8px 10px", color: "#374151" }}>{tx.dateHachToan}</td>,
                    <td style={{ padding: "8px 10px", color: "#374151" }}>{tx.dateChungTu}</td>,
                    <td style={{ padding: "8px 10px" }}>
                      <span
                        style={{ color: "var(--brand)", fontWeight: 600, cursor: "pointer" }}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (tx.kind === "transfer") { viewBankTransfer(String(tx.id).slice(9)); return; }
                          setSelectedRowId(tx.id);
                          setViewingBankVoucher(tx);
                        }}
                      >
                        {tx.code}
                      </span>
                    </td>,
                    <td style={{ padding: "8px 10px", color: "#1f2937" }}>{tx.description}</td>,
                    <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 600 }}>
                      {formatVND(tx.amount)}
                    </td>,
                    <td style={{ padding: "8px 10px", color: "#374151" }}>{tx.partner}</td>,
                    <td style={{padding:"8px 10px"}}>{tx.bankAccount||""}</td>,<td style={{padding:"8px 10px"}}>{tx.reasonLabel||""}</td>,<td style={{padding:"8px 10px"}}>{tx.documentType||(tx.kind==="receipt"?"Thu tiền gửi":tx.kind==="transfer"?"Chuyển tiền nội bộ":"Ủy nhiệm chi")}</td>,
                    <td style={{ padding: "8px 10px", textAlign: "center", position: "relative" }} onClick={(e) => e.stopPropagation()}>
                      <div className="misa-row-action-cell">
                        {tx.kind !== "transfer" && (
                          <button
                            type="button"
                            className="misa-row-action-link print"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedVoucher({
                                code: tx.code,
                                date: parseReportDate(tx.dateChungTu),
                                person: tx.partner,
                                address: "Hà Nội",
                                reason: tx.description,
                                debitAccount: tx.rows?.[0]?.debit || tx.debit || (tx.kind === "receipt" ? "1121" : "6427"),
                                creditAccount: tx.rows?.[0]?.credit || tx.credit || (tx.kind === "receipt" ? "131" : "1121"),
                                amount: tx.amount,
                                amountInWords: convertNumberToVietnameseWords(tx.amount),
                                notes: "Chứng từ ngân hàng",
                                chiefAccountant: "Trương Thị B",
                                director: "Nguyễn Văn A",
                              });
                              setShowVoucherModal(true);
                            }}
                          >
                            In
                          </button>
                        )}
                        <button
                          type="button"
                          className="misa-row-action-link view"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (tx.kind === "transfer") { viewBankTransfer(String(tx.id).slice(9)); return; }
                            setSelectedRowId(tx.id);
                            setViewingBankVoucher(tx);
                          }}
                        >
                          Xem
                        </button>
                        <button
                          type="button"
                          aria-label={`Chức năng chứng từ ${tx.code}`}
                          aria-expanded={bankRowMenu === tx.id}
                          className={`misa-row-action-trigger ${bankRowMenu === tx.id ? "active" : ""}`}
                          onClick={(event) => {
                            event.stopPropagation();
                            setBankRowMenu((previous) => (previous === tx.id ? null : tx.id));
                          }}
                          title="Thêm thao tác"
                        >
                          <ChevronDown size={13} style={{ transform: bankRowMenu === tx.id ? "rotate(180deg)" : "none", transition: "transform 0.15s" }} />
                        </button>
                        {bankRowMenu === tx.id && (
                          <>
                            <div
                              style={{ position: "fixed", inset: 0, zIndex: 70 }}
                              onClick={() => setBankRowMenu(null)}
                            />
                            <div className="misa-row-action-menu" role="menu" aria-label={`Chức năng ${tx.code}`}>
                              {tx.kind === "transfer" ? (
                                <>
                                  {tx.status === "draft" && (
                                    <button
                                      type="button"
                                      role="menuitem"
                                      className="misa-row-action-item"
                                      onClick={(event) => {
                                        event.stopPropagation();
                                        editBankTransfer(String(tx.id).slice(9));
                                      }}
                                    >
                                      Sửa
                                    </button>
                                  )}
                                  {tx.status === "draft" && (
                                    <button
                                      type="button"
                                      role="menuitem"
                                      className="misa-row-action-item"
                                      onClick={(event) => {
                                        event.stopPropagation();
                                        void setBankPosting("posted", [tx]);
                                        setBankRowMenu(null);
                                      }}
                                    >
                                      Ghi sổ
                                    </button>
                                  )}
                                  {tx.status === "draft" && (
                                    <button
                                      type="button"
                                      role="menuitem"
                                      className="misa-row-action-item danger"
                                      onClick={(event) => {
                                        event.stopPropagation();
                                        void cancelBankTransfer(String(tx.id).slice(9));
                                      }}
                                    >
                                      Hủy
                                    </button>
                                  )}
                                  {tx.status === "posted" && (
                                    <button
                                      type="button"
                                      role="menuitem"
                                      className="misa-row-action-item"
                                      onClick={(event) => {
                                        event.stopPropagation();
                                        void setBankPosting("draft", [tx]);
                                        setBankRowMenu(null);
                                      }}
                                    >
                                      Bỏ ghi sổ
                                    </button>
                                  )}
                                </>
                              ) : (
                                <>
                                  <button
                                    type="button"
                                    role="menuitem"
                                    className="misa-row-action-item"
                                    onClick={(event) => {
                                      event.stopPropagation();
                                      setBankRowMenu(null);
                                      setSelectedRowId(tx.id);
                                      setViewingBankVoucher(tx);
                                    }}
                                  >
                                    {tx.status === "posted" ? "Xem chứng từ" : "Sửa chứng từ"}
                                  </button>
                                  <button
                                    type="button"
                                    role="menuitem"
                                    className="misa-row-action-item"
                                    onClick={(event) => {
                                      event.stopPropagation();
                                      void setBankPosting(tx.status === "posted" ? "draft" : "posted", [tx]);
                                      setBankRowMenu(null);
                                    }}
                                  >
                                    {tx.status === "posted" ? "Bỏ ghi sổ" : "Ghi sổ"}
                                  </button>
                                  <div className="misa-row-action-divider" />
                                  <button
                                    type="button"
                                    role="menuitem"
                                    className="misa-row-action-item danger"
                                    onClick={(event) => {
                                      event.stopPropagation();
                                      setBankRowMenu(null);
                                      void deleteBankTransaction(tx);
                                    }}
                                  >
                                    Xóa
                                  </button>
                                </>
                              )}
                            </div>
                          </>
                        )}
                      </div>
                    </td>,<td>{tx.partnerCode||""}</td>,<td>{tx.beneficiaryAccount||""}</td>,<td>{tx.beneficiaryBank||""}</td>,<td>{tx.address||""}</td>,<td>{tx.employee||""}</td>,<td>{tx.bankName||""}</td>,<td>{tx.combinedInvoices||""}</td>,<td>{tx.settled||""}</td>,<td>{tx.extended1||""}</td>,<td>{tx.extended2||""}</td>,<td>{tx.extended3||""}</td>,<td>{tx.extended4||""}</td>,<td>{tx.extended5||""}</td>,<td>{tx.extended6||""}</td>,<td>{tx.extended7||""}</td>,<td>{tx.extended8||""}</td>,<td>{tx.extended9||""}</td>,<td>{tx.extended10||""}</td>,<td>{tx.createdBy||""}</td>,<td>{tx.createdAt||""}</td>,<td>{tx.updatedBy||""}</td>,<td>{tx.updatedAt||""}</td>];const cell=cells[column.id-2];return cloneElement(cell,{key:column.id,style:{...cell.props.style,width:column.width,minWidth:column.width}});})}
                  </tr>
                );
              })}
            {!filteredTransactions.length&&<tr><td colSpan={1+bankColumns.filter(column=>column.visible).length} style={{textAlign:'center',padding:24}}>Không có chứng từ phù hợp với điều kiện tìm kiếm</td></tr>}
            </tbody>
            <tfoot><tr style={{background:'#f8fafc',fontWeight:700}}><td/>{bankColumns.filter(column=>column.visible).map(column=><td key={column.id} style={{padding:10,textAlign:column.id===6?'right':'left'}}>{column.id===2?'Tổng':column.id===6?formatVND(filteredTransactions.reduce((sum,transaction)=>sum+transaction.amount,0)):''}</td>)}</tr></tfoot>
          </table>
        </div>

        {/* Master Table Pagination */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "8px 14px",
            background: "#ffffff",
            borderBottom: "1px solid #e5e7eb",
            fontSize: 12,
            color: "#6b7280",
          }}
        >
          <div>
            Tổng số: <strong>{filteredTransactions.length}</strong>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span>Số dòng/trang</span>
              <MisaDropdownSelect
                value={bankPageSize}
                onChange={(val) => {
                  setBankPageSize(Number(val));
                  setBankPage(1);
                }}
                options={[
                  { value: 20, label: "20" },
                  { value: 50, label: "50" },
                  { value: 100, label: "100" },
                ]}
                minWidth={90}
                buttonStyle={{ height: 26, padding: "0 8px", fontSize: 12 }}
                ariaLabel="Số dòng/trang"
              />
            </div>
            <div style={{ display: "flex", gap: 4 }}>
              <button aria-label="Trang đầu tiền gửi" disabled={bankVisiblePage===1} onClick={()=>setBankPage(1)}>|&lt;</button><button aria-label="Trang trước tiền gửi" disabled={bankVisiblePage===1} onClick={()=>setBankPage(bankVisiblePage-1)}>&lt;</button><span>{bankVisiblePage}/{bankPages}</span><button aria-label="Trang sau tiền gửi" disabled={bankVisiblePage===bankPages} onClick={()=>setBankPage(bankVisiblePage+1)}>&gt;</button><button aria-label="Trang cuối tiền gửi" disabled={bankVisiblePage===bankPages} onClick={()=>setBankPage(bankPages)}>&gt;|</button>
            </div>
          </div>
        </div>

        {/* Split Detail Pane (Image 4 & 5) */}
        {selectedTransaction && (
          <div style={{ height: detailExpanded ? 240 : 40, background: "#ffffff", display: "flex", flexDirection: "column", transition: "height 0.2s ease" }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "8px 14px",
                background: "#f8fafc",
                borderTop: "1px solid #e2e8f0",
                borderBottom: "1px solid #e2e8f0",
                cursor: "pointer",
              }}
              onClick={() => setDetailExpanded(!detailExpanded)}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <strong style={{ fontSize: 12, color: "#1e293b" }}>Chi tiết</strong>
                <ChevronDown
                  size={14}
                  style={{
                    transform: detailExpanded ? "rotate(0deg)" : "rotate(-90deg)",
                    transition: "transform 0.2s ease",
                  }}
                />
              </div>
              <span style={{ fontSize: 11, color: "#64748b" }}>
                {selectedTransaction.code} - {selectedTransaction.partner}
              </span>
            </div>

            {detailExpanded && (
              <div style={{ flex: 1, overflow: "auto" }}>
                <nav className="ce-toolbar" aria-label="Chi tiết chứng từ ngân hàng" style={{padding:'0 10px'}}><button onClick={()=>setBankDetailTab('accounting')}>Hạch toán</button><button onClick={()=>setBankDetailTab('services')}>Chi tiết dịch vụ và thuế</button></nav>{bankDetailTab==='accounting'?<BankAccountingDetail key={selectedTransaction.id} rows={selectedTransaction.rows?.length?selectedTransaction.rows:[{id:selectedTransaction.id,description:selectedTransaction.description,debit:selectedTransaction.debit||(selectedTransaction.kind==='receipt'?'1121':'6427'),credit:selectedTransaction.credit||(selectedTransaction.kind==='receipt'?'131':'1121'),amount:selectedTransaction.amount,partnerName:selectedTransaction.partner}]}/>:<table className="misa-table" style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                  <thead>
                    <tr style={{ background: "#e6f4ea", borderBottom: "1px solid #cbd5e1" }}>
                      <th style={{ width: 36, textAlign: "center", padding: "8px 4px" }}>#</th>
                      <th style={{ width: 100, textAlign: "left", padding: "8px 10px" }}>Mã hàng</th>
                      <th style={{ textAlign: "left", padding: "8px 10px" }}>Tên dịch vụ</th>
                      <th style={{ textAlign: "left", padding: "8px 10px" }}>Diễn giải thuế</th>
                      <th style={{ width: 85, textAlign: "right", padding: "8px 10px" }}>% thuế GTGT</th>
                      <th style={{ width: 110, textAlign: "right", padding: "8px 10px" }}>Tiền thuế GTGT</th>
                      <th style={{ width: 95, textAlign: "center", padding: "8px 10px" }}>TK thuế GTGT</th>
                      <th style={{ width: 95, textAlign: "left", padding: "8px 10px" }}>Số hóa đơn</th>
                      <th style={{ width: 95, textAlign: "left", padding: "8px 10px" }}>Ngày hóa đơn</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedTransaction.items.map((it, idx) => (
                      <tr key={idx} style={{ borderBottom: "1px solid #f1f5f9" }}>
                        <td style={{ textAlign: "center", padding: "8px 4px", color: "#6b7280" }}>{idx + 1}</td>
                        <td style={{ padding: "8px 10px", fontWeight: 600, color: "#1e293b" }}>{it.code}</td>
                        <td style={{ padding: "8px 10px", color: "#1f2937" }}>{it.name}</td>
                        <td style={{ padding: "8px 10px", color: "#4b5563" }}>{it.taxDesc}</td>
                        <td style={{ padding: "8px 10px", textAlign: "right" }}>{it.taxRate}%</td>
                        <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 600 }}>{formatVND(it.taxAmount)}</td>
                        <td style={{ padding: "8px 10px", textAlign: "center" }}>{it.taxAccount}</td>
                        <td style={{ padding: "8px 10px", color: "var(--brand)" }}>{it.invoiceCode}</td>
                        <td style={{ padding: "8px 10px", color: "#374151" }}>{it.invoiceDate}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colSpan={9}>Tổng số: {selectedTransaction.items.length} dòng</td>
                    </tr>
                  </tfoot>
                </table>}
              </div>
            )}
          </div>
        )}

        {/* MODALS */}
        {renderModals()}
      </div>
    );
  }

  // --------------------------------------------------------------------
  // RENDER TAB: "Quy trình" (Exact flowchart matching Image 2 & 3)
  // --------------------------------------------------------------------
  return (
    <div
      className="ref-process-wrapper"
      style={{
        background: "#f1f5f9",
        height: "100%",
        padding: "10px 16px",
        overflowY: "auto",
        overflowX: "hidden",
      }}
    >
      <div
        className="ref-process-layout"
        style={{
          maxWidth: 1080,
          display: "grid",
          gridTemplateColumns: "minmax(0, 2.3fr) minmax(250px, 1fr)",
          gap: 14,
          margin: "0 auto",
        }}
      >
        {/* Panel 1: NGHIỆP VỤ TIỀN GỬI (Flowchart canvas) */}
        <section
          className="ref-process-panel"
          style={{
            background: "#ffffff",
            borderRadius: 8,
            border: "1px solid #e2e8f0",
            boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
            overflow: "visible",
            position: "relative",
            zIndex: 20,
          }}
        >
          <h2
            style={{
              fontSize: 13,
              fontWeight: 700,
              textAlign: "center",
              margin: 0,
              padding: "14px 10px",
              borderBottom: "1px solid #f1f5f9",
              color: "#1e293b",
              letterSpacing: "0.5px",
            }}
          >
            NGHIỆP VỤ TIỀN GỬI
          </h2>

          <div
            className="ref-process-canvas sv-flow-nodes"
            style={{
              position: "relative",
              height: 310,
              margin: "0 10px",
              overflow: "visible",
            }}
          >
            {/* SVG Connecting Flow Lines with Arrows (Image 2 & 3) */}
            <svg
              className="ref-flow-lines sv-flow-connector"
              viewBox="0 0 650 300"
              preserveAspectRatio="none"
              aria-hidden="true"
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: 300,
                pointerEvents: "none",
                overflow: "visible",
              }}
            >
              <defs>
                <marker
                  id="ref-arrow-bank"
                  markerWidth="7"
                  markerHeight="7"
                  refX="6"
                  refY="3.5"
                  orient="auto"
                >
                  <polygon points="0 0, 7 3.5, 0 7" fill="#94a3b8" />
                </marker>
              </defs>

              {/* 1. Horizontal arrow from Đề nghị chi tiền (13% = 85) to Chi tiền (38% = 247) */}
              <path
                d="M 125 188 L 200 188"
                stroke="#cbd5e1"
                strokeWidth="1.5"
                fill="none"
                markerEnd="url(#ref-arrow-bank)"
              />

              {/* 2. Vertical T-junction line between Thu tiền and Chi tiền */}
              <path
                d="M 305 75 L 305 188"
                stroke="#cbd5e1"
                strokeWidth="1.5"
                fill="none"
              />
              <path
                d="M 290 75 L 305 75 M 290 188 L 305 188"
                stroke="#cbd5e1"
                strokeWidth="1.5"
                fill="none"
              />

              {/* 3. Horizontal branch from midpoint between Thu and Chi to Đối chiếu ngân hàng (63% = 410) */}
              <path
                d="M 305 136 L 365 136"
                stroke="#cbd5e1"
                strokeWidth="1.5"
                fill="none"
                markerEnd="url(#ref-arrow-bank)"
              />

              {/* 4. Horizontal arrow going right from Đối chiếu ngân hàng to Dự báo dòng tiền (87% = 566) */}
              <path
                d="M 455 136 L 520 136"
                stroke="#cbd5e1"
                strokeWidth="1.5"
                fill="none"
                markerEnd="url(#ref-arrow-bank)"
              />
            </svg>

            {/* Click outside backdrop for flowchart menus */}
            {activeFlowchartMenu && (
              <div
                style={{ position: "fixed", inset: 0, zIndex: 18 }}
                onClick={() => setActiveFlowchartMenu(null)}
              />
            )}

            {/* Node 1: Đề nghị chi tiền (Left, aligned with Chi tiền) */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "13%",
                transform: "translateX(-50%)",
                top: 145,
                width: 100,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 2,
              }}
              onClick={() => {
                navigate(href("/bank/payment-requests"));
              }}
              title="Đề nghị chi tiền"
            >
              <span className="ref-business-icon request" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>ĐN</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "#f59e0b", borderColor: "#fbbf24" }}
                >
                  <ArrowRight size={14} strokeWidth={2.5} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3 }}>
                Đề nghị chi tiền
              </span>
            </div>

            {/* Node 2: Thu tiền (Top Center) */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "38%",
                transform: "translateX(-50%)",
                top: 25,
                width: 100,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                zIndex: activeFlowchartMenu === "receipt" ? 60 : 10,
              }}
              onMouseEnter={() => handleFlowchartMouseEnter("receipt")}
              onMouseLeave={handleFlowchartMouseLeave}
            >
              <div
                style={{
                  cursor: "pointer",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
                onClick={() => setActiveFlowchartMenu("receipt")}
                title="Lập chứng từ thu tiền gửi"
              >
                {/* MISA Banknote Icon: THU */}
                <span className="ref-business-icon receive" style={{ marginBottom: 6 }}>
                  <span className="ref-document-sheet" style={{ background: "linear-gradient(90deg, #10b981, #059669)", border: "1px solid #34d399" }}>
                    <b style={{ color: "#ffffff", fontWeight: 800 }}>THU</b>
                    <i />
                    <i />
                    <i />
                  </span>
                  <span className="ref-gold-icon" style={{ background: "#f59e0b", borderColor: "#fbbf24" }}>
                    <Coins size={16} />
                  </span>
                </span>
                <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500 }}>
                  Thu tiền
                </span>
              </div>

              {/* Action Dropdown */}
              {activeFlowchartMenu === "receipt" && (
                <div
                  className="ref-action-options"
                  style={{
                    position: "absolute",
                    top: "calc(100% + 4px)",
                    left: "50%",
                    transform: "translateX(-50%)",
                    minWidth: 240,
                    zIndex: 100,
                    background: "#ffffff",
                    boxShadow: "0 12px 28px rgba(0,0,0,0.18), 0 3px 8px rgba(0,0,0,0.06)",
                    borderRadius: 6,
                    border: "1px solid #cbd5e1",
                    padding: "4px 0",
                  }}
                  onMouseEnter={() => handleFlowchartMouseEnter("receipt")}
                  onMouseLeave={handleFlowchartMouseLeave}
                >
                  <button
                    type="button"
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowCreateVoucher("receipt");
                    }}
                  >
                    Thu tiền
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowCustomerModal(true);
                    }}
                  >
                    Thu tiền theo hóa đơn
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowMultiCustomerModal(true);
                    }}
                  >
                    Thu tiền theo hóa đơn nhiều khách hàng
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowTransferModal(true);
                    }}
                  >
                    Chuyển tiền nội bộ
                  </button>
                </div>
              )}
            </div>

            {/* Node 3: Chi tiền (Bottom Center) */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "38%",
                transform: "translateX(-50%)",
                top: 145,
                width: 100,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                zIndex: activeFlowchartMenu === "payment" ? 60 : 10,
              }}
              onMouseEnter={() => handleFlowchartMouseEnter("payment")}
              onMouseLeave={handleFlowchartMouseLeave}
            >
              <div
                style={{
                  cursor: "pointer",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
                onClick={() => setActiveFlowchartMenu("payment")}
                title="Lập chứng từ chi tiền gửi (Ủy nhiệm chi)"
              >
                {/* MISA Banknote Icon: CHI */}
                <span className="ref-business-icon pay" style={{ marginBottom: 6 }}>
                  <span className="ref-document-sheet" style={{ background: "linear-gradient(90deg, #10b981, #059669)", border: "1px solid #34d399" }}>
                    <b style={{ color: "#ffffff", fontWeight: 800 }}>CHI</b>
                    <i />
                    <i />
                    <i />
                  </span>
                  <span className="ref-gold-icon" style={{ background: "#ea580c", borderColor: "#f97316" }}>
                    <Coins size={16} />
                  </span>
                </span>
                <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500 }}>
                  Chi tiền
                </span>
              </div>

              {/* Action Dropdown */}
              {activeFlowchartMenu === "payment" && (
                <div
                  className="ref-action-options"
                  style={{
                    position: "absolute",
                    top: "calc(100% + 4px)",
                    left: "50%",
                    transform: "translateX(-50%)",
                    minWidth: 240,
                    zIndex: 100,
                    background: "#ffffff",
                    boxShadow: "0 12px 28px rgba(0,0,0,0.18), 0 3px 8px rgba(0,0,0,0.06)",
                    borderRadius: 6,
                    border: "1px solid #cbd5e1",
                    padding: "4px 0",
                  }}
                  onMouseEnter={() => handleFlowchartMouseEnter("payment")}
                  onMouseLeave={handleFlowchartMouseLeave}
                >
                  <button
                    type="button"
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowCreateVoucher("payment");
                    }}
                  >
                    Chi tiền
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setCreateVoucherTypeIndex(MISA_BANK_PAYMENT_TYPES.findIndex(type => type.id === "supplier_invoice"));
                      setShowCreateVoucher("payment");
                    }}
                  >
                    Trả tiền theo hóa đơn
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowTaxModal(true);
                    }}
                  >
                    Nộp thuế
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowInsuranceModal(true);
                    }}
                  >
                    Nộp bảo hiểm
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowSalaryModal(true);
                    }}
                  >
                    Trả lương
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveFlowchartMenu(null);
                      setShowTransferModal(true);
                    }}
                  >
                    Chuyển tiền nội bộ
                  </button>
                </div>
              )}
            </div>

            {/* Node 4: Đối chiếu ngân hàng (Right, middle vertical) */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "63%",
                transform: "translateX(-50%)",
                top: 96,
                width: 100,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 2,
              }}
              onClick={() => {
                notify("Chuyển tới tính năng Đối chiếu ngân hàng...");
                navigate(href('/bank/reconciliation'));
              }}
              role="button"
              tabIndex={0}
              onKeyDown={event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();navigate(href('/bank/reconciliation'));}}}
              title="Đối chiếu ngân hàng"
            >
              <span className="ref-business-icon reconcile" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>ĐC</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "#f59e0b", borderColor: "#fbbf24" }}
                >
                  <FileCheck size={15} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3 }}>
                Đối chiếu ngân hàng
              </span>
            </div>

            {/* Node 5: Dự báo dòng tiền (Right, connected to arrow) */}
            <div className="sv-flow-node"
              style={{
                position: "absolute",
                left: "87%",
                transform: "translateX(-50%)",
                top: 96,
                width: 110,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                cursor: "pointer",
                textAlign: "center",
                zIndex: 2,
              }}
              onClick={() => {
                navigate(href("/bank/cashflow"));
              }}
              title="Dự báo dòng tiền"
            >
              <span className="ref-business-icon forecast" style={{ marginBottom: 6 }}>
                <span
                  className="ref-document-sheet"
                  style={{
                    background: "linear-gradient(90deg, #10b981, #059669)",
                    border: "1px solid #34d399",
                  }}
                >
                  <b style={{ color: "#ffffff", fontWeight: 800 }}>DB</b>
                  <i /><i /><i />
                </span>
                <span
                  className="ref-gold-icon"
                  style={{ background: "var(--brand)", borderColor: "#38bdf8" }}
                >
                  <Calculator size={14} strokeWidth={2.2} />
                </span>
              </span>
              <span style={{ fontSize: 11.5, color: "#334155", fontWeight: 500, lineHeight: 1.3 }}>
                Dự báo dòng tiền
              </span>
            </div>
          </div>
        </section>

        {/* Panel 2: BÁO CÁO (Right Column matching Image 2 & 3) */}
        <aside
          className="ref-process-reports"
          style={{
            background: "#ffffff",
            borderRadius: 8,
            border: "1px solid #e2e8f0",
            boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
          }}
        >
          <h2
            style={{
              fontSize: 13,
              fontWeight: 700,
              textAlign: "center",
              margin: 0,
              padding: "14px 10px",
              borderBottom: "1px solid #f1f5f9",
              color: "#1e293b",
              letterSpacing: "0.5px",
            }}
          >
            BÁO CÁO
          </h2>
          <ul
            style={{
              padding: "8px 16px",
              margin: 0,
              flex: 1,
              display: "flex",
              flexDirection: "column",
              listStyle: "none",
            }}
          >
            {[
              "Bảng kê chứng từ theo khế ước cho vay",
              "Bảng kê chứng từ theo khế ước vay",
              "Bảng kê số dư ngân hàng",
              "Bảng kê số dư tiền theo ngày",
              "Báo cáo tổng hợp tình hình khế ước cho vay",
            ].map((repName) => (
              <li
                key={repName}
                style={{
                  borderBottom: "1px solid #f1f5f9",
                  display: "flex",
                  alignItems: "center",
                  minHeight: 46,
                  fontSize: 12,
                  color: "#334155",
                  padding: "6px 0 6px 14px",
                  position: "relative",
                  cursor: "pointer",
                }}
                onClick={() => navigate(href("/bank/reports")+"&report="+encodeURIComponent(repName))}
              >
                <span
                  style={{
                    position: "absolute",
                    left: 0,
                    top: "50%",
                    transform: "translateY(-50%)",
                    width: 4,
                    height: 4,
                    borderRadius: "50%",
                    background: "#000000",
                  }}
                />
                <span style={{ transition: "color 0.15s ease" }} className="hover-link">
                  {repName}
                </span>
              </li>
            ))}
          </ul>
          <div
            style={{
              textAlign: "center",
              padding: "12px",
              borderTop: "1px solid #f1f5f9",
            }}
          >
            <span
              style={{
                color: "var(--brand)",
                fontSize: 12,
                fontWeight: 600,
                cursor: "pointer",
              }}
              onClick={() => navigate(href("/bank/reports"))}
            >
              Tất cả báo cáo
            </span>
          </div>
        </aside>

        {/* Panel 3: Master Data / Shortcuts (Middle row spanning 100%) */}
        <div
          className="ref-shortcuts"
          style={{
            gridColumn: "1 / -1",
            display: "grid",
            gridTemplateColumns: "repeat(6, 1fr)",
            background: "#ffffff",
            borderRadius: 8,
            border: "1px solid #e2e8f0",
            overflow: "hidden",
            boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
            position: "relative",
            zIndex: 1,
          }}
        >
          <button
            type="button"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              padding: "14px 8px",
              background: "#ffffff",
              border: "none",
              borderRight: "1px solid #f1f5f9",
              cursor: "pointer",
              fontSize: 12,
              color: "#334155",
            }}
            onClick={() => navigate(href("/directory") + "&directory=" + encodeURIComponent("Tài khoản ngân hàng"))}
          >
            <CreditCard size={20} style={{ color: "var(--brand)" }} />
            <span>Tài khoản ngân hàng</span>
          </button>

          <button
            type="button"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              padding: "14px 8px",
              background: "#ffffff",
              border: "none",
              borderRight: "1px solid #f1f5f9",
              cursor: "pointer",
              fontSize: 12,
              color: "#334155",
            }}
            onClick={() => navigate(href("/directory") + "&directory=" + encodeURIComponent("Khách hàng"))}
          >
            <UserRound size={20} style={{ color: "#f59e0b" }} />
            <span>Khách hàng</span>
          </button>

          <button
            type="button"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              padding: "14px 8px",
              background: "#ffffff",
              border: "none",
              borderRight: "1px solid #f1f5f9",
              cursor: "pointer",
              fontSize: 12,
              color: "#334155",
            }}
            onClick={() => navigate(href("/directory") + "&directory=" + encodeURIComponent("Nhà cung cấp"))}
          >
            <Building2 size={20} style={{ color: "var(--brand)" }} />
            <span>Nhà cung cấp</span>
          </button>

          <button
            type="button"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              padding: "14px 8px",
              background: "#ffffff",
              border: "none",
              borderRight: "1px solid #f1f5f9",
              cursor: "pointer",
              fontSize: 12,
              color: "#334155",
            }}
            onClick={() => navigate(href("/directory") + "&directory=" + encodeURIComponent("Nhân viên"))}
          >
            <Users size={20} style={{ color: "#10b981" }} />
            <span>Nhân viên</span>
          </button>

          <button
            type="button"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              padding: "14px 8px",
              background: "#ffffff",
              border: "none",
              borderRight: "1px solid #f1f5f9",
              cursor: "pointer",
              fontSize: 12,
              color: "#334155",
            }}
            onClick={() => navigate(href("/ledger/process"))}
          >
            <Calculator size={20} style={{ color: "var(--brand)" }} />
            <span>Tính tỷ giá xuất quỹ</span>
          </button>

          <button
            type="button"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              padding: "14px 8px",
              background: "#ffffff",
              border: "none",
              cursor: "pointer",
              fontSize: 12,
              color: "#334155",
            }}
            onClick={() => setBankOptionsOpen(true)}
          >
            <SlidersHorizontal size={20} style={{ color: "#f59e0b" }} />
            <span>Tùy chọn</span>
          </button>
        </div>
      </div>

      {renderModals()}
    </div>
  );
}
