import { createPortal } from "react-dom";
import { useEffect, useRef, useState } from "react";
import { Calendar } from "lucide-react";
import { cashDateValue, currentCashDate } from "./cash-date";

export default function VoucherDateField({
  value,
  onChange,
  label,
  className = "misa-voucher-input",
}: {
  value: string;
  onChange: (value: string) => void;
  label: string;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const [view, setView] = useState<"days" | "months" | "years">("days");
  const [position, setPosition] = useState({ left: 0, top: 0 });
  const initial = new Date(cashDateValue(value));
  const [month, setMonth] = useState(
    Number.isFinite(initial.getTime()) ? initial.getMonth() : new Date().getMonth(),
  );
  const [year, setYear] = useState(
    Number.isFinite(initial.getTime()) ? initial.getFullYear() : new Date().getFullYear(),
  );
  const root = useRef<HTMLDivElement>(null);
  const popup = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const close = (event: MouseEvent) => {
      if (
        !root.current?.contains(event.target as Node) &&
        !popup.current?.contains(event.target as Node)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, [open]);

  const show = () => {
    const date = new Date(cashDateValue(value));
    if (Number.isFinite(date.getTime())) {
      setMonth(date.getMonth());
      setYear(date.getFullYear());
    }
    const rect = root.current?.getBoundingClientRect();
    if (rect) {
      setPosition({
        left: Math.max(8, Math.min(rect.right - 300, window.innerWidth - 308)),
        top: Math.max(8, Math.min(rect.bottom + 3, window.innerHeight - 350)),
      });
    }
    setView("days");
    setOpen(!open);
  };

  const move = (direction: number) => {
    if (view === "years") {
      setYear(year + direction * 12);
      return;
    }
    if (view === "months") {
      setYear(year + direction);
      return;
    }
    const next = new Date(year, month + direction, 1);
    setYear(next.getFullYear());
    setMonth(next.getMonth());
  };

  const choose = (date: Date) => {
    onChange(currentCashDate(date));
    setOpen(false);
  };

  const days = new Date(year, month + 1, 0).getDate();
  const offset = (new Date(year, month, 1).getDay() + 6) % 7;
  const buttonStyle = {
    border: 0,
    background: "transparent",
    height: 32,
    cursor: "pointer",
    color: "#475569",
  };

  return (
    <div
      ref={root}
      style={{
        position: "relative",
        width: "100%",
        height: 32,
        minHeight: 32,
        display: "flex",
        alignItems: "center",
        zIndex: open ? 2000 : undefined,
      }}
      onKeyDown={(event) => {
        if (event.key === "Escape" && open) {
          event.stopPropagation();
          setOpen(false);
        }
      }}
    >
      <input
        className={className}
        aria-label={label}
        value={value}
        placeholder="DD/MM/YYYY"
        onChange={(event) => onChange(event.target.value)}
        style={{ width: "100%", height: "100%", paddingRight: 28, boxSizing: "border-box" }}
      />
      <button
        type="button"
        aria-label={`Chọn ngày ${label}`}
        aria-expanded={open}
        onClick={show}
        style={{
          position: "absolute",
          right: 4,
          top: "50%",
          transform: "translateY(-50%)",
          width: 24,
          height: 24,
          padding: 0,
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          border: 0,
          background: "transparent",
          cursor: "pointer",
          color: "#059669",
        }}
      >
        <Calendar size={15} />
      </button>
      {open &&
        createPortal(
          <div
            ref={popup}
            onKeyDown={(event) => {
              if (event.key === "Escape") {
                event.stopPropagation();
                setOpen(false);
              }
            }}
            role="dialog"
            aria-label={`Lịch ${label}`}
            style={{
              position: "fixed",
              ...position,
              zIndex: 14000,
              width: 300,
              maxHeight: "calc(100vh - 24px)",
              overflow: "auto",
              padding: 12,
              background: "white",
              border: "1px solid #d1d5db",
              borderRadius: 7,
              boxShadow: "0 4px 14px #0002",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <button
                type="button"
                aria-label="Kỳ trước trên lịch"
                style={buttonStyle}
                onClick={() => move(-1)}
              >
                ‹
              </button>
              <button
                type="button"
                style={{ ...buttonStyle, fontWeight: 600 }}
                onClick={() =>
                  setView(view === "days" ? "months" : view === "months" ? "years" : "days")
                }
              >
                {view === "years"
                  ? `${year - 5} – ${year + 6}`
                  : view === "months"
                    ? `Năm ${year}`
                    : `Tháng ${month + 1} Năm ${year}`}
              </button>
              <button
                type="button"
                aria-label="Kỳ sau trên lịch"
                style={buttonStyle}
                onClick={() => move(1)}
              >
                ›
              </button>
            </div>
            {view === "days" ? (
              <>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(7,1fr)",
                    textAlign: "center",
                    padding: "8px 0",
                    borderBottom: "1px solid #e5e7eb",
                    color: "#6b7280",
                  }}
                >
                  {["T2", "T3", "T4", "T5", "T6", "T7", "CN"].map((day) => (
                    <span key={day}>{day}</span>
                  ))}
                </div>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(7,1fr)",
                    gap: 4,
                    padding: "8px 0",
                  }}
                >
                  {Array.from({ length: offset }, (_, index) => (
                    <span key={`blank-${index}`} />
                  ))}
                  {Array.from({ length: days }, (_, index) => {
                    const date = new Date(year, month, index + 1);
                    const selected = currentCashDate(date) === value;
                    return (
                      <button
                        key={index}
                        type="button"
                        aria-label={`Chọn ${currentCashDate(date)}`}
                        style={{
                          ...buttonStyle,
                          borderRadius: "50%",
                          background: selected ? "#059669" : "transparent",
                          color: selected ? "white" : "#64748b",
                        }}
                        onClick={() => choose(date)}
                      >
                        {index + 1}
                      </button>
                    );
                  })}
                </div>
              </>
            ) : (
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(3,1fr)",
                  gap: 8,
                  padding: "12px 0",
                }}
              >
                {Array.from({ length: 12 }, (_, index) => (
                  <button
                    key={index}
                    type="button"
                    style={buttonStyle}
                    onClick={() => {
                      if (view === "years") {
                        setYear(year - 5 + index);
                        setView("months");
                      } else {
                        setMonth(index);
                        setView("days");
                      }
                    }}
                  >
                    {view === "years" ? year - 5 + index : `Tháng ${index + 1}`}
                  </button>
                ))}
              </div>
            )}
            <button
              type="button"
              style={{ ...buttonStyle, width: "100%", borderTop: "1px solid #e5e7eb", color: "#059669" }}
              onClick={() => choose(new Date())}
            >
              Hôm nay
            </button>
          </div>,
          document.body,
        )}
    </div>
  );
}
